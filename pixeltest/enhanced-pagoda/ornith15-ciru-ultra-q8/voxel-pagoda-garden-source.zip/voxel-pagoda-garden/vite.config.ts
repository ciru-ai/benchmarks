import { defineConfig } from 'vite';

// Local Vite dev server for the voxel pagoda garden.
// Serves the TypeScript entry and hot-reloads in the browser.
export default defineConfig({
  root: '.',
  server: {
    port: 5173,
    host: true,
  },
  build: {
    outDir: 'dist',
    sourcemap: true,
  },
});
