import * as THREE from 'three';
import { type KindSpec, kindSpecs } from './colors';
import { type Voxel, pseudoRandom, VoxelCollection } from './VoxelCollection';

/**
 * Turns a VoxelCollection into InstancedMesh batches — one InstancedMesh per
 * kind — sharing a cached material per kind so the whole scene draws with a
 * handful of draw calls.
 *
 * Each voxel gets a per-instance color derived from its kind's palette entry
 * with bounded HSL jitter, so a field of grass reads as thousands of subtle
 * greens. `colorFor` also supports `randomColors` kinds (flowers) that pick a
 * fresh hue per voxel.
 */

const specs = new Map<string, KindSpec>(kindSpecs.map((s) => [s.name, s]));
const materialCache = new Map<string, THREE.MeshStandardMaterial>();

export function kindExists(name: string): boolean {
  return specs.has(name);
}

export function kindNames(): readonly string[] {
  return Array.from(specs.keys());
}

const boxGeometry = new THREE.BoxGeometry(0.98, 0.98, 0.98);

function getMaterial(kind: string): THREE.MeshStandardMaterial {
  const cached = materialCache.get(kind);
  if (cached) return cached;

  const spec = specs.get(kind)!;
  const material = new THREE.MeshStandardMaterial({
    color: new THREE.Color(spec.base),
    roughness: spec.roughness ?? 0.8,
    metalness: spec.metalness ?? 0,
    emissive: spec.emissive ? new THREE.Color(spec.emissive) : new THREE.Color(0x000000),
    emissiveIntensity: spec.emissiveIntensity ?? 0,
    transparent: !!spec.transparent,
    opacity: spec.opacity ?? 1,
    depthWrite: !spec.transparent,
  });
  materialCache.set(kind, material);
  return material;
}

/** HSL jitter for a voxel instance derived from a stable per-index hash. */
function jitter(color: THREE.Color, spec: KindSpec, index: number): THREE.Color {
  const hsl: { h: number; s: number; l: number } = { h: 0, s: 0, l: 0 };
  color.getHSL(hsl);
  const r = pseudoRandom(index * 2654435761 >>> 0);
  const r2 = pseudoRandom(index * 40503 + 11);
  if (spec.hueVar) hsl.h = ((hsl.h + (r - 0.5) * spec.hueVar) % 1 + 1) % 1;
  if (spec.satVar) hsl.s = Math.min(0.98, Math.max(0.12, hsl.s + (r - 0.5) * spec.satVar));
  if (spec.lightVar) hsl.l = Math.min(0.86, Math.max(0.22, hsl.l + (r2 - 0.5) * spec.lightVar));
  return color.setHSL(hsl.h, hsl.s, hsl.l);
}

/** Flowers / torches pick a random palette color; other kinds jitter their base. */
function colorFor(spec: KindSpec, index: number): THREE.Color {
  if (spec.randomColors) {
    const n = Math.floor(pseudoRandom(index * 2654435761 >>> 0) * spec.randomColors.length);
    return jitter(new THREE.Color(spec.randomColors[n]), spec, index);
  }
  return jitter(new THREE.Color(spec.base), spec, index);
}

export interface RenderOptions {
  castShadow?: boolean;
  receiveShadow?: boolean;
  /** Extra world-space translation applied to the whole rendered group. */
  position?: THREE.Vector3Like;
}

/** Render a collection into a THREE.Group of InstancedMesh batches. */
export function render(collection: VoxelCollection, options: RenderOptions = {}): THREE.Group {
  const group = new THREE.Group();

  const byKind = new Map<string, Voxel[]>();
  collection.forEach((v) => {
    const list = byKind.get(v.kind);
    if (list) list.push(v);
    else byKind.set(v.kind, [v]);
  });

  const dummy = new THREE.Object3D();

  for (const [kind, voxels] of byKind) {
    const material = getMaterial(kind);
    const mesh = new THREE.InstancedMesh(boxGeometry, material, voxels.length);
    mesh.castShadow = options.castShadow ?? true;
    mesh.receiveShadow = options.receiveShadow ?? true;

    for (let n = 0; n < voxels.length; n++) {
      const v = voxels[n];
      const s = v.scale ?? 1;
      dummy.position.set(v.x, v.y, v.z);
      dummy.rotation.set(0, v.rotY ?? 0, 0);
      dummy.scale.set(s, s, s);
      dummy.updateMatrix();
      mesh.setMatrixAt(n, dummy.matrix);

      mesh.setColorAt(n, colorFor(specs.get(kind)!, n));
    }

    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    group.add(mesh);
  }

  if (options.position) group.position.set(options.position.x, options.position.y, options.position.z);
  group.updateMatrixWorld(true);
  return group;
}
