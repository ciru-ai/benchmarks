/**
 * Pure data: the voxel palette.
 *
 * Each kind describes ONE base material plus how its per-instance color may
 * vary, so a large field of "grass" still reads as thousands of slightly
 * different green cubes rather than a flat block. `randomColors` kinds (flowers)
 * pick a fresh hue per voxel.
 */

export interface KindSpec {
  /** Stable identifier used by every module when placing voxels. */
  name: string;
  /** Hex base color for the material. */
  base: string;
  roughness?: number;
  metalness?: number;
  emissive?: string;
  emissiveIntensity?: number;
  transparent?: boolean;
  opacity?: number;
  /** Fraction (0..1) of hue jitter around the base hue. */
  hueVar?: number;
  /** Fraction of saturation jitter. */
  satVar?: number;
  /** Fraction of lightness jitter (kept inside a sane band). */
  lightVar?: number;
  /** When set, each voxel is painted a random color from this list. */
  randomColors?: string[];
}

export const kindSpecs: KindSpec[] = [
  // --- Terrain -----------------------------------------------------------------
  { name: 'grass', base: '#5aa84a', hueVar: 0.06, satVar: 0.26, lightVar: 0.30, roughness: 1 },
  { name: 'grassDry', base: '#9db85a', lightVar: 0.22, roughness: 1 },
  { name: 'grassDark', base: '#3f8a38', lightVar: 0.24, roughness: 1 },
  { name: 'dirt', base: '#6b4a2f', lightVar: 0.24, roughness: 1 },
  { name: 'dirtDark', base: '#4f3621', lightVar: 0.22, roughness: 1 },
  { name: 'gravel', base: '#c9b98a', lightVar: 0.18, roughness: 1 },

  // --- Stone -------------------------------------------------------------------
  { name: 'stone', base: '#8f949b', hueVar: 0.02, lightVar: 0.30, roughness: 0.95 },
  { name: 'stoneDark', base: '#5f656b', lightVar: 0.26, roughness: 0.98 },
  { name: 'rock', base: '#6d7278', lightVar: 0.26, roughness: 1 },
  { name: 'snow', base: '#eef1f5', lightVar: 0.06, roughness: 0.9 },

  // --- Water -------------------------------------------------------------------
  {
    name: 'water',
    base: '#2f86c0',
    metalness: 0.55,
    roughness: 0.18,
    transparent: true,
    opacity: 0.82,
    emissive: '#0d3556',
    emissiveIntensity: 0.35,
    hueVar: 0.03,
    lightVar: 0.14,
  },
  {
    name: 'deepWater',
    base: '#1a5a86',
    metalness: 0.6,
    roughness: 0.2,
    transparent: true,
    opacity: 0.9,
    emissive: '#08283f',
    emissiveIntensity: 0.4,
    lightVar: 0.12,
  },

  // --- Wood --------------------------------------------------------------------
  { name: 'wood', base: '#7a4b2b', lightVar: 0.18, roughness: 0.82 },
  { name: 'woodDark', base: '#4f3320', lightVar: 0.18, roughness: 0.86 },
  { name: 'woodLight', base: '#a8703f', lightVar: 0.16, roughness: 0.8 },

  // --- Pagoda roofs / trim -----------------------------------------------------
  { name: 'roof', base: '#a52233', hueVar: 0.03, lightVar: 0.20, roughness: 0.55, metalness: 0.1 },
  { name: 'roofDark', base: '#5c1a22', lightVar: 0.18, roughness: 0.6 },
  { name: 'cream', base: '#efe3c8', lightVar: 0.12, roughness: 0.86 },
  {
    name: 'gold',
    base: '#e8b923',
    metalness: 0.85,
    roughness: 0.35,
    emissive: '#5a4408',
    emissiveIntensity: 0.35,
    hueVar: 0.03,
    lightVar: 0.16,
  },

  // --- Vegetation --------------------------------------------------------------
  { name: 'trunk', base: '#5b3a22', lightVar: 0.22, roughness: 0.92 },
  { name: 'leaf', base: '#4f9a3a', hueVar: 0.07, satVar: 0.28, lightVar: 0.30, roughness: 1 },
  { name: 'leafDark', base: '#2f6b28', lightVar: 0.26, roughness: 1 },
  { name: 'leafAutumn', base: '#cf5c2a', hueVar: 0.05, lightVar: 0.22, roughness: 1 },

  // --- Cherry blossom ----------------------------------------------------------
  { name: 'blossomPink', base: '#f7a8c4', hueVar: 0.04, satVar: 0.28, lightVar: 0.34, roughness: 0.9 },
  { name: 'blossomWhite', base: '#fbe9f0', lightVar: 0.22, roughness: 0.9 },
  { name: 'blossomDeep', base: '#ec7aa0', hueVar: 0.03, lightVar: 0.22, roughness: 0.9 },

  // --- Flowers (colorful) ------------------------------------------------------
  {
    name: 'flower',
    base: '#e63946',
    randomColors: ['#e63946', '#f4d03f', '#ff6fb5', '#a569bd', '#ffffff', '#f7a8c4', '#ff9f45', '#57c78a'],
    lightVar: 0.14,
    roughness: 0.85,
  },
  {
    name: 'flowerBright',
    base: '#f4d03f',
    randomColors: ['#f4d03f', '#e63946', '#c0392b', '#9b5de5', '#ff6fb5', '#ffffff'],
    lightVar: 0.14,
    roughness: 0.85,
  },

  // --- Pond life ---------------------------------------------------------------
  { name: 'lilyPad', base: '#3f8f4a', lightVar: 0.20, roughness: 0.7 },
  { name: 'lotusPink', base: '#ff8fb1', lightVar: 0.22, roughness: 0.7 },
  { name: 'lotusBud', base: '#f2c6dd', lightVar: 0.20, roughness: 0.75 },
  { name: 'lotusYellow', base: '#ffe066', lightVar: 0.16, roughness: 0.7 },

  // --- Lanterns / torches ------------------------------------------------------
  {
    name: 'lanternPaper',
    base: '#ffefc2',
    roughness: 0.6,
    emissive: '#ffcf6b',
    emissiveIntensity: 0.7,
    lightVar: 0.10,
  },
  {
    name: 'torchFlame',
    base: '#ff8a1e',
    metalness: 0,
    roughness: 1,
    emissive: '#ff5a00',
    emissiveIntensity: 1.2,
    hueVar: 0.04,
    lightVar: 0.22,
  },
];
