/**
 * A mutable bag of voxel placements.
 *
 * Modules accumulate voxels here (integer grid coordinates, one cube per
 * placement) and hand the collection to `VoxelLibrary.render`, which turns it
 * into InstancedMesh batches. Geometric fill helpers (`prism`, `wall`,
 * `ellipsoid`, `line`) keep the scene modules declarative.
 */

export interface Voxel {
  x: number;
  y: number;
  z: number;
  kind: string;
  /** Optional Y rotation (radians) for organic bits like flowers/torches. */
  rotY?: number;
  /** Per-voxel scale factor (default 1). */
  scale?: number;
}

export interface VoxelOptions {
  rotY?: number;
  scale?: number;
}

export class VoxelCollection {
  private items: Voxel[] = [];

  get size(): number {
    return this.items.length;
  }

  /** Place a single voxel with options. */
  place(x: number, y: number, z: number, kind: string, opts: VoxelOptions = {}): this {
    const v: Voxel = { x, y, z, kind };
    if (opts.rotY !== undefined) v.rotY = opts.rotY;
    if (opts.scale !== undefined) v.scale = opts.scale;
    this.items.push(v);
    return this;
  }
  /** Remove every voxel matching predicate. Returns this for chaining. */
  remove(predicate: (v: Voxel) => boolean): this {
    this.items = this.items.filter((v) => !predicate(v));
    return this;
  }
  /** Fill an axis-aligned box [x0..x0+dx, y.., z..] inclusive. */
  prism(
    x0: number,
    y0: number,
    z0: number,
    dx: number,
    dy: number,
    dz: number,
    kind: string,
    opts: VoxelOptions = {},
  ): this {
    for (let x = 0; x <= dx; x++)
      for (let y = 0; y <= dy; y++)
        for (let z = 0; z <= dz; z++) this.place(x0 + x, y0 + y, z0 + z, kind, opts);
    return this;
  }

  /**
   * Place a hollow shell (walls only) for a box, leaving the interior empty.
   * Useful for pagoda floors and towers so windows/interiors can be added.
   */
  wall(
    x0: number,
    y0: number,
    z0: number,
    dx: number,
    dy: number,
    dz: number,
    kind: string,
    opts: VoxelOptions = {},
  ): this {
    const border = 1;
    for (let x = 0; x <= dx; x++)
      for (let y = 0; y <= dy; y++)
        for (let z = 0; z <= dz; z++) {
          const onBorder =
            x <= border || x >= dx - border || z <= border || z >= dz - border || y === 0 || y === dy;
          if (onBorder) this.place(x0 + x, y0 + y, z0 + z, kind, opts);
        }
    return this;
  }

  /**
   * Fill an axis-aligned ellipsoid centered at (cx, cy, cz) with radii
   * (rx, ry, rz). `density` (0..1) randomly drops voxels for an organic look.
   */
  ellipsoid(
    cx: number,
    cy: number,
    cz: number,
    rx: number,
    ry: number,
    rz: number,
    kind: string,
    density = 1,
    opts: VoxelOptions = {},
  ): this {
    const minX = Math.floor(cx - rx);
    const maxX = Math.ceil(cx + rx);
    const minY = Math.floor(cy - ry);
    const maxY = Math.ceil(cy + ry);
    const minZ = Math.floor(cz - rz);
    const maxZ = Math.ceil(cz + rz);
    for (let x = minX; x <= maxX; x++)
      for (let y = minY; y <= maxY; y++)
        for (let z = minZ; z <= maxZ; z++) {
          const nx = (x - cx) / rx;
          const ny = (y - cy) / ry;
          const nz = (z - cz) / rz;
          const d = nx * nx + ny * ny + nz * nz;
          if (d <= 1 && (density >= 1 || pseudoRandom(x * 73 + y * 17 + z * 31) < density))
            this.place(x, y, z, kind, opts);
        }
    return this;
  }

  /** Place a vertical line (cylinder-ish) from y0 to y1 inclusive at (x, z). */
  line(x: number, z: number, y0: number, y1: number, kind: string, opts: VoxelOptions = {}): this {
    const lo = Math.min(y0, y1);
    const hi = Math.max(y0, y1);
    for (let y = lo; y <= hi; y++) this.place(x, y, z, kind, opts);
    return this;
  }

  get(i: number): Voxel {
    return this.items[i];
  }

  forEach(cb: (v: Voxel, i: number) => void): this {
    this.items.forEach(cb);
    return this;
  }

  clear(): this {
    this.items = [];
    return this;
  }
}

/** Deterministic hash -> [0,1) so voxel variation is stable across renders. */
export function pseudoRandom(seed: number): number {
  let x = (seed >>> 0) % 2147483647;
  if (x === 0) x = 1;
  x = (x * 16807) % 2147483647;
  return (x - 1) / 2147483646;
}
