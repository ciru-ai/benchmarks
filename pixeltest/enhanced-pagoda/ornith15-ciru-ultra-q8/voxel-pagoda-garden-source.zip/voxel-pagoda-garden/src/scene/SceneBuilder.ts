import * as THREE from 'three';
import { buildGround } from './Ground';
import { buildPagoda } from './Pagoda';
import { buildFeatures } from './Features';
import { buildTrees } from './Trees';

/** Composes the whole garden. Built up module-by-module and verified along the way. */
export function buildScene(): THREE.Group {
  const group = new THREE.Group();
  group.add(buildGround());
  group.add(buildPagoda());
  group.add(buildFeatures());
  group.add(buildTrees());
  return group;
}
