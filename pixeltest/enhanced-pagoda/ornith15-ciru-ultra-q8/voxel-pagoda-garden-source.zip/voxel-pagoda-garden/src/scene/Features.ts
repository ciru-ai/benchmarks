import * as THREE from 'three';
import { VoxelCollection } from '../voxel/VoxelCollection';
import { render } from '../voxel/VoxelLibrary';
import { POND, WATER_LEVEL, terrainHeight } from './Ground';

/**
 * Garden features: standing water with lotus and lily pads, an arched stone
 * bridge crossing the pond (aligned with the pagoda's south door), a curving
 * stepping-stone path, stone lanterns and scattered shore rocks. Water is
 * poured into the basin carved by the Ground module up to a fixed level, so
 * the surface is a flat plane.
 */

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

/** Terrain height, clamped so water/bridge footings have a sane floor. */
function floorHeight(x: number, z: number): number {
  return clamp(Math.floor(terrainHeight(x, z)), WATER_LEVEL - 4, WATER_LEVEL + 3);
}

// --- Water --------------------------------------------------------------------
/** Pour water into the basin and scatter lotus / lily pads across it. */
function buildWater(voxels: VoxelCollection): void {
  const r = POND.r;
  for (let x = POND.x - r; x <= POND.x + r; x++) {
    for (let z = POND.z - r; z <= POND.z + r; z++) {
      const d = Math.hypot(x - POND.x, z - POND.z);
      if (d > r) continue;
      const top = floorHeight(x, z);
      if (top >= WATER_LEVEL) continue; // shore / land: no water
      for (let y = top + 1; y <= WATER_LEVEL; y++) {
        voxels.place(x, y, z, y <= WATER_LEVEL - 2 ? 'deepWater' : 'water');
      }
      // Lily pads and lotus flowers float on the surface.
      if (top <= WATER_LEVEL - 1) {
        const n = (x * 73 + z * 17 + 5) % 9;
        if (n === 0) voxels.place(x, WATER_LEVEL + 1, z, 'lilyPad', { rotY: n % 4 });
        else if (n === 3 || n === 7) voxels.place(x, WATER_LEVEL + 2, z, 'lotusPink');
        else if (n === 5) voxels.place(x, WATER_LEVEL + 2, z, 'lotusYellow');
        else if (n === 1) voxels.place(x, WATER_LEVEL + 1, z, 'lotusBud');
      }
    }
  }
}

// --- Bridge -------------------------------------------------------------------
/**
 * Build an arched stone bridge centered at cx, spanning along z from cz0 to
 * cz1. The deck rises in a sine hump; stone posts with a low rail line the
 * east/west sides. Returns the collection (caller positions it).
 */
function buildBridge(voxels: VoxelCollection, cx: number, cz0: number, cz1: number): void {
  const arch = 2.4;
  const length = cz1 - cz0;
  const deckBase = WATER_LEVEL + 1;
  for (let i = 0; i <= length; i++) {
    const z = cz0 + i;
    const t = i / length;
    const deckY = deckBase + Math.round(Math.sin(Math.PI * t) * arch);

    voxels.place(cx, deckY, z, 'stone'); // center deck
    voxels.place(cx - 1, deckY, z, 'stoneDark'); // east walkway
    voxels.place(cx + 1, deckY, z, 'stoneDark'); // west walkway

    // Support pillars down into the basin.
    const pillarTop = deckY - 1;
    for (let y = floorHeight(cx, z) + 1; y < pillarTop; y++) voxels.place(cx, y, z, 'stoneDark');

    // Railing posts every three voxels.
    if (i % 3 === 0) {
      voxels.place(cx - 1, deckY + 1, z, 'stone');
      voxels.place(cx + 1, deckY + 1, z, 'stone');
    }
  }
}

// --- Stone path ---------------------------------------------------------------
/** Lay a gentle curving line of stepping stones from A to B. */
function buildPath(voxels: VoxelCollection, ax: number, az: number, bx: number, bz: number, curve = 0): void {
  const steps = 22;
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const x = ax + (bx - ax) * t + Math.sin(Math.PI * t) * curve;
    const z = az + (bz - az) * t;
    const gx = Math.round(x);
    const gz = Math.round(z);
    const gy = floorHeight(gx, gz);
    voxels.place(gx, gy + 1, gz, 'gravel');
    voxels.place(gx + 1, gy + 1, gz, 'gravel');
  }
}

// --- Stone lantern (touto) ----------------------------------------------------
/** A compact Japanese stone lantern grounded at (x, z). */
function buildLantern(voxels: VoxelCollection, x: number, z: number): void {
  const baseY = floorHeight(x, z);
  voxels.prism(x - 1, baseY, z - 1, 2, 0, 2, 'stoneDark'); // base slab
  voxels.line(x, z, baseY + 1, baseY + 2, 'stone'); // pillar
  voxels.prism(x - 1, baseY + 3, z - 1, 2, 0, 2, 'stone'); // fire box
  voxels.place(x, baseY + 4, z, 'lanternPaper'); // glowing chamber
  voxels.prism(x - 1, baseY + 5, z - 1, 2, 0, 2, 'stoneDark'); // roof
  voxels.place(x, baseY + 6, z, 'gold'); // finial
}

// --- Shore rocks --------------------------------------------------------------
function buildRocks(voxels: VoxelCollection, cx: number, cz: number, spread: number): void {
  for (let x = cx - spread; x <= cx + spread; x++) {
    for (let z = cz - spread; z <= cz + spread; z++) {
      const d = Math.hypot(x - cx, z - cz);
      if (d > spread) continue;
      if ((x * 31 + z * 17 + 3) % 5 === 0 && (x * 7 + z * 3) % 7 === 2) {
        const gy = floorHeight(x, z);
        voxels.place(x, gy + 1, z, 'rock');
        if ((x + z) % 4 === 0) voxels.place(x, gy + 2, z, 'rock');
      }
    }
  }
}

// --- Composition --------------------------------------------------------------
/** All water, bridge, path, lanterns and shore rocks. */
export function buildFeatures(): THREE.Group {
  const voxels = new VoxelCollection();

  buildWater(voxels);

  // Bridge crosses the pond on the pagoda's south-door axis (x = POND.x).
  buildBridge(voxels, POND.x, POND.z - 9, POND.z + 7);

  // Path from the pagoda's south door (z+) curving to the bridge's near end.
  buildPath(voxels, 2, 5, POND.x - 1, POND.z - 9 + 1, 2);

  // Lanterns flank the path near the pagoda and at the bridge's near end.
  buildLantern(voxels, 3, 8);
  buildLantern(voxels, -3, 9);
  buildLantern(voxels, POND.x - 2, POND.z - 9);
  buildLantern(voxels, POND.x + 2, POND.z - 9 + 1);

  // Rocks ring the near shore.
  buildRocks(voxels, POND.x - 5, POND.z - 8, 4);

  return render(voxels);
}
