import * as THREE from 'three';
import { VoxelCollection } from '../voxel/VoxelCollection';
import { render } from '../voxel/VoxelLibrary';

/**
 * A three-tier octagonal pagoda.
 *
 * Each tier = stone floor slab + octagonal cream walls + gold railing trim +
 * a flared roof whose eaves flare outward and whose four corners kick up. A
 * gold finial (sorin) crowns the top. Tiers shrink and rise as the tower goes
 * up. The roof is built as stacked hollow octagonal rings so it stays light.
 */

/** Is a cell within a light-octagon of "radius" r (square with clipped corners). */
function inOctagon(dx: number, dz: number, r: number): boolean {
  return Math.abs(dx) <= r && Math.abs(dz) <= r && Math.abs(dx) + Math.abs(dz) <= r + Math.floor(r * 0.85);
}

function placeDisc(voxels: VoxelCollection, cx: number, y: number, cz: number, r: number, kind: string): void {
  for (let dx = -r; dx <= r; dx++)
    for (let dz = -r; dz <= r; dz++) if (inOctagon(dx, dz, r)) voxels.place(cx + dx, y, cz + dz, kind);
}

/** Hollow octagonal shell: cells in ring(r) but not ring(r-1). */
function placeRing(voxels: VoxelCollection, cx: number, y: number, cz: number, r: number, kind: string): void {
  for (let dx = -r; dx <= r; dx++)
    for (let dz = -r; dz <= r; dz++)
      if (inOctagon(dx, dz, r) && !inOctagon(dx, dz, r - 1)) voxels.place(cx + dx, y, cz + dz, kind);
}

/** Hollow octagonal cylinder of a given height. */
function placeWalls(voxels: VoxelCollection, cx: number, y0: number, cz: number, r: number, h: number, kind: string): void {
  for (let y = 0; y < h; y++) placeRing(voxels, cx, y0 + y, cz, r, kind);
}

/**
 * Remove a small front-center block of a wall stack to make a doorway.
 * faceDir: +1 removes the stack at z = cz + faceDir.
 */
function carveDoor(voxels: VoxelCollection, cx: number, y0: number, cz: number, faceDir: 1 | -1, h: number): void {
  const zx = cz + faceDir;
  voxels.remove((v) => v.x === cx && v.z === zx && v.y >= y0 && v.y < y0 + h && Math.abs(v.x - cx) <= 1);
}

/** Flared octagonal roof from eave radius up to a small peak. Upturns the corner eaves. */
function buildRoof(voxels: VoxelCollection, cx: number, baseY: number, cz: number, rEave: number, peak: number, height: number): void {
  for (let k = 0; k < height; k++) {
    const t = k / (height - 1);
    const r = Math.round(rEave + (peak - rEave) * t);
    const y = baseY + k;
    placeRing(voxels, cx, y, cz, r, 'roof');

    // Kick the diagonal corners up by one to read as upturned eaves.
    if (k === 0) {
      for (const sx of [-1, 1])
        for (const sz of [-1, 1]) {
          const c = Math.floor(r * 0.82);
          if (inOctagon(sx * c, sz * c, r)) voxels.place(cx + sx * c, y + 1, cz + sz * c, 'roofDark');
        }
    }
  }
  // Ridge cap: a thin gold band at the roof top.
  placeDisc(voxels, cx, baseY + height - 1, cz, Math.max(1, peak), 'gold');
}

export function buildPagoda(): THREE.Group {
  const voxels = new VoxelCollection();
  const cx = 0;
  const cz = 0;

  // --- Stepped stone platform --------------------------------------------------
  placeDisc(voxels, cx, 0, cz, 13, 'stone');
  placeDisc(voxels, cx, 1, cz, 11, 'stoneDark');
  placeDisc(voxels, cx, 2, cz, 9, 'stone');

  // --- Tier radii/heights shrink toward the top --------------------------------
  const tiers = [
    { r: 8, wall: 4, roofR: 10, roofH: 5 },
    { r: 6, wall: 4, roofR: 8.5, roofH: 5 },
    { r: 4.2, wall: 4, roofR: 7, roofH: 5 },
  ];

  let top = 3; // top of the platform floor
  for (let i = 0; i < tiers.length; i++) {
    const t = tiers[i];
    const yFloor = top;
    placeDisc(voxels, cx, yFloor, cz, t.r, 'cream'); // floor slab
    const yWall = yFloor + 1;
    placeWalls(voxels, cx, yWall, cz, t.r, t.wall, 'cream');
    // A doorway into the lowest tier's south face.
    if (i === 0) carveDoor(voxels, cx, yWall, cz, 1, t.wall);
    placeRing(voxels, cx, yWall + t.wall, cz, t.r, 'gold'); // railing trim

    const yRoof = yWall + t.wall + 1;
    buildRoof(voxels, cx, yRoof, cz, t.roofR, 1, t.roofH);
    top = yRoof + t.roofH; // start next tier just above this roof
  }

  // --- Finial (sorin) ----------------------------------------------------------
  const finBase = top;
  placeDisc(voxels, cx, finBase, cz, 3, 'gold');
  placeDisc(voxels, cx, finBase + 1, cz, 2, 'gold');
  voxels.line(cx, cz, finBase + 2, finBase + 8, 'gold');
  placeDisc(voxels, cx, finBase + 8, cz, 1, 'gold');
  voxels.place(cx, finBase + 9, cz, 'gold');

  return render(voxels);
}
