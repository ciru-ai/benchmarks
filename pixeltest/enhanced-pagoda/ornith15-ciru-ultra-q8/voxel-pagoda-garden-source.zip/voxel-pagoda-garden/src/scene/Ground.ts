import * as THREE from 'three';
import { VoxelCollection } from '../voxel/VoxelCollection';
import { render } from '../voxel/VoxelLibrary';

/**
 * Base garden terrain.
 *
 * A value-noise heightfield drives the grass surface. A pond basin is carved
 * near (+16, -10) and the pagoda pad is flattened around the origin. Grass,
 * dirt, dirt-free patches, scattered flowers and small rock outcrops are all
 * laid out from the same heightfield so the surface reads as one coherent
 * field. The basin is left empty (no grass) so the Features module can pour
 * water into it at a fixed level.
 */

export const TERRAIN_SIZE = 54; // half-extent in voxels on each axis
export const WATER_LEVEL = 0; // voxel level the pond fills to

// --- Deterministic value noise -------------------------------------------------
function hash2(x: number, z: number): number {
  let h = x * 374761393 + z * 668265263;
  h = (h ^ (h >> 13)) * 1274126177;
  return ((h ^ (h >> 16)) >>> 0) / 4294967296;
}

function smoothNoise(x: number, z: number): number {
  const xi = Math.floor(x);
  const zi = Math.floor(z);
  const u = (x - xi) ** 2 * (3 - 2 * (x - xi));
  const v = (z - zi) ** 2 * (3 - 2 * (z - zi));
  const a = hash2(xi, zi);
  const b = hash2(xi + 1, zi);
  const c = hash2(xi, zi + 1);
  const d = hash2(xi + 1, zi + 1);
  const top = a + (b - a) * u;
  const bot = c + (d - c) * u;
  return top + (bot - top) * v;
}

function fbm(x: number, z: number, octaves = 3, persistence = 0.5): number {
  let amp = 1;
  let freq = 1;
  let sum = 0;
  let norm = 0;
  for (let i = 0; i < octaves; i++) {
    sum += amp * smoothNoise(x * freq, z * freq);
    norm += amp;
    amp *= persistence;
    freq *= 2;
  }
  return sum / norm;
}

// Pond + pagoda pad layout
export const POND = { x: 0, z: 24, r: 10 };
export const PAD = { x: 0, z: 0, r: 12 };

function clamp(v: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, v));
}

/** Height (in voxels) of the grass surface at world (x, z). */
export function terrainHeight(x: number, z: number): number {
  let h = fbm(x * 0.075, z * 0.075, 3) * 4.2 + fbm(x * 0.25, z * 0.25, 2) * 1.1;

  // Carve the pond basin.
  const dp = Math.hypot(x - POND.x, z - POND.z);
  if (dp < POND.r) {
    const t = 1 - dp / POND.r;
    h -= t * t * 5.0;
  }

  // Flatten the pagoda pad.
  const dPad = Math.hypot(x - PAD.x, z - PAD.z);
  if (dPad < PAD.r) {
    const t = clamp(1 - dPad / PAD.r, 0, 1);
    h = h * (1 - t) + 1.2 * t;
  }

  return Math.round(h);
}

export function buildGround(): THREE.Group {
  const voxels = new VoxelCollection();
  const half = TERRAIN_SIZE;

  for (let x = -half; x <= half; x++) {
    for (let z = -half; z <= half; z++) {
      const top = terrainHeight(x, z);

      const inPond = Math.hypot(x - POND.x, z - POND.z) < POND.r - 1;
      if (inPond) continue; // leave the basin empty for water

      // Dirt column from the base up to the surface.
      voxels.prism(x, 0, z, 0, top, 0, 'dirt');
      // Surface voxel: grass, or occasional dry/dark patches.
      const r = hash2(x * 7 + 3, z * 13 + 1);
      let surface = 'grass';
      if (r > 0.9) surface = 'grassDry';
      else if (r < 0.08) surface = 'grassDark';
      voxels.place(x, top, z, surface);

      // Scattered flowers on the grass.
      if (hash2(x * 31 + 5, z * 17 + 9) > 0.985) {
        const f = hash2(x * 5, z * 11) > 0.5 ? 'flower' : 'flowerBright';
        voxels.place(x, top + 1, z, f, { rotY: hash2(x, z) * Math.PI * 2 });
      }

      // Rock outcrops on steeper-looking cells near the ridge.
      if (top >= 3 && hash2(x * 41, z * 59) > 0.97) {
        voxels.place(x, top + 1, z, 'rock');
      }
    }
  }

  return render(voxels);
}
