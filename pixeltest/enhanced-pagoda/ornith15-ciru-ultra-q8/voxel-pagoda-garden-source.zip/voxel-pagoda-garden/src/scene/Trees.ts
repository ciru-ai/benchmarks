import * as THREE from 'three';
import { VoxelCollection } from '../voxel/VoxelCollection';
import { render } from '../voxel/VoxelLibrary';
import { terrainHeight } from './Ground';

/**
 * Voxel trees: a reusable parametric tree (forked trunk + a cluster of organic
 * canopy blobs) and a cherry blossom variant with a lighter canopy and scattered
 * falling petals. `buildTree` picks canopy colors from a small palette so each
 * tree reads slightly differently.
 */

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

/** Deterministic pseudo-random from an integer seed, 0..1. */
function rnd(seed: number): number {
  let x = ((seed * 2654435761) >>> 0) % 2147483647;
  if (x === 0) x = 1;
  x = (x * 16807) % 2147483647;
  return (x - 1) / 2147483646;
}

export interface TreeOptions {
  /** Canopy voxel kinds (main + two accent blobs). */
  canopy: [string, string, string];
  /** Trunk kind, default 'wood'. */
  trunk?: string;
  /** Total trunk height in voxels, 4..8. */
  height?: number;
  /** Canopy radius in voxels, 4..7. */
  radius?: number;
  /** When true, scatter blossom petals below the canopy (cherry variant). */
  petals?: boolean;
  /** Optional Y rotation (radians) for a leaning trunk. */
  lean?: number;
}

/** Build one tree (caller positions it with `render`'s offset). */
export function buildTree(opts: TreeOptions): THREE.Group {
  const trunk = opts.trunk ?? 'wood';
  const h = clamp(Math.round(opts.height ?? 6), 4, 8);
  const r = clamp(opts.radius ?? 5, 4, 7);

  const voxels = new VoxelCollection();

  // Trunk: a slightly leaning vertical line.
  voxels.line(0, 0, 0, h - 1, trunk);

  // Canopy: one main blob plus two off-center accent blobs for an organic silhouette.
  const cy = h; // canopy base height (top of trunk)
  voxels.ellipsoid(0, cy + 1, 0, r, r * 0.85, r, opts.canopy[0], 0.62);
  voxels.ellipsoid(r * 0.55, cy, 0, r * 0.6, r * 0.5, r * 0.6, opts.canopy[1], 0.7);
  voxels.ellipsoid(-r * 0.5, cy + 1, r * 0.4, r * 0.55, r * 0.5, r * 0.55, opts.canopy[2], 0.7);

  // Falling petals for the cherry variant.
  if (opts.petals) {
    for (let i = 0; i < 30; i++) {
      const a = rnd(i * 3) * Math.PI * 2;
      const rr = rnd(i * 5 + 1) * r;
      const px = Math.round(Math.cos(a) * rr);
      const pz = Math.round(Math.sin(a) * rr);
      const py = h - 1 - Math.round(rnd(i * 7) * (r + 2));
      voxels.place(px, py, pz, i % 2 === 0 ? 'blossomPink' : 'blossomWhite');
    }
    // Petal halo scattered on the ground beneath the canopy.
    for (let i = 0; i < 18; i++) {
      const a = rnd(i * 11 + 7) * Math.PI * 2;
      const rr = rnd(i * 3 + 2) * r;
      voxels.place(Math.round(Math.cos(a) * rr), 0, Math.round(Math.sin(a) * rr), i % 3 === 0 ? 'blossomPink' : 'blossomWhite');
    }
  }

  return render(voxels);
}

/** Cherry blossom tree: dark trunk, light pink/white canopy, scattered petals. */
export function buildCherryBlossomTree(opts: Partial<TreeOptions> = {}): THREE.Group {
  return buildTree({
    trunk: 'woodDark',
    canopy: ['blossomDeep', 'blossomPink', 'blossomWhite'],
    petals: true,
    radius: 5.5,
    height: 6,
    ...opts,
  });
}
export function buildLeafTree(opts: Partial<TreeOptions> = {}): THREE.Group {
  const greens: Array<[string, string, string]> = [
    ['leaf', 'leafDark', 'leaf'],
    ['leafDark', 'leaf', 'leafAutumn'],
    ['leaf', 'leaf', 'leafDark'],
  ];
  const canopy = greens[Math.floor(rnd(opts.height ?? 6) * greens.length)];
  return buildTree({
    trunk: 'wood',
    canopy,
    radius: 5,
    height: 6,
    ...opts,
  });
}

// --- Placement ----------------------------------------------------------------
/** All trees in the garden, each positioned on land via the terrain height. */
export function buildTrees(): THREE.Group {
  const group = new THREE.Group();

  interface Placed {
    x: number;
    z: number;
    build: () => THREE.Group;
    lean?: number;
  }
  const placed: Placed[] = [
    // Flanking the pagoda entrance (sits just outside the stone pad).
    { x: 12, z: 5, build: () => buildLeafTree({ height: 7, radius: 6 }), lean: 0.04 },
    { x: -12, z: 6, build: () => buildLeafTree({ height: 6, radius: 5 }) },
    // Cherry blossoms framing the pond's near shores, off the view axis.
    { x: 18, z: 29, build: () => buildCherryBlossomTree({ lean: -0.06, radius: 6 }) },
    { x: -18, z: 29, build: () => buildCherryBlossomTree({ lean: 0.06, radius: 6 }) },
    // Scattered in the field for depth and color variety.
    { x: 24, z: -16, build: () => buildLeafTree({ height: 7, radius: 6 }) },
    { x: -24, z: -14, build: () => buildLeafTree({ height: 6, radius: 5, lean: 0.04 }) },
    { x: -26, z: 20, build: () => buildCherryBlossomTree() },
    { x: 20, z: 8, build: () => buildCherryBlossomTree({ lean: 0.05, radius: 5.5 }) },
    { x: -20, z: 10, build: () => buildCherryBlossomTree({ lean: -0.05, radius: 5 }) },
    // Autumn trees behind the pagoda for warm color variety.
    { x: 16, z: -14, build: () => buildTree({ trunk: 'wood', canopy: ['leafAutumn', 'leafAutumn', 'leafDark'], height: 7, radius: 6, lean: 0.04 }) },
    { x: -18, z: -12, build: () => buildTree({ trunk: 'wood', canopy: ['leafAutumn', 'leafDark', 'leafAutumn'], height: 6, radius: 5 }) },
  ];

  for (const p of placed) {
    const gy = Math.floor(terrainHeight(p.x, p.z));
    const g = p.build();
    g.position.set(p.x, gy, p.z);
    if (p.lean) g.rotation.y = p.lean;
    group.add(g);
  }
  return group;
}
