import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { buildScene } from './scene/SceneBuilder';

const app = document.getElementById('app')!;
const statusEl = document.getElementById('status')!;
const fpsEl = document.getElementById('fps')!;

// --- Renderer -----------------------------------------------------------------
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
renderer.outputColorSpace = THREE.SRGBColorSpace;
app.appendChild(renderer.domElement);

// --- Scene & camera -----------------------------------------------------------
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x8fc7ea);
scene.fog = new THREE.Fog(0x9ecbe8, 60, 280);

const camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 500);
camera.position.set(56, 50, 60);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.08;
controls.target.set(0, 12, 6);
controls.minDistance = 12;
controls.maxDistance = 160;
controls.maxPolarAngle = Math.PI / 2.05;

// --- Lights -------------------------------------------------------------------
const hemi = new THREE.HemisphereLight(0xcfe8ff, 0x4a6b3a, 0.75);
scene.add(hemi);

const sun = new THREE.DirectionalLight(0xfff2d6, 2.1);
sun.position.set(48, 66, 34);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
sun.shadow.camera.near = 1;
sun.shadow.camera.far = 200;
sun.shadow.camera.left = -64;
sun.shadow.camera.right = 64;
sun.shadow.camera.top = 64;
sun.shadow.camera.bottom = -64;
sun.shadow.bias = -0.0004;
sun.shadow.normalBias = 0.02;
scene.add(sun);

const fill = new THREE.DirectionalLight(0x9fb8ff, 0.35);
fill.position.set(-40, 30, -30);
scene.add(fill);

// --- Scene content ------------------------------------------------------------
const root = new THREE.Group();
scene.add(root);
root.add(buildScene());
statusEl.textContent = 'scene ready';

// --- Resize -------------------------------------------------------------------
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

// --- Loop ---------------------------------------------------------------------
let last = performance.now();
let frames = 0;
let fpsAccum = 0;
function animate() {
  requestAnimationFrame(animate);
  controls.update();
  renderer.render(scene, camera);

  const now = performance.now();
  const dt = now - last;
  last = now;
  frames++;
  fpsAccum += dt;
  if (fpsAccum >= 500) {
    fpsEl.textContent = `${Math.round((frames * 1000) / fpsAccum)} fps`;
    frames = 0;
    fpsAccum = 0;
  }
}
animate();
