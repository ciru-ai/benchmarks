import { FALLS, POOL } from './core/layout';
import { T, LOOP } from './core/schedule';
import { clamp, lerp, smoothstep } from './core/palette';

/**
 * The director: one pure function from loop-seconds to every look value — sky, fog, grade, the
 * sun, the water's ripples and foam, the veil, the lantern wave, the dragon's climb, the
 * draw-back, bloom. Nothing animates anywhere else, so the film and the interactive tour are the
 * same piece of timing.
 *
 * The colour arc is a dawn: the valley opens moonlit and nearly monochrome, pigment spreads from
 * the strike along the water as the lake fills, the sun clears the Dragon Ridge at `dawn`, and the
 * draw-back pulls both the water and the colour back up into the pearl.
 */

interface SkyKey {
  t: number;
  top: number;
  horizon: number;
  bottom: number;
  stars: number;
  haze: number;
}

/** Moonlit indigo → the strike's bloom → pre-dawn teal → sunrise peach and gold → back to indigo. */
const SKY: SkyKey[] = [
  { t: 0.0, top: 0x03060f, horizon: 0x0c1830, bottom: 0x050a14, stars: 1.0, haze: 0.16 },
  { t: 3.4, top: 0x0a1226, horizon: 0x27465f, bottom: 0x0b1524, stars: 0.82, haze: 0.3 },
  { t: 4.3, top: 0x14424e, horizon: 0x74b7a4, bottom: 0x1a3346, stars: 0.46, haze: 0.62 },
  { t: 7.4, top: 0x123146, horizon: 0x4a7f8c, bottom: 0x14283a, stars: 0.4, haze: 0.52 },
  { t: 12.0, top: 0x1b4a63, horizon: 0x7aa7ae, bottom: 0x203a4e, stars: 0.22, haze: 0.55 },
  { t: 19.0, top: 0x26618c, horizon: 0xb0909e, bottom: 0x2b4a60, stars: 0.1, haze: 0.6 },
  { t: 26.0, top: 0x1d5c8c, horizon: 0xc98a63, bottom: 0x28455a, stars: 0.0, haze: 0.62 },
  { t: 33.0, top: 0x26739f, horizon: 0xe79f6d, bottom: 0x2f5872, stars: 0.0, haze: 0.54 },
  { t: 38.2, top: 0x2e87bd, horizon: 0xf0b98a, bottom: 0x37647f, stars: 0.0, haze: 0.48 },
  { t: 40.6, top: 0x2f6f9e, horizon: 0xffb27a, bottom: 0x33566f, stars: 0.06, haze: 0.52 },
  { t: 42.2, top: 0x10233c, horizon: 0x4c6079, bottom: 0x14263a, stars: 0.5, haze: 0.36 },
  { t: 44.0, top: 0x03060f, horizon: 0x0c1830, bottom: 0x050a14, stars: 1.0, haze: 0.16 },
];

interface NumKey {
  t: number;
  v: number;
}

function keysAt(keys: NumKey[], t: number): number {
  if (t <= keys[0].t) return keys[0].v;
  for (let i = 1; i < keys.length; i++) {
    const a = keys[i - 1];
    const b = keys[i];
    if (t <= b.t) {
      const k = (t - a.t) / Math.max(0.0001, b.t - a.t);
      return lerp(a.v, b.v, k * k * (3 - 2 * k));
    }
  }
  return keys[keys.length - 1].v;
}

function channel(hex: number, shift: number): number {
  return (hex >> shift) & 255;
}

function skyAt(t: number): { top: number; horizon: number; bottom: number; stars: number; haze: number } {
  let i = SKY.length - 2;
  for (let k = 1; k < SKY.length; k++) {
    if (t <= SKY[k].t) {
      i = k - 1;
      break;
    }
  }
  const a = SKY[i];
  const b = SKY[Math.min(SKY.length - 1, i + 1)];
  const k = clamp((t - a.t) / Math.max(0.0001, b.t - a.t), 0, 1);
  const e = k * k * (3 - 2 * k);
  const mix = (x: number, y: number) =>
    (Math.round(lerp(channel(x, 16), channel(y, 16), e)) << 16) |
    (Math.round(lerp(channel(x, 8), channel(y, 8), e)) << 8) |
    Math.round(lerp(channel(x, 0), channel(y, 0), e));
  return {
    top: mix(a.top, b.top),
    horizon: mix(a.horizon, b.horizon),
    bottom: mix(a.bottom, b.bottom),
    stars: lerp(a.stars, b.stars, e),
    haze: lerp(a.haze, b.haze, e),
  };
}

/** Exposure rides how much sky and water are in frame: the wide valley reads brightest. */
const EXPOSURE: NumKey[] = [
  { t: 0.0, v: 0.74 },
  { t: 3.4, v: 0.82 },
  { t: 4.3, v: 0.92 },
  { t: 7.4, v: 0.84 },
  { t: 12.0, v: 0.8 },
  { t: 19.0, v: 0.82 },
  { t: 26.0, v: 0.84 },
  { t: 33.0, v: 0.86 },
  { t: 38.2, v: 0.88 },
  { t: 41.0, v: 0.8 },
  { t: 42.6, v: 0.84 },
  { t: 44.0, v: 0.74 },
];

/** 1 = moonlit monochrome, 0 = full pigment. The pigment rides out from the strike on the water. */
const GRADE: NumKey[] = [
  { t: 0.0, v: 1.0 },
  { t: 3.4, v: 0.96 },
  { t: 4.4, v: 0.78 },
  { t: 7.0, v: 0.6 },
  { t: 11.0, v: 0.4 },
  { t: 16.0, v: 0.22 },
  { t: 22.0, v: 0.08 },
  { t: 27.0, v: 0.0 },
  { t: 40.4, v: 0.0 },
  { t: 41.8, v: 0.42 },
  { t: 43.0, v: 0.82 },
  { t: 44.0, v: 1.0 },
];

/** How far the pigment front has travelled from the strike point, in world units. */
const FRONT: NumKey[] = [
  { t: 0.0, v: 0 },
  { t: 3.6, v: 6 },
  { t: 6.2, v: 52 },
  { t: 11.0, v: 104 },
  { t: 17.0, v: 168 },
  { t: 24.0, v: 240 },
  { t: 44.0, v: 240 },
];

const FOG_NEAR: NumKey[] = [
  { t: 0.0, v: 240 },
  { t: 7.4, v: 210 },
  { t: 12.0, v: 150 },
  { t: 20.0, v: 95 },
  { t: 27.0, v: 62 },
  { t: 33.0, v: 90 },
  { t: 38.2, v: 150 },
  { t: 42.2, v: 210 },
  { t: 44.0, v: 240 },
];

const FOG_FAR: NumKey[] = [
  { t: 0.0, v: 1500 },
  { t: 7.4, v: 1250 },
  { t: 12.0, v: 980 },
  { t: 20.0, v: 720 },
  { t: 27.0, v: 520 },
  { t: 33.0, v: 640 },
  { t: 38.2, v: 900 },
  { t: 42.2, v: 1200 },
  { t: 44.0, v: 1500 },
];

/** The far range: always there, but kept a stop under the near country. */
const FAR_GAIN: NumKey[] = [
  { t: 0.0, v: 0.5 },
  { t: 7.4, v: 0.58 },
  { t: 19.0, v: 0.66 },
  { t: 33.0, v: 0.74 },
  { t: 38.2, v: 0.78 },
  { t: 42.2, v: 0.6 },
  { t: 44.0, v: 0.5 },
];

/** The sun clears the ridge late: a warm lift that grows through `dawn`. */
const SUN_GAIN: NumKey[] = [
  { t: 0.0, v: 0.0 },
  { t: 22.0, v: 0.0 },
  { t: 27.0, v: 0.14 },
  { t: 33.0, v: 0.36 },
  { t: 38.2, v: 0.5 },
  { t: 40.6, v: 0.5 },
  { t: 42.2, v: 0.14 },
  { t: 44.0, v: 0.0 },
];

/** Sun elevation, 0 = on the ridge line, 1 = the baked lighting's own key direction. */
const SUN_LIFT: NumKey[] = [
  { t: 0.0, v: 0.34 },
  { t: 22.0, v: 0.3 },
  { t: 33.0, v: 0.58 },
  { t: 38.2, v: 0.86 },
  { t: 44.0, v: 0.34 },
];

const BLOOM: NumKey[] = [
  { t: 0.0, v: 0.3 },
  { t: 3.4, v: 0.42 },
  { t: 4.3, v: 1.05 },
  { t: 6.0, v: 0.62 },
  { t: 12.0, v: 0.46 },
  { t: 20.0, v: 0.5 },
  { t: 27.0, v: 0.56 },
  { t: 33.0, v: 0.78 },
  { t: 36.4, v: 0.62 },
  { t: 39.0, v: 0.62 },
  { t: 42.2, v: 0.4 },
  { t: 44.0, v: 0.3 },
];

/** Wind: the groves breathe through the middle of the loop. */
const SWAY: NumKey[] = [
  { t: 0.0, v: 0.0 },
  { t: 19.0, v: 0.0 },
  { t: 22.0, v: 0.16 },
  { t: 30.0, v: 0.3 },
  { t: 38.2, v: 0.4 },
  { t: 41.0, v: 0.22 },
  { t: 43.4, v: 0.0 },
  { t: 44.0, v: 0.0 },
];

export interface Look {
  sky: { top: number; horizon: number; bottom: number; stars: number; haze: number };
  /** 1 = moonlit monochrome, 0 = full pigment */
  ink: number;
  colorFront: number;
  /** 0..1 of the draw-back */
  dissolve: number;
  swirl: number;
  sway: number;
  /** how alive the water is */
  water: number;
  glowGain: number;
  exposure: number;
  bloom: number;
  /** multiplier on the far range's exposure */
  farGain: number;
  /** the pearl: 0 before it is lit, 1 at the strike point */
  pearl: number;
  pearlGlow: number;
  /** how far the veil is pouring, 0..1 */
  pour: number;
  foam: number;
  mist: number;
  petals: number;
  skyLanterns: number;
  /** the koi school's surface activity, 0..1 */
  shoal: number;
  /** the golden koi's climb up the veil, 0..1 */
  leap: number;
  /** the dragon's climb around the padoga, 0..1 */
  dragon: number;
  /** radius of the lantern-ignition wave travelling out of the padoga, in world units */
  lanternWave: number;
  /** the water's ripple ring: centre, radius, strength */
  rippleAt: readonly [number, number];
  rippleR: number;
  rippleGain: number;
  fogHex: number;
  fogNear: number;
  fogFar: number;
  /** the sun: unit-ish direction, colour, gain */
  sun: readonly [number, number, number];
  sunHex: number;
  sunGain: number;
}

const FOG_HEX: NumKey[] = [
  { t: 0.0, v: 0x0a1120 },
  { t: 4.3, v: 0x274a52 },
  { t: 12.0, v: 0x243a4c },
  { t: 26.0, v: 0x36485a },
  { t: 33.0, v: 0x4c6274 },
  { t: 38.2, v: 0x647c90 },
  { t: 42.2, v: 0x2b3a4c },
  { t: 44.0, v: 0x0a1120 },
];

const SUN_HEX: NumKey[] = [
  { t: 0.0, v: 0xff9f5c },
  { t: 26.0, v: 0xffb877 },
  { t: 33.0, v: 0xffd0a0 },
  { t: 38.2, v: 0xfff0cf },
  { t: 44.0, v: 0xff9f5c },
];

/** A colour ramp: the same key times, interpolated one channel at a time. */
function ramp(keys: NumKey[]) {
  const r = keys.map((k) => ({ t: k.t, v: channel(k.v, 16) }));
  const g = keys.map((k) => ({ t: k.t, v: channel(k.v, 8) }));
  const b = keys.map((k) => ({ t: k.t, v: channel(k.v, 0) }));
  return (t: number) =>
    (Math.round(keysAt(r, t)) << 16) | (Math.round(keysAt(g, t)) << 8) | Math.round(keysAt(b, t));
}

const fogHexAt = ramp(FOG_HEX);
const sunHexAt = ramp(SUN_HEX);

export function look(t: number): Look {
  const s = Math.max(0, Math.min(LOOP, t));

  // ---- the pearl's descent, then its rest at the gate, then the climb home
  const pearlUp = smoothstep(T.fall.start, T.fall.start + T.fall.dur, s);
  const home = smoothstep(T.draw.start + 0.6, T.draw.start + T.draw.dur, s);
  const pearl = clamp(pearlUp - home, 0, 1);

  // ---- the draw-back: everything spirals up into the gate, and it finishes six tenths of a second
  // before the wrap. The opening beat is empty sky, so the loop point needs a stretch where nothing
  // stands — a dissolve that lands exactly at 44 leaves a wet sheet on screen at the cut.
  const dissolve = smoothstep(T.draw.start, T.draw.start + 2.4, s);
  const swirl = dissolve * 5.2;
  const hold = 1 - dissolve;

  // ---- the ripple: one shockwave off the strike, then the falls' own pulse
  const shock = (s - T.strike.start) * 26;
  const pulse = ((s - T.life.start) * 11) % 46;
  const useShock = s < T.life.start;
  const rippleR = useShock ? Math.max(0, shock) : pulse;
  const rippleGain =
    (useShock
      ? Math.exp(-Math.max(0, s - T.strike.start) * 0.55) * (s > T.strike.start ? 1 : 0)
      : Math.exp(-pulse * 0.055) * smoothstep(T.life.start, T.life.start + 1.2, s)) * 0.55 * hold;

  const sunLift = keysAt(SUN_LIFT, s);
  const az = 1.06;
  const ey = 0.18 + sunLift * 0.92;
  const len = Math.hypot(Math.cos(az), ey, Math.sin(az));

  return {
    sky: skyAt(s),
    ink: keysAt(GRADE, s),
    colorFront: keysAt(FRONT, s),
    dissolve,
    swirl,
    sway: keysAt(SWAY, s),
    water: clamp(smoothstep(T.basin.start, T.basin.start + 2.2, s) * hold, 0, 1),
    glowGain: clamp(smoothstep(T.village.start + 0.6, T.life.start + 1.0, s) * hold, 0, 1),
    exposure: keysAt(EXPOSURE, s),
    bloom: keysAt(BLOOM, s),
    farGain: keysAt(FAR_GAIN, s),
    pearl,
    pearlGlow: clamp(1 - Math.abs(pearl - 1) * 3.2, 0, 1) * 0.9 + pearl * 0.1,
    pour: clamp(smoothstep(T.falls.start, T.falls.start + 1.9, s) * hold, 0, 1),
    foam: clamp(smoothstep(T.falls.start + 1.1, T.falls.start + 2.4, s) * hold, 0, 1),
    mist: clamp(smoothstep(T.falls.start + 1.3, T.falls.start + 2.6, s) * 0.9 * hold, 0, 1),
    petals: clamp(smoothstep(T.gardens.start + 1.4, T.village.start + 0.8, s) * hold, 0, 1),
    skyLanterns: clamp(smoothstep(T.dragon.start + 0.8, T.dawn.start + 0.6, s) * hold, 0, 1),
    shoal: clamp(smoothstep(T.life.start, T.life.start + 1.8, s) * hold, 0, 1),
    leap: clamp((s - T.leap.start) / Math.max(0.001, T.leap.dur), 0, 1),
    dragon: clamp((s - T.dragon.start) / Math.max(0.001, T.dragon.dur + 1.6), 0, 1),
    lanternWave: smoothstep(T.dragon.start + 0.4, T.dawn.start + 1.6, s) * 190,
    rippleAt: useShock ? [FALLS.x, FALLS.lipZ] : [POOL.x, POOL.z],
    rippleR,
    rippleGain,
    fogHex: fogHexAt(s),
    fogNear: keysAt(FOG_NEAR, s),
    fogFar: keysAt(FOG_FAR, s),
    sun: [Math.cos(az) / len, ey / len, Math.sin(az) / len],
    sunHex: sunHexAt(s),
    sunGain: keysAt(SUN_GAIN, s),
  };
}
