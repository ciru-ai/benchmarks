import { VoxelWorld } from '../core/VoxelWorld';
import { C, clamp, hash3, lerp, mixHex, smoothstep } from '../core/palette';
import { COURT, FALLS, LAKE, MID, POOL, RIDGE, CELL } from '../core/layout';

/**
 * The valley floor of JADEFALL, authored on the MID lattice (0.6 units per cell).
 *
 * The landform is a *max/min of smooth features* rather than a noise field: a base surface that
 * is the lake bowl inside the shoreline and the rising country outside it, cut down by the arm,
 * the plunge pool and the gorge notch, then pushed up by the island mesa and the west bank. The
 * coastlines are therefore the intersections of those surfaces, which is what makes them read as
 * carved shore rather than as a disc dropped on a plane.
 *
 * `groundY` is exported so the composer can stand objects on the land without re-deriving it.
 */

/** Bilinear value noise over a lattice of the given period, in 0..1. */
function vnoise(x: number, z: number, period: number, seed: number): number {
  const gx = x / period;
  const gz = z / period;
  const x0 = Math.floor(gx);
  const z0 = Math.floor(gz);
  const fx = gx - x0;
  const fz = gz - z0;
  const sx = fx * fx * (3 - 2 * fx);
  const sz = fz * fz * (3 - 2 * fz);
  const a = hash3(x0, 0, z0, seed);
  const b = hash3(x0 + 1, 0, z0, seed);
  const c = hash3(x0, 0, z0 + 1, seed);
  const d = hash3(x0 + 1, 0, z0 + 1, seed);
  return lerp(lerp(a, b, sx), lerp(c, d, sx), sz);
}

/** Two octaves of noise, centred on zero. */
const relief = (x: number, z: number, seed: number): number =>
  (vnoise(x, z, 13, seed) - 0.5) * 5.2 + (vnoise(x, z, 5.5, seed + 31) - 0.5) * 2.1;

/** Distance from a plan point to the segment a→b. */
function segDist(x: number, z: number, ax: number, az: number, bx: number, bz: number): number {
  const vx = bx - ax;
  const vz = bz - az;
  const wx = x - ax;
  const wz = z - az;
  const t = clamp((wx * vx + wz * vz) / (vx * vx + vz * vz), 0, 1);
  return Math.hypot(x - (ax + vx * t), z - (az + vz * t));
}

/** Normalised distance in the lake's plan ellipse; 1 is the shoreline. */
export function lakeQ(x: number, z: number): number {
  return Math.hypot((x - LAKE.cx) / LAKE.rx, (z - LAKE.cz) / LAKE.rz);
}

/** A knoll: `amp` units of Gaussian rise about (hx, hz) with radius `r`. */
const knoll = (x: number, z: number, hx: number, hz: number, r: number, amp: number): number =>
  amp * Math.exp(-(((x - hx) ** 2 + (z - hz) ** 2) / (r * r)));

/**
 * The land's surface height in world units at plan (x, z) — the lake bed where there is water,
 * the ground where there is not. Deterministic; safe to call from the composer.
 */
export function groundY(x: number, z: number): number {
  // The shore is the lake's ellipse wandering by up to ±8% through long-wavelength noise, so the
  // water meets the land on a coast and not on a compass drawing.
  const q = lakeQ(x, z) * (1 + 0.16 * (vnoise(x, z, 13, 401) - 0.5));

  // ---- base: the bowl inside the shoreline, the country rising outside it
  const depth = 11.6 * (1 - Math.pow(clamp(q, 0, 1), 3.0));
  // The country's hills and noise live only beyond the shore. Anywhere they leak into the basin
  // they stand at the water's own height, and a shelf there reads as one flat field, not a lake.
  const outside = smoothstep(1.0, 1.3, q);
  // The MID lattice is a square with a hard edge, and the FAR foothills outside it stand at 5-25.
  // Everything the country gains past the shore is handed back before that edge so the two
  // lattices meet with the FAR standing above the MID — otherwise every wide beat shows a
  // rectangular cliff around the valley. The same factor carries the hill ring that closes the
  // valley in view, so the country is never the flat shelf it would otherwise become.
  const edge = 1 - 0.78 * smoothstep(52, 66, Math.hypot(x, z));
  const hillRing =
    knoll(x, z, 0, -52, 26, 13) +
    knoll(x, z, 34, -34, 22, 12) +
    knoll(x, z, 52, 8, 22, 11) +
    knoll(x, z, 34, 40, 22, 10) +
    knoll(x, z, -6, 50, 26, 11) +
    knoll(x, z, -44, 30, 22, 12) +
    knoll(x, z, -56, -14, 24, 13);
  const upLift =
    edge *
      (13 * smoothstep(1.0, 1.2, q) +
        outside *
          (knoll(x, z, -54, 34, 22, 14) +
            knoll(x, z, -46, -18, 18, 10) +
            hillRing +
            relief(x, z, 17) +
            9 * (vnoise(x, z, 24, 137) - 0.5) * 2));
  let ground = upLift - depth;

  // The worked east country is a bench, not a hillside: the terraces, stalls and houses are
  // flat-footed builders, so a slope steeper than a few units leaves their floors hanging over the
  // ground next door. Both bounds ride `edge`, so the bench dissolves before the lattice's rim.
  if (x > 24) {
    const benchHi = edge * (16.2 + 2.6 * vnoise(x, z, 18, 211));
    const benchLo = edge * 12.4 * smoothstep(1.04, 1.18, q);
    ground = Math.max(Math.min(ground, benchHi), benchLo);
  }

  // ---- cuts: corridors carved down to an absolute level. Beyond each corridor the level climbs
  // past anything the country can reach, so it stops clamping — a constant far value would plane
  // the whole valley down to the sill of its deepest cut and the country would be one shelf.
  const armShape = 1 - smoothstep(9.5, 17.5, segDist(x, z, POOL.x, POOL.z, -16.5, -20.5));
  const armCut = -7.4 + 78 * (1 - armShape);
  const poolShape = 1 - smoothstep(6.5, 12.5, Math.hypot(x - POOL.x, z - POOL.z));
  const poolCut = -9.6 + 78 * (1 - poolShape);
  const gorgeShape = 1 - smoothstep(7.5, 16.5, segDist(x, z, FALLS.x, FALLS.lipZ + 2, POOL.x, POOL.z));
  const gorgeCut = -6.2 + 78 * (1 - gorgeShape);

  const notchHalf = FALLS.width * 0.5;
  const notch =
    FALLS.lipY - 1.4 +
    7.5 * smoothstep(notchHalf, notchHalf + 6.5, Math.abs(x - FALLS.x)) +
    3.0 * smoothstep(2.5, 9.0, Math.abs(z - FALLS.lipZ));
  const channel =
    FALLS.lipY - 1.4 + 5.4 * smoothstep(3.6, 9.5, segDist(x, z, FALLS.x, FALLS.lipZ, -43.5, -59.5));

  ground = Math.min(ground, armCut, poolCut, gorgeCut);
  if (Math.abs(x - FALLS.x) < notchHalf + 6.5 && z < FALLS.lipZ + 9) ground = Math.min(ground, notch);
  if (z < FALLS.lipZ - 1) ground = Math.min(ground, channel);

  // ---- raises: the island mesa, and the west bank the causeway lands on
  // A superellipse on the court's own square: an elliptical mesa leaves the sea wall's corners
  // hanging over the water, and the precinct then reads as a slab set down on land.
  const mesaX = Math.abs(x - COURT.x) / 18.7;
  const mesaZ = Math.abs(z - COURT.z) / 18.7;
  const islandU = Math.pow(mesaX * mesaX * mesaX * mesaX + mesaZ * mesaZ * mesaZ * mesaZ, 0.25);
  ground = Math.max(ground, lerp(-16, COURT.deckY, 1 - smoothstep(0.82, 1.05, islandU)));

  const bankU = 1 - smoothstep(-24.6, -21.4, x);
  const bankCap = 1 - smoothstep(7.0, 15.0, Math.abs(z - 3));
  ground = Math.max(ground, lerp(-13, 8.6, bankU * bankCap));

  // ---- the Dragon Ridge behind the falls, with a plateau along the whole northern edge
  const ridgeRise = smoothstep(RIDGE.z1 - 1.5, RIDGE.z1 - 14, z);
  // The plateau rides `edge` as well: the ridge's own back would otherwise march off the lattice's
  // north rim as a flat-topped wall, and the FAR seam belt cannot cover a crest that tall.
  const plateau = edge * (41.5 + 4.5 * vnoise(x, z, 16, 71) + knoll(x, z, -44, -50, 26, 12));
  ground = Math.max(ground, lerp(-13, plateau, ridgeRise));

  // The MID lattice tops out at 61.2 world units. Knee the sum rather than let a column be
  // clipped by the lattice ceiling, which would open a flat hole in the ridge.
  const knee = 40;
  return ground > knee ? knee + (ground - knee) * 0.35 : ground;
}

/** Surface colour of a column: wet rock under water, sand at the mark, grass and forest above. */
function surfaceColor(x: number, y: number, z: number, steep: boolean): number {
  const grain = hash3(x, Math.round(y), z, 5);
  if (y < -6.5) return mixHex(C.inkSoft, C.slate, 0.3 + 0.4 * grain);
  if (y < -2.4) return mixHex(C.slate, C.jadeDeep, 0.25 + 0.5 * grain);
  if (y < 1.0) return mixHex(C.sand, C.gravel, 0.28 + 0.5 * grain);
  if (y < 2.3) return mixHex(C.gravel, C.sand, 0.32 + 0.4 * grain);
  if (steep) {
    // Steps on a hillside read as vegetated rock, not a quarry face: keep them near the turf value.
    const lit = 0.35 + 0.25 * grain;
    return mixHex(C.mossDeep, C.pine, clamp(lit, 0, 1));
  }
  if (y > 48) return mixHex(C.stoneLite, C.gravel, 0.3 + 0.5 * grain);
  if (y > 34) return mixHex(C.mossDeep, C.pineDeep, 0.3 + 0.42 * grain);
  const turf = mixHex(C.moss, C.mossDeep, 0.28 + 0.5 * grain);
  if (grain > 0.82) return mixHex(turf, C.leaf, 0.6);
  if (y > 10 && grain < 0.16) return mixHex(turf, C.pineDeep, 0.5);
  return turf;
}


/** Subsurface colour: the mass of the column, darkening with depth below the surface. */
function massColor(y: number, x: number, z: number): number {
  const grain = hash3(x, Math.round(y), z, 13);
  if (y > 3) return mixHex(C.soilDark, C.inkSoft, 0.3 + 0.4 * grain);
  return mixHex(C.ink, C.inkDeep, 0.25 + 0.5 * grain);
}

export interface LandArgs {
  seed: number;
  /** reveal start of the deepest bed cells */
  t: number;
  /** seconds the whole landform takes, bottom-up */
  dur: number;
}

/**
 * Fill the MID lattice with the valley: every column from the floor of the grid to `groundY`,
 * bed-first and crest-last. Reads `groundY` only, so the water, the precinct and the props can be
 * placed against exactly the same surface. Footprint: the whole MID grid.
 */
export function authorValley(world: VoxelWorld, a: LandArgs): void {
  const cell = CELL.mid;
  const rowOf = (y: number) => Math.round((y - MID.origin[1]) / cell - 1e-6);

  for (let c = 0; c < MID.sx; c++) {
    const x = MID.origin[0] + (c + 0.5) * cell;
    for (let l = 0; l < MID.sz; l++) {
      const z = MID.origin[2] + (l + 0.5) * cell;
      const h = groundY(x, z);
      const top = rowOf(h);
      if (top < 0) continue;

      // steep where the column next to it drops more than two cells
      const hx = groundY(x + cell, z) - groundY(x - cell, z);
      const hz = groundY(x, z + cell) - groundY(x, z - cell);
      const steep = Math.hypot(hx, hz) > 2.2;

      const f = clamp(top / 96, 0, 1);
      const t = a.t + f * a.dur * 0.78;
      for (let r = 0; r <= top; r++) {
        const y = MID.origin[1] + (r + 0.5) * cell;
        const surface = r === top;
        world.set(c, r, l, surface ? surfaceColor(x, y, z, steep) : massColor(y, x, z), {
          t: surface ? t : t - a.dur * 0.16,
          dur: 0.3,
        });
      }

      // a wet, luminous band where the veil's spray keeps the gorge rock damp
      if (h > -3 && h < 6.5 && Math.hypot(x - POOL.x, z - POOL.z) < 15 && hash3(c, top, l, 23) > 0.9) {
        world.set(c, top, l, mixHex(C.flouroshDeep, C.jadeDeep, 0.4 + 0.4 * hash3(c, top, l, 29)), {
          t: t + 0.2,
          dur: 0.3,
        });
      }
    }
  }
}

export interface GorgeArgs {
  seed: number;
  t: number;
  dur: number;
}

/**
 * The buttresses and ledges the veil falls between: jagged rock fins built on the sill so the
 * water never reads as a sheet pasted on a cliff, plus the shelf the river runs out along.
 * Footprint: x within ±18 of `FALLS.x`, z from the crest down to the pool.
 */
export function authorGorge(world: VoxelWorld, a: GorgeArgs): void {
  const cell = CELL.mid;
  const colOf = (x: number) => Math.round((x - MID.origin[0]) / cell);
  const laneOf = (z: number) => Math.round((z - MID.origin[2]) / cell);
  const rowOf = (y: number) => Math.round((y - MID.origin[1]) / cell);

  // the sill the river spills over, dressed as masonry under the lip
  const sillRow = rowOf(FALLS.lipY - 1.2);
  for (let x = FALLS.x - FALLS.width * 0.5 - 3; x <= FALLS.x + FALLS.width * 0.5 + 3; x += cell) {
    for (let z = FALLS.lipZ - 3.2; z <= FALLS.lipZ + 1.2; z += cell) {
      const c = colOf(x);
      const l = laneOf(z);
      const top = Math.max(sillRow, rowOf(groundY(x, z)));
      for (let r = rowOf(groundY(x, z)); r <= top; r++) {
        world.set(c, r, l, mixHex(C.stone, C.slate, 0.3 + 0.4 * hash3(c, r, l, 41)), {
          t: a.t + 0.1,
          dur: 0.3,
        });
      }
    }
  }

  // three rock fins standing in the gorge, tallest under the widest ribs of water
  const fins: [number, number, number, number][] = [
    [-38.4, -41.4, 12.6, 5.2],
    [-26.4, -40.2, 10.2, 4.4],
    [-32.6, -37.2, 6.4, 3.4],
  ];
  for (const [fx, fz, fh, fr] of fins) {
    const base = rowOf(-3.5);
    const topRow = rowOf(fh);
    for (let r = base; r <= topRow; r++) {
      const taper = fr * (1 - 0.52 * ((r - base) / Math.max(1, topRow - base)));
      for (let dz = -Math.ceil(taper); dz <= Math.ceil(taper); dz++) {
        for (let dx = -Math.ceil(taper); dx <= Math.ceil(taper); dx++) {
          const d = Math.hypot(dx, dz);
          if (d > taper + 0.35 * (hash3(colOf(fx) + dx, r, laneOf(fz) + dz, 57) - 0.5)) continue;
          const c = colOf(fx) + dx;
          const l = laneOf(fz) + dz;
          const wx = MID.origin[0] + (c + 0.5) * cell;
          const wz = MID.origin[2] + (l + 0.5) * cell;
          if (Math.hypot(wx - FALLS.x, wz - FALLS.lipZ) < 3.2) continue;
          const cap = r === topRow;
          world.set(c, r, l, cap
            ? mixHex(C.mossDeep, C.stoneLite, 0.35 + 0.4 * hash3(c, r, l, 61))
            : mixHex(C.slate, C.inkSoft, 0.3 + 0.45 * hash3(c, r, l, 67)), {
            t: a.t + (1 - (r - base) / Math.max(1, topRow - base)) * a.dur * 0.5,
            dur: 0.3,
          });
        }
      }
    }
  }
}

/**
 * A flat-topped rock islet in the lake, `r` world units across with its deck at `topY`. Used for
 * the pavilion isles and for the landing staging under the causeway.
 */
export function islet(
  world: VoxelWorld,
  cx: number,
  cz: number,
  r: number,
  topY: number,
  a: { t: number; dur: number; seed: number },
): void {
  const cell = CELL.mid;
  const colOf = (x: number) => Math.round((x - MID.origin[0]) / cell);
  const laneOf = (z: number) => Math.round((z - MID.origin[2]) / cell);
  const rowOf = (y: number) => Math.round((y - MID.origin[1]) / cell);
  const topRow = rowOf(topY);
  const rr = r / cell;
  for (let dz = -Math.ceil(rr) - 1; dz <= Math.ceil(rr) + 1; dz++) {
    for (let dx = -Math.ceil(rr) - 1; dx <= Math.ceil(rr) + 1; dx++) {
      const d = Math.hypot(dx, dz);
      if (d > rr + 1.4) continue;
      const c = colOf(cx) + dx;
      const l = laneOf(cz) + dz;
      const slope = 1 - smoothstep(rr * 0.55, rr + 1.2, d);
      const low = rowOf(Math.min(-4, groundY(MID.origin[0] + (c + 0.5) * cell, MID.origin[2] + (l + 0.5) * cell)));
      const cap = low + Math.round((topRow - low) * slope);
      for (let r2 = low; r2 <= cap; r2++) {
        const y = MID.origin[1] + (r2 + 0.5) * cell;
        const last = r2 === cap;
        world.set(c, r2, l, last
          ? y < 0.6
            ? mixHex(C.sand, C.gravel, 0.3 + 0.5 * hash3(c, r2, l, a.seed))
            : mixHex(C.moss, C.mossDeep, 0.3 + 0.5 * hash3(c, r2, l, a.seed + 3))
          : mixHex(C.ink, C.slate, 0.25 + 0.4 * hash3(c, r2, l, a.seed + 7)), {
          t: a.t + (1 - slope) * a.dur * 0.4,
          dur: 0.3,
        });
      }
    }
  }
}
