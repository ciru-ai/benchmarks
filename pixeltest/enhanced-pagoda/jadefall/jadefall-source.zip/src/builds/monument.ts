import { Kind, VoxelWorld } from '../core/VoxelWorld';
import { C, hash3, mixHex, shade } from '../core/palette';
import { PAGODA, fineRow } from '../core/layout';
import { BuilderArgs, FADE, dice, opt, reveal, swayAt } from './types';
import { RoofSpec, balustrade, brackets, curvedRoof, masonry, stoneStair, stoneSteps } from './pagoda';

/**
 * JADEFALL 瓦城 — the island precinct's monumental architecture, authored on the FINE lattice
 * (0.2 units a cell, row 0 being the temple deck plane).
 *
 * Everything here is written in one geometry language: a coursed marble terrace (the podium), a
 * battered and crenellated court wall around it, and a nine-tier temple on the crown, all roofed
 * with the shared `curvedRoof` ogee so the precinct reads as one school of builders rather than
 * nine objects. Reveal is support first, ornament last: footing `f = 0`, ridge and finial `f = 1`.
 *
 * Nothing is ever written below `a.y` — the builder is told which plane it stands on and authors
 * upward only, so the mesa and the water below stay the stage's business.
 */

// ------------------------------------------------------------------ shared helpers

/** Read an integer knob, clamped to the lattice-safe range. */
function int(a: BuilderArgs, key: string, dflt: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, Math.round(opt(a, key, dflt))));
}

/** A stone tone with deterministic ink-wash grain so no two blocks read identically. */
function tone(a: BuilderArgs, base: number, x: number, y: number, z: number, k: number): number {
  return shade(base, k * (0.9 + 0.1 * hash3(x, y, z, a.seed + 3)));
}

/**
 * Dressed paving: a full square slab with a 4-cell field grid, darker joint lines and a hard
 * border course. One row tall — it is a floor, never a mass.
 */
function pavingSlab(
  world: VoxelWorld,
  a: BuilderArgs,
  cx: number,
  cz: number,
  half: number,
  y: number,
  f: number,
): void {
  for (let dz = -half; dz <= half; dz++) {
    for (let dx = -half; dx <= half; dx++) {
      const border = Math.abs(dx) === half || Math.abs(dz) === half;
      const joint = (dx + 4 * half) % 4 === 0 || (dz + 4 * half) % 4 === 0;
      const base = border ? C.marble : joint ? C.marbleDeep : C.marbleLite;
      const k = border ? 0.9 : joint ? 0.82 : 1;
      world.set(cx + dx, y, cz + dz, tone(a, base, cx + dx, y, cz + dz, k), {
        t: reveal(a, f),
        dur: FADE,
      });
    }
  }
}

/**
 * Coursed facing for a square terrace: perimeter walls only (the mass is never seen), with a
 * recessed joint seam every fourth course and alternating quoins at the angles.
 */
function coursedFacing(
  world: VoxelWorld,
  a: BuilderArgs,
  cx: number,
  cz: number,
  half: number,
  y0: number,
  y1: number,
  f: number,
): void {
  for (let y = y0; y <= y1; y++) {
    const d = y - y0;
    const seam = d % 4 === 3;
    const inset = seam ? 1 : 0;
    const k = seam ? 0.8 : 0.92 + 0.06 * (Math.floor(d / 4) % 2);
    for (let t = -half + inset; t <= half - inset; t++) {
      for (const [x, z] of [
        [cx + t, cz - half + inset],
        [cx + t, cz + half - inset],
        [cx - half + inset, cz + t],
        [cx + half - inset, cz + t],
      ] as const) {
        const quoin = Math.abs(t) % 4 === 0 && d % 2 === 0;
        world.set(x, y, z, tone(a, quoin ? C.marbleLite : C.marble, x, y, z, quoin ? k + 0.09 : k), {
          t: reveal(a, f),
          dur: FADE,
        });
      }
    }
  }
}

/**
 * One solid marble flight climbing toward -z on a terrace's +z face: a filled spandrel under the
 * treads, a cheek wall riding the stringer with a newel at each end, and the dressed treads from
 * the library `stoneStair` last, so the walking surface keeps the pale tone.
 */
function stairFlight(
  world: VoxelWorld,
  a: BuilderArgs,
  cx: number,
  footLane: number,
  startRow: number,
  run: number,
  rise: number,
  width: number,
  f: number,
): void {
  const w0 = -Math.floor(width / 2);
  const w1 = w0 + width - 1;
  const treadRow = (i: number) => Math.floor(((i + 1) * rise) / run) - 1;
  for (let i = 0; i < run; i++) {
    const r = treadRow(i);
    if (r < 0) continue;
    world.box(
      cx + w0, startRow, footLane - i,
      cx + w1, startRow + r, footLane - i,
      tone(a, C.marbleDeep, cx, startRow + r, footLane - i, 0.86),
      { t: reveal(a, f), dur: FADE },
    );
  }
  for (const side of [-1, 1]) {
    const ex = cx + side * (w1 + 1);
    for (let i = 0; i < run; i++) {
      const r = treadRow(i);
      if (r < 0) continue;
      world.set(ex, startRow + r + 1, footLane - i, tone(a, C.marbleLite, ex, 0, footLane - i, 1), {
        t: reveal(a, f),
        dur: FADE,
      });
    }
    // Newels at the foot and the head of the cheek.
    for (const i of [0, run - 1]) {
      const r = Math.max(0, treadRow(i));
      for (let y = startRow; y <= startRow + r + 2; y++) {
        world.set(ex, y, footLane - i, y === startRow + r + 2 ? C.gilt : C.marble, {
          t: reveal(a, f),
          dur: FADE,
        });
      }
    }
  }
  stoneStair(world, a, cx, startRow, footLane, 1, run, width, rise, f);
}

/**
 * The ceremonial ramp (yu lu) between a double stair's two flights: one unpitched slab of pale
 * marble banded in gilt, carved rather than stepped.
 */
function imperialRamp(
  world: VoxelWorld,
  a: BuilderArgs,
  cx: number,
  footLane: number,
  startRow: number,
  run: number,
  rise: number,
  f: number,
): void {
  for (let i = 0; i < run; i++) {
    const r = Math.max(0, Math.floor(((i + 1) * rise) / run) - 1);
    for (let d = -2; d <= 2; d++) {
      const carved = i % 2 === 0 && (d + 2) % 2 === 0;
      world.set(
        cx + d,
        startRow + r,
        footLane - i,
        carved ? C.gilt : tone(a, C.marbleLite, cx + d, startRow + r, footLane - i, 1.04),
        { t: reveal(a, f), dur: FADE },
      );
    }
  }
}

/**
 * A timber storey on a rectangular plan: stone sill, lacquered corner posts, plaster panels with
 * mullions, an optional framed window in the middle of each face, and a double lintel band. The
 * interior stays hollow — nothing above the podium's crown is ever entered.
 */
function storeyBody(
  world: VoxelWorld,
  a: BuilderArgs,
  cx: number,
  cz: number,
  hx: number,
  hz: number,
  y0: number,
  height: number,
  windows: boolean,
  f: number,
): void {
  const ax = Math.round(hx);
  const az = Math.round(hz);
  const y1 = y0 + Math.max(5, height) - 1;
  const band0 = y1 - 2;
  const band1 = y1 - 1;
  const wLo = y0 + 3;
  const wHi = y1 - 4;
  for (const side of [0, 1, 2, 3] as const) {
    const alongX = side < 2;
    const sgn = side % 2 === 0 ? -1 : 1;
    const run = alongX ? ax : az;
    const halfW = windows && run >= 6 ? Math.min(2, Math.floor(run / 4)) : 0;
    for (let d = -run; d <= run; d++) {
      const px = alongX ? cx + d : cx + sgn * ax;
      const pz = alongX ? cz + sgn * az : cz + d;
      const ox = alongX ? 0 : sgn;
      const oz = alongX ? sgn : 0;
      const isCorner = Math.abs(d) === run;
      const inWindow = halfW > 0 && Math.abs(d) <= halfW;
      for (let y = y0; y <= y1; y++) {
        if (isCorner) {
          world.set(px, y, pz, y === y1 ? C.ironwoodLite : C.vermilionDeep, {
            t: reveal(a, f),
            dur: FADE,
          });
          continue;
        }
        if (y === y0) {
          world.set(px, y, pz, tone(a, C.marble, px, y, pz, 0.94), { t: reveal(a, f), dur: FADE });
          continue;
        }
        if (y === y0 + 1) {
          world.set(px, y, pz, tone(a, C.marbleLite, px, y, pz, 0.98), { t: reveal(a, f), dur: FADE });
          continue;
        }
        if (y >= band0) {
          const c = y === band0 ? C.woodDark : y === band1 ? C.vermilionDeep : C.wood;
          world.set(px, y, pz, (d + 100) % 3 === 0 && y === band0 ? C.ironwood : c, {
            t: reveal(a, f),
            dur: FADE,
          });
          continue;
        }
        if (inWindow && y >= wLo && y <= wHi) {
          if (Math.abs(d) === halfW) {
            world.set(px, y, pz, C.woodDark, { t: reveal(a, f), dur: FADE });
          }
          continue;
        }
        if ((d + 100) % 3 === 0) {
          world.set(px, y, pz, C.woodDark, { t: reveal(a, f), dur: FADE });
          continue;
        }
        const wash = 0.84 + 0.16 * hash3(px, y, pz, a.seed + 17);
        world.set(
          px,
          y,
          pz,
          shade(mixHex(C.paper, C.mist, 0.34), wash * (0.84 + 0.16 * ((y - y0) / Math.max(1, y1 - y0)))),
          { t: reveal(a, f), dur: FADE },
        );
      }
      if (inWindow) {
        world.set(px, wLo - 1, pz, tone(a, C.marbleLite, px, wLo, pz, 1.02), { t: reveal(a, f), dur: FADE });
        world.set(px + ox, wHi, pz + oz, C.woodDark, { t: reveal(a, f), dur: FADE });
      }
    }
  }
}

/** A hanging bell under an eave tip: a hanger, the bronze body, and the mouth. */
function hangingBell(
  world: VoxelWorld,
  a: BuilderArgs,
  x: number,
  y: number,
  z: number,
  above: number,
  f: number,
  glow: number,
): void {
  world.set(x, y, z, C.ironwood, {
    t: reveal(a, f),
    dur: FADE,
    sway: swayAt(above, above, 0.55),
  });
  world.set(x, y - 1, z, shade(C.bronze, 1.06), {
    t: reveal(a, f + 0.01),
    dur: FADE,
    sway: swayAt(above - 1, above, 0.55),
  });
  if (glow > 0) {
    world.set(x, y - 2, z, C.goldHot, {
      kind: Kind.Glow,
      glow,
      t: reveal(a, 0.96),
      dur: FADE,
      sway: swayAt(above - 2, above, 0.55),
    });
  } else {
    world.set(x, y - 2, z, shade(C.goldDeep, 0.85), {
      t: reveal(a, f + 0.02),
      dur: FADE,
      sway: swayAt(above - 2, above, 0.55),
    });
  }
}

/** A stone lantern standard: battered base, shaft, lamp box and hood. `glow` lights the box. */
function lanternStandard(
  world: VoxelWorld,
  a: BuilderArgs,
  x: number,
  z: number,
  y0: number,
  h: number,
  f: number,
  glow: number,
): void {
  world.box(x - 1, y0, z - 1, x + 1, y0, z + 1, tone(a, C.stone, x, y0, z, 0.86), {
    t: reveal(a, f),
    dur: FADE,
  });
  world.set(x, y0 + 1, z, tone(a, C.stoneLite, x, y0 + 1, z, 0.94), { t: reveal(a, f), dur: FADE });
  for (let y = y0 + 2; y < y0 + h - 1; y++) {
    world.set(x, y, z, tone(a, C.stone, x, y, z, 0.9), { t: reveal(a, f), dur: FADE });
  }
  world.set(x, y0 + h - 1, z, C.lanternCore, { kind: Kind.Glow, glow, t: reveal(a, 0.95), dur: FADE });
  world.box(x - 1, y0 + h, z - 1, x + 1, y0 + h, z + 1, shade(C.stoneLite, 0.9), {
    t: reveal(a, f + 0.04),
    dur: FADE,
  });
  world.set(x, y0 + h + 1, z, C.stone, { t: reveal(a, f + 0.06), dur: FADE });
}

/** A pitched tile cap over a straight wall: three receding courses plus a gilt-disc ridge. */
function tileCap(
  world: VoxelWorld,
  a: BuilderArgs,
  x0: number,
  x1: number,
  cz: number,
  y: number,
  halfThick: number,
  f: number,
): void {
  for (let x = x0; x <= x1; x++) {
    const rib = ((x + 400) & 1) === 0 ? C.tile : C.tileRim;
    world.box(x, y, cz - halfThick, x, y, cz + halfThick, shade(rib, 0.94), {
      t: reveal(a, f),
      dur: FADE,
    });
    world.box(x, y + 1, cz - halfThick + 1, x, y + 1, cz + halfThick - 1, rib, {
      t: reveal(a, f),
      dur: FADE,
    });
    world.set(x, y + 2, cz, (x + 400) % 4 === 0 ? C.tileRim : shade(C.tileDeep, 0.86), {
      t: reveal(a, f + 0.02),
      dur: FADE,
    });
  }
}

// ------------------------------------------------------------------ monuments

/**
 * The marble podium: three coursed tiers (half-extents 47 / 37 / 27) whose crown deck lands on
 * `a.y + 30` — the row the temple's first storey stands on. Every tier is railed, and a double
 * stair with a carved central ramp descends the +z face of the lower two tiers. Four gilt finial
 * posts mark the crown's angles. Footprint 95x95 cells, no glow.
 */
export function marblePodium(world: VoxelWorld, a: BuilderArgs): void {
  const tiers = int(a, 'tiers', 3, 1, 3);
  const CROWN = 30;
  // Course heights are 6 / 12 / 12 at the default; with fewer tiers the rows are re-scaled so the
  // crown deck is always exactly `a.y + 30` and the temple always finds the same plane.
  const heights: number[] = [];
  let used = 0;
  for (let i = 0; i < tiers; i++) {
    const h = i === 0 ? Math.round(CROWN * 0.2) : Math.round((CROWN - used) / (tiers - i));
    heights.push(h);
    used += h;
  }
  heights[heights.length - 1] += CROWN - used;

  let deck = a.y;
  for (let i = 0; i < tiers; i++) {
    const half = 47 - 10 * i;
    const f = 0.02 + 0.1 * i;
    const top = deck + heights[i];
    coursedFacing(world, a, a.x, a.z, half, deck, top - 1, f);
    pavingSlab(world, a, a.x, a.z, half, top, f + 0.04);
    deck = top;
  }

  // A balustrade on every deck edge, four cells to a post. The great stair is authored after the
  // rails, so its spandrels and newels cut the opening where it lands on the first deck.
  deck = a.y;
  for (let i = 0; i < tiers; i++) {
    const half = 47 - 10 * i;
    deck += heights[i];
    const f = 0.3 + 0.1 * i;
    balustrade(world, a, a.x, a.z, half - 1, deck + 1, f, 4);
  }

  // The double stair: flights flanking a carved ramp, tier 1 off the court floor and tier 2 off
  // the first deck. Authored after the rails so the flights cut cleanly through the break.
  deck = a.y;
  for (let i = 0; i < Math.min(2, tiers); i++) {
    deck += heights[i];
    if (i === 0) {
      for (const s of [-1, 1]) stairFlight(world, a, a.x + s * 7, a.z + 47, a.y, 6, 6, 7, 0.42);
      imperialRamp(world, a, a.x, a.z + 47, a.y, 6, 6, 0.44);
    } else {
      for (const s of [-1, 1]) stairFlight(world, a, a.x + s * 7, a.z + 46, deck, 9, 12, 7, 0.5);
      imperialRamp(world, a, a.x, a.z + 46, deck, 9, 12, 0.52);
    }
  }

  // Gilt finial posts at the crown's four angles — the podium's only ornament, and no light.
  const crownHalf = 47 - 10 * (tiers - 1);
  const crown = a.y + CROWN;
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      const x = a.x + sx * crownHalf;
      const z = a.z + sz * crownHalf;
      for (let y = crown + 1; y <= crown + 5; y++) {
        const c =
          y === crown + 1 ? C.marbleDeep : y === crown + 5 ? C.goldLite : y % 2 === 0 ? C.gilt : C.gold;
        world.set(x, y, z, c, { t: reveal(a, 0.84 + 0.04 * (y - crown)), dur: FADE });
      }
    }
  }
}

/**
 * The walled court: a battered, crenellated perimeter of half-extent 63 with corner towers three
 * cells wider than the wall, a tiled coping along the walk, a two-storey gate pavilion astride a
 * passage cut through the -x face, and the interior paved in dressed marble. Footprint 127x127.
 */
export function islandCourt(world: VoxelWorld, a: BuilderArgs): void {
  const wallH = int(a, 'wallH', 22, 12, 34);
  const half = 63;
  const thick = 5;
  // Crenellar pitch, locked to the object's seed rather than to wall-clock time.
  const cren = 2 + (dice(a)() > 0.5 ? 1 : 0);

  // Interior paving first, at the deck row only, so the wall courses stand on it.
  pavingSlab(world, a, a.x, a.z, 62, a.y, 0.06);

  // The four walls first: a battered plinth course inside the ring, the plastered face with its
  // buttress piers, the walk deck, and a tiled coping pitched over the inner cells. The -x face is
  // cut open for the gate passage — thirteen cells wide, wallH - 4 rows clear.
  const walk = a.y + wallH - 1;
  const lintel = a.y + wallH - 4;
  for (const side of [0, 1, 2, 3] as const) {
    const alongX = side < 2;
    const sgn = side % 2 === 0 ? -1 : 1;
    for (let t = thick; t < thick + 2; t++) {
      for (let dln = -half; dln <= half; dln++) {
        if (side === 2 && Math.abs(dln) <= 7 && t === thick + 1) continue;
        const x = alongX ? a.x + dln : a.x + sgn * (half - t);
        const z = alongX ? a.z + sgn * (half - t) : a.z + dln;
        for (let y = a.y; y <= a.y + 2; y++) {
          if (y === a.y + 2 && t === thick + 1) continue;
          world.set(x, y, z, tone(a, C.inkSoft, x, y, z, 0.88 + 0.05 * (t - thick)), {
            t: reveal(a, 0.02),
            dur: FADE,
          });
        }
      }
    }
    for (let dln = -half; dln <= half; dln++) {
      const passage = side === 2 && Math.abs(dln) <= 6;
      for (let t = 0; t < thick; t++) {
        const x = alongX ? a.x + dln : a.x + sgn * (half - t);
        const z = alongX ? a.z + sgn * (half - t) : a.z + dln;
        for (let y = a.y; y <= walk - 1; y++) {
          if (passage && y < lintel) continue;
          world.set(x, y, z, wallCell(a, x, y, z, t), { t: reveal(a, 0.04), dur: FADE });
        }
        world.set(x, walk, z, tone(a, C.marbleLite, x, walk, z, 0.9), { t: reveal(a, 0.12), dur: FADE });
        if (t >= 1) {
          world.set(x, walk + 1, z, (dln + 400) % 2 === 0 ? C.tile : C.tileRim, {
            t: reveal(a, 0.16),
            dur: FADE,
          });
        }
        if (t >= 2) {
          world.set(x, walk + 2, z, (dln + 400) % 2 === 0 ? C.tileRim : C.tile, {
            t: reveal(a, 0.18),
            dur: FADE,
          });
        }
      }
      if (passage) continue;
      // Crenellar rhythm on the parapet, taller at the angles.
      const ox = alongX ? a.x + dln : a.x + sgn * half;
      const oz = alongX ? a.z + sgn * half : a.z + dln;
      if ((dln + 400) % cren === 0 || Math.abs(dln) === half) {
        const top = Math.abs(dln) === half ? walk + 3 : walk + 2;
        for (let y = walk + 1; y <= top; y++) {
          world.set(ox, y, oz, tone(a, C.marbleLite, ox, y, oz, 0.98), { t: reveal(a, 0.2), dur: FADE });
        }
        world.set(ox, top + 1, oz, C.tileRim, { t: reveal(a, 0.22), dur: FADE });
      }
    }
  }

  // Corner towers last, so they swallow the wall ends: eight cells on side, three wider than the
  // wall, rising eight rows above it and capped with a small hip roof.
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      masonry(
        world,
        a,
        a.x + sx * (half - 7),
        a.y,
        a.z + sz * (half - 7),
        a.x + sx * half,
        a.y + wallH + 7,
        a.z + sz * half,
        0.1,
        C.stone,
      );
      world.box(
        a.x + sx * (half - 8),
        a.y + wallH + 8,
        a.z + sz * (half - 8),
        a.x + sx * half,
        a.y + wallH + 8,
        a.z + sz * half,
        shade(C.marbleLite, 0.94),
        { t: reveal(a, 0.16), dur: FADE },
      );
      const cap: RoofSpec = {
        cx: a.x + sx * (half - 4),
        cz: a.z + sz * (half - 4),
        hx: 4,
        hz: 4,
        y0: a.y + wallH + 9,
        rise: 4,
        lift: 2,
        f0: 0.66,
        f1: 0.72,
        seed: a.seed + 41 + 7 * (sx + sz),
      };
      curvedRoof(world, a, cap);
    }
  }

  // Two lamps in the jambs of the gate passage — the court's only light.
  for (const sz of [-1, 1]) {
    world.set(a.x - (half - 2), a.y + 4, a.z + sz * 7, C.lanternCore, {
      kind: Kind.Glow,
      glow: 0.75,
      t: reveal(a, 0.94),
      dur: 0.6,
    });
  }

  gatePavilion(world, a, a.x - (half - 6), a.z, wallH);
}

/** One cell of the court wall: battered plinth below, plastered face above, buttress piers. */
function wallCell(a: BuilderArgs, x: number, y: number, z: number, t: number): number {
  if (y <= a.y + 2) return tone(a, C.stone, x, y, z, 0.78 + 0.04 * t);
  const course = (y - a.y) % 5 === 0 ? 0.86 : 1;
  const buttress = (x + z + 800) % 8 === 0 && t > 1;
  return tone(a, buttress ? C.marbleDeep : mixHex(C.paper, C.stoneLite, 0.45), x, y, z, course * (buttress ? 1.02 : 0.95));
}

/**
 * The two-storey house over the gate passage: framed posts, two bracket courses, one hip roof. It
 * stands on the wall deck so the passage runs beneath it, and its widest eave is pulled back to the
 * outer face of the curtain wall — the court keeps its 127x127 footprint.
 */
function gatePavilion(world: VoxelWorld, a: BuilderArgs, cx: number, cz: number, wallH: number): number {
  const y0 = a.y + wallH;
  stoneSteps(world, a, cx, cz, 5, y0, 1, 0.24, 0.24);
  storeyBody(world, a, cx, cz, 4, 8, y0 + 1, 10, true, 0.3);
  brackets(world, a, cx, cz, 4, y0 + 10, 2, 0.36);
  storeyBody(world, a, cx, cz, 3, 6, y0 + 12, 8, false, 0.42);
  brackets(world, a, cx, cz, 3, y0 + 19, 2, 0.48);
  return curvedRoof(world, a, {
    cx,
    cz,
    hx: 5,
    hz: 10,
    y0: y0 + 21,
    rise: 5,
    lift: 3,
    f0: 0.52,
    f1: 0.6,
    seed: a.seed + 23,
  });
}

/**
 * The nine-tier temple on the podium's crown. Each tier is a lacquered storey of 13 rows on a
 * 21-row pitch: bracket course, then a curved roof whose eave overlaps the storey it crowns by
 * two rows, then the stone terrace the next storey stands on. `walkRing` adds a railed ambulatory
 * around the first tier and landings at the fourth and seventh. Bells hang at the eave tips of the
 * third, sixth and ninth.
 */
export function greatPagoda(world: VoxelWorld, a: BuilderArgs): void {
  const want = int(a, 'tiers', 9, 5, 11);
  const half = int(a, 'half', 21, 12, 24);
  const ring = int(a, 'walkRing', 0, 0, 1);
  const STOREY = 13;
  const RISE = 6;
  const PITCH = 21;
  // Lattice budget: the ridge of the topmost roof may never pass the camera ceiling row, so the
  // 21-row pitch closes up when more than nine tiers are asked for.
  const ceiling = Math.min(fineRow(PAGODA.topY), world.sy - 1);
  const tiers = Math.max(1, Math.min(want, Math.floor((ceiling - a.y - STOREY - RISE) / 9)));
  const pitch = Math.max(
    9,
    Math.min(PITCH, Math.floor((ceiling - a.y - STOREY - RISE - 1) / Math.max(1, tiers - 1))),
  );

  const halves: number[] = [];
  for (let i = 0; i < tiers; i++) halves.push(Math.max(3, Math.round(half * Math.pow(PAGODA.taper, i))));

  if (ring) ambulatory(world, a, halves[0]);

  for (let i = 0; i < tiers; i++) {
    const f = 0.08 + 0.62 * (i / tiers);
    const y0 = a.y + 1 + pitch * i;
    const h = halves[i];
    const roofHalf = h + 8;
    const lift = i === 0 ? 3 : i >= tiers - 3 ? 1 : 2;
    // Roof first, then the storey: the sheet leans against the storey above instead of poking
    // through this one's walls.
    const top = curvedRoof(world, a, {
      cx: a.x,
      cz: a.z,
      hx: roofHalf,
      hz: roofHalf,
      y0: y0 + STOREY - 1,
      rise: RISE,
      lift,
      f0: f + 0.05,
      f1: f + 0.13,
      seed: a.seed + 29 * i,
    });
    storeyBody(world, a, a.x, a.z, h, h, y0, STOREY, i <= 2, f);
    brackets(world, a, a.x, a.z, h, y0 + STOREY - 3, 2, f + 0.04);
    if (i < tiers - 1) {
      const next = halves[i + 1];
      const terrace = top;
      // Props from the sheet below up to the terrace ring, laid before the slab so they land on
      // the roof's own surface.
      for (let dz = -next - 1; dz <= next + 1; dz++) {
        for (let dx = -next - 1; dx <= next + 1; dx++) {
          if (Math.abs(dx) !== next + 1 && Math.abs(dz) !== next + 1) continue;
          if ((dx + dz + 400) % 4 !== 0) continue;
          for (let y = Math.max(a.y + 1, world.heightAt(a.x + dx, a.z + dz)); y < terrace; y++) {
            world.set(a.x + dx, y, a.z + dz, C.woodDark, { t: reveal(a, f + 0.14), dur: FADE });
          }
        }
      }
      for (let dz = -next - 1; dz <= next + 1; dz++) {
        for (let dx = -next - 1; dx <= next + 1; dx++) {
          world.set(a.x + dx, terrace, a.z + dz, tone(a, C.marble, a.x + dx, terrace, a.z + dz, 0.94), {
            t: reveal(a, f + 0.16),
            dur: FADE,
          });
        }
      }
      if (i === 3 || i === 6) balustrade(world, a, a.x, a.z, next + 1, terrace + 1, f + 0.18, 3);
    }
    // Bells at the four eave tips of the third, sixth and ninth tier; only the front tip of each
    // of those three tiers carries the light.
    if (i === 2 || i === 5 || i === 8) {
      const tipRow = y0 + STOREY - 1 + lift;
      for (const sx of [-1, 1]) {
        for (const sz of [-1, 1]) {
          hangingBell(world, a, a.x + sx * roofHalf, tipRow - 1, a.z + sz * roofHalf, y0 - a.y, f + 0.2, sx === 1 && sz === 1 ? 0.62 : 0);
        }
      }
    }
  }
}

/** The covered walk ring at the temple's foot: paved terrace, posts, a leaning tiled shed. */
function ambulatory(world: VoxelWorld, a: BuilderArgs, storeyHalf: number): void {
  const out = storeyHalf + 4;
  pavingSlab(world, a, a.x, a.z, out, a.y + 1, 0.05);
  const postRing = out - 1;
  for (let d = -postRing; d <= postRing; d++) {
    for (const [x, z] of [
      [a.x + d, a.z - postRing],
      [a.x + d, a.z + postRing],
      [a.x - postRing, a.z + d],
      [a.x + postRing, a.z + d],
    ] as const) {
      if (d % 4 !== 0 && Math.abs(d) !== postRing) continue;
      for (let y = a.y + 2; y <= a.y + 5; y++) {
        world.set(x, y, z, y === a.y + 2 ? C.marbleDeep : C.vermilionDeep, {
          t: reveal(a, 0.1),
          dur: FADE,
        });
      }
    }
  }
  // Two stepping rings of tile, sloping down and out from the temple wall to the outer eave.
  for (const [r, y, k] of [
    [out, a.y + 5, 1],
    [out - 1, a.y + 5, 0.94],
    [storeyHalf + 1, a.y + 6, 1.02],
    [storeyHalf + 2, a.y + 6, 0.92],
  ] as const) {
    for (let d = -r; d <= r; d++) {
      for (const [x, z] of [
        [a.x + d, a.z - r],
        [a.x + d, a.z + r],
        [a.x - r, a.z + d],
        [a.x + r, a.z + d],
      ] as const) {
        const rib = ((x + z + 400) & 1) === 0 ? C.tile : C.tileRim;
        world.set(x, y, z, shade(rib, k), { t: reveal(a, 0.16), dur: FADE });
      }
    }
  }
  // A small hip pavilion at each corner of the walk.
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      curvedRoof(world, a, {
        cx: a.x + sx * out,
        cz: a.z + sz * out,
        hx: 3,
        hz: 3,
        y0: a.y + 6,
        rise: 2,
        lift: 2,
        f0: 0.2,
        f1: 0.24,
        seed: a.seed + 61 + 5 * (sx + sz),
      });
    }
  }
}

/**
 * The finial, set on the ridge of the topmost roof: a lotus base, nine stacked rings, the crossed
 * shakujo arms, a jewel and the flame pearl at the tip. Its height is capped by the lattice row of
 * `PAGODA.topY`, the camera's ceiling, so the spiral beat always finds the same crown.
 */
export function finalSpire(world: VoxelWorld, a: BuilderArgs): void {
  const want = int(a, 'h', 18, 12, 24);
  const ceiling = Math.min(fineRow(PAGODA.topY), world.sy - 1);
  const h = Math.max(4, Math.min(want, ceiling - a.y));
  const crown = a.y + h;
  // Every cell of the finial passes through this: nothing may sit above the crown row, whatever
  // `h` asks for, so the camera ceiling always holds.
  const put = (x: number, y: number, z: number, c: number, f: number, glow = -1): void => {
    if (y > crown || y > ceiling) return;
    world.set(
      x,
      y,
      z,
      c,
      glow < 0 ? { t: reveal(a, f), dur: FADE } : { kind: Kind.Glow, glow, t: reveal(a, f), dur: FADE },
    );
  };

  // Lotus base: a marble calyx and two crowns of petals.
  for (let k = 0; k < 3; k++) {
    const r = 2.4 - k * 0.6;
    const y = a.y + k;
    for (let dx = -3; dx <= 3; dx++) {
      for (let dz = -3; dz <= 3; dz++) {
        if (Math.hypot(dx, dz) > r) continue;
        const petal = Math.abs(dx) === Math.abs(dz);
        put(a.x + dx, y, a.z + dz, shade(petal ? C.goldLite : C.gold, 0.86 + 0.1 * k), 0.82 + 0.02 * k);
      }
    }
  }

  // Nine stacked rings, wide to narrow.
  const ringLo = a.y + 3;
  const ringHi = a.y + Math.max(3, h - 6);
  for (let k = 0; k < 9; k++) {
    const y = ringLo + Math.round((k * (ringHi - ringLo)) / 8);
    const r = k < 5 ? 2 : 1;
    for (let dx = -r; dx <= r; dx++) {
      for (let dz = -r; dz <= r; dz++) {
        if (Math.abs(dx) !== r && Math.abs(dz) !== r) continue;
        put(a.x + dx, y, a.z + dz, k % 2 === 0 ? C.gilt : C.goldPale, 0.88 + 0.03 * (k / 8));
      }
    }
  }

  // The mast, then the crossed shakujo arms that spread beneath the jewel.
  const jewel = crown - 3;
  for (let y = a.y + 1; y <= crown; y++) {
    put(a.x, y, a.z, y > jewel ? C.goldPale : C.gold, 0.9);
  }
  const armRow = ringHi + 2;
  const cross = Math.min(Math.min(3, Math.max(2, Math.round(h * 0.22))), crown - 1 - armRow);
  for (let k = -cross; k <= cross; k++) {
    put(a.x + k, armRow + Math.abs(k), a.z, C.goldPale, 0.93);
    put(a.x, armRow + Math.abs(k), a.z + k, C.goldLite, 0.93);
  }

  put(a.x, jewel, a.z, C.lanternCore, 0.98, 0.8);
  put(a.x, crown, a.z, C.pearl, 1, 1);
}

/**
 * The bell house: a post-and-beam tower on a one-cell plinth, open on every side so the tie beams
 * read, with an outward-sweeping hipped roof over each floor and the bell hung under the top eave.
 * Everything scales off `scale`, which is what lets it fit the narrow ring between podium and wall.
 */
export function bellTower(world: VoxelWorld, a: BuilderArgs): void {
  const floors = int(a, 'floors', 2, 1, 3);
  const scale = Math.max(0.25, Math.min(1, opt(a, 'scale', 0.34)));
  const side = Math.max(7, Math.round(44 * scale));
  const half = Math.floor(side / 2);
  const floorH = Math.max(6, Math.round(20 * scale));
  const roofRise = Math.max(3, Math.round(4 * scale) + 1);
  const picket = 2 + (dice(a)() > 0.5 ? 1 : 0);

  stoneSteps(world, a, a.x, a.z, half, a.y, 1, 0.02, 0.02);
  let y = a.y + 1;
  let beam = y;
  for (let fl = 0; fl < floors; fl++) {
    const f = 0.06 + 0.24 * fl;
    const h = Math.max(2, half - fl);
    for (const sx of [-1, 1]) {
      for (const sz of [-1, 1]) {
        for (let k = 0; k < floorH; k++) {
          world.set(a.x + sx * h, y + k, a.z + sz * h, k === floorH - 1 ? C.ironwoodLite : C.vermilionDeep, {
            t: reveal(a, f),
            dur: FADE,
          });
        }
      }
    }
    // Open sides: a rail picket every other cell, and two tie beams run the full width.
    for (let dln = -h; dln <= h; dln++) {
      for (const [x, z] of [
        [a.x + dln, a.z - h],
        [a.x + dln, a.z + h],
        [a.x - h, a.z + dln],
        [a.x + h, a.z + dln],
      ] as const) {
        world.set(x, y + floorH - 2, z, C.woodDark, { t: reveal(a, f + 0.05), dur: FADE });
        world.set(x, y + floorH - 4, z, C.wood, { t: reveal(a, f + 0.05), dur: FADE });
        if (dln % picket === 0) {
          world.set(x, y, z, tone(a, C.marble, x, y, z, 0.92), { t: reveal(a, f), dur: FADE });
          world.set(x, y + 1, z, shade(C.vermilion, 0.86), { t: reveal(a, f), dur: FADE });
          world.set(x, y + 2, z, C.marbleLite, { t: reveal(a, f), dur: FADE });
        }
      }
    }
    beam = y + floorH - 2;
    brackets(world, a, a.x, a.z, h, y + floorH - 1, 2, f + 0.08);
    curvedRoof(world, a, {
      cx: a.x,
      cz: a.z,
      hx: h + 2,
      hz: h + 2,
      y0: y + floorH,
      rise: roofRise,
      lift: 2,
      f0: f + 0.1,
      f1: f + 0.18,
      seed: a.seed + 13 * fl,
    });
    y = y + floorH + roofRise + 2;
  }

  // The bell hangs from the top tie beam; one lantern lights the beam at the front rail.
  hangingBell(world, a, a.x, beam - 1, a.z, beam - a.y, 0.72, 0);
  world.set(a.x, beam + 1, a.z + Math.max(2, half - (floors - 1)), C.lanternCore, {
    kind: Kind.Glow,
    glow: 0.7,
    t: reveal(a, 0.95),
    dur: 0.6,
  });
}

/**
 * The cloister: a colonnade running +x, a paved strip nine cells deep, paired posts every four
 * cells along both long edges, a lintel beam and rafter grid, and one small curved roof per bay.
 * Bays reveal outward from the first.
 */
export function cloister(world: VoxelWorld, a: BuilderArgs): void {
  const bays = int(a, 'bays', 6, 3, 10);
  const bay = int(a, 'bay', 8, 6, 12);
  const h = int(a, 'h', 16, 10, 22);
  const len = bays * bay;
  const depth = 4;

  for (let i = 0; i <= len; i++) {
    for (let dz = -depth; dz <= depth; dz++) {
      const x = a.x + i;
      const joint = i % 4 === 0 || (dz + 4) % 4 === 0;
      world.set(x, a.y, a.z + dz, tone(a, joint ? C.marbleDeep : C.marbleLite, x, a.y, a.z + dz, joint ? 0.84 : 1), {
        t: reveal(a, 0.02),
        dur: FADE,
      });
    }
  }

  for (let i = 0; i <= len; i += 4) {
    const f = 0.06 + 0.5 * (i / len) + (i % 8 === 0 ? 0 : 0.03);
    for (const sz of [-1, 1]) {
      for (const dz of [depth, depth - 1]) {
        const z = a.z + sz * dz;
        for (let y = a.y + 1; y <= a.y + h - 3; y++) {
          world.set(a.x + i, y, z, y === a.y + 1 ? C.marbleDeep : C.vermilionDeep, {
            t: reveal(a, f),
            dur: FADE,
          });
        }
      }
    }
  }

  // Lintel beams and the rafter grid they carry.
  for (let i = 0; i <= len; i++) {
    const f = 0.3 + 0.4 * (i / len);
    for (const sz of [-1, 1]) {
      world.box(a.x + i, a.y + h - 2, a.z + sz * depth, a.x + i, a.y + h - 2, a.z + sz * (depth - 1), C.woodDark, {
        t: reveal(a, f),
        dur: FADE,
      });
      world.box(a.x + i, a.y + h - 3, a.z + sz * depth, a.x + i, a.y + h - 3, a.z + sz * depth, C.wood, {
        t: reveal(a, f),
        dur: FADE,
      });
    }
    if (i % 2 === 0) {
      world.box(a.x + i, a.y + h - 1, a.z - depth, a.x + i, a.y + h - 1, a.z + depth, shade(C.ironwood, 1.1), {
        t: reveal(a, f + 0.02),
        dur: FADE,
      });
    }
  }

  for (let b = 0; b < bays; b++) {
    const f = 0.42 + 0.5 * (b / Math.max(1, bays - 1));
    curvedRoof(world, a, {
      cx: a.x + bay * b + Math.round(bay / 2),
      cz: a.z,
      hx: Math.round(bay / 2),
      hz: depth,
      y0: a.y + h,
      rise: 3,
      lift: 2,
      f0: f,
      f1: f + 0.06,
      seed: a.seed + 37 + 11 * b,
    });
  }
}

/**
 * The screened wall: a battered stone base, a plastered panel face with pilasters every eight
 * cells, a square lattice window in the middle, and a tiled cap with upturned hip roofs at both
 * ends. Three cells thick, running +x centred on `(a.x, a.z)`.
 */
export function spiritScreen(world: VoxelWorld, a: BuilderArgs): void {
  const width = int(a, 'width', 49, 21, 65);
  const h = int(a, 'h', 29, 15, 40);
  const halfW = Math.floor(width / 2);
  const x0 = a.x - halfW;
  const x1 = a.x + halfW;

  // Battered plinth: two rows five cells thick, four more at three.
  for (let y = a.y; y <= a.y + 5; y++) {
    const t = y <= a.y + 1 ? 2 : 1;
    for (let dz = -t; dz <= t; dz++) {
      for (let x = x0 - (t === 2 ? 1 : 0); x <= x1 + (t === 2 ? 1 : 0); x++) {
        world.set(x, y, a.z + dz, tone(a, y <= a.y + 1 ? C.stone : C.stoneLite, x, y, a.z + dz, 0.8 + 0.05 * (t === 2 ? 0 : 1)), {
          t: reveal(a, 0.02),
          dur: FADE,
        });
      }
    }
  }
  // Moulding course on top of the base.
  world.box(x0, a.y + 6, a.z - 2, x1, a.y + 6, a.z + 2, shade(C.marbleLite, 0.94), {
    t: reveal(a, 0.1),
    dur: FADE,
  });

  // Panel face with a framed square lattice window punched through the middle.
  const faceTop = a.y + h - 4;
  const wLo = a.y + 9;
  const wHi = Math.min(a.y + Math.min(h - 6, 20), a.y + 20);
  const winHalf = Math.min(4, Math.max(2, Math.round(h * 0.16)));
  for (let x = x0; x <= x1; x++) {
    for (let y = a.y + 7; y <= faceTop; y++) {
      const inWin = Math.abs(x - a.x) <= winHalf && y >= wLo && y <= wHi;
      for (let dz = -1; dz <= 1; dz++) {
        if (inWin) {
          // A two-cell grid of bars leaves a square of openings behind the frame.
          const bar = (x + 400) % 2 === 0 || (y + 400) % 2 === 0;
          if (dz === 0 && bar) {
            world.set(x, y, a.z + dz, C.woodDark, { t: reveal(a, 0.34), dur: FADE });
          }
          continue;
        }
        world.set(x, y, a.z + dz, tone(a, mixHex(C.paper, C.mist, 0.3), x, y, a.z + dz, 0.88 + 0.1 * ((y - a.y) % 3 === 0 ? 0 : 1)), {
          t: reveal(a, 0.16),
          dur: FADE,
        });
      }
    }
  }
  // Jamb, lintel and sill of the window opening.
  for (const s of [-1, 1]) {
    for (let y = wLo - 1; y <= wHi + 1; y++) {
      world.set(a.x + s * (winHalf + 1), y, a.z, C.ironwood, { t: reveal(a, 0.36), dur: FADE });
    }
  }
  world.box(a.x - winHalf - 1, wHi + 1, a.z - 2, a.x + winHalf + 1, wHi + 1, a.z + 2, C.ironwoodLite, {
    t: reveal(a, 0.36),
    dur: FADE,
  });
  world.box(a.x - winHalf - 1, wLo - 1, a.z - 2, a.x + winHalf + 1, wLo - 1, a.z + 2, C.marbleLite, {
    t: reveal(a, 0.34),
    dur: FADE,
  });

  // Pilasters every eight cells, one row proud of the face, capped — the window span stays clear.
  for (let x = x0; x <= x1; x += 8) {
    if (Math.abs(x - a.x) <= winHalf + 1) continue;
    for (let y = a.y + 6; y <= a.y + h - 2; y++) {
      for (let dz = -1; dz <= 1; dz++) {
        world.set(x, y, a.z + dz, y === a.y + h - 2 ? C.wood : y % 4 === 0 ? C.marbleDeep : C.marble, {
          t: reveal(a, 0.24),
          dur: FADE,
        });
      }
    }
  }

  tileCap(world, a, x0 - 1, x1 + 1, a.z, a.y + h - 3, 2, 0.4);
  for (const s of [-1, 1]) {
    curvedRoof(world, a, {
      cx: a.x + s * (halfW - 3),
      cz: a.z,
      hx: 3,
      hz: 4,
      y0: a.y + h - 2,
      rise: 3,
      lift: 2,
      f0: 0.46,
      f1: 0.52,
      seed: a.seed + 83 + 3 * s,
    });
  }
}

/**
 * The lantern range: a timber beam on forks running +x, with `count` paper lanterns hung at
 * `pitch` cells. Each lantern is a one-cell hanger over exactly one glowing cell, all of them
 * swaying, so the rack lights `count` sprites and no more.
 */
export function lanternRack(world: VoxelWorld, a: BuilderArgs): void {
  const count = int(a, 'count', 6, 3, 8);
  const pitch = int(a, 'pitch', 12, 8, 18);
  const h = int(a, 'h', 14, 10, 20);
  const last = a.x + pitch * (count - 1);

  // Forks at each end and under every third lantern.
  for (let i = 0; i < count; i += 3) {
    const x = a.x + pitch * i;
    for (const sz of [-1, 1]) {
      for (let y = a.y; y <= a.y + h - 2; y++) {
        world.set(x, y, a.z + sz, y === a.y ? C.marbleDeep : C.ironwood, { t: reveal(a, 0.03), dur: FADE });
      }
    }
    world.box(x - 1, a.y + h - 2, a.z - 1, x + 1, a.y + h - 2, a.z + 1, C.woodDark, {
      t: reveal(a, 0.06),
      dur: FADE,
    });
  }
  // The twin beams.
  world.box(a.x - 2, a.y + h - 1, a.z, last + 2, a.y + h - 1, a.z, C.ironwoodLite, {
    t: reveal(a, 0.1),
    dur: FADE,
  });
  world.box(a.x - 2, a.y + h, a.z - 1, last + 2, a.y + h, a.z + 1, C.woodDark, {
    t: reveal(a, 0.14),
    dur: FADE,
  });

  for (let i = 0; i < count; i++) {
    const x = a.x + pitch * i;
    const f = 0.3 + 0.5 * (i / Math.max(1, count - 1));
    world.set(x, a.y + h - 2, a.z, C.ironwood, {
      t: reveal(a, f),
      dur: FADE,
      sway: swayAt(h - 2, h, 0.5),
    });
    world.set(x, a.y + h - 3, a.z, C.paper, {
      kind: Kind.Glow,
      glow: 1,
      t: reveal(a, f + 0.05),
      dur: FADE,
      sway: swayAt(h - 3, h, 0.5),
    });
    world.set(x, a.y + h - 4, a.z, C.vermilionDeep, {
      t: reveal(a, f + 0.08),
      dur: FADE,
      sway: swayAt(h - 4, h, 0.5),
    });
  }
}

/**
 * The moon bridge: an arched causeway along +x whose deck springs from `a.y` and crowns `arch`
 * rows up at the middle. Two rows thick, planked in alternating tone every two cells, railed with
 * vermilion caps, landed on a battered pier behind each end (authored upward only) and marked at
 * the crown with a pair of carved newels. One stone lantern standard at each head. Stone, so
 * nothing here sways.
 */
export function moonBridge(world: VoxelWorld, a: BuilderArgs): void {
  const span = int(a, 'span', 72, 40, 110);
  const arch = int(a, 'arch', 9, 4, 16);
  const width = int(a, 'width', 7, 5, 11);
  const hw = Math.floor(width / 2);
  const deckRow = (i: number) => a.y + Math.round(arch * Math.sin((Math.PI * i) / span));

  // Piers behind each abutment: battered footing, then coursed up to the deck's soffit.
  for (const end of [0, span] as const) {
    const step = end === 0 ? -1 : 1;
    for (let d = 1; d <= 2; d++) {
      const col = a.x + end + step * d;
      const top = deckRow(end === 0 ? d : span - d);
      for (let y = a.y; y <= top; y++) {
        const shoulder = y <= a.y + 1 ? 1 : 0;
        for (let dz = -hw - 1 - shoulder; dz <= hw + 1 + shoulder; dz++) {
          world.set(
            col,
            y,
            a.z + dz,
            tone(a, y === a.y ? C.inkSoft : C.stone, col, y, a.z + dz, 0.8 + 0.06 * (y & 1)),
            { t: reveal(a, 0.03), dur: FADE },
          );
        }
      }
    }
  }

  // The arched deck: pale planks alternating every two cells over a dark stringer course.
  for (let i = 0; i <= span; i++) {
    const y = deckRow(i);
    const plank = (Math.floor(i / 2) & 1) === 0;
    for (let dz = -hw; dz <= hw; dz++) {
      world.set(a.x + i, y, a.z + dz, tone(a, plank ? C.lacquerLite : C.vermilionDeep, a.x + i, y, a.z + dz, plank ? 0.94 : 0.86), {
        t: reveal(a, 0.1 + 0.4 * (i / span)),
        dur: FADE,
      });
      if (y > a.y) {
        world.set(a.x + i, y - 1, a.z + dz, shade(C.ironwood, 0.9), {
          t: reveal(a, 0.08 + 0.4 * (i / span)),
          dur: FADE,
        });
      }
    }
  }

  // Rail: a post every four cells under a handrail that follows the arch.
  for (let i = 0; i <= span; i++) {
    const y = deckRow(i);
    for (const sz of [-1, 1]) {
      if (i % 4 === 0) {
        for (const k of [1, 2]) {
          world.set(a.x + i, y + k, a.z + sz * hw, k === 1 ? C.marbleDeep : C.marble, {
            t: reveal(a, 0.3 + 0.3 * (i / span)),
            dur: FADE,
          });
        }
      }
      world.set(a.x + i, y + 3, a.z + sz * hw, (i + 400) % 4 === 0 ? C.gilt : C.vermilion, {
        t: reveal(a, 0.44 + 0.3 * (i / span)),
        dur: FADE,
      });
    }
  }

  // Crown newels, and one lantern standard at each head, planted on the pier shoulder.
  const mid = Math.round(span / 2);
  for (const sz of [-1, 1]) {
    const y = deckRow(mid);
    for (let k = 1; k <= 4; k++) {
      world.set(a.x + mid, y + k, a.z + sz * (hw + 1), k === 4 ? C.gilt : C.marbleLite, {
        t: reveal(a, 0.6),
        dur: FADE,
      });
    }
  }
  const stdH = Math.max(5, Math.round(arch * 0.7));
  for (const end of [0, span] as const) {
    const step = end === 0 ? -1 : 1;
    lanternStandard(
      world,
      a,
      a.x + end + step * 2,
      a.z + hw + 2,
      deckRow(end === 0 ? 2 : span - 2) + 1,
      stdH,
      0.72,
      0.85,
    );
  }
}