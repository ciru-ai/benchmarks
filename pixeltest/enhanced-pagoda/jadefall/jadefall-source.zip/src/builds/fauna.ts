/**
 * JADEFALL 翠瀑 — fauna: the movable models the composer drives along curves.
 *
 * Every builder here is a model factory: it fills a small private `VoxelWorld` authored on a
 * **0.25 world-unit lattice** (4 cells per world unit; the composer mounts the mesh at that cell
 * size), and returns that pivot in cells plus the reveal length. Models face their own **+x** with
 * the head at high x, so the composer can yaw +x onto the travel axis and bank around `center`.
 * Inside a model `y` is the vertical row index (feet / belly at low y) and `z` is the lateral
 * axis, symmetric about the model's centre line.
 *
 * Pure voxel writers: no THREE, no clock, no `Math.random` — all variation comes from `rng(seed)`
 * and `hash3`. Reveal time is authored from 0 (support) to `dt * 0.72` (ornament) with `dur: FADE`
 * — the same window `reveal()` produces for a builder pass at `a.t = 0`; the composer shifts these
 * clocks with `shiftReveal` when it schedules the beat.
 */

import { VoxelWorld, Kind } from '../core/VoxelWorld';
import { C, hash3, mixHex, rng, shade } from '../core/palette';
import { FADE, type MovableModel } from './types';

const clamp01 = (v: number): number => (v < 0 ? 0 : v > 1 ? 1 : v);

/** `set` bound to one model clock: `f` in 0..1 orders support first, ornament last. */
function putOn(
  world: VoxelWorld,
  dt: number,
): (x: number, y: number, z: number, hex: number, f: number, glow?: number) => void {
  return (x, y, z, hex, f, glow = 0): void => {
    const t = clamp01(f) * dt * 0.72;
    world.set(x, y, z, hex, glow > 0 ? { kind: Kind.Glow, glow, t, dur: FADE } : { t, dur: FADE });
  };
}

/** Per-cell brightness jitter, keyed on the model seed so scales never read as plastic. */
function tint(hex: number, x: number, y: number, z: number, seed: number, amount = 0.08): number {
  return shade(hex, 1 + (hash3(x, y, z, seed) - 0.5) * 2 * amount);
}

/**
 * Piecewise-linear sample of a body profile given as `[u, halfExtent]` stations with `u` running 0
 * at the tail to 1 at the snout; clamped outside the station range.
 */
function profile(stations: readonly (readonly [number, number])[], u: number): number {
  const first = stations[0];
  const last = stations[stations.length - 1];
  if (u <= first[0]) return first[1];
  if (u >= last[0]) return last[1];
  for (let i = 1; i < stations.length; i++) {
    const [u1, v1] = stations[i];
    if (u <= u1) {
      const [u0, v0] = stations[i - 1];
      return v0 + ((v1 - v0) * (u - u0)) / (u1 - u0);
    }
  }
  return last[1];
}

/** True when the offset `(a, b)` lies inside an ellipse of semi-axes `ra` × `rb`. */
function inEllipse(a: number, b: number, ra: number, rb: number): boolean {
  if (ra <= 0 || rb <= 0) return false;
  return (a * a) / (ra * ra) + (b * b) / (rb * rb) <= 1.0001;
}

/** Koi cross-section half-width (cells, lateral), narrow peduncle → girth behind the head → snout. */
const KOI_HALF_W: readonly (readonly [number, number])[] = [
  [0, 0.1],
  [0.22, 1.2],
  [0.56, 2.1],
  [0.84, 1.9],
  [1, 0.95],
];

/** Koi cross-section half-depth (cells, vertical). */
const KOI_HALF_D: readonly (readonly [number, number])[] = [
  [0, 0.7],
  [0.3, 1.6],
  [0.6, 2.1],
  [0.86, 1.8],
  [1, 1.3],
];

/** Fry half-width / half-depth; the rounding of the profile *is* the taper. */
const FRY_HALF_W: readonly (readonly [number, number])[] = [
  [0, 0.3],
  [0.4, 1.45],
  [0.78, 1.3],
  [1, 0.9],
];
const FRY_HALF_D: readonly (readonly [number, number])[] = [
  [0, 0.4],
  [0.38, 1.45],
  [0.8, 1.2],
  [1, 0.7],
];

/**
 * Koi — the shoal fish the composer herds across the lake and up the fall.
 *
 * Knobs: `seed` fixes body length (12-17 body cells) and scatters the coat patches, so two seeds
 * never give the same fish. `coat` picks the variety, default 0, clamped to 0..5 —
 * 0 kohaku (`koiWhite` + `koiRed`/`koiOrange`), 1 taisho (white + red + `koiBlack`), 2 showa
 * (black + red + white), 3 ogon (solid `koiGold`), 4 platinum (`koiWhite` + `koiSilver`),
 * 5 sakura (`koiCream` + `plumLite`). Fractional or out-of-range values are truncated/clamped.
 *
 * Anatomy: torpedo body with a shoulder girth and chamfered corners, a one-cell-wide caudal
 * peduncle, a forked caudal plate 1 cell thick, paired pectorals sweeping back and down, two
 * dorsal sails (long over the girth, short over the peduncle), an eye pair and a mouth barbel
 * pair. Cross-section 5 wide × 5 deep at the girth; fin edges one tone lighter; hidden core in a
 * darker tone. No glow cells — the composer lights the shoal externally.
 *
 * Grid 22 × 10 × 9 cells. Filled model: 21 long (snout to barbel tips; 19 to the tail), 7 wide
 * with the pectorals, 8 tall with the dorsal sails = at most 5.25 × 2.0 × 1.75 world units at
 * 0.25 u/cell; roughly 300 cells. Pivot `[(headX + 1) / 2, 4, 4]` — mid-length at body
 * mid-height. Reveal `dt` 0.4 s.
 */
export function makeKoi(seed: number, coat = 0): MovableModel {
  const sx = 22;
  const sy = 10;
  const sz = 9;
  const world = new VoxelWorld(sx, sy, sz);
  const put = putOn(world, 0.4);
  const d = rng((seed >>> 0) * 2654435761);

  const variety = Math.min(5, Math.max(0, Math.trunc(coat)));
  const coatTable: readonly { base: number; patch: number; alt: number; fin: number }[] = [
    { base: C.koiWhite, patch: C.koiRed, alt: C.koiOrange, fin: C.koiCream },
    { base: C.koiWhite, patch: C.koiRed, alt: C.koiBlack, fin: C.koiCream },
    { base: C.koiBlack, patch: C.koiRed, alt: C.koiWhite, fin: shade(C.koiCream, 0.7) },
    { base: C.koiGold, patch: C.koiGold, alt: C.goldLite, fin: C.goldPale },
    { base: C.koiWhite, patch: C.koiSilver, alt: C.mist, fin: C.pearl },
    { base: C.koiCream, patch: C.plumLite, alt: C.plum, fin: C.pearl },
  ];
  const c = coatTable[variety];

  const body = 12 + ((seed >>> 0) % 6); // 12..17 body cells
  const root = 2; // first body cell: the caudal peduncle
  const hx = root + body - 1; // snout cell, 13..18
  const cy = 4; // mid body height (pivot y)
  const cz = 4; // centre line (pivot z)
  const uAt = (x: number): number => (x - root + 1) / (body + 1);
  const hwAt = (x: number): number => Math.max(0, Math.round(profile(KOI_HALF_W, uAt(x))));
  const hdAt = (x: number): number => Math.max(1, Math.round(profile(KOI_HALF_D, uAt(x))));

  // Coat patches: 3-5 seeded blobs in body space; even indices take the coat colour, odd the
  // secondary. Positions and radii come from the seed stream, so no two fish match.
  const patches: { x: number; dz: number; dy: number; r: number }[] = [];
  const nPatch = 3 + Math.floor(d() * 3);
  for (let i = 0; i < nPatch; i++) {
    patches.push({
      x: root + 1 + Math.floor(d() * Math.max(1, body - 2)),
      dz: Math.floor(d() * 5) - 2,
      dy: Math.floor(d() * 5) - 2,
      r: 1.5 + d() * 1.4,
    });
  }

  // Body: the girth lands first and both ends follow; the four section corners are chamfered.
  for (let x = root; x <= hx; x++) {
    const hw = hwAt(x);
    const hd = hdAt(x);
    const fBody = 0.16 + 0.3 * (Math.abs(uAt(x) - 0.56) / 0.44);
    for (let dz = -hw; dz <= hw; dz++) {
      for (let dy = -hd; dy <= hd; dy++) {
        if (Math.abs(dz) === hw && Math.abs(dy) === hd) continue;
        const core = Math.abs(dz) <= hw - 2 && Math.abs(dy) <= hd - 2;
        if (core) {
          put(x, cy + dy, cz, shade(c.base, 0.55), fBody);
          continue;
        }
        let hex = dy === hd ? mixHex(c.base, C.mist, 0.14) : c.base;
        if (variety !== 3) {
          for (let p = 0; p < patches.length; p++) {
            const q = patches[p];
            const kx = x - q.x;
            const ky = cy + dy - (cy + q.dy);
            const kz = cz + dz - (cz + q.dz);
            if (kx * kx + ky * ky + kz * kz <= q.r * q.r) {
              hex = p % 2 ? c.alt : c.patch;
              break;
            }
          }
        }
        put(x, cy + dy, cz + dz, tint(hex, x, dy, dz, seed, 0.07), fBody + 0.03 * (hd - dy));
      }
    }
  }

  // Eyes on the widest part of the skull, one cell in from each flank.
  const eyeZ = hwAt(hx - 1);
  put(hx - 1, cy + 1, cz - eyeZ, C.inkSoft, 0.74);
  put(hx - 1, cy + 1, cz + eyeZ, C.inkSoft, 0.74);

  // Caudal fin: a flat plate one cell thick on the centre line, forked at the trailing edge.
  for (let dy = -2; dy <= 2; dy++) {
    put(root - 1, cy + dy, cz, mixHex(c.fin, C.pearl, 0.08 * Math.abs(dy)), 0.52);
  }
  for (let dy = -3; dy <= 3; dy++) {
    if (dy === 0) continue; // the fork
    put(root - 2, cy + dy, cz, mixHex(c.fin, C.pearl, 0.14 + 0.07 * Math.abs(dy)), 0.58);
  }

  // Pectoral fins: paired plates sweeping back and down from the shoulder girdle.
  const finX = hx - 3;
  for (const side of [-1, 1]) {
    for (let k = 0; k < 3; k++) {
      const edge = k === 2 ? 0.34 : 0.08;
      put(finX - k, cy - 1 - (k === 2 ? 1 : 0), cz + side * (1 + k), mixHex(c.fin, C.pearl, edge), 0.64 + 0.02 * k);
    }
  }

  // Two dorsal sails: the long one over the girth, the short one over the peduncle.
  const sail = (atX: number, heights: readonly number[], f: number): void => {
    for (let i = 0; i < heights.length; i++) {
      const x = atX + i;
      const base = cy + hdAt(x);
      for (let y = base; y <= base + heights[i]; y++) {
        const rim = y === base + heights[i] ? 0.32 : 0.06;
        put(x, y, cz, mixHex(c.fin, C.pearl, rim), f + 0.02 * i);
      }
    }
  };
  sail(root - 1 + Math.round(0.56 * (body + 1)), [1, 2, 2, 1], 0.6);
  sail(root + 1, [1, 1], 0.68);

  // Mouth barbels, the last thing to arrive.
  for (const side of [-1, 1]) {
    put(hx + 1, cy - 1, cz + side, shade(c.base, 0.72), 0.86);
    put(hx + 2, cy - 2, cz + side * 2, mixHex(c.fin, C.pearl, 0.3), 0.9);
  }

  return { world, center: [(hx + 1) / 2, cy, cz], dt: 0.4 };
}

/**
 * Fry — the baitfish that travel in numbers, so this one stays cheap.
 *
 * Knobs: `seed` only; it sets the overall length — 5-7 cells including the forked tail — and
 * nothing else. A tapering body of `koiSilver` with a `mist` back, a dark eye cell on each side
 * of the blunt head, and a two-vein forked tail plate 1 cell thick. No glow cells.
 *
 * Grid 9 × 6 × 5 cells. Filled model: 7-9 long, 3 wide, 4 tall = at most 2.25 × 1.0 × 0.75 world
 * units at 0.25 u/cell; roughly 30 cells. Pivot `[(headX + 1) / 2, 2, 2]` at body mid-height.
 * Reveal `dt` 0.4 s.
 */
export function makeFry(seed: number): MovableModel {
  const sx = 9;
  const sy = 6;
  const sz = 5;
  const world = new VoxelWorld(sx, sy, sz);
  const put = putOn(world, 0.4);

  const body = 4 + ((seed >>> 0) % 3); // 4..6 body cells
  const root = 2; // first body cell behind the tail
  const hx = root + body - 1; // 5..7
  const cy = 2;
  const cz = 2;
  const uAt = (x: number): number => (x - root + 1) / (body + 1);

  for (let x = root; x <= hx; x++) {
    const hw = Math.max(0, Math.round(profile(FRY_HALF_W, uAt(x))));
    const hd = Math.max(0, Math.round(profile(FRY_HALF_D, uAt(x))));
    const f = 0.18 + 0.24 * (1 - uAt(x));
    for (let dz = -hw; dz <= hw; dz++) {
      for (let dy = -hd; dy <= hd; dy++) {
        const back = dy === hd && hd > 0;
        put(x, cy + dy, cz + dz, back ? C.mist : C.koiSilver, f);
      }
    }
  }

  // Dark eyes on the head, then the forked tail.
  for (const side of [-1, 1]) put(hx, cy + 1, cz + side, C.inkSoft, 0.6);
  for (let dy = -1; dy <= 1; dy++) put(root - 1, cy + dy, cz, C.koiSilver, 0.4);
  for (const dy of [-2, -1, 1, 2]) put(root - 2, cy + dy, cz, mixHex(C.koiSilver, C.pearl, 0.24), 0.48);

  return { world, center: [(hx + 1) / 2, cy, cz], dt: 0.4 };
}

/**
 * Turtle — the slow shell that crosses the pool under the moon bridge.
 *
 * Knobs: `seed` only: shell length 7-9 cells (11-13 overall with head and tail), and the scute
 * pattern rotates with `(seed >> 1) % 3`.
 *
 * Anatomy: elliptical plan, `jadeDeep` dome with a lighter scute read — a vertebral row of
 * `jadeLite`/`jade` down the centre, a `jadePale` crown, a `jade` rim, a dark hidden core and a
 * `sand` plastron — plus a three-cell `jade` head with a dark eye pair, four paddling flippers
 * (front pair long, rear pair short) and a stub tail. No glow cells.
 *
 * Grid 15 × 11 × 10 cells. Filled model: 11-13 long, 9 wide with the flippers, 6 tall
 * = at most 3.25 × 1.5 × 2.25 world units at 0.25 u/cell; roughly 220 cells. Pivot `[6, 4, 5]` —
 * shell centre at mid-height, so the model banks as it swims. Reveal `dt` 0.4 s.
 */
export function makeTurtle(seed: number): MovableModel {
  const sx = 15;
  const sy = 11;
  const sz = 10;
  const world = new VoxelWorld(sx, sy, sz);
  const put = putOn(world, 0.4);

  const shell = 7 + ((seed >>> 0) % 3); // 7..9 cells along x
  const tailX = 0;
  const x0 = 1; // first shell cell
  const x1 = x0 + shell - 1; // last shell cell, 7..9
  const mid = (x0 + x1) / 2;
  const cy = 4; // shell mid-height (pivot y)
  const cz = 5; // centre line (pivot z)
  const floor = cy - 1; // plastron row
  const ra = shell / 2 + 0.5; // plan semi-axis along x
  const rb = 3; // plan semi-axis across
  const hMax = 3; // dome rise above the plastron
  const spin = ((seed >>> 1) % 3) | 0;

  // Flippers first — they are the support the shell lands on. Front pair long, rear pair short.
  for (const side of [-1, 1]) {
    for (let k = 0; k < 4; k++) {
      const tip = k === 3;
      put(x0 + 1 + k, cy - 1 - (tip ? 1 : 0), cz + side * (2 + Math.floor(k / 2)), tip ? mixHex(C.jade, C.jadePale, 0.3) : C.jade, 0.14);
    }
    for (let k = 0; k < 2; k++) {
      put(x1 - 1 - k, cy - 1, cz + side * (2 + k), k === 1 ? mixHex(C.jade, C.jadePale, 0.3) : C.jade, 0.16);
    }
  }

  // Shell: plastron plate, then every column of the dome filling up from its own floor.
  for (let x = x0; x <= x1; x++) {
    for (let dz = -rb; dz <= rb; dz++) {
      if (!inEllipse(x - mid, dz, ra, rb)) continue;
      const rim = !inEllipse(x - mid, dz, ra - 1, rb - 1);
      const s = Math.pow((x - mid) / ra, 2) + Math.pow(dz / rb, 2);
      const h = rim ? 1 : Math.max(1, Math.round(hMax * Math.sqrt(Math.max(0, 1 - s))));
      put(x, floor, cz + dz, C.sand, 0.2);
      for (let y = floor + 1; y <= floor + h; y++) {
        const crown = h >= hMax - 1 && y === floor + h;
        let hex: number;
        if (y < floor + h) hex = shade(C.jadeDeep, 0.55);
        else if (crown) hex = C.jadePale;
        else if (rim) hex = C.jade;
        else if (dz === 0) hex = (x + spin) % 2 === 0 ? C.jadeLite : C.jade;
        else hex = (x + Math.abs(dz) + spin) % 3 === 0 ? C.jade : C.jadeDeep;
        put(x, y, cz + dz, hex, 0.24 + (0.26 * (y - floor)) / hMax);
      }
    }
  }

  // Neck and head out of the front, eyes last; stub tail out of the back.
  for (let k = 1; k <= 3; k++) {
    const x = x1 + k;
    const neck = k < 3;
    const half = neck ? 0 : 1;
    for (let dz = -half; dz <= half; dz++) {
      put(x, cy + (neck ? 0 : 1), cz + dz, neck ? shade(C.jade, 0.88) : C.jade, 0.5 + 0.06 * k);
    }
  }
  for (const side of [-1, 1]) put(x1 + 3, cy + 2, cz + side, C.inkSoft, 0.8);
  put(tailX, floor + 1, cz, shade(C.jade, 0.7), 0.46);

  return { world, center: [6, cy, cz], dt: 0.4 };
}

/** Dorsal flank-fin heights for one segment, station 0..8 along the 9-cell body ring. */
const DRAGON_FIN: readonly number[] = [1, 2, 3, 3, 2, 2, 1, 1, 1];

/** Dorsal ridge spikes of one segment, `[cell x, spike height]`; identical on every ring. */
const DRAGON_SPIKES: readonly (readonly [number, number])[] = [
  [1, 2],
  [3, 3],
  [5, 3],
  [7, 2],
];

/**
 * Dragon segment — one ring of the coil that climbs the padoga. Chain these end to end: the
 * cross-section, the ridge and the flank fins are deliberately fixed so consecutive rings meet.
 *
 * Knobs: `seed` only, and it moves nothing but the grain of the scales — geometry is constant.
 *
 * Anatomy: a 9-cell body with a near-circular 7 × 7 cross-section of `dragonJade` over a darker
 * core, a `dragonBelly` underside (bottom row plus the row above it), a `dragonGold` dorsal ridge
 * of four spikes on the crest, and a flowing fin plate on each flank (two cells deep over the
 * middle stations, `jadePale` crest). Exactly 2 `Kind.Glow` cells (`jadePale`, glow 0.55) sit in
 * the notches between spikes as the ridge's luminous line.
 *
 * Grid 9 × 12 × 13 cells = 2.25 × 3.0 × 3.25 world units at 0.25 u/cell; roughly 340 cells.
 * Pivot `[4.5, 4, 6]` — mid-length at body mid-height, so a run of rings banks as one body.
 * Reveal `dt` 0.6 s.
 */
export function makeDragonSegment(seed: number): MovableModel {
  const sx = 9;
  const sy = 12;
  const sz = 13;
  const world = new VoxelWorld(sx, sy, sz);
  const put = putOn(world, 0.6);
  const cy = 4;
  const cz = 6;
  const r = 3; // fixed radius: every ring is the same size

  // Body: belly lands first, the back follows, the axis stays dark.
  for (let x = 0; x < sx; x++) {
    for (let dy = -r; dy <= r; dy++) {
      for (let dz = -r; dz <= r; dz++) {
        const d2 = dy * dy + dz * dz;
        if (d2 > r * r + 0.5) continue;
        const hex =
          dy <= -2
            ? tint(dy === -r ? shade(C.dragonBelly, 0.86) : C.dragonBelly, x, dy, dz, seed, 0.06)
            : d2 <= 2.5
              ? shade(C.dragonJade, 0.55)
              : tint(C.dragonJade, x, dy, dz, seed, 0.09);
        put(x, cy + dy, cz + dz, hex, 0.1 + 0.18 * ((dy + r) / (2 * r)));
      }
    }
  }

  // Gilt ridge and its two luminous cells.
  for (const [x, h] of DRAGON_SPIKES) {
    for (let k = 1; k <= h; k++) {
      const crest = k === h;
      put(x, cy + r + k, cz, crest ? mixHex(C.dragonGold, C.goldPale, 0.45) : C.dragonGold, 0.46 + 0.06 * k);
    }
  }
  for (const x of [2, 6]) put(x, cy + r + 1, cz, C.jadePale, 0.64, 0.55);

  // Flank fins: a swept plate on each side, deeper over the middle of the ring.
  for (const side of [-1, 1]) {
    for (let i = 0; i < DRAGON_FIN.length; i++) {
      const n = DRAGON_FIN[i];
      const deep = i === 2 || i === 3;
      for (let k = 0; k < n; k++) {
        const crest = k === n - 1;
        const f = 0.34 + 0.05 * i;
        put(i, cy + k, cz + side * (r + 1), crest ? mixHex(C.dragonJadeDeep, C.jadePale, 0.45) : tint(C.dragonJade, i, k, 7, seed, 0.08), f);
        if (deep) put(i, cy + k, cz + side * (r + 2), crest ? mixHex(C.jadePale, C.pearl, 0.3) : C.dragonJadeDeep, f + 0.02);
      }
    }
  }

  return { world, center: [4.5, cy, cz], dt: 0.6 };
}

/**
 * Dragon head — the lead of the coil. 18-22 cells long, the neck section at low x matching a
 * segment's 7 × 7 ring so the join is flush, the skull and snout running out to high x.
 *
 * Knobs: `seed` only: overall length 18 + (seed mod 5), and the grain of the scales.
 *
 * Anatomy: 7 × 7 neck, domed skull tapering to a snout with a dark nostril pair, an upper tooth
 * row of `pearl` hanging off the palate, and a lower jaw hinged at the back that drops up to four
 * rows toward the front so the mouth stands open, with its own tooth row. Two branching antler
 * horns in `dragonGold` rise from the brow and sweep back (a second tine forks out of each), a
 * `jadePale` mane ruff fans over the neck, and a whisker pair streams 8 cells backward from the
 * snout. Exactly 2 `Kind.Glow` cells (`pearl`, glow 1) are the eyes.
 *
 * Grid 26 × 20 × 14 cells = 6.5 × 5.0 × 3.5 world units at 0.25 u/cell; roughly 470 cells.
 * Pivot `[0.5, 6, 7]` — on the neck join, so the head leads forward of its anchor and nods about
 * the neck. Reveal `dt` 0.6 s.
 */
export function makeDragonHead(seed: number): MovableModel {
  const sx = 26;
  const sy = 20;
  const sz = 14;
  const world = new VoxelWorld(sx, sy, sz);
  const put = putOn(world, 0.6);
  const cy = 6;
  const cz = 7;
  const len = 18 + ((seed >>> 0) % 5); // 18..22 cells overall
  const neckEnd = 3;
  const brow = Math.round(len * 0.6) - 1; // last domed skull cell, 10..12
  const snout = len - 1; // front face, 17..21
  const palate = cy - 1; // floor of the upper jaw
  const hwAt = (x: number): number => (x <= brow ? (x - neckEnd <= 2 ? 3 : 2) : (x - brow) / (snout - brow) < 0.5 ? 2 : 1);
  const highAt = (x: number): number =>
    x <= neckEnd ? 3 : x <= brow ? 3 - Math.floor((x - neckEnd) / 4) : 2 - ((x - brow) / (snout - brow) > 0.75 ? 1 : 0);

  // Neck: the same 7 × 7 ring a segment ends on.
  for (let x = 0; x <= neckEnd; x++) {
    for (let dy = -3; dy <= 3; dy++) {
      for (let dz = -3; dz <= 3; dz++) {
        if (dy * dy + dz * dz > 9.5) continue;
        put(x, cy + dy, cz + dz, dy <= -2 ? C.dragonBelly : tint(C.dragonJade, x, dy, dz, seed, 0.09), 0.08 + 0.1 * (x / neckEnd));
      }
    }
  }

  // Skull and snout: dome over the palate, corners chamfered.
  for (let x = neckEnd + 1; x <= snout; x++) {
    const hw = hwAt(x);
    const high = highAt(x);
    const f = 0.14 + 0.2 * ((x - neckEnd) / (snout - neckEnd));
    for (let dz = -hw; dz <= hw; dz++) {
      for (let dy = -2; dy <= high; dy++) {
        if (Math.abs(dz) === hw && dy === high) continue;
        const hex =
          dy === high ? mixHex(C.dragonJade, C.jadePale, 0.22) : dy === -2 ? C.dragonBelly : tint(C.dragonJade, x, dy, dz, seed, 0.08);
        put(x, cy + dy, cz + dz, hex, f);
      }
    }
  }
  for (const side of [-1, 1]) put(snout, cy, cz + side * hwAt(snout), C.inkSoft, 0.9);

  // Lower jaw: hinged under the back of the skull, dropping forward to open the mouth.
  const jawStart = neckEnd + 2;
  for (let x = jawStart; x <= snout - 1; x++) {
    const drop = 1 + Math.min(3, Math.floor((x - jawStart) / 3));
    const jy = palate - 1 - drop;
    const hw = x < brow ? 2 : 1;
    for (let dz = -hw; dz <= hw; dz++) {
      put(x, jy, cz + dz, shade(C.dragonBelly, 0.88), 0.38);
      put(x, jy + 1, cz + dz, tint(C.dragonJade, x, jy + 1, dz, seed, 0.07), 0.4);
    }
    if ((x - jawStart) % 2 === 1) {
      for (const side of [-1, 1]) put(x, jy + 2, cz + side * hw, C.pearl, 0.84);
    }
  }
  // Upper tooth row off the palate.
  for (let x = brow + 1; x <= snout - 1; x += 2) {
    for (const side of [-1, 1]) put(x, palate - 1, cz + side, C.pearl, 0.8);
  }

  // Antlers: main beam sweeping up and back off the brow, one tine branching off each.
  for (const side of [-1, 1]) {
    for (let i = 0; i < 6; i++) {
      const x = brow - 1 - i;
      const y = cy + highAt(x) + 1 + i;
      put(x, y, cz + side * (2 + Math.floor(i / 3)), i === 5 ? mixHex(C.dragonGold, C.goldPale, 0.5) : C.dragonGold, 0.54 + 0.05 * i);
    }
    for (let k = 0; k < 3; k++) {
      const x = brow - 3 - k;
      put(x, cy + highAt(x) + 3 + k, cz + side * 4, k === 2 ? mixHex(C.dragonGold, C.goldPale, 0.4) : C.dragonGold, 0.6 + 0.05 * k);
    }
  }

  // Mane ruff over the neck and shoulders.
  for (let x = 0; x <= neckEnd + 1; x++) {
    const n = 3 - Math.floor(x / 2);
    for (const side of [-1, 0, 1]) {
      for (let k = 0; k < n; k++) {
        const crest = k === n - 1;
        put(x, cy + 4 + k, cz + side * 3, crest ? mixHex(C.jadePale, C.pearl, 0.3) : tint(C.jadePale, x, k, side, seed, 0.1), 0.44 + 0.05 * k);
      }
    }
  }

  // Whiskers streaming eight cells back from the snout, then the glowing eyes.
  for (const side of [-1, 1]) {
    for (let k = 0; k < 8; k++) {
      const x = snout - 1 - k;
      put(x, palate + Math.floor(k / 4), cz + side * (2 + Math.floor(k / 3)), mixHex(C.jadePale, C.goldPale, 0.25 + 0.09 * k), 0.68 + 0.03 * k);
    }
  }
  for (const side of [-1, 1]) put(brow - 1, cy + 2, cz + side * hwAt(brow - 1), C.pearl, 0.92, 1);

  return { world, center: [0.5, cy, cz], dt: 0.6 };
}

/**
 * Dragon tail — the trailing fan of the coil. The join face is at high x so it reads as the last
 * ring's continuation; the fan trails to low x.
 *
 * Knobs: `seed` only: overall length 12 + (seed mod 5) → 12-16 cells, and the grain of the scales.
 *
 * Anatomy: a body tapering from the 7 × 7 ring down to a one-cell peduncle (`dragonBelly` floor,
 * pale crest), then a fanning caudal plate one cell thick on the centre line in three tones —
 * `dragonJade` at the root, `jade` through the middle, `jadePale` along the rim. No glow cells.
 *
 * Grid 18 × 16 × 9 cells = 4.5 × 4.0 × 2.25 world units at 0.25 u/cell; roughly 230 cells.
 * Pivot `[len - 0.5, 7, 4]` — on the join face, so the fan trails behind its anchor.
 * Reveal `dt` 0.6 s.
 */
export function makeDragonTail(seed: number): MovableModel {
  const len = 12 + ((seed >>> 0) % 5); // 12..16 cells
  const sx = 18;
  const sy = 16;
  const sz = 9;
  const world = new VoxelWorld(sx, sy, sz);
  const put = putOn(world, 0.6);
  const cy = 7;
  const cz = 4;
  const joint = len - 1; // meets the last segment

  for (let x = 0; x <= joint; x++) {
    const r = Math.max(1, 1 + Math.round((2 * (x - 1)) / Math.max(1, joint - 1)));
    for (let dy = -r; dy <= r; dy++) {
      for (let dz = -r; dz <= r; dz++) {
        if (dy * dy + dz * dz > r * r + 0.5) continue;
        const hex =
          dy === -r
            ? shade(C.dragonBelly, 0.92)
            : dy === r
              ? mixHex(C.dragonJade, C.jadePale, 0.18)
              : tint(C.dragonJade, x, dy, dz, seed, 0.09);
        put(x, cy + dy, cz + dz, hex, 0.1 + 0.24 * (x / joint));
      }
    }
  }

  // Fanning plate: root, waist and scalloped rim in three jade tones.
  const fan: readonly (readonly [number, number])[] = [
    [4, 4],
    [3, 6],
    [2, 7],
    [1, 6],
    [0, 4],
  ];
  for (const [x, span] of fan) {
    for (let dy = -span; dy <= span; dy++) {
      const u = Math.abs(dy) / span;
      const hex = u < 0.45 ? C.dragonJade : u < 0.8 ? C.jade : mixHex(C.jadePale, C.pearl, 0.25);
      put(x, cy + dy, cz, hex, 0.3 + 0.3 * (1 - x / 4));
    }
  }

  return { world, center: [joint + 0.5, cy, cz], dt: 0.6 };
}

/**
 * Crane — the pair the dawn beat flies over the lake.
 *
 * Knobs: `seed` only: body length 7-9 cells, and which wing carries the extra row of dihedral, so
 * two seeds never beat the same way.
 *
 * Anatomy: a short deep body on the axis; a neck carried forward and up out of the front with a
 * black ruff at its root, a `ruby` crown behind a four-cell pale beak; two legs trailing straight
 * back past the tail; wings spread on ±z with a rising dihedral, white coverts inboard and black
 * primaries at the tips. No glow cells — the composer lights the birds with the sky.
 *
 * Grid 24 × 12 × 27 cells. Filled model: 23 long from beak tip to tail, 25 across the wings,
 * 9 tall with the dihedral = at most 5.75 × 2.25 × 6.25 world units at 0.25 u/cell; roughly
 * 200 cells. Pivot `[10, 5, 13]` — shoulder centre, so the model banks about the body. Reveal
 * `dt` 0.5 s.
 */
export function makeCrane(seed: number): MovableModel {
  const sx = 24;
  const sy = 12;
  const sz = 27;
  const world = new VoxelWorld(sx, sy, sz);
  const put = putOn(world, 0.5);

  const body = 7 + ((seed >>> 0) % 3); // 7..9 cells along x
  const x0 = 5;
  const x1 = x0 + body - 1;
  const mid = (x0 + x1) / 2;
  const cy = 5;
  const cz = 13;
  const lead = (seed >>> 2) & 1 ? 1 : -1;

  // Legs first: authored straight back, they never bend, so the silhouette reads as soaring.
  for (const side of [-1, 1]) {
    for (let k = 0; k <= 4; k++) put(x0 - 1 - k, cy - 2 - (k > 3 ? 1 : 0), cz + side, C.inkSoft, 0.16);
  }

  // Body: an ellipsoid column filled from its own floor, pale along the back.
  const ra = body / 2 + 0.5;
  const rb = 2;
  for (let x = x0; x <= x1; x++) {
    for (let dz = -rb; dz <= rb; dz++) {
      if (!inEllipse(x - mid, dz, ra, rb)) continue;
      const s = Math.pow((x - mid) / ra, 2) + Math.pow(dz / rb, 2);
      const h = Math.max(1, Math.round(2 * Math.sqrt(Math.max(0, 1 - s))));
      for (let dy = -1; dy <= h; dy++) {
        put(x, cy + dy, cz + dz, dy === h ? tint(C.koiWhite, x, dy, dz, seed) : shade(C.koiCream, 0.72), 0.22);
      }
    }
  }

  // Tail: the black plume drooping back off the rear.
  for (let k = 0; k < 4; k++) {
    for (let dz = -1; dz <= 1; dz++) {
      put(x0 - 1 - k, cy + 1 - Math.ceil(k / 2), cz + dz, k < 2 ? shade(C.koiWhite, 0.82) : C.koiBlack, 0.3);
    }
  }

  // Neck out and up, ruff at the root, then the crown, the eye pair and the beak.
  for (let k = 1; k <= 5; k++) {
    const x = x1 + k;
    const y = cy + Math.ceil(k / 2);
    put(x, y, cz, k < 3 ? shade(C.koiBlack, 1.15) : C.koiWhite, 0.45 + 0.05 * k);
    if (k < 3) put(x, y - 1, cz, C.koiBlack, 0.42);
  }
  const hx = x1 + 5;
  const hy = cy + 3;
  put(hx + 1, hy + 1, cz, C.ruby, 0.88);
  for (const side of [-1, 1]) put(hx, hy, cz + side, C.koiWhite, 0.8);
  for (let k = 1; k <= 4; k++) put(hx + k, hy, cz, k === 4 ? C.sand : C.paper, 0.9 + 0.02 * k);

  // Wings: dihedral rising outboard, chord narrowing, primaries black past the eighth cell.
  for (const side of [-1, 1]) {
    for (let d = 1; d <= 12; d++) {
      const chord = d < 4 ? 6 : d < 8 ? 4 : 2;
      const y = cy + 1 + Math.floor((d + (side === lead ? 1 : 0)) / 3);
      const tip = d > 8;
      for (let k = 0; k < chord; k++) {
        const x = Math.round(mid) - 2 + k + (tip ? 1 : 0);
        const hex = tip && k >= chord - 2 ? C.koiBlack : tint(C.koiWhite, x, y, d * side, seed, 0.06);
        put(x, y - (tip ? 1 : 0), cz + side * d, hex, 0.3 + 0.045 * d);
      }
    }
  }

  return { world, center: [10, cy, cz], dt: 0.5 };
}
