import { Kind, VoxelWorld } from '../core/VoxelWorld';
import { C, hash3, mixHex, rng, shade } from '../core/palette';
import { BuilderArgs, FADE, MovableModel, opt, reveal, swayAt } from './types';

/**
 * Settlement and garden furniture of the valley, authored on the MID lattice (cell 0.6 world
 * units, 5/3 cells per world unit).
 *
 * The village must read as warm timber, plaster, thatch, tile and stone with vermilion accents, so
 * every builder here tints per cell and keeps an accent colour in the roof line. Reveal is always
 * support first, ornament last: footing, post and deck at `f` 0, awning, ridge and jewel last.
 * Nothing is written below `a.y`; a builder that stands over water (the dock, the boat) starts its
 * piles at `a.y` and builds the deck up from there. The one exception is `stairRun`, whose `a.y` is
 * the landing at the head of the flight and which therefore descends from it.
 *
 * `makeWaterwheel` and `makeBoatModel` are the exception to the MID lattice: each fills a small private
 * `VoxelWorld` at 0.25 world units per cell and hands back the pivot, so the composer can mesh it once
 * and spin or bob that Object3D. Their reveal windows are relative (0..`dt`) like every other builder's,
 * and each builder's own doc comment states its glow-cell count.
 */

// ------------------------------------------------------------------ helpers

/** Whole-cell clamp for a knob. */
function clampInt(v: number, lo: number, hi: number): number {
  return Math.round(Math.min(hi, Math.max(lo, v)));
}

/** Reveal window for one part of a static builder. */
function put(a: BuilderArgs, f: number): { t: number; dur: number } {
  return { t: reveal(a, f), dur: FADE };
}

/** Per-cell tint so a run of identical timber or masonry never reads as plastic. */
function tint(hex: number, x: number, y: number, z: number, amount = 0.08): number {
  return shade(hex, 1 + (hash3(x, y, z, 21) - 0.5) * 2 * amount);
}

/** Village materials the palette has no single key for, composed once. */
const PLASTER = mixHex(C.moon, C.sand, 0.2);
const STRAW = mixHex(C.sand, C.bambooDeep, 0.45);
const THATCH = mixHex(C.barkLite, C.soilDark, 0.42);
const ROPE = mixHex(C.paper, C.soil, 0.42);

/** `set` bound to one model clock: `f` in 0..1 orders support first, ornament last. */
function mput(
  world: VoxelWorld,
  dt: number,
): (x: number, y: number, z: number, hex: number, f: number, glow?: number, kind?: Kind) => void {
  return (x, y, z, hex, f, glow = 0, kind): void => {
    const t = Math.max(0, Math.min(1, f)) * dt * 0.72;
    const o: { t: number; dur: number; kind?: Kind; glow?: number } = { t, dur: FADE };
    if (kind !== undefined) o.kind = kind;
    if (glow > 0) o.glow = glow;
    world.set(x, y, z, hex, o);
  };
}

/** Model grain, keyed on the model seed so two wheels or boats never match. */
function grain(hex: number, x: number, y: number, z: number, seed: number, amount = 0.08): number {
  return shade(hex, 1 + (hash3(x, y, z, seed) - 0.5) * 2 * amount);
}

const ARMS: ReadonlyArray<readonly [number, number]> = [
  [-1, 0],
  [1, 0],
  [0, -1],
  [0, 1],
];

const CORNERS: ReadonlyArray<readonly [number, number]> = [
  [-1, -1],
  [-1, 1],
  [1, -1],
  [1, 1],
];

/** Offsets on the perimeter of the rectangle `-hx..hx` x `-hz..hz`, no duplicates. */
function ring(hx: number, hz: number): Array<[number, number]> {
  const out: Array<[number, number]> = [];
  for (let dz = -hz; dz <= hz; dz++) {
    out.push([-hx, dz]);
    out.push([hx, dz]);
  }
  for (let dx = -hx + 1; dx <= hx - 1; dx++) {
    out.push([dx, -hz]);
    out.push([dx, hz]);
  }
  return out;
}

// ------------------------------------------------------------------ roof library

/**
 * Hipped ogee roof, 2 cells thick, ridge running along x. `ridge` is the half-length of the flat
 * ridge; the four corners climb `lift` rows clear of the mid-eave line. Reveal runs eave first.
 */
interface HipSpec {
  cx: number;
  cz: number;
  /** half-span along x and z */
  hx: number;
  hz: number;
  /** half-length of the flat ridge along x */
  ridge: number;
  /** row of the mid-eave line */
  y0: number;
  /** rows from the mid-eave line up to the ridge */
  rise: number;
  /** rows the four corner tips climb above their own eave height */
  lift: number;
  /** slope exponent: 1 is straight, larger is concave under the ridge */
  ogee: number;
  /** reveal fraction of the eave and of the ridge */
  f0: number;
  f1: number;
  seed: number;
  /** field colour, gilt eave discs, soffit colour */
  tile: number;
  rim: number;
  soffit: number;
  /** draw a second gilt course along the ridge */
  gild: boolean;
  /** lay the ridge along z instead of x; `hx` and `hz` keep their own axes */
  flip: boolean;
}

function hipHeight(s: HipSpec, along: number, across: number): number {
  const la = Math.max(1, s.flip ? s.hz : s.hx);
  const lc = Math.max(1, s.flip ? s.hx : s.hz);
  const ax = s.ridge >= la ? 0 : Math.max(0, (Math.abs(along) - s.ridge) / (la - s.ridge));
  const t = Math.max(ax, Math.abs(across) / lc);
  const lift = s.lift * Math.pow(Math.abs(along) / la, 2.2) * Math.pow(Math.abs(across) / lc, 2.2);
  return s.y0 + Math.round(s.rise * (1 - Math.pow(t, s.ogee)) + lift);
}

/**
 * Paint one hipped roof and its ridge. Tile ribs alternate across the fall line, the outer band is
 * picked out in gilt eave discs, every corner gets an upturned claw and the ridge ends curl. Returns
 * the topmost row used.
 */
function hipRoof(world: VoxelWorld, a: BuilderArgs, s: HipSpec): number {
  const la = Math.max(1, s.flip ? s.hz : s.hx);
  const lc = Math.max(1, s.flip ? s.hx : s.hz);
  const rx = (along: number, across: number): number => s.cx + (s.flip ? across : along);
  const rz = (along: number, across: number): number => s.cz + (s.flip ? along : across);
  for (let along = -la; along <= la; along++) {
    for (let across = -lc; across <= lc; across++) {
      const ax = s.ridge >= la ? 0 : Math.max(0, (Math.abs(along) - s.ridge) / (la - s.ridge));
      const t = Math.max(ax, Math.abs(across) / lc);
      const rib = Math.abs(along) >= Math.abs(across) ? across : along;
      let hex = ((rib + 100) & 1) === 0 ? s.tile : mixHex(s.tile, s.rim, 0.45);
      if (t > 0.93) hex = s.rim;
      if (hash3(along + s.cx * 3, 0, across + s.cz * 5, s.seed + 13) > 0.88) hex = mixHex(hex, C.mist, 0.13);
      const f = s.f0 + (s.f1 - s.f0) * (1 - t);
      const y = hipHeight(s, along, across);
      const gx = rx(along, across);
      const gz = rz(along, across);
      world.set(gx, y, gz, hex, put(a, f));
      world.set(gx, y - 1, gz, s.soffit, put(a, f));
    }
  }
  const top = s.y0 + s.rise;
  const cap = shade(C.tileDeep, 0.82);
  for (let along = -s.ridge; along <= s.ridge; along++) {
    world.set(rx(along, 0), top + 1, rz(along, 0), cap, put(a, s.f1));
    if (s.gild)
      world.set(rx(along, 0), top + 2, rz(along, 0), (along + 100) % 2 === 0 ? C.gilt : C.goldLite, put(a, s.f1));
  }
  for (const dir of [-1, 1]) {
    world.set(rx(dir * (s.ridge + 1), 0), top + 1, rz(dir * (s.ridge + 1), 0), s.rim, put(a, s.f1));
    world.set(rx(dir * (s.ridge + 2), 0), top + 2, rz(dir * (s.ridge + 2), 0), C.goldDeep, put(a, s.f1));
  }
  for (const sa of [-1, 1]) {
    for (const sb of [-1, 1]) {
      world.set(
        rx(sa * la, sb * lc),
        hipHeight(s, sa * la, sb * lc) + 1,
        rz(sa * la, sb * lc),
        s.rim,
        put(a, s.f0),
      );
    }
  }
  return top + 2;
}

/** Column row of a gable roof whose ridge runs along x. */
function gableRow(s: GableSpec, dz: number): number {
  const t = Math.abs(dz) / Math.max(1, s.hz);
  return s.eave + s.rise - Math.round(s.rise * Math.pow(t, s.ogee));
}

interface GableSpec {
  cx: number;
  cz: number;
  hx: number;
  hz: number;
  /** row of the eave line at |dz| == hz */
  eave: number;
  /** rows from the eave line to the ridge */
  rise: number;
  ogee: number;
  f0: number;
  f1: number;
  seed: number;
  tile: number;
  rib: number;
  soffit: number;
  ridgeCap: number;
}

/** Gable roof, ridge along x, 2 cells thick, with barge boards and lifted end horns. */
function gableRoof(world: VoxelWorld, a: BuilderArgs, s: GableSpec): number {
  for (let dz = -s.hz; dz <= s.hz; dz++) {
    const row = gableRow(s, dz);
    for (let dx = -s.hx; dx <= s.hx; dx++) {
      let hex = (dx + 100) % 2 === 0 ? s.tile : s.rib;
      if (Math.abs(dz) === s.hz) hex = mixHex(s.tile, C.slate, 0.18);
      if (hash3(dx + s.cx * 5, 1, dz + s.cz * 3, s.seed + 29) > 0.9) hex = mixHex(hex, C.mist, 0.12);
      const f = s.f0 + (s.f1 - s.f0) * (Math.abs(dz) / Math.max(1, s.hz));
      world.set(s.cx + dx, row, s.cz + dz, tint(hex, s.cx + dx, row, s.cz + dz, 0.06), put(a, f));
      world.set(s.cx + dx, row - 1, s.cz + dz, s.soffit, put(a, f));
    }
  }
  const top = s.eave + s.rise;
  for (let dx = -s.hx; dx <= s.hx; dx++) {
    world.set(s.cx + dx, top + 1, s.cz, s.ridgeCap, put(a, s.f1));
    if ((dx + 100) % 3 === 0) world.set(s.cx + dx, top + 2, s.cz, mixHex(s.ridgeCap, C.goldPale, 0.5), put(a, s.f1));
  }
  for (const dir of [-1, 1]) {
    world.set(s.cx + dir * (s.hx + 1), top + 1, s.cz, s.ridgeCap, put(a, s.f1));
    world.set(s.cx + dir * s.hx, gableRow(s, -s.hz) + 1, s.cz - s.hz, mixHex(s.tile, C.goldPale, 0.35), put(a, s.f0));
    world.set(s.cx + dir * s.hx, gableRow(s, s.hz) + 1, s.cz + s.hz, mixHex(s.tile, C.goldPale, 0.35), put(a, s.f0));
  }
  return top + 2;
}

/**
 * Gable-end wall: plaster infill under the roof line with timber studs on the slope and a sill band.
 * `hx` is the end plane (the wall is 1 cell thick along x).
 */
function gableWall(
  world: VoxelWorld,
  a: BuilderArgs,
  s: GableSpec,
  ex: number,
  wallTop: number,
  plaster: number,
  f: number,
): void {
  for (let dz = -s.hz; dz <= s.hz; dz++) {
    const roof = gableRow(s, dz) - 2;
    for (let r = wallTop + 1; r <= roof; r++) {
      const stud = Math.abs(dz) === s.hz || r === roof || (dz + 100) % 4 === 0;
      world.set(
        ex,
        r,
        s.cz + dz,
        stud ? shade(C.ironwood, 1.08) : tint(plaster, ex, r, s.cz + dz, 0.05),
        put(a, f + 0.16 * (Math.abs(dz) / Math.max(1, s.hz))),
      );
    }
  }
}

/** Louvred vent in a gable end, so a loft reads as occupied. */
function gableVent(
  world: VoxelWorld,
  a: BuilderArgs,
  ex: number,
  row: number,
  cz: number,
  f: number,
): void {
  for (let dz = -1; dz <= 1; dz++) {
    world.set(ex, row, cz + dz, C.goldPale, put(a, f));
    world.set(ex, row + 1, cz + dz, shade(C.ironwood, 0.9), put(a, f + 0.06));
  }
}

// ------------------------------------------------------------------ stone lantern

/**
 * Snow-view stone lantern, exactly `h` cells tall. Knobs: `h` default 10, clamped 8..22; extra
 * height goes to the shaft first, then to the firebox. Footprint 5x5 cells (cap), 3x3 below.
 * Glow: 1 (the firebox core).
 */
export function stoneLantern(world: VoxelWorld, a: BuilderArgs): void {
  const h = clampInt(opt(a, 'h', 10), 8, 22);
  const { x, y, z } = a;
  const extra = h - 7;
  const shaftGrow = Math.ceil(extra * 0.5);
  const boxGrow = extra - shaftGrow;

  // footing
  world.box(x - 1, y, z - 1, x + 1, y, z + 1, tint(shade(C.stone, 0.78), x, y, z, 0.06), put(a, 0));
  world.set(x, y, z, C.stoneLite, put(a, 0));

  // shaft with a collar at the head
  const shaftTop = y + shaftGrow;
  for (let r = y + 1; r <= shaftTop; r++) world.set(x, r, z, tint(C.stoneLite, x, r, z, 0.05), put(a, 0.1));
  for (const [dx, dz] of ARMS) world.set(x + dx, shaftTop, z + dz, shade(C.stone, 0.86), put(a, 0.18));

  // abacus
  const py = shaftTop + 1;
  world.box(x - 1, py, z - 1, x + 1, py, z + 1, C.marbleLite, put(a, 0.26));

  // firebox: four corner posts, an empty middle, a lintel band
  const fy0 = py + 1;
  const fy1 = fy0 + 1 + boxGrow;
  for (let r = fy0; r <= fy1; r++) {
    for (const [dx, dz] of CORNERS)
      world.set(x + dx, r, z + dz, tint(shade(C.stone, 0.84), x + dx, r, z + dz, 0.05), put(a, 0.36));
    if (r === fy1) for (const [dx, dz] of ARMS) world.set(x + dx, r, z + dz, C.marbleDeep, put(a, 0.52));
  }
  world.set(x, Math.floor((fy0 + fy1) / 2), z, C.lanternCore, {
    kind: Kind.Glow,
    glow: 1,
    ...put(a, 0.64),
  });

  // cap: diamond slab, the four points lifted, jewel on the spine
  const ry = fy1 + 1;
  for (let dz = -2; dz <= 2; dz++) {
    for (let dx = -2; dx <= 2; dx++) {
      const r2 = dx * dx + dz * dz;
      if (r2 > 4) continue;
      const rib = Math.abs(dx) >= Math.abs(dz) ? dz : dx;
      world.set(x + dx, ry, z + dz, ((rib + 100) & 1) === 0 ? C.tile : C.tileRim, put(a, 0.74));
      if (r2 === 4) world.set(x + dx, ry + 1, z + dz, C.tileRim, put(a, 0.82));
    }
  }
  world.set(x, ry + 1, z, C.goldLite, put(a, 0.9));
  world.set(x, ry + 2, z, C.gold, put(a, 1));
}

/**
 * A row of stone lanterns running along +x from `a.x`. Knobs: `count` default 7 (clamped 1..24),
 * `pitch` default 8 cells (clamped 4..24), `h` default 10 — the nominal height; every lantern is
 * knocked one row up or down by `hash3` so the line does not read as a fence of copies.
 * Footprint `((count - 1) * pitch + 5)` cells long, 5 cells deep. Glow: `count` (one per lantern).
 */
export function lanternLine(world: VoxelWorld, a: BuilderArgs): void {
  const count = clampInt(opt(a, 'count', 7), 1, 24);
  const pitch = clampInt(opt(a, 'pitch', 8), 4, 24);
  const base = clampInt(opt(a, 'h', 10), 8, 22);
  for (let i = 0; i < count; i++) {
    const cx = a.x + i * pitch;
    const tall = hash3(cx, 0, a.z, a.seed + 5) > 0.55 ? 1 : 0;
    stoneLantern(world, {
      ...a,
      x: cx,
      t: a.t + a.dt * 0.055 * i,
      dt: Math.max(0.6, a.dt * 0.45),
      seed: a.seed + i * 7919,
      opts: { ...(a.opts ?? {}), h: base + tall },
    });
  }
}

// ------------------------------------------------------------------ pavilion

/**
 * Open stone pavilion: stepped plinth, railed deck, 4 or 6 vermilion columns with gilt capitals, a
 * clerestory and a double-eaved ogee roof with a gilt ridge, finial and a lantern hung inside.
 * Knobs: `half` default 9 (plinth half-span, clamped 5..16), `h` default 12 (column rows, clamped
 * 6..26), `cols` 4 or 6, default 4. Footprint `(2*half+5)` x `(2*half+7)` cells: the steps on the two
 * z faces reach `half+3`, the roof eaves `half+2`. Glow: 2 (the two cells of the hung roof lantern).
 */
export function pavilion(world: VoxelWorld, a: BuilderArgs): void {
  const half = clampInt(opt(a, 'half', 9), 5, 16);
  const h = clampInt(opt(a, 'h', 12), 6, 26);
  const cols = Math.round(opt(a, 'cols', 4)) === 6 ? 6 : 4;
  const { x, y, z } = a;
  const deck = y + 2;
  const hc = half - 2;

  // plinth: masonry ring, then the deck slab
  const plinth = ring(half, half);
  for (const [dx, dz] of plinth) {
    const hex = (dx + dz + 200) % 3 === 0 ? C.marbleDeep : tint(C.stone, x + dx, y, z + dz, 0.06);
    world.set(x + dx, y, z + dz, hex, put(a, 0));
    world.set(x + dx, y + 1, z + dz, tint(C.marble, x + dx, y + 1, z + dz, 0.05), put(a, 0.04));
  }
  world.box(x - half, deck, z - half, x + half, deck, z + half, C.marbleLite, put(a, 0.1));

  // stairs on the +z and -z faces
  for (const dir of [-1, 1]) {
    for (let i = 0; i < 3; i++) {
      const row = y + i;
      const dz = half + 1 + (2 - i);
      world.box(x - 2, row, z + dir * dz, x + 2, row, z + dir * dz, tint(C.marbleDeep, x, row, z + dz, 0.05), put(a, 0.06));
    }
  }

  // railing: sill, balusters, handrail, newels at the corners and mid-spans
  const rail = ring(half - 1, half - 1);
  for (const [dx, dz] of rail) {
    if (Math.abs(dx) <= 2 && Math.abs(dz) === half - 1) continue;
    world.set(x + dx, deck + 1, z + dz, C.marble, put(a, 0.42));
    if ((dx + dz + 200) % 2 === 0) world.set(x + dx, deck + 2, z + dz, shade(C.marbleLite, 0.94), put(a, 0.46));
    if ((dx + dz + 200) % 3 === 0) world.set(x + dx, deck + 3, z + dz, C.marbleLite, put(a, 0.5));
  }
  for (const [dx, dz] of CORNERS) {
    for (let r = deck + 1; r <= deck + 4; r++) world.set(x + dx * (half - 1), r, z + dz * (half - 1), C.marbleLite, put(a, 0.44));
  }
  for (const [dx, dz] of [[0, -1], [0, 1], [-1, 0], [1, 0]] as const) {
    for (let r = deck + 1; r <= deck + 4; r++) world.set(x + dx * (half - 1), r, z + dz * (half - 1), C.marbleLite, put(a, 0.44));
  }

  // columns with stone plinths and pale capitals
  const postTop = deck + h;
  const sites: Array<[number, number]> = [];
  for (const [sx, sz] of CORNERS) sites.push([sx * hc, sz * hc]);
  if (cols === 6) sites.push([0, -hc], [0, hc]);
  for (const [dx, dz] of sites) {
    for (let ox = 0; ox <= 1; ox++) {
      for (let oz = 0; oz <= 1; oz++) {
        const px = x + (dx > 0 ? dx - 1 : dx === 0 ? ox - 1 : dx) + (dx !== 0 ? ox : 0);
        const pz = z + (dz > 0 ? dz - 1 : dz === 0 ? oz - 1 : dz) + (dz !== 0 ? oz : 0);
        world.set(px, deck, pz, shade(C.marbleDeep, 0.9), put(a, 0.2));
        for (let r = deck + 1; r <= postTop; r++)
          world.set(px, r, pz, tint(C.vermilion, px, r, pz, 0.07), put(a, 0.24));
        world.set(px, postTop + 1, pz, C.goldPale, put(a, 0.56));
      }
    }
  }

  // architrave joining the capitals
  for (const sz of [-1, 1])
    world.beam([x - hc, postTop + 1, z + sz * hc], [x + hc, postTop + 1, z + sz * hc], 1, C.vermilionDeep, put(a, 0.3));
  for (const sx of [-1, 1])
    world.beam([x + sx * hc, postTop + 1, z - hc], [x + sx * hc, postTop + 1, z + hc], 1, C.vermilionDeep, put(a, 0.3));

  // lower eave
  const low: HipSpec = {
    cx: x,
    cz: z,
    hx: half + 2,
    hz: half + 2,
    ridge: Math.max(1, half - 3),
    y0: postTop + 2,
    rise: 3,
    lift: 2,
    ogee: 1.7,
    f0: 0.6,
    f1: 0.7,
    seed: a.seed,
    tile: C.tile,
    rim: C.tileRim,
    soffit: mixHex(C.lacquer, C.goldPale, 0.5),
    gild: false,
    flip: false,
  };
  hipRoof(world, a, low);

  // clerestory: a paper band on four posts, punched through by the lantern
  const inner = Math.max(3, half - 3);
  const bandTop = postTop + 6;
  for (const [dx, dz] of ring(inner, inner)) {
    for (let r = postTop + 3; r <= bandTop; r++) {
      const post = (dx + inner) % inner === 0 && (dz + inner) % inner === 0;
      world.set(
        x + dx,
        r,
        z + dz,
        post || r === bandTop ? (post ? C.vermilion : C.goldPale) : C.paper,
        put(a, 0.66),
      );
    }
  }

  // upper roof
  const up: HipSpec = {
    cx: x,
    cz: z,
    hx: inner,
    hz: inner,
    ridge: Math.max(1, Math.round(inner * 0.4)),
    y0: bandTop + 1,
    rise: 5,
    lift: 3,
    ogee: 1.55,
    f0: 0.72,
    f1: 0.88,
    seed: a.seed + 3,
    tile: C.tile,
    rim: C.tileRim,
    soffit: mixHex(C.lacquer, C.goldPale, 0.5),
    gild: true,
    flip: false,
  };
  const ridgeTop = hipRoof(world, a, up);

  // finial
  for (let r = ridgeTop + 1; r <= ridgeTop + 3; r++) world.set(x, r, z, r === ridgeTop + 3 ? C.goldLite : C.gold, put(a, 0.94));
  world.set(x - 1, ridgeTop + 1, z, C.gilt, put(a, 0.96));
  world.set(x + 1, ridgeTop + 1, z, C.gilt, put(a, 0.96));

  // roof lantern hung in the hollow, the only lit cells of the interior
  const hang = Math.min(bandTop, postTop + Math.round(h * 0.6));
  world.set(x, hang + 4, z, shade(C.ironwood, 1.1), put(a, 0.9));
  world.set(x, hang + 3, z, C.lantern, { kind: Kind.Glow, glow: 0.6, ...put(a, 0.94) });
  world.set(x, hang + 2, z, C.lanternCore, { kind: Kind.Glow, glow: 1, ...put(a, 1) });
}

/**
 * Gate hall at the head of the causeway. Knobs: `span` default 26 cells (clamped 14..60, measured
 * along the front of the gate), `h` default 20 (clamped 14..44) - the posts take `h` - 7 rows and the
 * roof puts the crest at `a.y + h + 6`; `dir` 0 spans along +x (default), 1 spans along +z.
 * Four heavy 2x2 posts, a double lintel, a plaque under the eave, a tiled ogee roof with lifted horns
 * and a piered wing wall marching off each end.
 * Footprint `(span + 17)` x 16 cells, transposed when `dir` is 1. Glow: 4 (two door lanterns of two).
 */
export function mountainGate(world: VoxelWorld, a: BuilderArgs): void {
  const span = clampInt(opt(a, 'span', 26), 14, 60);
  const h = clampInt(opt(a, 'h', 20), 14, 44);
  const flip = clampInt(opt(a, 'dir', 0), 0, 1) === 1;
  const { x, y, z } = a;
  const half = Math.floor(span / 2);
  const pz = 4;
  const postTop = y + h - 7;
  const gx = (u: number, v: number): number => (flip ? x + v : x + u);
  const gz = (u: number, v: number): number => (flip ? z + u : z + v);

  // platform, paving pattern, and the apron where the causeway meets the threshold
  for (let u = -half - 1; u <= half + 1; u++) {
    for (let v = -pz - 1; v <= pz + 1; v++) {
      const px = gx(u, v);
      const pz0 = gz(u, v);
      world.set(px, y, pz0, tint(C.stone, px, y, pz0, 0.05), put(a, 0));
      world.set(
        px,
        y + 1,
        pz0,
        (u + v + 400) % 2 === 0
          ? tint(C.marbleLite, px, y + 1, pz0, 0.05)
          : tint(C.marble, px, y + 1, pz0, 0.05),
        put(a, 0.03),
      );
    }
  }
  for (let u = -4; u <= 4; u++) {
    for (let k = 2; k <= 4; k++) {
      const px = gx(u, pz + k);
      const pz0 = gz(u, pz + k);
      world.set(px, y, pz0, tint(C.marbleDeep, px, y, pz0, 0.04), put(a, 0.05));
    }
  }

  // four heavy posts: plinth, vermilion shaft, pale capital
  for (const ou of [-(half - 3), -(half - 8), half - 8, half - 3]) {
    for (let su = 0; su <= 1; su++) {
      for (let sv = 0; sv <= 1; sv++) {
        const u = ou + su - (ou > 0 ? 1 : 0);
        const v = sv === 0 ? -2 : 1;
        const px = gx(u, v);
        const pz0 = gz(u, v);
        world.set(px, y + 2, pz0, shade(C.marbleDeep, 0.92), put(a, 0.12));
        for (let r = y + 3; r <= postTop; r++)
          world.set(px, r, pz0, tint(C.vermilion, px, r, pz0, 0.08), put(a, 0.16));
        world.set(px, postTop + 1, pz0, C.goldPale, put(a, 0.5));
      }
    }
  }

  // double lintel along the front and back ranks of posts
  for (const v of [-2, 1]) {
    world.beam(
      [gx(-half + 3, v), postTop + 2, gz(-half + 3, v)],
      [gx(half - 3, v), postTop + 2, gz(half - 3, v)],
      1,
      C.vermilionDeep,
      put(a, 0.34),
    );
    world.beam(
      [gx(-half + 3, v), postTop + 3, gz(-half + 3, v)],
      [gx(half - 3, v), postTop + 3, gz(half - 3, v)],
      1,
      C.lacquer,
      put(a, 0.4),
    );
  }

  // plaque under the eave: two gilt bands around a lacquer field with a gilt seal
  const pr = Math.round((y + postTop) * 0.66);
  for (let u = -2; u <= 2; u++) {
    const px = gx(u, pz - 1);
    const pz0 = gz(u, pz - 1);
    world.set(px, pr, pz0, C.gold, put(a, 0.72));
    world.set(px, pr + 2, pz0, C.gold, put(a, 0.72));
    world.set(px, pr + 1, pz0, u === 0 ? C.goldLite : C.lacquer, put(a, 0.76));
  }

  // door lanterns hung at the inner posts
  for (const ou of [-(half - 8), half - 8]) {
    const px = gx(ou, pz);
    const pz0 = gz(ou, pz);
    world.set(px, postTop + 1, pz0, shade(C.ironwood, 1.1), put(a, 0.86));
    world.set(px, postTop, pz0, C.lantern, { kind: Kind.Glow, glow: 0.7, ...put(a, 0.9) });
    world.set(px, postTop - 1, pz0, C.lanternCore, { kind: Kind.Glow, glow: 1, ...put(a, 0.94) });
  }

  // wing walls marching out from the outer posts, plaster between piers
  for (const dir of [-1, 1]) {
    for (let k = 0; k <= 6; k++) {
      const u = dir * (half + 2 + k);
      const end = k === 6;
      const f = 0.2 + 0.05 * k;
      for (let r = y; r <= y + 6; r++) {
        const pier = k % 4 === 0 || r === y || end;
        for (let v = -1; v <= 1; v++) {
          const px = gx(u, v);
          const pz0 = gz(u, v);
          world.set(
            px,
            r,
            pz0,
            pier ? tint(C.marbleDeep, px, r, pz0, 0.05) : tint(PLASTER, px, r, pz0, 0.04),
            put(a, f),
          );
        }
      }
      for (let v = -1; v <= 1; v++) {
        const px = gx(u, v);
        const pz0 = gz(u, v);
        world.set(px, y + 7, pz0, v === 0 ? C.tileDeep : C.tile, put(a, f + 0.2));
      }
      if (end)
        for (let v = -1; v <= 1; v++) world.set(gx(u, v), y + 8, gz(u, v), C.tileRim, put(a, f + 0.3));
    }
  }

  // tiled roof, horns up, gilt spine, then the crest jewel
  const roof: HipSpec = {
    cx: x,
    cz: z,
    hx: flip ? pz + 3 : half + 3,
    hz: flip ? half + 3 : pz + 3,
    ridge: Math.max(2, half - 5),
    y0: postTop + 4,
    rise: 5,
    lift: 4,
    ogee: 1.5,
    f0: 0.6,
    f1: 0.84,
    seed: a.seed,
    tile: C.tile,
    rim: C.tileRim,
    soffit: mixHex(C.lacquer, C.goldPale, 0.5),
    gild: true,
    flip,
  };
  const top = hipRoof(world, a, roof);
  world.set(x, top + 1, z, C.gold, put(a, 0.92));
  world.set(x, top + 2, z, C.gilt, put(a, 0.96));
}

/**
 * Roadside market stall: trestle counter, a two-tier shelf behind it, a striped awning of paper and
 * vermilion on timber posts, cargo crates and one hanging lantern. Knobs: none. Footprint 15 x 9
 * cells (x -7..+7, z -3..+5), 9 rows tall. Glow: 1 (the hanging lantern).
 */
export function marketStall(world: VoxelWorld, a: BuilderArgs): void {
  const { x, y, z } = a;
  const d = rng(a.seed * 6151);

  // trestles and the plank counter
  for (const tx of [-5, 0, 5]) {
    for (const tz of [-2, 1]) {
      world.set(x + tx, y, z + tz, C.ironwood, put(a, 0));
      world.set(x + tx, y + 1, z + tz, tint(C.woodDark, x + tx, y + 1, z + tz, 0.05), put(a, 0.05));
    }
  }
  world.box(x - 6, y + 2, z - 3, x + 6, y + 2, z + 2, tint(C.wood, x, y + 2, z, 0.07), put(a, 0.14));

  // shelf against the back posts, jars and folded cloth
  for (const px of [-7, -1, 6]) {
    for (let r = y; r <= y + 4; r++) world.set(x + px, r, z - 3, tint(C.bark, x + px, r, z - 3, 0.06), put(a, 0.08));
  }
  for (const row of [y + 3, y + 4]) {
    for (let dx = -6; dx <= 5; dx++) {
      if ((dx + 100) % 4 === 0) continue;
      world.set(x + dx, row, z - 3, tint(C.woodDark, x + dx, row, z - 3, 0.05), put(a, 0.2));
    }
  }
  const goods = [C.lotusPink, C.bambooLite, C.marbleLite, C.plum, C.mossLite];
  for (let dx = -5; dx <= 5; dx += 3) {
    const hex = goods[Math.abs(dx + Math.floor(d() * goods.length)) % goods.length];
    world.set(x + dx, y + 3, z - 1, hex, put(a, 0.5));
    if (hash3(dx, y, z, a.seed + 7) > 0.45) world.set(x + dx, y + 3, z + 1, goods[(dx + 8) % goods.length], put(a, 0.54));
  }

  // awning: paper and vermilion bands falling from the back beam to the front eave
  for (const px of [-6, 6]) {
    for (let r = y; r <= y + 4; r++) world.set(x + px, r, z + 4, tint(C.bark, x + px, r, z + 4, 0.06), put(a, 0.24));
    for (const dx of [-7, 7]) world.set(x + dx, y + 4, z + 4, C.barkLite, put(a, 0.3));
  }
  for (let dz = -3; dz <= 4; dz++) {
    const r = y + 7 - Math.floor(((dz + 3) * 2) / 7);
    for (let dx = -7; dx <= 7; dx++) {
      const band = (((dx + 7) / 3) | 0) % 2 === 0;
      world.set(x + dx, r, z + dz, band ? tint(C.paper, x + dx, r, z + dz, 0.04) : C.vermilion, put(a, 0.36));
      world.set(x + dx, r - 1, z + dz, mixHex(C.lacquer, C.goldPale, 0.4), put(a, 0.4));
    }
  }
  // valance along the front eave, hem knocked out on the beat
  for (let dx = -7; dx <= 7; dx++) {
    if ((dx + 7) % 2 === 1) continue;
    world.set(x + dx, y + 4, z + 4, C.vermilionDeep, put(a, 0.58));
  }

  // cargo: two crates and a barrel at the ends, one crate stacked
  const crate = (cx: number, cz: number, f: number): void => {
    world.box(cx, y, cz, cx + 1, y + 1, cz + 1, tint(C.woodDark, cx, y, cz, 0.07), put(a, f));
    world.box(cx, y + 2, cz, cx + 1, y + 2, cz + 1, tint(C.bamboo, cx, y + 2, cz, 0.07), put(a, f + 0.06));
  };
  crate(x - 7, z + 2, 0.62);
  if (d() > 0.45) world.box(x - 7, y + 3, z + 2, x - 6, y + 4, z + 3, tint(C.wood, x - 7, y + 3, z + 2, 0.06), put(a, 0.68));
  crate(x + 6, z - 2, 0.62);
  for (let r = y; r <= y + 2; r++) world.set(x + 7, r, z + 2, tint(C.barkLite, x + 7, r, z + 2, 0.06), put(a, 0.64));

  // hanging lantern off the front-left post
  world.set(x - 6, y + 7, z + 5, C.lanternCore, { kind: Kind.Glow, glow: 0.9, ...put(a, 0.9) });
  world.set(x - 6, y + 8, z + 5, shade(C.ironwood, 1.05), put(a, 0.94));
}

/**
 * Village house. Knobs: `halfX` default 6 (clamped 4..9, footprint x = `2*halfX+4` incl. the chimney),
 * `halfZ` default 5 (clamped 3..7, footprint z = `2*halfZ+3`), `wallH` default 6 (clamped 4..7 eave
 * rows; total height = `wallH + 11`), `thatch` 1 thatch / 0 tile, default 1. Plaster walls with timber
 * posts, a framed door on +z, a lattice window on -z, a gable roof 2 cells thick, a stone chimney with
 * three smoke cells. Interior hollow. At the clamps: 22 x 17 cells, 18 rows. Glow: 1 (the window).
 */
export function house(world: VoxelWorld, a: BuilderArgs): void {
  const halfX = clampInt(opt(a, 'halfX', 6), 4, 9);
  const halfZ = clampInt(opt(a, 'halfZ', 5), 3, 7);
  const wallH = clampInt(opt(a, 'wallH', 6), 4, 7);
  const thatch = Math.round(opt(a, 'thatch', 1)) === 0 ? 0 : 1;
  const { x, y, z } = a;
  const hx = halfX - 1;
  const hz = halfZ - 1;
  const wallTop = y + wallH;
  const perim = ring(hx, hz);

  // footing
  world.box(x - hx, y, z - hz, x + hx, y, z + hz, tint(C.stone, x, y, z, 0.06), put(a, 0));

  // walls: plaster infill, timber posts at the corners and mid-spans, sill and wall plate
  for (const [dx, dz] of perim) {
    const post = (Math.abs(dx) === hx && Math.abs(dz) === hz) || (dx === 0 && Math.abs(dz) === hz) || (Math.abs(dx) === hx && dz === 0);
    const door = dz === hz && Math.abs(dx) <= 1;
    const win = dz === -hz && Math.abs(dx) <= 1;
    for (let r = y + 1; r <= wallTop; r++) {
      if (door && r <= y + 4) continue;
      if (win && r >= y + 2 && r <= y + 3) continue;
      world.set(
        x + dx,
        r,
        z + dz,
        post ? tint(C.bark, x + dx, r, z + dz, 0.06) : tint(PLASTER, x + dx, r, z + dz, 0.04),
        put(a, 0.1),
      );
    }
    world.set(x + dx, y + 1, z + dz, shade(C.ironwood, 1.05), put(a, 0.12));
    world.set(x + dx, wallTop + 1, z + dz, tint(C.ironwoodLite, x + dx, wallTop + 1, z + dz, 0.05), put(a, 0.3));
  }

  // door frame and lintel
  for (const dx of [-2, 2]) {
    for (let r = y + 1; r <= y + 4; r++) world.set(x + dx, r, z + hz, C.barkLite, put(a, 0.2));
  }
  world.box(x - 2, y + 5, z + hz, x + 2, y + 5, z + hz, C.woodDark, put(a, 0.24));
  for (const dx of [-1, 0]) {
    for (let r = y + 1; r <= y + 3; r++) world.set(x + dx, r, z + hz, tint(C.woodDark, x + dx, r, z + hz, 0.07), put(a, 0.34));
  }

  // window: lattice over a single lit cell
  for (const dx of [-1, 0]) {
    for (let r = y + 2; r <= y + 3; r++) {
      world.set(x + dx, r, z - hz, r === y + 3 ? C.lantern : C.paper, r === y + 3 ? { kind: Kind.Glow, glow: 0.85, ...put(a, 0.8) } : put(a, 0.4));
    }
  }
  world.set(x, y + 2, z - hz, C.woodDark, put(a, 0.46));
  world.set(x, y + 3, z - hz, C.goldPale, put(a, 0.46));

  // porch: two posts and a plank over the door
  for (const dx of [-2, 2]) {
    for (let r = y; r <= y + 4; r++) world.set(x + dx, r, z + hz + 2, tint(C.bark, x + dx, r, z + hz + 2, 0.06), put(a, 0.16));
  }
  world.box(x - 3, y + 5, z + hz + 1, x + 3, y + 5, z + hz + 2, tint(C.woodDark, x, y + 5, z + hz + 1, 0.06), put(a, 0.44));
  world.set(x, y, z + hz + 1, C.marbleDeep, put(a, 0.05));

  // roof, ridge along x
  const g: GableSpec = {
    cx: x,
    cz: z,
    hx: hx + 1,
    hz: hz + 2,
    eave: wallTop + 2,
    rise: thatch ? 5 : 4,
    ogee: thatch ? 1.15 : 1.5,
    f0: 0.5,
    f1: 0.82,
    seed: a.seed,
    tile: thatch ? STRAW : C.tile,
    rib: thatch ? THATCH : C.tileRim,
    soffit: mixHex(C.lacquer, C.goldPale, 0.5),
    ridgeCap: thatch ? THATCH : C.tileDeep,
  };
  const top = gableRoof(world, a, g);
  for (const side of [-1, 1]) {
    gableWall(world, a, g, x + side * hx, wallTop + 1, PLASTER, 0.56);
    world.set(x + side * hx, gableRow(g, 0) - 2, z, C.goldPale, put(a, 0.86));
  }

  // chimney on the -x gable, with a little smoke
  const cx = x - hx - 2;
  for (let r = y; r <= wallTop + 4; r++) {
    world.set(cx, r, z, tint(r > wallTop ? C.marbleLite : C.stone, cx, r, z, 0.06), put(a, 0.18));
    world.set(cx, r, z - 1, tint(r > wallTop ? C.marbleLite : C.stone, cx, r, z - 1, 0.06), put(a, 0.18));
  }
  world.box(cx - 1, wallTop + 5, z - 1, cx + 1, wallTop + 5, z + 1, C.marbleDeep, put(a, 0.88));
  for (let i = 0; i < 3; i++) {
    const r = wallTop + 6 + i * 2;
    world.set(cx + (i % 2), r, z + (i === 1 ? 1 : 0), mixHex(C.mist, C.paper, 0.25 * i), {
      sway: swayAt(r - y, top - y, 1),
      ...put(a, 0.9 + i * 0.03),
    });
  }
}

/**
 * Raised-floor timber store on stumps: stone-capped piles, a plank floor, plank walls with a lifted
 * hatch on the +z side, and a shingled gable roof. Knobs: `halfX` default 4 (clamped 3..7), `halfZ`
 * default 3 (clamped 2..6), `lift` default 4 stump rows (clamped 3..8).
 * Footprint `(2*halfX+5)` x `(3*halfZ+4)` cells - 13 x 13 at the defaults, 19 x 22 at the clamps -
 * and `lift + 12` rows tall. The ramp runs out on +z. Glow: 0.
 */
export function granary(world: VoxelWorld, a: BuilderArgs): void {
  const halfX = clampInt(opt(a, 'halfX', 4), 3, 7);
  const halfZ = clampInt(opt(a, 'halfZ', 3), 2, 6);
  const lift = clampInt(opt(a, 'lift', 4), 3, 8);
  const { x, y, z } = a;
  const hx = halfX - 1;
  const hz = halfZ - 1;
  const floor = y + lift;

  // stumps on stone bases, corner posts and mid-span posts
  const sites: Array<[number, number]> = [];
  for (const [sx, sz] of CORNERS) sites.push([sx * hx, sz * hz]);
  sites.push([0, -hz], [0, hz], [-hx, 0], [hx, 0]);
  for (const [dx, dz] of sites) {
    world.set(x + dx, y, z + dz, tint(C.stone, x + dx, y, z + dz, 0.07), put(a, 0));
    for (let r = y + 1; r < floor; r++)
      world.set(x + dx, r, z + dz, tint(C.ironwood, x + dx, r, z + dz, 0.06), put(a, 0.06));
    if (lift > 4) world.set(x + dx, floor - 2, z + dz, shade(C.barkLite, 0.95), put(a, 0.1));
  }
  // stretchers tying the trestles together
  for (const dz of [-hz, 0, hz]) world.beam([x - hx, floor - 2, z + dz], [x + hx, floor - 2, z + dz], 0, C.woodDark, put(a, 0.12));
  for (const dx of [-hx, 0, hx]) world.beam([x + dx, floor - 2, z - hz], [x + dx, floor - 2, z + hz], 0, C.woodDark, put(a, 0.12));

  // plank floor with a skirt board
  world.box(x - hx - 1, floor, z - hz, x + hx + 1, floor, z + hz, tint(C.wood, x, floor, z, 0.07), put(a, 0.2));
  world.box(x - hx - 1, floor - 1, z - hz, x + hx + 1, floor - 1, z + hz, shade(C.woodDark, 0.9), put(a, 0.18));

  // store body
  const wallTop = floor + 4;
  for (let r = floor + 1; r <= wallTop; r++) {
    for (const [dx, dz] of ring(hx + 1, hz)) {
      const post = (Math.abs(dx) === hx + 1 && Math.abs(dz) === hz) || (dz === 0 && Math.abs(dx) === hx + 1) || (dx === 0);
      const hatch = dz === hz && Math.abs(dx) <= 1 && r >= floor + 1 && r <= floor + 2;
      if (hatch) continue;
      world.set(
        x + dx,
        r,
        z + dz,
        post ? tint(C.bark, x + dx, r, z + dz, 0.05) : tint(((r + 100) % 2 === 0 ? C.bambooDeep : C.wood), x + dx, r, z + dz, 0.05),
        put(a, 0.3),
      );
    }
  }
  // hatch with a lifting pole and grain sacks inside the opening
  for (const dx of [-2, 2]) for (let r = floor + 1; r <= floor + 3; r++) world.set(x + dx, r, z + hz, C.barkLite, put(a, 0.36));
  world.box(x - 2, floor + 4, z + hz, x + 2, floor + 4, z + hz, C.woodDark, put(a, 0.4));
  for (const dx of [-1, 0]) {
    world.set(x + dx, floor + 1, z + hz, C.sand, put(a, 0.52));
    world.set(x + dx, floor + 2, z + hz - 1, C.gravel, put(a, 0.56));
  }
  world.set(x, floor + 2, z + hz, C.bambooLite, put(a, 0.6));

  // shingled roof, ridge along x
  const g: GableSpec = {
    cx: x,
    cz: z,
    hx: hx + 2,
    hz: hz + 2,
    eave: wallTop + 1,
    rise: 4,
    ogee: 1.35,
    f0: 0.55,
    f1: 0.86,
    seed: a.seed + 11,
    tile: C.bambooDeep,
    rib: C.woodDark,
    soffit: mixHex(C.lacquer, C.goldPale, 0.45),
    ridgeCap: C.ironwood,
  };
  gableRoof(world, a, g);
  for (const side of [-1, 1]) gableWall(world, a, g, x + side * (hx + 2), wallTop, C.bambooDeep, 0.6);
  gableVent(world, a, x - (hx + 2), wallTop + 2, z, 0.88);

  // ramp down to the ground on +z
  for (let k = 0; k <= hz + 3; k++) {
    const r = floor - 1 - Math.floor((k * (lift - 1)) / (hz + 3));
    world.box(x - 1, r, z + hz + 1 + k, x + 1, r, z + hz + 1 + k, tint(C.woodDark, x, r, z + hz + k, 0.06), put(a, 0.24));
  }
}

/**
 * Timber jetty reaching out over the water. Knobs: `len` default 22 cells along +x (clamped 8..60),
 * `wid` default 7 cells across z (clamped 3..15). Driven pile rows every 3 cells, stretchers, a deck
 * 2 cells thick, mooring posts at the head, a crate and a barrel, and a ladder down the far end.
 * The deck top sits 3 rows above `a.y`; nothing is written below `a.y`. Footprint `len` x `wid`.
 */
export function dock(world: VoxelWorld, a: BuilderArgs): void {
  const len = clampInt(opt(a, 'len', 22), 8, 60);
  const wid = clampInt(opt(a, 'wid', 7), 3, 15);
  const { x, y, z } = a;
  const back = Math.floor((len - 1) / 2);
  const front = len - 1 - back;
  const hw = Math.floor(wid / 2);
  const deck = y + 3;

  // pile bents
  for (let k = 0; k <= back + front; k += 3) {
    const u = x - back + k;
    for (const dz of [-hw, hw]) {
      for (let r = y; r <= deck; r++) world.set(u, r, z + dz, tint(C.ironwood, u, r, z + dz, 0.07), put(a, 0));
    }
    if (hw >= 3) for (let r = y; r <= deck - 2; r++) world.set(u, r, z, tint(C.ironwood, u, r, z, 0.07), put(a, 0.02));
    for (let r = deck - 2; r <= deck - 1; r++) world.box(u, r, z - hw, u, r, z + hw, shade(C.woodDark, 0.95), put(a, 0.08));
  }
  // stringers along the length
  for (const dz of [-hw, 0, hw]) world.beam([x - back, deck - 1, z + dz], [x + front, deck - 1, z + dz], 0, C.woodDark, put(a, 0.12));

  // deck: two courses of planks running along x
  for (let u = x - back; u <= x + front; u++) {
    for (let dz = -hw; dz <= hw; dz++) {
      const end = u === x - back || u === x + front || (u - (x - back)) % 5 === 0;
      const hex = end ? shade(C.woodDark, 0.96) : dz % 2 === 0 ? tint(C.wood, u, deck, z + dz, 0.06) : shade(C.wood, 0.9);
      world.set(u, deck, z + dz, hex, put(a, 0.2));
      world.set(u, deck - 1, z + dz, shade(C.ironwoodLite, 0.95), put(a, 0.18));
    }
  }

  // mooring posts at the head and at the bend
  for (const mx of [x + front - 1, x - back + 2]) {
    for (const mz of [hw - 1, -(hw - 1)]) {
      for (let r = deck + 1; r <= deck + 2; r++) world.set(mx, r, z + mz, tint(C.barkLite, mx, r, z + mz, 0.06), put(a, 0.5));
      world.set(mx, deck + 3, z + mz, C.goldPale, put(a, 0.6));
    }
  }

  // cargo near the shore end: a crate and a barrel
  world.box(x - back + 4, deck + 1, z - 2, x - back + 5, deck + 2, z - 1, tint(C.woodDark, x - back + 4, deck + 1, z - 2, 0.07), put(a, 0.62));
  for (let r = deck + 1; r <= deck + 3; r++) {
    world.set(x - back + 7, r, z + 1, r === deck + 2 ? C.bark : tint(C.barkLite, x - back + 7, r, z + 1, 0.05), put(a, 0.66));
    world.set(x - back + 7, r, z + 2, r === deck + 2 ? C.bark : tint(C.barkLite, x - back + 7, r, z + 2, 0.05), put(a, 0.66));
  }

  // ladder down the head of the jetty
  for (const dz of [hw - 1, hw]) {
    for (let r = y; r <= deck; r++) world.set(x + front, r, z + dz, tint(C.bamboo, x + front, r, z + dz, 0.05), put(a, 0.72));
  }
  for (let r = y + 1; r <= deck - 1; r += 2) world.set(x + front - 1, r, z + hw - 1 + 1, C.bambooDeep, put(a, 0.76));
}

/**
 * Split-rail fence running along +x, centred on `a.x`: posts every 4 cells on stone footings, two
 * rails with an occasional break, moss on a few post caps. Knobs: `len` default 24 cells (clamped
 * 6..96), `h` default 4 (clamped 3..8). Footprint `len - 1` x 1 cells, `h + 2` rows tall.
 */
export function fenceRun(world: VoxelWorld, a: BuilderArgs): void {
  const len = clampInt(opt(a, 'len', 24), 6, 96);
  const h = clampInt(opt(a, 'h', 4), 3, 8);
  const { x, y, z } = a;
  const half = Math.floor((len - 1) / 2);
  const rails = [y + Math.max(1, Math.round(h * 0.4)), y + h - 1];
  for (let u = x - half; u <= x + half; u++) {
    if ((u - (x - half)) % 4 === 0) {
      world.set(u, y, z, tint(C.stone, u, y, z, 0.07), put(a, 0));
      for (let r = y + 1; r <= y + h; r++) world.set(u, r, z, tint(C.bark, u, r, z, 0.07), put(a, 0.04));
      if (hash3(u, 0, z, a.seed + 3) > 0.6) {
        world.set(u, y + h + 1, z, C.mossLite, { kind: Kind.Foliage, sway: swayAt(h + 1, h + 2, 0.5), ...put(a, 0.9) });
      } else {
        world.set(u, y + h + 1, z, C.barkLite, put(a, 0.9));
      }
      continue;
    }
    for (const r of rails) {
      if ((u + 100) % 9 === 0) continue;
      world.set(u, r, z, tint((u + r) % 2 === 0 ? C.wood : C.bambooDeep, u, r, z, 0.06), put(a, 0.3));
    }
  }
}

/**
 * Banner pole: a stone drum, a timber mast, a gilt finial and a cross spar, from which a 1-cell-thick
 * cloth hangs in the `z` plane so a walker moving along +x reads its face. The hem waves on `hash3`.
 * Knobs: `h` default 18 (clamped 12..34, mast rows), `banner` 1|0 default 1 (0 draws a bare spar).
 * Footprint 7 x 3 cells, tallest cell `a.y + h + 2`.
 */
export function bannerPole(world: VoxelWorld, a: BuilderArgs): void {
  const h = clampInt(opt(a, 'h', 18), 12, 34);
  const show = Math.round(opt(a, 'banner', 1)) === 0 ? 0 : 1;
  const { x, y, z } = a;

  // drum and guy stones
  world.box(x - 1, y, z - 1, x + 1, y, z + 1, tint(C.stone, x, y, z, 0.07), put(a, 0));
  world.set(x, y + 1, z, C.marbleDeep, put(a, 0.04));

  // mast
  for (let r = y + 2; r <= y + h; r++) world.set(x, r, z, tint(C.bark, x, r, z, 0.06), put(a, 0.08));

  // cross spar and its braces
  const spar = y + h - 2;
  for (const dx of [-3, 3]) world.beam([x + dx, spar, z], [x + dx, spar + 2, z], 0, C.barkLite, put(a, 0.3));
  world.beam([x - 3, spar, z], [x + 3, spar, z], 0, C.barkLite, put(a, 0.26));
  for (const dx of [-1, 1]) {
    world.set(x + dx, spar + 1, z, C.bark, put(a, 0.32));
    world.set(x + 2 * dx, spar + 2, z, C.bark, put(a, 0.34));
  }

  if (show) {
    const hem = y + 5;
    for (let dx = -3; dx <= 3; dx++) {
      const drop = hash3(dx, 0, z, a.seed + 17) > 0.62 ? 1 : 0;
      for (let r = spar - 1; r >= hem + drop; r--) {
        const stripe = (((dx + 3) / 2) | 0) % 2 === 0;
        world.set(
          x + dx,
          r,
          z + 1,
          stripe ? tint(C.vermilion, x + dx, r, z + 1, 0.05) : C.vermilionDeep,
          { sway: swayAt(r - y, h + 2, 0.7), ...put(a, 0.5) },
        );
      }
      world.set(x + dx, hem + drop - 1, z + 1, C.goldLite, { sway: swayAt(hem - y, h + 2, 0.9), ...put(a, 0.86) });
    }
    // a knot of rope tying the cloth to the spar
    for (const dx of [-3, 0, 3]) world.set(x + dx, spar - 1, z + 1, ROPE, put(a, 0.56));
  }

  // finial
  world.set(x, y + h + 1, z, C.gold, put(a, 0.92));
  world.set(x, y + h + 2, z, C.gilt, put(a, 1));
}

/**
 * Processional stone stair descending along +x. `a.y` is the row of the TOP landing, so unlike the
 * other builders this one runs *downward* from it — the composer places it where a terrace steps to
 * the level below. Knobs: `len` default 18 tread columns (clamped 6..48), `width` default 9 (clamped
 * 5..18), `drop` default `round(len / 2)` rows (clamped 4..24) — the fall is about one row every two
 * columns (~30 deg); after every 6 tread columns a flat landing 2 cells deep. Both edges carry a
 * `marbleDeep` kerb one row above the tread and a solid stepped stringer under it; each landing gets
 * a lantern in both kerbs. Footprint `(len + 2)` x `(width + 2)` cells. Glow: 2 per landing.
 */
export function stairRun(world: VoxelWorld, a: BuilderArgs): void {
  const len = clampInt(opt(a, 'len', 18), 6, 48);
  const width = clampInt(opt(a, 'width', 9), 5, 18);
  const drop = clampInt(opt(a, 'drop', Math.round(len / 2)), 4, 24);
  const { x, y, z } = a;
  const hw = Math.floor(width / 2);
  const total = len + 2;
  const unit = 8;

  // walk the run once so the descent lands exactly on `drop` rows and the landings stay flat
  let treads = 0;
  for (let i = 0; i < total; i++) if (i % unit < 6) treads++;
  const step = drop / Math.max(1, treads);
  const rows: number[] = [];
  const land: boolean[] = [];
  let cur = y;
  let acc = 0;
  for (let i = 0; i < total; i++) {
    const landing = i % unit >= 6;
    rows.push(cur);
    land.push(landing);
    if (landing) continue;
    acc += step;
    if (acc >= 1) {
      const d = Math.floor(acc);
      cur -= d;
      acc -= d;
    }
  }
  const bottom = cur;

  for (let i = 0; i < total; i++) {
    const row = rows[i];
    const f = 0.05 + (0.5 * i) / total;
    for (let dz = -hw; dz <= hw; dz++) {
      const edge = Math.abs(dz) === hw;
      world.set(
        x + i,
        row,
        z + dz,
        tint((i + dz) % 2 === 0 ? C.marbleLite : C.stone, x + i, row, z + dz, 0.05),
        put(a, f),
      );
      world.set(x + i, row - 1, z + dz, shade(C.marbleDeep, 0.92), put(a, f));
      if (!edge) continue;
      for (let r = row - 2; r >= bottom; r--) world.set(x + i, r, z + dz, tint(C.stone, x + i, r, z + dz, 0.06), put(a, f + 0.05));
    }
  }

  for (const sz of [-1, 1]) {
    for (let i = 0; i < total; i++) {
      const row = rows[i];
      const f = 0.55 + (0.25 * i) / total;
      const kz = z + sz * (hw + 1);
      world.set(x + i, row + 1, kz, tint(C.marbleDeep, x + i, row + 1, kz, 0.05), put(a, f));
      if (land[i] && i % unit === unit - 1) {
        world.set(x + i, row + 2, kz, C.marbleLite, put(a, f + 0.12));
        world.set(x + i, row + 3, kz, C.lanternCore, { kind: Kind.Glow, glow: 0.95, ...put(a, 0.92) });
      }
    }
  }
}

/**
 * Village well: a dry-stone ring with a pale coping, water in the throat, a timber frame and beam, a
 * bronze pulley and a bucket on a rope, all under a small tiled gable. Knobs: `r` default 3 (clamped
 * 2..5, the outer radius of the ring in cells). Footprint `(2r+7)` x `(2r+3)` cells, 15 rows tall.
 */
export function stoneWell(world: VoxelWorld, a: BuilderArgs): void {
  const r = clampInt(opt(a, 'r', 3), 2, 5);
  const { x, y, z } = a;
  const inner = (r - 1.6) * (r - 1.6);

  // ring wall and coping
  for (let dx = -r; dx <= r; dx++) {
    for (let dz = -r; dz <= r; dz++) {
      const d2 = dx * dx + dz * dz;
      if (d2 > r * r) continue;
      if (d2 > inner) {
        for (let row = y; row <= y + 2; row++)
          world.set(x + dx, row, z + dz, tint(row === y ? C.stone : C.stoneLite, x + dx, row, z + dz, 0.07), put(a, 0.02));
      } else {
        world.set(x + dx, y + 1, z + dz, C.waterGlow, { kind: Kind.Water, glow: 0.45, ...put(a, 0.3) });
      }
      if (d2 <= (r + 0.5) * (r + 0.5) && d2 > inner)
        world.set(x + dx, y + 3, z + dz, tint(C.marbleLite, x + dx, y + 3, z + dz, 0.05), put(a, 0.4));
    }
  }

  // frame, beam, pulley
  for (const sx of [-1, 1]) {
    for (let row = y; row <= y + 7; row++) world.set(x + sx * (r + 1), row, z, tint(C.bark, x + sx * (r + 1), row, z, 0.06), put(a, 0.1));
    world.set(x + sx * (r + 2), y, z, C.stone, put(a, 0));
  }
  world.beam([x - r - 1, y + 8, z], [x + r + 1, y + 8, z], 0, C.woodDark, put(a, 0.34));
  for (const dx of [-1, 0, 1]) world.set(x + dx, y + 7, z, C.bronze, put(a, 0.5));
  world.set(x, y + 6, z, C.bronze, put(a, 0.54));

  // sheltering gable
  const g: GableSpec = {
    cx: x,
    cz: z,
    hx: r + 2,
    hz: r + 1,
    eave: y + 9,
    rise: 3,
    ogee: 1.3,
    f0: 0.6,
    f1: 0.86,
    seed: a.seed + 5,
    tile: C.tile,
    rib: C.tileRim,
    soffit: mixHex(C.lacquer, C.goldPale, 0.5),
    ridgeCap: C.tileDeep,
  };
  gableRoof(world, a, g);

  // rope and bucket, the last thing to arrive
  world.set(x, y + 5, z, ROPE, put(a, 0.9));
  world.set(x, y + 4, z, ROPE, put(a, 0.9));
  for (const dx of [-1, 0, 1]) world.set(x + dx, y + 3, z, dx === 0 ? C.waterLite : C.bambooLite, put(a, 0.96));
}

/**
 * Carved signpost: stone footing, timber mast, a long arm pointing +x and a short arm pointing -x,
 * each with a painted board on both faces, braces under the long arm and a gilt head.
 * Knobs: `h` default 10 (clamped 7..18, mast rows). Footprint 9 x 3 cells, tallest `a.y + h + 2`.
 */
export function signPost(world: VoxelWorld, a: BuilderArgs): void {
  const h = clampInt(opt(a, 'h', 10), 7, 18);
  const { x, y, z } = a;

  world.box(x - 1, y, z - 1, x + 1, y, z + 1, tint(C.stone, x, y, z, 0.07), put(a, 0));
  for (let r = y + 1; r <= y + h; r++) world.set(x, r, z, tint(C.bark, x, r, z, 0.06), put(a, 0.06));

  const armA = y + h - 1;
  const armB = y + h - 4;
  for (let i = 1; i <= 5; i++) world.set(x + i, armA, z, tint(C.woodDark, x + i, armA, z, 0.06), put(a, 0.36));
  for (let i = 1; i <= 3; i++) world.set(x - i, armB, z, tint(C.woodDark, x - i, armB, z, 0.06), put(a, 0.4));
  for (let i = 1; i <= 5; i++) {
    for (const sz of [-1, 1]) {
      world.set(x + i, armA - 1, z + sz, i % 3 === 0 ? C.vermilion : tint(C.paper, x + i, armA - 1, z + sz, 0.04), put(a, 0.6));
    }
  }
  for (let i = 1; i <= 3; i++) {
    for (const sz of [-1, 1]) {
      world.set(x - i, armB - 1, z + sz, i === 2 ? C.vermilion : tint(C.paper, x - i, armB - 1, z + sz, 0.04), put(a, 0.64));
    }
  }
  // braces
  for (const sz of [-1, 1]) {
    world.set(x + 2, armA - 2, z + sz, C.barkLite, put(a, 0.5));
    world.set(x + 1, armA - 1, z + sz, C.barkLite, put(a, 0.5));
    world.set(x - 1, armB - 2, z + sz, C.barkLite, put(a, 0.52));
  }
  world.set(x, y + h + 1, z, C.marbleLite, put(a, 0.86));
  world.set(x, y + h + 2, z, C.gold, put(a, 1));
}

/**
 * Dry-stone retaining wall along +x, the thing that holds the paddies on the terraces: two cells
 * thick, coursed with jointed faces, a pale cop row overhanging one cell each side and a weep hole
 * every sixth column. `a.y` is the row of the ground in front of the wall; the face rises `h` rows
 * and the cap sits on top. Knobs: `len` default 24 (clamped 6..96), `h` default 4 (clamped 3..8).
 * Footprint `(len + 1)` x 4 cells, `h + 1` rows tall. Glow: 0.
 */
export function terraceWall(world: VoxelWorld, a: BuilderArgs): void {
  const len = clampInt(opt(a, 'len', 24), 6, 96);
  const h = clampInt(opt(a, 'h', 4), 3, 8);
  const { x, y, z } = a;
  for (let i = 0; i <= len; i++) {
    const f = 0.02 + 0.5 * (i / (len + 1));
    for (let dz = 0; dz <= 1; dz++) {
      for (let dy = 0; dy < h; dy++) {
        const wy = y + dy;
        // a stone is 2-3 cells wide along the course; the seam between stones reads as a joint
        const course = Math.floor((i + (dy % 2) * 2) / 3);
        const seam = i % 3 === (dy % 2) * 2;
        const weep = dy === 0 && i % 6 === 3 && dz === 1;
        const hex = weep
          ? C.soilDark
          : seam
            ? tint(C.slate, x + i, wy, z + dz, 0.05)
            : tint(course % 3 === 0 ? C.stoneLite : C.stone, x + i, wy, z + dz, 0.07);
        world.set(x + i, wy, z + dz, hex, put(a, f + 0.04 * dy));
      }
    }
  }
  const cy = y + h;
  for (let i = 0; i <= len; i++) {
    for (let dz = -1; dz <= 2; dz++) {
      world.set(x + i, cy, z + dz, tint(C.marbleLite, x + i, cy, z + dz, 0.06), put(a, 0.62));
    }
  }
}

/**
 * Paddy bund: a rectangular ridge of `soil` and `moss` one cell wide enclosing a flooded plot, the
 * interior planted with short `bambooLite` and `leaf` seedlings on a 3-cell pitch and standing one
 * row above the bund. Knobs: `wid` default 30 (clamped 12..33, cells along x), `dep` default 22
 * (clamped 10..25, cells along z). Footprint `2*floor(wid/2)+1` x `2*floor(dep/2)+1` cells - 33 x 25 at
 * the clamps - and at most 4 rows tall. Glow: 0.
 */
export function paddyRidge(world: VoxelWorld, a: BuilderArgs): void {
  const wid = clampInt(opt(a, 'wid', 30), 12, 33);
  const dep = clampInt(opt(a, 'dep', 22), 10, 25);
  const { x, y, z } = a;
  const hx = Math.floor(wid / 2);
  const hz = Math.floor(dep / 2);

  // flooded interior: shallow water the seedlings stand in
  for (let dx = -hx + 1; dx <= hx - 1; dx++) {
    for (let dz = -hz + 1; dz <= hz - 1; dz++) {
      world.set(x + dx, y, z + dz, C.waterGlow, { kind: Kind.Water, glow: 0.22, ...put(a, 0.05) });
    }
  }

  // seedlings, every third cell, tallest toward the far side of the terrace
  for (let dx = -hx + 2; dx <= hx - 2; dx += 3) {
    for (let dz = -hz + 2; dz <= hz - 2; dz += 3) {
      if (hash3(x + dx, y, z + dz, a.seed + 5) < 0.16) continue;
      const stalk = hash3(x + dx, y, z + dz, a.seed + 11) > 0.62 ? 2 : 1;
      for (let dy = 1; dy <= stalk; dy++) {
        world.set(x + dx, y + dy, z + dz, dy === stalk ? C.bambooLite : C.bamboo, {
          kind: Kind.Foliage,
          sway: swayAt(dy, 3, 0.5),
          ...put(a, 0.45 + 0.05 * dy),
        });
      }
      if (hash3(x + dx, y, z + dz, a.seed + 17) > 0.72) {
        world.set(x + dx, y + stalk + 1, z + dz, tint(C.leaf, x + dx, y + stalk + 1, z + dz, 0.1), {
          kind: Kind.Foliage,
          sway: swayAt(stalk + 1, 3, 0.6),
          ...put(a, 0.72),
        });
      }
    }
  }

  // the bund: a raised earth ring with a mossy crest and a slip of an inlet at the +z corner
  for (let dx = -hx; dx <= hx; dx++) {
    for (let dz = -hz; dz <= hz; dz++) {
      if (Math.max(Math.abs(dx) - hx, Math.abs(dz) - hz) !== 0) continue;
      const f = 0.02 + 0.18 * ((dx + hx) / Math.max(1, wid - 1));
      world.set(x + dx, y, z + dz, tint(C.soil, x + dx, y, z + dz, 0.08), put(a, f));
      const cap = hash3(x + dx, y + 1, z + dz, a.seed + 23) > 0.55 ? C.mossLite : C.moss;
      world.set(x + dx, y + 1, z + dz, tint(cap, x + dx, y + 1, z + dz, 0.1), put(a, f + 0.3));
    }
  }
  for (const dz of [hz - 1, hz])
    world.set(x - hx + 2, y, z + dz, tint(C.gravel, x - hx + 2, y, z + dz, 0.06), put(a, 0.5));
}

/**
 * Flagstone path along +x: a gravel bed with irregular stones laid on it, each 2-3 cells long and
 * 2-3 cells wide, the line wandering a cell either side of the axis. Knobs: `len` default 24
 * (clamped 8..96), `wid` default 3 (clamped 2..6, the band the stones may sit across). Footprint
 * `len` x `(wid + 2)` cells, 2 rows tall.
 */
export function rockPath(world: VoxelWorld, a: BuilderArgs): void {
  const len = clampInt(opt(a, 'len', 24), 8, 96);
  const wid = clampInt(opt(a, 'wid', 3), 2, 6);
  const { x, y, z } = a;
  const hw = Math.floor(wid / 2);

  // gravel bed, patchy so the ground shows through in places
  for (let i = 0; i < len; i++) {
    for (let dz = -hw - 1; dz <= hw + 1; dz++) {
      if (hash3(x + i, y, z + dz, a.seed + 31) < 0.32) continue;
      world.set(x + i, y, z + dz, tint(C.gravel, x + i, y, z + dz, 0.1), put(a, 0.02));
    }
  }

  // the stones themselves, one stride at a time
  let i = 0;
  while (i < len) {
    const long = 2 + Math.floor(hash3(x + i, y, z, a.seed + 41) * 2);
    const span = 2 + Math.floor(hash3(x + i, y, z, a.seed + 47) * 2);
    const off = Math.round((hash3(x + i, y, z, a.seed + 53) - 0.5) * (wid - 1));
    const face = hash3(x + i, y, z, a.seed + 59) > 0.5 ? C.stoneLite : C.stone;
    const f = 0.3 + 0.55 * (i / len);
    for (let dx = 0; dx < long && i + dx < len; dx++) {
      for (let dz = 0; dz < span; dz++) {
        const pz = Math.max(-hw, Math.min(hw, off + dz - Math.floor((span - 1) / 2)));
        world.set(x + i + dx, y + 1, z + pz, tint(face, x + i + dx, y + 1, z + pz, 0.06), put(a, f));
      }
    }
    i += long + 1;
  }
}

/**
 * Rowing skiff grounded on the shore, keel along +x: a planked bottom that curves to a point at stem
 * and stern, sheer strakes raked up and picked out in vermilion at both ends, two thwarts, a coiled
 * rope and one oar shipped over the +z side. Knobs: `len` default 22 (clamped 20..26 cells along x).
 * Footprint `len` x 7 cells, 3 rows tall.
 */
export function boatStatic(world: VoxelWorld, a: BuilderArgs): void {
  const len = clampInt(opt(a, 'len', 22), 20, 26);
  const { x, y, z } = a;
  const hw = 3;

  for (let i = 0; i < len; i++) {
    const t = i / (len - 1);
    const w = Math.max(1, Math.round(hw * Math.sin(Math.PI * (0.07 + 0.86 * t))));
    const f = 0.04 + 0.4 * t;
    for (let dz = -(w - 1); dz <= w - 1; dz++) {
      world.set(
        x + i,
        y,
        z + dz,
        tint(dz === 0 ? C.ironwood : C.woodDark, x + i, y, z + dz, 0.07),
        put(a, f),
      );
    }
    const rake = t < 0.16 || t > 0.84 ? 2 : 1;
    for (const sz of [-1, 1]) {
      for (let dy = 1; dy <= rake; dy++) {
        const pz = z + sz * Math.max(1, w - 1);
        const hex = dy === rake && rake === 2 ? C.vermilion : tint(C.wood, x + i, y + dy, pz, 0.08);
        world.set(x + i, y + dy, pz, hex, put(a, f + 0.22));
      }
    }
  }

  // thwarts, then the gear, arriving last
  for (const frac of [0.34, 0.66]) {
    const i = Math.round(frac * (len - 1));
    for (let dz = -1; dz <= 1; dz++) world.set(x + i, y + 1, z + dz, C.barkLite, put(a, 0.68));
  }
  for (const dz of [-1, 0]) world.set(x + len - 4, y + 1, z + dz, ROPE, put(a, 0.84));
  for (let k = 0; k < 5; k++) {
    world.set(x + Math.round(len * 0.4) + k, y + 2, z + 2 + Math.floor(k / 2), k === 4 ? C.barkLite : C.bamboo, put(a, 0.9));
  }
}

/**
 * Mill water wheel, authored in a private lattice of 0.25 world units per cell and facing +x. The
 * disc lies in the x-y plane: two `woodDark` rims at z 2 and z 4, twelve `wood` paddles on the rim
 * at 30 degrees, four `ironwood` spokes across the hub at 45 degrees, an `ironwoodLite` axle stub
 * projecting from the hub toward -x, and six `bambooLite` ladles lashed inside the rim between the
 * paddles. Diameter 26 cells (6.5 world units); grid 27 x 27 x 5 cells, about 360 cells filled.
 *
 * Pivot `center` is the axle centre `[13, 13, 2]`, so spinning the mounted model about z turns the
 * wheel in its own plane; the rim reaches 13 cells (3.25 units) below the pivot. Reveal `dt` 0.9 s:
 * hub and spokes first, paddles, then the ladles.
 */
export function makeWaterwheel(seed: number): MovableModel {
  const dt = 0.9;
  const world = new VoxelWorld(27, 27, 5);
  const put2 = mput(world, dt);
  const d = rng((seed >>> 0) * 2654435761);
  const cx = 13;
  const cy = 13;
  const rimR = 11;

  // hub, then the axle stub walking off toward -x
  for (let dy = -2; dy <= 2; dy++) {
    for (let dz = -1; dz <= 1; dz++) {
      if (dy * dy > 4 - dz * dz * 1.4) continue;
      put2(cx, cy + dy, 2 + dz, grain(C.ironwoodLite, cx, cy + dy, 2 + dz, seed, 0.1), 0.05);
    }
  }
  for (let dz = 0; dz <= 4; dz++) put2(cx, cy, dz, C.ironwood, 0.08);
  for (let dx = 0; dx <= 3; dx++) put2(cx - dx, cy, 0, grain(C.ironwoodLite, cx - dx, cy, 0, seed, 0.1), 0.12);
  put2(cx - 4, cy, 0, C.goldDeep, 0.9);

  // two rims and the four spokes
  for (const rz of [2, 4]) {
    for (let dx = -rimR - 1; dx <= rimR + 1; dx++) {
      for (let dy = -rimR - 1; dy <= rimR + 1; dy++) {
        const r = Math.hypot(dx, dy);
        if (Math.abs(r - rimR) > 0.62) continue;
        put2(cx + dx, cy + dy, rz, grain(C.woodDark, cx + dx, cy + dy, rz, seed, 0.09), 0.18);
      }
    }
  }
  for (let s = 0; s < 4; s++) {
    const th = Math.PI / 4 + (s * Math.PI) / 2;
    for (let r = 3; r <= rimR; r++) {
      const px = cx + Math.round(r * Math.cos(th));
      const py = cy + Math.round(r * Math.sin(th));
      put2(px, py, 3, grain(C.ironwood, px, py, 3, seed, 0.1), 0.3);
    }
  }

  // twelve paddles, each a board lashed between the two rims
  for (let k = 0; k < 12; k++) {
    const th = (k * Math.PI) / 6 + d() * 0.05;
    const hex = k % 2 === 0 ? C.wood : shade(C.wood, 0.88);
    for (let r = rimR - 2; r <= rimR + 2; r++) {
      const px = cx + Math.round(r * Math.cos(th));
      const py = cy + Math.round(r * Math.sin(th));
      for (let dz = 2; dz <= 4; dz++)
        put2(px, py, dz, grain(hex, px, py, dz, seed + 7, 0.08), 0.5 + 0.1 * Math.abs(Math.sin(th)));
    }
  }

  // ladles lashed inside the rim, the last thing to arrive
  for (let k = 0; k < 6; k++) {
    const th = (k * Math.PI) / 6 + Math.PI / 12;
    for (let r = rimR - 4; r <= rimR - 2; r++) {
      const px = cx + Math.round(r * Math.cos(th));
      const py = cy + Math.round(r * Math.sin(th));
      put2(px, py, 4, r === rimR - 2 ? C.bambooLite : grain(C.bamboo, px, py, 4, seed + 13, 0.1), 0.86);
    }
    put2(cx + Math.round((rimR - 1) * Math.cos(th)), cy + Math.round((rimR - 1) * Math.sin(th)), 4, ROPE, 0.94);
  }

  return { world, center: [cx, cy, 2], dt };
}

/**
 * Canopy boat for the lake, authored in a private lattice of 0.25 world units per cell and facing
 * +x: a hollow planked hull that curves to a point at stem and stern with a `vermilionDeep` waterline
 * band, fore and aft decks, two thwarts, a domed canopy of `paper` panels between `woodDark` ribs
 * over the middle seat, a steering oar shipped aft over the +z quarter, a robed fisherman with a
 * straw hat standing at the stern, and one `lanternCore` stern lantern (Glow 0.8).
 *
 * Length 30 hull cells (7.5 world units), 8 wide with the shipped oar, 11 tall with the fisherman's
 * hat; grid 32 x 13 x 11 cells, about 330 cells filled. Pivot `center` is the hull's waterline centre
 * `[14.5, 3, 5]`, so the hull rides half-submerged on any mount. Reveal `dt` 0.8 s: keel first,
 * canopy, figure and lantern last.
 */
export function makeBoatModel(seed: number): MovableModel {
  const dt = 0.8;
  const world = new VoxelWorld(32, 13, 11);
  const put2 = mput(world, dt);
  const cz = 5;
  const wl = 3;
  const len = 30;
  /** half-beam of the hull at a station, 1 at both ends and 3 amidships */
  const hw = (i: number): number =>
    Math.max(1, Math.round(3.4 * Math.sin(Math.PI * (0.07 + 0.86 * (i / (len - 1))))));

  // hull shell: floor, flaring strakes, waterline band, inset gunwale
  for (let i = 0; i < len; i++) {
    const w = hw(i);
    const f = 0.02 + 0.34 * (i / (len - 1));
    const foot = Math.max(0, w - 2);
    for (let dz = -foot; dz <= foot; dz++)
      put2(i, wl - 2, cz + dz, grain(C.ironwood, i, wl - 2, cz + dz, seed, 0.07), f);
    for (const sz of [-1, 1]) {
      put2(i, wl - 1, cz + sz * (w - 1), grain(C.woodDark, i, wl - 1, cz + sz * (w - 1), seed, 0.09), f + 0.08);
      put2(i, wl, cz + sz * w, grain(C.vermilionDeep, i, wl, cz + sz * w, seed, 0.07), f + 0.16);
      put2(i, wl + 1, cz + sz * (w - 1), grain(C.wood, i, wl + 1, cz + sz * (w - 1), seed, 0.09), f + 0.24);
    }
  }

  // fore and aft decks and the two thwarts
  for (const i of [0, 1, 2, 3, len - 4, len - 3, len - 2, len - 1]) {
    const w = hw(i);
    for (let dz = -(w - 1); dz <= w - 1; dz++)
      put2(i, wl + 1, cz + dz, grain(C.barkLite, i, wl + 1, cz + dz, seed + 3, 0.08), 0.46);
  }
  for (const i of [11, 18]) {
    for (let dz = -1; dz <= 1; dz++) put2(i, wl + 2, cz + dz, C.wood, 0.5);
  }

  // domed canopy over the middle seat: ribs at every other station, paper panels between
  for (let i = 10; i <= 19; i++) {
    const along = 0.34 + 0.66 * Math.sin(Math.PI * ((i - 10) / 9));
    for (let dz = -2; dz <= 2; dz++) {
      const rise = Math.round(4.4 * Math.sqrt(Math.max(0, 1 - (dz * dz) / 7.3)) * along);
      if (rise < 1) continue;
      const rib = i % 2 === 0;
      for (let dy = rise; dy >= rise - (rise >= 3 ? 1 : 0); dy--) {
        const hex = rib ? C.woodDark : C.paper;
        put2(i, wl + 2 + dy, cz + dz, grain(hex, i, wl + 2 + dy, cz + dz, seed + 5, 0.07), 0.56);
      }
    }
  }

  // steering oar shipped aft, then the fisherman and his lantern
  for (let k = 0; k < 5; k++)
    put2(len - 4 + k, wl + 1 - Math.floor(k / 3), cz + 2 + Math.floor(k / 2), k >= 3 ? C.barkLite : C.bamboo, 0.8);
  const fx = len - 6;
  for (let dy = 0; dy < 2; dy++) put2(fx, wl + 2 + dy, cz, C.inkSoft, 0.84);
  for (let dy = 2; dy < 5; dy++)
    put2(fx, wl + 2 + dy, cz, grain(C.azure, fx, wl + 2 + dy, cz, seed + 17, 0.1), 0.86);
  put2(fx, wl + 7, cz, C.sand, 0.9);
  for (const dz of [-1, 0, 1]) put2(fx, wl + 8, cz + dz, STRAW, 0.94);
  for (const dx of [-1, 1]) put2(fx + dx, wl + 8, cz, STRAW, 0.94);
  put2(fx, wl + 4, cz - 2, C.lanternCore, 0.98, 0.8, Kind.Glow);
  put2(fx, wl + 3, cz - 2, C.ironwood, 0.92);

  return { world, center: [len / 2 - 0.5, wl, cz], dt };
}
