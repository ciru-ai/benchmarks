/**
 * JADEFALL grove library — the valley's planting, authored on the MID lattice (cell 0.6 world
 * units, 5 cells = 3 units). Full-colour dawn: maples in red/orange/gold, cherry and plum in
 * pink, bright bamboo, dark pine, willow at the water, reeds in the marsh, lotus in the ponds.
 *
 * Every canopy cell is `Kind.Foliage` with `sway: swayAt(heightAboveBase, total, strength)`, the
 * strength ramped per part so crowns breathe and roots do not; trunks and branch supports are
 * `Kind.Solid` and run continuously from `a.y` upward. Crowns are ellipsoidal clusters grown
 * outward from their axis with a hash-eroded rim and two or three tones per cluster — never a
 * perfect sphere — and a mass cell is laid only where it already touches something written, so
 * nothing floats. Reveal is support-first, ornament-last: `reveal(a, f)` with `dur: FADE`.
 */

import { C, clamp, hash3, lerp, mixHex, shade, smoothstep } from '../core/palette';
import { Kind, type Put, VoxelWorld } from '../core/VoxelWorld';
import { type BuilderArgs, FADE, dice, opt, reveal, swayAt } from './types';

// ------------------------------------------------------------------ palette ramps
// Each ramp is ordered dark → light: `tint` biases the lit (upper) side toward the bright end.

type Ramp = readonly number[];

const BARK: Ramp = [C.bark, C.barkLite, mixHex(C.bark, C.mossDeep, 0.3)];
const DARKBARK: Ramp = [C.ironwood, C.ironwoodLite, mixHex(C.bark, C.ironwoodLite, 0.5)];
const TWIG: Ramp = [C.woodDark, C.ironwood, C.ironwoodLite];
const ROCK: Ramp = [C.slate, C.stone, C.stoneLite];
const MOSS: Ramp = [C.mossDeep, C.moss, C.mossLite];
const NEEDLE: Ramp = [C.pineDeep, C.pine, mixHex(C.pine, C.mossLite, 0.45)];
const WEEP: Ramp = [mixHex(C.bambooDeep, C.moss, 0.45), C.leaf, mixHex(C.bambooLite, C.mossLite, 0.45)];
const FERN: Ramp = [mixHex(C.mossDeep, C.bambooDeep, 0.55), C.mossDeep, mixHex(C.moss, C.bambooLite, 0.4)];
const REED: Ramp = [mixHex(C.bambooDeep, C.mossDeep, 0.45), C.bambooDeep, C.bamboo];
const REEDHEAD: Ramp = [mixHex(C.soilDark, C.maple, 0.3), mixHex(C.bark, C.mapleOrange, 0.35), C.barkLite];
const SWORD: Ramp = [mixHex(C.bambooDeep, C.mossDeep, 0.5), C.bambooDeep, mixHex(C.bamboo, C.moss, 0.4)];
const PAD: Ramp = [C.mossDeep, C.lotusLeaf, mixHex(C.lotusLeaf, C.mossLite, 0.55)];
const BAOB: Ramp = [C.bambooDeep, C.bamboo, C.bambooLite];
const GOLDLOW: Ramp = [mixHex(C.ginkgo, C.bambooDeep, 0.55), mixHex(C.ginkgo, C.moss, 0.4), C.ginkgo];
const GOLD: Ramp = [C.ginkgo, mixHex(C.ginkgo, C.mapleGold, 0.45), mixHex(C.ginkgo, C.goldLite, 0.55)];
const BLOOM_A: Ramp = [C.plumDeep, C.plum, C.plumLite];
const BLOOM_B: Ramp = [C.plum, C.plumLite, C.cherryLite];
const BLOOM_C: Ramp = [C.cherryDeep, C.cherry, C.cherryLite];
const AZALEA: Ramp = [mixHex(C.plumDeep, C.ink, 0.28), C.plumDeep, C.plum, mixHex(C.plum, C.plumLite, 0.5)];
const FLECK: Ramp = [C.lanternCore];
const MAPLE: Ramp = [mixHex(C.mapleRed, C.ink, 0.3), C.mapleRed, C.maple, C.mapleOrange, C.mapleGold];

/** Golden angle in radians — spreads culms, strands and pads without a visible grid. */
const GA = 2.399963;

// ------------------------------------------------------------------ authoring helpers

/** Integer knob clamped to the range named in the builder's doc comment. */
function knob(a: BuilderArgs, name: string, def: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, Math.round(opt(a, name, def))));
}

/** Fractional knob clamped to the range named in the builder's doc comment. */
function knobf(a: BuilderArgs, name: string, def: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, opt(a, name, def)));
}

interface Craft {
  /** reveal fraction: 0 = the support that appears first, 1 = the ornament that lands last */
  f: number;
  /** whole height of the object in cells — the denominator of the sway ramp */
  total: number;
  /** sway weight at the top of this part; trunks low, crowns high */
  strength: number;
  /** hash offset so neighbouring parts never match */
  seed: number;
}

interface MassCraft extends Craft {
  /** 0..1 chance of dropping a surface cell — ragged rim. */
  erode: number;
  /** surface jitter in cells. */
  noise: number;
  /** cells within this many cells of the vertical axis are never eroded — the load path. Default 0. */
  spine?: number;
  /** write the mass as Solid (rock, rooted wood) instead of breathing Foliage. Default false. */
  solid?: boolean;
}

/** One cell's colour: a ramp entry drawn by hash, nudged up the ramp on the lit upper side. */
function tint(ramp: Ramp, q: number, grain: number, lit: boolean): number {
  const n = ramp.length;
  let i = Math.floor(q * n);
  if (i < 0) i = 0;
  if (i > n - 1) i = n - 1;
  if (lit && i < n - 1) i += 1;
  return shade(ramp[i], 0.84 + 0.3 * grain);
}

/**
 * Continuous woody support between two cell points. `side` is the square cross-section in cells
 * (1 or 2), centred on the line's column. Exactly one axis advances per cell, so every step is
 * face-adjacent to the last and the run never overshoots `y1`.
 */
function strut(
  world: VoxelWorld,
  a: BuilderArgs,
  x0: number,
  y0: number,
  z0: number,
  x1: number,
  y1: number,
  z1: number,
  side: number,
  ramp: Ramp,
  o: Craft,
): void {
  const s = Math.max(1, Math.round(side));
  const off = 1 - s;
  const ax = Math.abs(x1 - x0);
  const ay = Math.abs(y1 - y0);
  const az = Math.abs(z1 - z0);
  const ux = Math.sign(x1 - x0);
  const uy = Math.sign(y1 - y0);
  const uz = Math.sign(z1 - z0);
  const run = Math.max(1, ax + ay + az);
  let tx = 0;
  let ty = 0;
  let tz = 0;
  for (let k = 0; k <= run; k++) {
    if (k > 0) {
      // advance whichever axis is furthest behind its share of the run
      let best = -Infinity;
      let axis = -1;
      if (tx < ax) {
        best = (ax * k) / run - tx;
        axis = 0;
      }
      if (ty < ay) {
        const due = (ay * k) / run - ty;
        if (due > best) {
          best = due;
          axis = 1;
        }
      }
      if (tz < az && (az * k) / run - tz > best) axis = 2;
      if (axis === 0) tx += 1;
      else if (axis === 1) ty += 1;
      else if (axis === 2) tz += 1;
    }
    const px = x0 + ux * tx;
    const py = y0 + uy * ty;
    const pz = z0 + uz * tz;
    for (let dy = 0; dy < s; dy++) {
      const y = py + dy;
      if (y < a.y) continue;
      for (let dz = off; dz < off + s; dz++) {
        for (let dx = off; dx < off + s; dx++) {
          world.set(px + dx, y, pz + dz, tint(ramp, hash3(px + dx, y, pz + dz, o.seed), hash3(pz + dz, y, px + dx, o.seed + 41), false), {
            kind: Kind.Solid,
            t: reveal(a, o.f),
            dur: FADE,
            sway: swayAt(y - a.y, o.total, o.strength),
          });
        }
      }
    }
  }
}

/** True when a cell would touch something already written — nothing grows into thin air. */
function anchored(world: VoxelWorld, x: number, y: number, z: number): boolean {
  for (let dy = -1; dy <= 1; dy++) {
    for (let dz = -1; dz <= 1; dz++) {
      for (let dx = -1; dx <= 1; dx++) {
        if (world.occupied(x + dx, y + dy, z + dz)) return true;
      }
    }
  }
  return false;
}

/**
 * Ellipsoidal cluster of cells with a jittered, hash-eroded rim, grown outward from its axis row
 * by row. Erosion only ever removes a cell that nothing will be written above (`up > 1`) and never
 * touches the `spine`, and a cell is only laid where it touches something already written, so a
 * mass built from these keeps one continuous load path down to the wood below.
 */
function cluster(
  world: VoxelWorld,
  a: BuilderArgs,
  cx: number,
  cy: number,
  cz: number,
  rx: number,
  ry: number,
  rz: number,
  ramp: Ramp,
  o: MassCraft,
): void {
  const ax = Math.max(0.5, rx);
  const ay = Math.max(0.5, ry);
  const az = Math.max(0.5, rz);
  const erode = o.erode;
  const noise = o.noise;
  const spine = o.spine ?? 0;
  const kind: Kind = o.solid ? Kind.Solid : Kind.Foliage;
  const ex = Math.ceil(ax);
  const ey = Math.ceil(ay);
  const ez = Math.ceil(az);
  const rings = Math.max(ex, ez);
  for (let dy = -ey; dy <= ey; dy++) {
    const y = cy + dy;
    if (y < a.y) continue;
    for (let ring = 0; ring <= rings; ring++) {
      for (let dz = -ring; dz <= ring; dz++) {
        for (let dx = -ring; dx <= ring; dx++) {
          if (Math.max(Math.abs(dx), Math.abs(dz)) !== ring) continue;
          const x = cx + dx;
          const z = cz + dz;
          const q = hash3(x, y, z, o.seed);
          const d = Math.sqrt((dx / ax) ** 2 + (dy / ay) ** 2 + (dz / az) ** 2);
          if (d + (q - 0.5) * 2 * noise > 1) continue;
          const up = Math.sqrt((dx / ax) ** 2 + ((dy + 1) / ay) ** 2 + (dz / az) ** 2);
          const ragged = hash3(x, z, y, o.seed + 977) < (erode * (d - 0.64)) / 0.36;
          if (d > 0.64 && ragged && up > 1 && dx * dx + dz * dz > spine * spine) continue;
          if (y > a.y && !anchored(world, x, y, z)) continue;
          world.set(x, y, z, tint(ramp, hash3(x, z, y, o.seed + 31), q, dy > 0), {
            kind,
            t: reveal(a, o.f),
            dur: FADE,
            sway: swayAt(y - a.y, o.total, o.strength),
          });
        }
      }
    }
  }
}

/**
 * Repaint the exposed upper faces of an already-written mass: moss on rock, lantern flecks on a
 * shrub. `cut` is the hash threshold, 0 = every exposed face, 1 = none.
 */
function faceTint(
  world: VoxelWorld,
  a: BuilderArgs,
  x0: number,
  x1: number,
  y0: number,
  y1: number,
  z0: number,
  z1: number,
  ramp: Ramp,
  cut: number,
  o: Craft,
  solid: boolean,
): void {
  for (let y = Math.max(a.y, y0); y <= y1; y++) {
    for (let z = z0; z <= z1; z++) {
      for (let x = x0; x <= x1; x++) {
        if (!world.occupied(x, y, z) || world.occupied(x, y + 1, z)) continue;
        if (hash3(x, z, y, o.seed) < cut) continue;
        world.set(x, y, z, tint(ramp, hash3(x, y, z, o.seed + 19), hash3(x, z, y, o.seed + 57), true), {
          kind: solid ? Kind.Solid : Kind.Foliage,
          t: reveal(a, o.f),
          dur: FADE,
          sway: swayAt(y - a.y, o.total, o.strength),
        });
      }
    }
  }
}

/** Two-or-three-tone maple window: `hot` slides it from deep red toward orange and gold. */
function mapleRamp(hot: number, q: number): Ramp {
  const top = MAPLE.length - 3;
  const i = clamp(Math.round(q * top + (hot - 0.5) * 1.4), 0, top);
  return [MAPLE[i], MAPLE[i + 1], mixHex(MAPLE[i + 1], MAPLE[i + 2], 0.45)];
}

// ------------------------------------------------------------------ trees

/**
 * Conical evergreen: a 2×2 bole tapering to a single-cell spike, then flattened needle whorls
 * that shrink as they climb; the two lowest tiers are widened by paired side pads, each carried
 * by its own branch stub. Needle tones pine/pineDeep with a moss-lit top.
 *
 * Knobs: `h` cells above `a.y` (default 26, clamped 14…32); `whorls` (default 5, clamped 4…6).
 * Footprint radius `ceil(min(0.24 h, 6.5) + 0.7)` cells → 15×15 at the default, 17×17 at `h` = 32,
 * never wider than `h`; total height `h` rows. About 630 cells at the default, ≤ 830 at the
 * maximum knobs. Dry land — banks, terraces, ridge shoulder.
 */
export function pineTree(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const h = knob(a, 'h', 26, 14, 32);
  const whorls = knob(a, 'whorls', 5, 4, 6);
  const lean = Math.round(rnd() * 2) - 1;
  const mid = a.y + Math.round(h * 0.74);

  strut(world, a, a.x, a.y, a.z, a.x + lean, mid, a.z, 2, BARK, {
    f: 0.03,
    total: h,
    strength: 0.18,
    seed: a.seed,
  });
  strut(world, a, a.x + lean, mid, a.z, a.x + lean * 2, a.y + h, a.z, 1, BARK, {
    f: 0.16,
    total: h,
    strength: 0.34,
    seed: a.seed + 9,
  });

  const r0 = Math.max(2, Math.min(h * 0.24, 6.5));
  for (let i = 0; i < whorls; i++) {
    const k = whorls === 1 ? 0 : i / (whorls - 1);
    const cx = a.x + Math.round(lean * (0.35 + 0.65 * k));
    const cy = a.y + Math.round(h * (0.4 + 0.52 * k));
    const rr = Math.max(1.2, r0 * (1 - 0.92 * k)) + rnd() * 0.7;
    cluster(world, a, cx, cy, a.z, rr, 1.1 + 0.4 * (1 - k), rr, NEEDLE, {
      f: 0.32 + 0.5 * k,
      total: h,
      strength: 0.6 + 0.55 * k,
      seed: a.seed + i * 41,
      erode: 0.34,
      noise: 0.32,
      spine: 1,
    });
    if (i > 1) continue;
    for (let s = 0; s < 2; s++) {
      const ang = (s === 0 ? 0.6 : 3.7) + rnd() * 0.5;
      const sx = cx + Math.round(Math.cos(ang) * rr * 0.6);
      const sz = a.z + Math.round(Math.sin(ang) * rr * 0.6);
      strut(world, a, a.x + lean, cy - 1, a.z, sx, cy, sz, 1, TWIG, {
        f: 0.3 + 0.06 * i,
        total: h,
        strength: 0.45,
        seed: a.seed + 131 + i * 7 + s,
      });
      cluster(world, a, sx, cy + 1, sz, rr * 0.46, 1.05, rr * 0.46, NEEDLE, {
        f: 0.44 + 0.5 * k,
        total: h,
        strength: 0.85,
        seed: a.seed + 211 + i * 13 + s * 5,
        erode: 0.3,
        noise: 0.28,
      });
    }
  }

  cluster(world, a, a.x + lean * 2, a.y + h - 1, a.z, 1.15, 1.15, 1.15, NEEDLE, {
    f: 0.96,
    total: h,
    strength: 1.15,
    seed: a.seed + 77,
    erode: 0.18,
    noise: 0.2,
  });
}

/**
 * Layered maple: a short 2×2 bole splitting into three limbs, then a crown in two tiers of
 * flame-shaped clusters — three low and wide, the rest stacked to a dome. Each cluster mixes two
 * or three tones drawn from a red→gold window, so no two maples read alike.
 *
 * Knobs: `h` (default 22, clamped 12…34); `hot` 0..1 colour bias, 0 = deep red, 1 = orange/gold
 * (default 0.5, clamped); `clusters` total crown clusters (default 6, clamped 5…7).
 * Footprint radius `round(0.16 h) + 3` cells → 15×15 at the default, 17×17 at `h` = 34. About
 * 430–470 cells, ≤ 510 at the maximum knobs.
 */
export function mapleTree(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const h = knob(a, 'h', 22, 12, 34);
  const hot = knobf(a, 'hot', 0.5, 0, 1);
  const clusters = knob(a, 'clusters', 6, 5, 7);
  const lean = Math.round(rnd() * 2) - 1;
  const crownY = a.y + Math.round(h * 0.5);

  strut(world, a, a.x, a.y, a.z, a.x + lean, crownY, a.z, 2, BARK, {
    f: 0.03,
    total: h,
    strength: 0.2,
    seed: a.seed,
  });
  const arms = 3;
  for (let i = 0; i < arms; i++) {
    const ang = (i / arms) * Math.PI * 2 + 0.4 + rnd() * 0.5;
    strut(
      world,
      a,
      a.x + lean,
      crownY - 1,
      a.z,
      a.x + lean + Math.round(Math.cos(ang) * 3),
      crownY + 2 + Math.round(rnd() * 2),
      a.z + Math.round(Math.sin(ang) * 3),
      1,
      TWIG,
      { f: 0.2 + 0.05 * i, total: h, strength: 0.4, seed: a.seed + 61 + i },
    );
  }

  const ring = Math.max(2, Math.round(h * 0.16));
  const low = 3;
  const high = clusters - low - 1;
  for (let i = 0; i < low; i++) {
    const ang = (i / low) * Math.PI * 2 + rnd() * 0.5;
    cluster(
      world,
      a,
      a.x + Math.round(Math.cos(ang) * ring),
      crownY + 1,
      a.z + Math.round(Math.sin(ang) * ring),
      2.9 + rnd() * 0.5,
      2.2 + rnd() * 0.3,
      2.9 + rnd() * 0.5,
      mapleRamp(hot, rnd()),
      {
        f: 0.34 + 0.08 * i,
        total: h,
        strength: 0.8,
        seed: a.seed + 17 + i * 23,
        erode: 0.28,
        noise: 0.3,
        spine: 1,
      },
    );
  }
  for (let i = 0; i < high; i++) {
    const ang = (i / high) * Math.PI * 2 + 1.1 + rnd() * 0.4;
    cluster(
      world,
      a,
      a.x + Math.round(Math.cos(ang) * 2),
      crownY + 4 + Math.round(rnd()),
      a.z + Math.round(Math.sin(ang) * 2),
      2.5 + rnd() * 0.4,
      2 + rnd() * 0.3,
      2.5 + rnd() * 0.4,
      mapleRamp(hot, rnd()),
      {
        f: 0.6 + 0.09 * i,
        total: h,
        strength: 1,
        seed: a.seed + 103 + i * 29,
        erode: 0.26,
        noise: 0.3,
        spine: 1,
      },
    );
  }
  cluster(world, a, a.x + lean, crownY + 6, a.z, 2.1, 1.7, 2.1, mapleRamp(hot, rnd()), {
    f: 0.92,
    total: h,
    strength: 1.2,
    seed: a.seed + 307,
    erode: 0.22,
    noise: 0.24,
  });
}

/**
 * Spreading cherry: a dark bole to half height, one thin branch out to each blossom cloud, the
 * clouds set on a wide ring so the canopy overhangs far wider than the tree is tall, and a crown
 * cloud over the centre. Clouds mix plum / plumLite / cherryLite per cluster.
 *
 * Knobs: `h` (default 20, clamped 12…30); `clouds` ring clouds (default 8, clamped 5…11).
 * Footprint radius `round(0.32 h) + 3` cells → 19×19 at the default, ≤ 27×27 at `h` = 30 with 11
 * clouds; the canopy itself is about 7 rows deep. About 575 cells, ≤ 840 at the maximum knobs.
 */
export function cherryTree(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const h = knob(a, 'h', 20, 12, 30);
  const clouds = knob(a, 'clouds', 8, 5, 11);
  const lean = Math.round(rnd() * 2) - 1;
  const boleTop = a.y + Math.round(h * 0.48);
  const canopyY = a.y + Math.round(h * 0.66);
  const ring = Math.max(3, Math.round(h * 0.32));

  strut(world, a, a.x, a.y, a.z, a.x + lean, canopyY, a.z, 2, DARKBARK, {
    f: 0.03,
    total: h,
    strength: 0.18,
    seed: a.seed,
  });

  for (let i = 0; i < clouds; i++) {
    const ang = (i / clouds) * Math.PI * 2 + rnd() * 0.45;
    const rr = ring * (0.72 + rnd() * 0.28);
    const cx = a.x + Math.round(Math.cos(ang) * rr);
    const cz = a.z + Math.round(Math.sin(ang) * rr);
    const cy = canopyY + Math.round(rnd() * 2);
    strut(world, a, a.x + lean, boleTop, a.z, cx, cy - 1, cz, 1, DARKBARK, {
      f: 0.24 + 0.03 * i,
      total: h,
      strength: 0.35,
      seed: a.seed + 41 + i * 3,
    });
    const pick = rnd();
    cluster(world, a, cx, cy + 1, cz, 2 + rnd() * 0.6, 1.8 + rnd() * 0.3, 2 + rnd() * 0.6,
      pick < 0.34 ? BLOOM_A : pick < 0.67 ? BLOOM_B : BLOOM_C, {
      f: 0.46 + 0.04 * i,
      total: h,
      strength: 0.95,
      seed: a.seed + 151 + i * 19,
      erode: 0.26,
      noise: 0.3,
      spine: 1,
    });
  }

  cluster(world, a, a.x + lean, canopyY + 3, a.z, 3 + rnd() * 0.4, 2 + rnd() * 0.3, 3 + rnd() * 0.4, BLOOM_B, {
    f: 0.9,
    total: h,
    strength: 1.15,
    seed: a.seed + 401,
    erode: 0.22,
    noise: 0.26,
    spine: 1,
  });
}

/**
 * Fan-shaped ginkgo: a straight bole with two short leaders, then a crown built row by row of
 * elliptical discs whose radius grows with height — a flare, not a ball. The lowest rows are still
 * greening, the upper rows full gold.
 *
 * Knobs: `h` (default 24, clamped 14…28); `flare` crown radius in cells at the top (default
 * `round(0.24 h)`, clamped 2…7).
 * Footprint radius `flare + 1` cells → 15×15 at the default, 17×17 at the widest flare. About
 * 530–560 cells at the default, ≤ 845 at the maximum knobs.
 */
export function ginkgoTree(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const h = knob(a, 'h', 24, 14, 28);
  const lean = Math.round(rnd() * 2) - 1;
  const crownBase = a.y + Math.round(h * 0.4);
  const flare = Math.max(2, Math.min(7, Math.round(opt(a, 'flare', h * 0.24))));

  strut(world, a, a.x, a.y, a.z, a.x + lean, crownBase, a.z, 2, BARK, {
    f: 0.03,
    total: h,
    strength: 0.16,
    seed: a.seed,
  });
  for (let i = 0; i < 2; i++) {
    strut(
      world,
      a,
      a.x + lean,
      crownBase,
      a.z,
      a.x + lean + (i === 0 ? -1 : 1),
      a.y + Math.round(h * (i === 0 ? 0.6 : 0.66)),
      a.z,
      1,
      TWIG,
      { f: 0.2 + 0.04 * i, total: h, strength: 0.35, seed: a.seed + 23 + i },
    );
  }

  const rows = Math.max(6, h - Math.round(h * 0.4));
  for (let dy = 0; dy < rows; dy++) {
    const k = dy / (rows - 1);
    const rr = lerp(1.2, flare, smoothstep(0, 1, k)) + rnd() * 0.4;
    cluster(world, a, a.x + lean + Math.round(lean * k), crownBase + dy, a.z, rr, 0.5, rr * 0.7,
      k < 0.3 ? GOLDLOW : GOLD, {
      f: 0.28 + 0.6 * k,
      total: h,
      strength: 0.55 + 0.6 * k,
      seed: a.seed + 5 + dy * 17,
      erode: 0.3,
      noise: 0.28,
      spine: 1,
    });
  }
}

// ------------------------------------------------------------------ bamboo, willow, marsh

/**
 * Bamboo grove: `count` perfectly straight single-cell culms on a golden-angle spiral, each with
 * a darker node ring every 3 cells, a one-cell leaf sprig at every node above the fourth, and a
 * 3×3 leaf mass crowning the culm. Culm tones bamboo/bambooLite with bambooDeep nodes.
 *
 * Knobs: `count` culms (default 9, clamped 3…16); `h` tallest culm in cells (default 26, clamped
 * 14…36); each culm is 72–100 % of `h`.
 * Footprint radius `ceil(1.05 √(count−1)) + 1` cells → 9×9 at the default, ≤ 13×13 at `count` = 16;
 * 3×3 per culm. About 35–45 cells per culm, ≈ 360 at the default, ≤ 835 fully grown.
 */
export function bambooGrove(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const count = knob(a, 'count', 9, 3, 16);
  const h = knob(a, 'h', 26, 14, 36);
  const DIRS = [
    [1, 0],
    [0, 1],
    [-1, 0],
    [0, -1],
  ] as const;

  for (let i = 0; i < count; i++) {
    const ang = i * GA + rnd() * 0.5;
    const rr = 1.05 * Math.sqrt(i);
    const cx = a.x + Math.round(Math.cos(ang) * rr);
    const cz = a.z + Math.round(Math.sin(ang) * rr);
    const hh = Math.round(h * (0.72 + 0.28 * hash3(cx, 0, cz, a.seed + 3)));

    for (let y = a.y; y <= a.y + hh; y++) {
      const n = y - a.y;
      const q = hash3(cx, y, cz, a.seed + 11);
      const node = n % 3 === 0 && n > 0;
      const tone = node ? C.bambooDeep : q > 0.62 ? C.bambooLite : q > 0.24 ? C.bamboo : C.bambooDeep;
      world.set(cx, y, cz, shade(tone, 0.8 + 0.3 * hash3(cz, y, cx, a.seed + 29)), {
        kind: Kind.Foliage,
        t: reveal(a, 0.05 + 0.45 * (n / Math.max(1, hh))),
        dur: FADE,
        sway: swayAt(n, h, 0.5),
      });
      if (!node || n < 4) continue;
      const d = DIRS[(i + n) & 3];
      world.set(cx + d[0], y, cz + d[1], tint(BAOB, hash3(cx + d[0], y, cz + d[1], a.seed + 53), q, true), {
        kind: Kind.Foliage,
        t: reveal(a, 0.55 + 0.3 * (n / Math.max(1, hh))),
        dur: FADE,
        sway: swayAt(n, h, 0.95),
      });
    }

    // 3×3 leaf mass on top of the culm
    for (let dy = 0; dy < 3; dy++) {
      const y = a.y + hh + dy;
      const keep = dy === 2 ? 0.72 : dy === 1 ? 0.45 : 0.2;
      for (let dz = -1; dz <= 1; dz++) {
        for (let dx = -1; dx <= 1; dx++) {
          if (dx === 0 && dz === 0 && dy > 0) continue;
          const q = hash3(cx + dx, y, cz + dz, a.seed + 97 + i * 7);
          if (q < keep || !anchored(world, cx + dx, y, cz + dz)) continue;
          world.set(cx + dx, y, cz + dz, tint(BAOB, q, hash3(cz + dz, y, cx + dx, a.seed + 5), true), {
            kind: Kind.Foliage,
            t: reveal(a, 0.62 + 0.3 * dy),
            dur: FADE,
            sway: swayAt(y - a.y, h, 1.05),
          });
        }
      }
    }
  }

  // two shoots pushing up at the edge of the clump
  for (let i = 0; i < 2; i++) {
    const ang = count * GA + i * 1.7;
    const cx = a.x + Math.round(Math.cos(ang) * (1.2 * Math.sqrt(count) + 1));
    const cz = a.z + Math.round(Math.sin(ang) * (1.2 * Math.sqrt(count) + 1));
    const hh = 2 + Math.round(rnd() * 2);
    for (let n = 0; n <= hh; n++) {
      world.set(cx, a.y + n, cz, tint(BAOB, 0.85, hash3(cx, n, cz, a.seed + 7), true), {
        kind: Kind.Foliage,
        t: reveal(a, 0.7 + 0.1 * n),
        dur: FADE,
        sway: swayAt(n, h, 1.1),
      });
    }
  }
}

/**
 * Willow at the water: a leaning bole with three arching leaders, a crown mass of short fronds,
 * and `strands` single-cell weeping threads — each one finds the lowest crown cell over its column
 * and hangs straight down 6–10 cells from it. Strand tones leaf/bambooLite/moss, the brightest
 * green in the valley.
 *
 * Knobs: `h` (default 24, clamped 16…34); `strands` (default 22, clamped 12…34).
 * Footprint radius 5 cells → 11×11 whatever `h` is; strands stop above `a.y`. About 390–400 cells
 * at the default, ≤ 500 at the maximum knobs. Set its feet on the bank, not in deep water.
 */
export function willow(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const h = knob(a, 'h', 24, 16, 34);
  const strands = knob(a, 'strands', 22, 12, 34);
  const lean = Math.round(rnd() * 2) - 1;
  const crownBase = a.y + Math.round(h * 0.58);

  strut(world, a, a.x, a.y, a.z, a.x + lean, crownBase, a.z, 2, BARK, {
    f: 0.03,
    total: h,
    strength: 0.16,
    seed: a.seed,
  });
  for (let i = 0; i < 3; i++) {
    const ang = (i / 3) * Math.PI * 2 + 0.5 + rnd() * 0.4;
    strut(
      world,
      a,
      a.x + lean,
      crownBase - 1,
      a.z,
      a.x + Math.round(Math.cos(ang) * 3),
      crownBase + 2,
      a.z + Math.round(Math.sin(ang) * 3),
      1,
      TWIG,
      { f: 0.18 + 0.04 * i, total: h, strength: 0.4, seed: a.seed + 31 + i },
    );
  }

  cluster(world, a, a.x + lean, crownBase + 2, a.z, 4.2, 2.1, 4.2, WEEP, {
    f: 0.34,
    total: h,
    strength: 0.75,
    seed: a.seed + 71,
    erode: 0.26,
    noise: 0.3,
    spine: 1,
  });
  for (let i = 0; i < 2; i++) {
    const ang = i * Math.PI + 0.9 + rnd() * 0.4;
    cluster(
      world,
      a,
      a.x + Math.round(Math.cos(ang) * 3.4),
      crownBase + 1,
      a.z + Math.round(Math.sin(ang) * 3.4),
      2.1,
      1.6,
      2.1,
      WEEP,
      { f: 0.5 + 0.06 * i, total: h, strength: 0.95, seed: a.seed + 173 + i * 11, erode: 0.3, noise: 0.3 },
    );
  }

  for (let i = 0; i < strands; i++) {
    const ang = i * GA + rnd() * 0.3;
    const rr = 2 + Math.round(rnd() * 2.5);
    const sx = a.x + Math.round(Math.cos(ang) * rr);
    const sz = a.z + Math.round(Math.sin(ang) * rr);
    // hang the strand from whatever crown cell already overhangs this column
    let top = -1;
    for (let y = a.y + h; y > a.y; y--) {
      if (world.occupied(sx, y, sz)) {
        top = y - 1;
        break;
      }
    }
    if (top < a.y) continue;
    const drop = Math.min(6 + Math.round(rnd() * 4), top - a.y);
    for (let d = 0; d <= drop; d++) {
      const y = top - d;
      const q = hash3(sx, y, sz, a.seed + 211 + i);
      world.set(sx, y, sz, tint(WEEP, q, hash3(sz, y, sx, a.seed + 13), d < drop * 0.5), {
        kind: Kind.Foliage,
        t: reveal(a, 0.56 + 0.02 * i),
        dur: FADE,
        sway: swayAt(y - a.y, h, 1.35),
      });
    }
  }
}

/**
 * Marsh reeds: `count` single-cell stalks on a tight spiral, each leaning a cell or two over its
 * height, capped by a darker two-cell seed head; a third of them carry one side blade.
 *
 * Knobs: `count` (default 14, clamped 6…26). Stalk height 4–7 cells, 5–9 cells with the head.
 * Footprint radius `ceil(0.75 √(count−1)) + 1` cells → 9×9 at the default, ≤ 11×11 at `count` = 26.
 * About 95–110 cells, ≤ 190 at the maximum count. WATER BUILDER — put `a.y` on the marsh surface.
 */
export function reedClump(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const count = knob(a, 'count', 14, 6, 26);

  for (let i = 0; i < count; i++) {
    const ang = i * GA + rnd() * 0.4;
    const rr = 0.75 * Math.sqrt(i);
    const cx = a.x + Math.round(Math.cos(ang) * rr);
    const cz = a.z + Math.round(Math.sin(ang) * rr);
    const hh = 4 + Math.round(rnd() * 3);
    const bend = Math.round(rnd() * 2) - 1;
    let topX = cx;

    for (let n = 0; n < hh; n++) {
      const x = cx + Math.round(bend * (n / Math.max(1, hh)) * 1.5);
      const y = a.y + n;
      const q = hash3(x, y, cz, a.seed + i);
      world.set(x, y, cz, tint(REED, q, hash3(cz, y, x, a.seed + 17), n > 1), {
        kind: Kind.Foliage,
        t: reveal(a, 0.1 + 0.45 * (n / Math.max(1, hh)) + 0.02 * i),
        dur: FADE,
        sway: swayAt(n, 9, 1.15),
      });
      topX = x;
    }

    const head = hh >= 6 ? 2 : 1;
    for (let n = 1; n <= head; n++) {
      const y = a.y + hh - 1 + n;
      const q = hash3(topX, y, cz, a.seed + 91 + i);
      world.set(topX, y, cz, tint(REEDHEAD, q, hash3(cz, y, topX, a.seed + 5), n === 1), {
        kind: Kind.Foliage,
        t: reveal(a, 0.72 + 0.04 * n),
        dur: FADE,
        sway: swayAt(y - a.y, 9, 1.3),
      });
    }

    if (hh < 6 || rnd() < 0.4) continue;
    const d = (i + hh) & 3;
    const bx = topX + (d === 0 ? 1 : d === 2 ? -1 : 0);
    const bz = cz + (d === 1 ? 1 : d === 3 ? -1 : 0);
    world.set(bx, a.y + hh - 2, bz, tint(REED, 0.8, 0.5, true), {
      kind: Kind.Foliage,
      t: reveal(a, 0.66),
      dur: FADE,
      sway: swayAt(hh - 2, 9, 1.25),
    });
  }
}

// ------------------------------------------------------------------ water gardens

/**
 * Lotus bed: flat pads drawn as small discs 2–4 cells across at row `a.y`, a few raised blossoms
 * on stems (four `lotusPink` petals around one `lanternCore` centre — exactly one Glow cell per
 * blossom) and a couple of flat-topped seed heads on their own stems.
 *
 * Knobs: `r` footprint radius in cells (default 9, clamped 4…10); `pads` (default 14, clamped
 * 6…24); `flowers` blossoms (default 4, clamped 0…7 — that many Glow cells); `seeds` seed heads
 * (default 2, clamped 0…4).
 * Footprint radius `r` → 19×19 at the default, ≤ 21×21 at `r` = 10. About 120 cells, ≤ 220 full.
 * WATER BUILDER — place `a.y` on the pond/lake surface row so the pads float.
 */
export function lotusBed(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const spread = knob(a, 'r', 9, 4, 10);
  const pads = knob(a, 'pads', 14, 6, 24);
  const flowers = knob(a, 'flowers', 4, 0, 7);
  const seeds = knob(a, 'seeds', 2, 0, 4);
  const spots: number[][] = [];
  // the blossom cores are the bed's whole Glow budget: nothing else may paint over them
  const setKeep = (x: number, y: number, z: number, color: number, put: Put): void => {
    if (world.kindAt(x, y, z) === Kind.Glow) return;
    world.set(x, y, z, color, put);
  };

  for (let i = 0; i < pads; i++) {
    const ang = i * GA + rnd() * 0.6;
    const rr = Math.max(0, spread - 2) * Math.sqrt((i + 0.4) / pads);
    const cx = a.x + Math.round(Math.cos(ang) * rr);
    const cz = a.z + Math.round(Math.sin(ang) * rr);
    spots.push([cx, cz]);
    const d = 2 + Math.round(rnd() * 2);
    const lift = hash3(cx, 1, cz, a.seed + 3) > 0.8 ? 1 : 0;
    const lim = Math.floor(d / 2);
    const cut = (d / 2 - 0.25) ** 2;
    for (let dx = -lim; dx <= d - 1 - lim; dx++) {
      for (let dz = -lim; dz <= d - 1 - lim; dz++) {
        if (dx * dx + dz * dz > cut) continue;
        const x = cx + dx;
        const z = cz + dz;
        const q = hash3(x, 2, z, a.seed + 31 + i);
        world.set(x, a.y + lift, z, tint(PAD, q, hash3(z, 2, x, a.seed + 61), true), {
          kind: Kind.Solid,
          t: reveal(a, 0.06 + 0.3 * (rr / Math.max(1, spread))),
          dur: FADE,
        });
      }
    }
    if (lift) {
      // a lifted pad still needs its stem down to the mud
      world.set(cx, a.y, cz, shade(C.lotusLeaf, 0.66), {
        kind: Kind.Solid,
        t: reveal(a, 0.04),
        dur: FADE,
      });
    }
  }

  for (let i = 0; i < flowers; i++) {
    const s = spots[Math.floor((i * spots.length) / Math.max(1, flowers)) % Math.max(1, spots.length)];
    const stem = 2 + Math.round(rnd());
    for (let n = 1; n <= stem; n++) {
      setKeep(s[0], a.y + n, s[1], tint(PAD, 0.35, hash3(s[0], n, s[1], a.seed + 7), false), {
        kind: Kind.Solid,
        t: reveal(a, 0.5 + 0.06 * i),
        dur: FADE,
      });
    }
    const top = a.y + stem + 1;
    for (let p = 0; p < 4; p++) {
      const dx = p === 0 ? 1 : p === 1 ? -1 : 0;
      const dz = p === 2 ? 1 : p === 3 ? -1 : 0;
      setKeep(s[0] + dx, top, s[1] + dz, shade(C.lotusPink, 0.9 + 0.22 * hash3(s[0] + dx, top, s[1] + dz, a.seed + i)), {
        kind: Kind.Foliage,
        t: reveal(a, 0.78 + 0.04 * i),
        dur: FADE,
        sway: swayAt(top - a.y, stem + 2, 0.55),
      });
    }
    world.set(s[0], top, s[1], C.lanternCore, {
      kind: Kind.Glow,
      glow: 0.72,
      t: reveal(a, 0.92 + 0.02 * i),
      dur: FADE,
    });
    setKeep(s[0], top + 1, s[1], C.lotusCream, {
      kind: Kind.Foliage,
      t: reveal(a, 0.96),
      dur: FADE,
      sway: swayAt(top + 1 - a.y, stem + 2, 0.6),
    });
  }

  for (let i = 0; i < seeds; i++) {
    const s = spots[Math.floor(((i + 0.5) * spots.length) / Math.max(1, seeds)) % Math.max(1, spots.length)];
    const stem = 3 + Math.round(rnd());
    for (let n = 1; n <= stem; n++) {
      setKeep(s[0], a.y + n, s[1], shade(C.lotusLeaf, 0.72 + 0.2 * hash3(s[0], n, s[1], a.seed + 19)), {
        kind: Kind.Solid,
        t: reveal(a, 0.55 + 0.07 * i),
        dur: FADE,
      });
    }
    const top = a.y + stem + 1;
    setKeep(s[0], top, s[1], mixHex(C.lotusLeaf, C.goldPale, 0.55), {
      kind: Kind.Foliage,
      t: reveal(a, 0.84 + 0.05 * i),
      dur: FADE,
      sway: swayAt(top - a.y, stem + 2, 0.5),
    });
    setKeep(s[0], top + 1, s[1], shade(C.mossDeep, 0.9), {
      kind: Kind.Foliage,
      t: reveal(a, 0.9),
      dur: FADE,
      sway: swayAt(top + 1 - a.y, stem + 2, 0.55),
    });
  }
}

/**
 * Iris patch: low sword-leaf fans — each blade a single cell rising 3–5 rows and leaning one cell
 * out every other row — with a few taller flower stalks carrying `wisteria` petals and a single
 * `ruby` standard.
 *
 * Knobs: `crowns` leaf fans (default 5, clamped 2…9); `blooms` flower stalks (default 4, clamped
 * 0…8).
 * Footprint radius 5 cells → 11×11, whatever `crowns` is. About 105–110 cells, ≤ 150 at the top.
 */
export function irisPatch(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const crowns = knob(a, 'crowns', 5, 2, 9);
  const blooms = knob(a, 'blooms', 4, 0, 8);
  const spots: number[][] = [];

  for (let c = 0; c < crowns; c++) {
    const ang = c * GA + rnd() * 0.4;
    const rr = 3 * Math.sqrt((c + 0.35) / crowns);
    const bx = a.x + Math.round(Math.cos(ang) * rr);
    const bz = a.z + Math.round(Math.sin(ang) * rr);
    spots.push([bx, bz]);
    const blades = 6;
    for (let i = 0; i < blades; i++) {
      const ba = (i / blades) * Math.PI * 2 + c * 0.5 + rnd() * 0.3;
      const len = 3 + Math.round(rnd() * 1.5);
      for (let n = 0; n <= len; n++) {
        const x = bx + Math.round(Math.cos(ba) * n * 0.45);
        const z = bz + Math.round(Math.sin(ba) * n * 0.45);
        const y = a.y + n;
        const q = hash3(x, y, z, a.seed + c * 13 + i);
        world.set(x, y, z, tint(SWORD, q, hash3(z, y, x, a.seed + 23), n > 1), {
          kind: Kind.Foliage,
          t: reveal(a, 0.1 + 0.3 * (n / Math.max(1, len)) + 0.04 * c),
          dur: FADE,
          sway: swayAt(n, 6, 0.85),
        });
      }
    }
  }

  for (let i = 0; i < blooms; i++) {
    const s = spots[Math.floor((i * spots.length) / Math.max(1, blooms)) % Math.max(1, spots.length)];
    const stem = 5 + Math.round(rnd() * 1.5);
    for (let n = 0; n < stem; n++) {
      world.set(s[0], a.y + n, s[1], tint(SWORD, 0.5, hash3(s[0], n, s[1], a.seed + 43), false), {
        kind: Kind.Solid,
        t: reveal(a, 0.5 + 0.05 * i),
        dur: FADE,
      });
    }
    const top = a.y + stem;
    world.set(s[0], top, s[1], shade(C.wisteria, 1.04), {
      kind: Kind.Foliage,
      t: reveal(a, 0.82 + 0.04 * i),
      dur: FADE,
      sway: swayAt(stem - a.y, stem + 2, 0.7),
    });
    world.set(s[0], top, s[1] + 1, C.wisteria, {
      kind: Kind.Foliage,
      t: reveal(a, 0.86 + 0.04 * i),
      dur: FADE,
      sway: swayAt(stem - a.y, stem + 2, 0.75),
    });
    world.set(s[0], top + 1, s[1], C.ruby, {
      kind: Kind.Foliage,
      t: reveal(a, 0.94),
      dur: FADE,
      sway: swayAt(stem + 1 - a.y, stem + 2, 0.8),
    });
  }
}

// ------------------------------------------------------------------ stone and undergrowth

/**
 * Moss boulder: a squashed rock ellipsoid in slate/stone tones with moss painted on the exposed
 * upper faces only, plus an optional fern rosette at the shade side of the base.
 *
 * Knobs: `r` rock radius in cells (default 3, clamped 2…6); `fern` 1 = one fern at the base,
 * 0 = none (default 1).
 * Footprint radius `ceil(r)` alone → 7×7 at the default, `round(r * 0.7) + 4` with the fern →
 * 13×13 (17×17 at `r` = 6). Height `2 floor(0.72 r) + 1` rows. About 100–120 cells at the default,
 * ≤ 640 at `r` = 6.
 */
export function mossBoulder(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const r = knobf(a, 'r', 3, 2, 6);
  const fern = knob(a, 'fern', 1, 0, 1);
  const ry = Math.max(1, r * 0.72);
  const cy = a.y + Math.floor(ry);
  const top = cy + Math.floor(ry);

  cluster(world, a, a.x, cy, a.z, r, ry, r * 0.92, ROCK, {
    f: 0.05,
    total: top - a.y + 3,
    strength: 0,
    seed: a.seed + 3,
    erode: 0.32,
    noise: 0.26,
    spine: 1,
    solid: true,
  });
  faceTint(
    world,
    a,
    a.x - Math.ceil(r),
    a.x + Math.ceil(r),
    a.y,
    top,
    a.z - Math.ceil(r),
    a.z + Math.ceil(r),
    MOSS,
    0.3,
    { f: 0.6, total: top - a.y + 3, strength: 0, seed: a.seed + 57 },
    true,
  );

  if (!fern) return;
  const ang = rnd() * Math.PI * 2;
  const off = Math.round(r * 0.7) + 1;
  fernPatch(world, {
    ...a,
    x: a.x + Math.round(Math.cos(ang) * off),
    z: a.z + Math.round(Math.sin(ang) * off),
    seed: a.seed + 911,
    opts: { crowns: 2, len: 4 },
  });
}

/**
 * Dry-stacked cairn: 3–5 boulders, each smaller than the one below and each sunk a row into it so
 * the stack reads as settled stone, drifted a cell off the plumb line as it rises, then moss
 * patching every exposed top face.
 *
 * Knobs: `stones` (default 4, clamped 3…5); `r` base boulder radius in cells (default 3, clamped
 * 2…5).
 * Footprint radius `ceil(r) + 1` cells → 9×9 at the default, ≤ 13×13 at `r` = 5. Height
 * `2 floor(0.85 r) + 1` rows for the base boulder plus about 2 rows per extra stone (≈ 8 rows at
 * the default, 19 at the maximum knobs). About 125 cells at the default, ≤ 735 fully stacked.
 */
export function rockStack(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const stones = knob(a, 'stones', 4, 3, 5);
  const r = knobf(a, 'r', 3, 2, 5);
  let cx = a.x;
  let cz = a.z;
  let base = a.y;
  let top = a.y;

  for (let i = 0; i < stones; i++) {
    const rr = Math.max(1, r * (1 - i / (stones + 0.35)));
    const ry = Math.max(1.2, rr * 0.85);
    const cy = base + Math.floor(ry) - (i === 0 ? 0 : 1);
    cluster(world, a, cx, cy, cz, rr, ry, rr * 0.94, ROCK, {
      f: 0.06 + 0.16 * i,
      total: 12,
      strength: 0,
      seed: a.seed + i * 37,
      erode: 0.3,
      noise: 0.24,
      spine: 1,
      solid: true,
    });
    if (i > 0) {
      // mortar neck: guarantees the joint into the boulder below despite the plan drift
      strut(world, a, cx, cy - Math.floor(ry) - 1, cz, cx, cy, cz, 1, ROCK, {
        f: 0.06 + 0.16 * i,
        total: 12,
        strength: 0,
        seed: a.seed + 404 + i,
      });
    }
    top = cy + Math.floor(ry);
    base = top;
    cx += Math.round(rnd() * 2) - 1;
    cz += Math.round(rnd() * 2) - 1;
  }

  faceTint(
    world,
    a,
    a.x - Math.ceil(r) - 1,
    a.x + Math.ceil(r) + 1,
    a.y,
    top,
    a.z - Math.ceil(r) - 1,
    a.z + Math.ceil(r) + 1,
    MOSS,
    0.42,
    { f: 0.72, total: 12, strength: 0, seed: a.seed + 173 },
    true,
  );
}

/**
 * Fern patch: `crowns` low rosettes, each six fronds arching up and over from a centre, plus an
 * unfurling crozier. Fronds are single cells, so the whole patch stays under knee height.
 *
 * Knobs: `crowns` rosettes (default 3, clamped 1…5); `len` cells per frond (default 4, clamped
 * 4…6).
 * Footprint radius `1 + round(0.65 len)` cells → 9×9 at the defaults, ≤ 11×11 at `len` = 6; height
 * 3 rows. About 55–65 cells at the defaults, ≤ 120 at the maximum knobs.
 */
export function fernPatch(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const crowns = knob(a, 'crowns', 3, 1, 5);
  const len = knob(a, 'len', 4, 4, 6);
  const reach = Math.max(2, Math.round(len * 0.65));

  for (let c = 0; c < crowns; c++) {
    const bx = a.x + (c === 0 ? 0 : Math.round(rnd() * 2) - 1);
    const bz = a.z + (c === 0 ? 0 : Math.round(rnd() * 2) - 1);
    const arms = 6;
    for (let i = 0; i < arms; i++) {
      const ang = (i / arms) * Math.PI * 2 + c * 0.4 + rnd() * 0.3;
      const ox = Math.round(Math.cos(ang) * reach);
      const oz = Math.round(Math.sin(ang) * reach);
      for (let s = 0; s <= len; s++) {
        const k = s / len;
        const x = bx + Math.round(ox * k);
        const z = bz + Math.round(oz * k);
        const y = a.y + Math.round(Math.sin(Math.PI * k) * 2);
        const q = hash3(x, y, z, a.seed + c * 17 + i);
        world.set(x, y, z, tint(FERN, q, hash3(z, y, x, a.seed + 5), y > a.y), {
          kind: Kind.Foliage,
          t: reveal(a, 0.14 + 0.4 * k + 0.06 * c),
          dur: FADE,
          sway: swayAt(y - a.y, len + 2, 0.9),
        });
      }
    }
    for (let n = 0; n <= 2; n++) {
      const x = bx + (n === 2 ? 1 : 0);
      const z = bz + (n === 1 ? 1 : 0);
      world.set(x, a.y + n, z, tint(FERN, 0.92, hash3(x, n, z, a.seed + 71), true), {
        kind: Kind.Foliage,
        t: reveal(a, 0.62 + 0.1 * n),
        dur: FADE,
        sway: swayAt(n, len + 2, 0.7),
      });
    }
  }
}

/**
 * Azalea bush: a dense rounded mass in deep plum with a single dark twig showing at the base,
 * then a handful of near-white `lanternCore` flecks painted on the lit faces — Solid, no Glow.
 *
 * Knobs: `r` radius in cells (default 3.4, clamped 2…4.5); `flecks` 0..16, drives how many lit
 * faces catch the light (default 7).
 * Footprint radius `ceil(r)` cells → 9×9 at the default, ≤ 11×11 at `r` = 4.5; height
 * `2 floor(0.82 r) + 1` ≈ 5–6 rows. About 130 cells at the default, ≤ 315 at the maximum knobs.
 */
export function azaleaBush(world: VoxelWorld, a: BuilderArgs): void {
  const r = knobf(a, 'r', 3.4, 2, 4.5);
  const flecks = knob(a, 'flecks', 7, 0, 16);
  const ry = r * 0.82;
  const cy = a.y + Math.floor(ry);
  const top = cy + Math.floor(ry);
  const total = top - a.y + 1;

  strut(world, a, a.x, a.y, a.z, a.x, cy, a.z, 1, TWIG, {
    f: 0.05,
    total,
    strength: 0.12,
    seed: a.seed + 11,
  });
  cluster(world, a, a.x, cy, a.z, r, ry, r * 0.94, AZALEA, {
    f: 0.3,
    total,
    strength: 0.85,
    seed: a.seed + 13,
    erode: 0.14,
    noise: 0.22,
    spine: 1,
  });
  faceTint(
    world,
    a,
    a.x - Math.ceil(r),
    a.x + Math.ceil(r),
    a.y,
    top,
    a.z - Math.ceil(r),
    a.z + Math.ceil(r),
    FLECK,
    1 - flecks / 40,
    { f: 0.86, total, strength: 0.9, seed: a.seed + 271 },
    false,
  );
}

/**
 * Moss patch: a one-cell-thick ground fur mottled across the moss family — dark in the hollows,
 * bright on the draws — with a wobbling edge so it never reads as a disc. Dressed over bare rock
 * and between boulders.
 *
 * Knobs: `r` radius in cells (default 5, clamped 2…9).
 * Footprint radius `ceil(r) + 1` cells → 13×13 at `r` = 5 once the wobble lands, 21×21 at `r` = 9;
 * height 1 cell. About 85 cells at `r` = 5, ≤ 270 at `r` = 9.
 */
export function mossPatch(world: VoxelWorld, a: BuilderArgs): void {
  const r = knobf(a, 'r', 5, 2, 9);
  const lim = Math.ceil(r);
  for (let dz = -lim; dz <= lim; dz++) {
    for (let dx = -lim; dx <= lim; dx++) {
      const d = Math.sqrt(dx * dx + dz * dz);
      const wob = (hash3(a.x + dx, 0, a.z + dz, a.seed) - 0.5) * 1.8;
      if (d > r + wob) continue;
      const q = hash3(a.x + dx, 3, a.z + dz, a.seed + 29);
      const edge = clamp(d / r, 0, 1);
      const tone = mixHex(
        mixHex(C.mossDeep, C.moss, edge * 0.35 + q * 0.65),
        C.mossLite,
        q > 0.84 ? 0.65 : 0,
      );
      world.set(a.x + dx, a.y, a.z + dz, shade(tone, 0.88 + 0.24 * q), {
        kind: Kind.Solid,
        t: reveal(a, 0.08 + 0.26 * (d / r)),
        dur: FADE,
      });
    }
  }
}
