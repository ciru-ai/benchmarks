import { Kind, VoxelWorld } from '../core/VoxelWorld';
import { C, clamp, hash3, mixHex, shade } from '../core/palette';
import { CELL, FALLS, LAKE_ROW, POOL, SHEET, WATER } from '../core/layout';
import { groundY } from './terrain';

/**
 * The water of JADEFALL, authored on two lattices.
 *
 * `authorLake` fills the WATER lattice: every column the landform leaves below the lake surface is
 * filled from its bed up to `LAKE_ROW`, and the authored depth (0 at the shore → 1 in the basin's
 * centre) rides in the shader's `aAnim.w` channel so the material can fade translucent jade in the
 * shallows to near-opaque teal in the deep and let the bed read through. Reveal runs shallow-first,
 * so the water arrives at the shore and closes over the basin.
 *
 * `authorVeil` writes falling water on the SHEET lattice: the river across the plateau to the sill,
 * the great veil on a ballistic arc, the side falls, and the foam the veil churns in the plunge
 * pool. `aAnim.w` carries aeration there — 0.25 for the glassy river, 1 for white water.
 */

const rowOfWater = (y: number) => Math.round((y - WATER.origin[1]) / CELL.water - 1e-6);

/** How deep the basin gets, in world units — the 1.0 end of the authored depth. */
const BASIN_DEPTH = 11.6;

/** Colour of a standing-water cell at the given authored depth. */
function lakeColor(depth: number, seedX: number, seedY: number, seedZ: number): number {
  const shallow = mixHex(C.waterLite, C.jadeLite, 0.4);
  const mid = mixHex(C.water, C.jade, 0.35);
  const deep = mixHex(C.jadeDeep, C.inkSoft, 0.5);
  const base = depth < 0.42 ? mixHex(shallow, mid, depth / 0.42) : mixHex(mid, deep, (depth - 0.42) / 0.58);
  const grain = 0.84 + 0.3 * hash3(seedX, seedY, seedZ, 91);
  return shade(base, clamp(grain * (1 - 0.3 * depth), 0.25, 1));
}

export interface WaterArgs {
  seed: number;
  /** reveal start of the shoreline cells */
  t: number;
  /** seconds the whole surface takes to close over the basin */
  dur: number;
}

/**
 * Fill the WATER lattice from the bed to the surface wherever the landform is below it. Footprint:
 * the whole lattice; the surface cells' top face is exactly y = 0.
 */
export function authorLake(world: VoxelWorld, a: WaterArgs): void {
  const cell = CELL.water;
  const topRow = LAKE_ROW;

  for (let c = 0; c < WATER.sx; c++) {
    const x = WATER.origin[0] + (c + 0.5) * cell;
    for (let l = 0; l < WATER.sz; l++) {
      const z = WATER.origin[2] + (l + 0.5) * cell;
      const h = groundY(x, z);
      if (h > -0.05) continue;

      const depth = clamp(-h / BASIN_DEPTH, 0, 1);
      const from = Math.max(rowOfWater(h) + 1, 0);
      // the shore floods first, the basin closes last
      const key = 1 - Math.pow(depth, 0.62);
      const t0 = a.t + key * a.dur * 0.74;

      for (let r = from; r <= topRow; r++) {
        const surface = r === topRow;
        world.set(c, r, l, lakeColor(depth, c, r * 3, l), {
          kind: Kind.Water,
          glow: depth,
          t: surface ? t0 : t0 + 0.08,
          dur: surface ? 0.42 : 0.3,
        });
      }
    }
  }
}

const sheetCol = (x: number) => Math.round((x - SHEET.origin[0]) / CELL.sheet);
const sheetLane = (z: number) => Math.round((z - SHEET.origin[2]) / CELL.sheet);
const sheetRow = (y: number) => Math.round((y - SHEET.origin[1]) / CELL.sheet);

/** Downstream travel of a drop that leaves the sill at `lipY` with just enough speed to land `landL` away. */
const speedFor = (lipY: number, landL: number) => landL / Math.sqrt((2 * lipY) / 9.8);

/**
 * One falling sheet from `x0`…`x1` across, sill at (`lipY`, `lipZ`), landing `landL` downstream.
 * The curtain widens as it falls, breaks into ribs whose density and aeration come from `seed`, and
 * reveals `f0` → `f1` from the sill down to the pool. Footprint: the x-span × the drop × ~8 cells.
 */
function curtain(
  world: VoxelWorld,
  a: WaterArgs,
  x0: number,
  x1: number,
  lipY: number,
  lipZ: number,
  landL: number,
  thickness: number,
  f0: number,
  f1: number,
): void {
  const v = speedFor(lipY, landL);
  for (let y = lipY; y > -1.2; y -= CELL.sheet) {
    const dropF = clamp((lipY - y) / (lipY + 1.2), 0, 1);
    const zCentre = lipZ + v * Math.sqrt((2 * Math.max(0, lipY - y)) / 9.8);
    const widen = thickness * (1 + 0.55 * dropF);
    const flank = (x1 - x0) * 0.5 * (1 + 0.2 * dropF);
    const mid = (x0 + x1) * 0.5;
    const row = sheetRow(y);
    const halfCols = Math.ceil(flank / CELL.sheet);
    for (let dc = -halfCols; dc <= halfCols; dc++) {
      const x = mid + dc * CELL.sheet;
      if (x < x0 - 0.6 || x > x1 + 0.6) continue;
      const u = (x - x0) / Math.max(0.001, x1 - x0);
      const rib = Math.sin(u * 9.4 + hash3(sheetCol(x), 0, 0, a.seed + 3) * 0.9);
      const density = 0.55 + 0.45 * rib;
      if (density < 0.34 && hash3(sheetCol(x), row, 7, a.seed + 11) > 0.24) continue;
      const aer = clamp(0.34 + 0.66 * dropF + 0.2 * rib, 0, 1);
      const dep = Math.max(1, Math.round(((widen * density) / CELL.sheet)));
      const f = f0 + (f1 - f0) * Math.pow(dropF, 0.85);
      for (let d = 0; d < dep; d++) {
        const zz = zCentre - (dep - 1) * CELL.sheet * 0.5 + d * CELL.sheet;
        world.set(
          sheetCol(x),
          row,
          sheetLane(zz),
          aer > 0.72
            ? mixHex(C.foam, C.waterGlow, 0.18 + 0.3 * hash3(sheetCol(x), row, d, a.seed + 17))
            : mixHex(C.waterGlow, C.waterLite, 0.25 + 0.5 * hash3(sheetCol(x), row, d, a.seed + 23)),
          { kind: Kind.Flow, glow: aer, t: a.t + f * a.dur * 0.66, dur: 0.34 },
        );
      }
    }
  }
}

/**
 * The falling water: the river out across the plateau, the great veil, the side falls, and the
 * churn ringing the impact. Footprint: the whole SHEET lattice; the sill sits at `FALLS.lipY`.
 */
export function authorVeil(world: VoxelWorld, a: WaterArgs): void {
  // ---- the river running to the sill
  const fromX = -43.5;
  const fromZ = -59.5;
  const steps = 74;
  for (let i = 0; i <= steps; i++) {
    const k = i / steps;
    const x = fromX + (FALLS.x - fromX) * k;
    const z = fromZ + (FALLS.lipZ - fromZ) * k;
    const y = 34.2 - 0.9 * k * k;
    const width = 3.4 + 3.6 * k;
    const radius = width * 0.5;
    const rc = Math.ceil(radius / CELL.sheet);
    // A round section, not a slab: the width belongs to both horizontal axes, so the stream
    // stays a river as it widens toward the sill instead of smearing along the travel axis.
    for (let dz = -rc; dz <= rc; dz++) {
      for (let dx = -rc; dx <= rc; dx++) {
        if (Math.hypot(dx, dz) * CELL.sheet > radius) continue;
        world.set(sheetCol(x) + dx, sheetRow(y), sheetLane(z) + dz, mixHex(C.water, C.jade, 0.25 + 0.4 * hash3(sheetCol(x) + dx, sheetRow(y), dz, a.seed + 31)), {
          kind: Kind.Water,
          glow: 0.5,
          t: a.t + k * a.dur * 0.4,
          dur: 0.3,
        });
      }
    }
  }

  // ---- the great veil, then the side falls
  const halfW = FALLS.width * 0.5;
  curtain(world, a, FALLS.x - halfW, FALLS.x + halfW, FALLS.lipY, FALLS.lipZ, FALLS.toZ - FALLS.lipZ, 4.2, 0.05, 1);
  const eh = FALLS.east.width * 0.5;
  curtain(world, a, FALLS.east.x - eh, FALLS.east.x + eh, FALLS.east.lipY, FALLS.east.lipZ, FALLS.east.toZ - FALLS.east.lipZ, 2.6, 0.2, 1);

  // ---- the churn ringing the impact, thickest under the veil
  const ringR = 8.4;
  const reach = Math.ceil(ringR / CELL.sheet);
  const c0 = sheetCol(POOL.x);
  const l0 = sheetLane(POOL.z + 1.6);
  for (let dz = -reach; dz <= reach; dz++) {
    for (let dx = -reach; dx <= reach; dx++) {
      const d = Math.hypot(dx, dz) * CELL.sheet;
      if (d > ringR) continue;
      const aer = clamp(1.05 - d / ringR, 0.15, 1);
      const rows = d < ringR * 0.55 ? 3 : 1;
      for (let r = 0; r < rows; r++) {
        world.set(c0 + dx, sheetRow(0.3 + r * 0.3), l0 + dz, aer > 0.7
          ? mixHex(C.foam, C.waterGlow, 0.1 + 0.35 * hash3(c0 + dx, r, l0 + dz, a.seed + 41))
          : mixHex(C.waterGlow, C.waterLite, 0.4), {
          kind: Kind.Flow,
          glow: aer,
          t: a.t + a.dur * 0.62 + (1 - aer) * 0.5,
          dur: 0.4,
        });
      }
    }
  }
}
