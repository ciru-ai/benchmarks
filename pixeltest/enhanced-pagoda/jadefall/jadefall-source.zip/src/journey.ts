import type { Beat } from './core/CameraRig';
import { FALLS, LOOK, PAGODA } from './core/layout';

/**
 * The tour, one list of beats, one beat per phase of `schedule.T`.
 *
 * Orbit beats (`r`/`az`/`el`/`ty`) circle the padoga axis at the world origin; track beats
 * (`pos`/`look`) go where an orbit cannot — in at the sill, down the gorge, and along the water.
 * `az` only ever decreases, so the run never snaps, and the last beat repeats the first pose one
 * full turn lower: the loop closes without a seam.
 *
 * Every pose here was checked against the authored height field (terrain and canopy included) and
 * clears it by several units along the interpolated path, because the valley rim the far ranges
 * stand on is 40-53 units tall: the wide beats fly over it, the low beats fly the water corridors,
 * where the surface is the lake plane itself.
 *
 * World numbers: lake surface y 0, bed to -24; temple mesa deck 7.2, podium top 13.2, finial
 * `PAGODA.topY` 54.4; the veil leaves the sill at y 33.6, z -45.6 and lands near z -31.
 */
export const BEATS: Beat[] = [
  // ---- the pearl falls, seen from high off the south-west water
  { t: 0.0, r: 110, az: 5.1, el: 0.55, ty: 18, fov: 46, caption: 'a jade pearl falls' },
  { t: 3.4, r: 124, az: 4.78, el: 0.46, ty: 18, fov: 48, ease: 'out', caption: 'it strikes the gate' },
  { t: 6.2, r: 112, az: 4.35, el: 0.5, ty: 18, fov: 50, caption: 'the basin fills' },
  // ---- stand above the pool and watch the veil start at the sill
  {
    t: 8.4,
    pos: [-6, 27, -13],
    look: [FALLS.x, FALLS.lipY - 8.6, FALLS.lipZ + 2.6],
    fov: 54,
    ease: 'out',
    caption: 'the veil begins to pour',
  },
  // ---- come round the island as the tiers stack up and the roofs open
  { t: 10.8, r: 88, az: 3.95, el: 0.36, ty: 38.5, fov: 44, caption: 'the podium rises' },
  { t: 14.0, r: 72, az: 3.4, el: 0.36, ty: 33, fov: 47, caption: 'nine roofs unfurl' },
  { t: 16.8, r: 60, az: 2.85, el: 0.45, ty: 34, fov: 49, caption: 'brackets and gilt' },
  { t: 19.0, r: 52, az: 2.3, el: 0.42, ty: 34, fov: 51, caption: 'the groves come into leaf' },
  // ---- a pass over the finial, turning from the ridge toward the lakeside
  {
    t: 20.6,
    pos: [PAGODA.x, PAGODA.topY + 13.6, 6],
    look: [-26, 30, -22],
    fov: 56,
    ease: 'out',
    caption: 'over the crown',
  },
  // ---- the settlement: terrace, market, stair foot, dock
  // Above the wood and looking down the bench: the grove now reaches this far, and any pose under
  // the crowns turns the shot into foliage. From here the gate, paddies and roofs read in one view.
  { t: 22.0, pos: [8, 40, 34], look: [45, 14, -10], fov: 54, caption: 'the village wakes' },
  // ---- down onto the south basin, in the water's own corridor
  { t: 23.4, pos: [-6, 13, 30], look: [-14, 7, 16], fov: 58, caption: 'the water wakes' },
  { t: 24.8, pos: [-14, 5.6, 24], look: [-26, 3.2, 14], fov: 60, ease: 'linear', caption: 'the school circles' },
  {
    t: 26.8,
    // Clear of the reed and bamboo margin on the south shore, which reaches twelve units.
    pos: [-11.5, 18.5, 18.5],
    look: [-27, 8.6, 0.5],
    fov: 60,
    ease: 'linear',
    caption: 'past the causeway',
  },
  // ---- climb the moat, over the causeway arch, and into the gorge as the leap begins
  { t: 28.6, pos: [-20, 24, -8], look: [-33, 16, -34], fov: 56, caption: 'into the gorge' },
  {
    t: 30.6,
    pos: [-16, 12, -24],
    look: [LOOK.plunge[0], 24, LOOK.lip[2] + 4],
    fov: 55,
    ease: 'out',
    caption: 'one koi takes the fall',
  },
  // ---- spiral up the padoga as the dragon coils around it
  { t: 33.6, r: 46, az: 1.55, el: 0.3, ty: 30, fov: 50, caption: 'it turns to dragon' },
  { t: 35.8, r: 38, az: 1.05, el: 0.48, ty: 40, fov: 47, caption: 'the valley lights' },
  // ---- sunrise: pull out and let the colour come up over the ridge
  { t: 37.6, r: 128, az: 0.5, el: 0.26, ty: 30, fov: 44, ease: 'out', caption: 'sunrise breaks' },
  { t: 39.6, r: 132, az: -0.05, el: 0.28, ty: 22, fov: 46, caption: 'every roof alight' },
  // ---- the water climbs back out of the world; close on the opening pose
  { t: 41.0, r: 152, az: -0.6, el: 0.34, ty: 18, fov: 44, caption: 'the water is drawn up' },
  { t: 44.0, r: 110, az: 5.1 - Math.PI * 2, el: 0.55, ty: 18, fov: 46, caption: 'the loop closes' },
];

export const TITLE = 'JADEFALL · 翠瀑';
export const SUBTITLE = 'a padoga at the foot of a white waterfall, and the koi that climbs it';
