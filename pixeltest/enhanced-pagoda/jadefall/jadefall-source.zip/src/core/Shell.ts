import * as THREE from 'three';
import { rawColor } from './color';

/**
 * The non-voxel set pieces of JADEFALL: the jade pearl that falls out of the stars, the stroke of
 * light it is drawn back along, the sun as it clears the Dragon Ridge, the mist collar that sits in
 * the valley between the lattices, and the bow the veil throws up in the gorge.
 *
 * Each is one mesh with its own shader and a scalar the composer drives, so a frame stays a pure
 * function of the loop clock.
 */

const BASIC_VERT = /* glsl */ `
varying vec2 vUv;
varying vec3 vWorld;
void main() {
  vUv = uv;
  vec4 w = modelMatrix * vec4(position, 1.0);
  vWorld = w.xyz;
  gl_Position = projectionMatrix * viewMatrix * w;
}
`;

/** The pearl: a hot jade core with a fresnel rim, riding a curve the composer hands it. */
export class Pearl {
  readonly mesh: THREE.Mesh;
  private readonly halo: THREE.Mesh;
  private readonly uniforms: Record<string, THREE.IUniform>;
  readonly curve: THREE.CatmullRomCurve3;

  constructor(radius: number, curve: THREE.CatmullRomCurve3) {
    this.uniforms = {
      uTime: { value: 0 },
      uGain: { value: 0 },
      uHot: { value: rawColor(0xeafff6) },
      uCold: { value: rawColor(0x2fd6b0) },
    };
    this.mesh = new THREE.Mesh(
      new THREE.IcosahedronGeometry(radius, 3),
      new THREE.ShaderMaterial({
        vertexShader: BASIC_VERT,
        fragmentShader: /* glsl */ `
precision highp float;
uniform float uTime;
uniform float uGain;
uniform vec3 uHot;
uniform vec3 uCold;
varying vec3 vWorld;
void main() {
  float pulse = 0.82 + 0.18 * sin(uTime * 5.2);
  vec3 col = mix(uCold, uHot, 0.55 + 0.45 * pulse);
  gl_FragColor = vec4(col * (1.6 + pulse * 1.2), clamp(uGain, 0.0, 1.0));
}
`,
        uniforms: this.uniforms,
        transparent: true,
        depthWrite: false,
      }),
    );
    this.halo = new THREE.Mesh(
      new THREE.SphereGeometry(radius * 3.4, 24, 16),
      new THREE.ShaderMaterial({
        vertexShader: BASIC_VERT,
        fragmentShader: /* glsl */ `
precision highp float;
uniform float uGain;
uniform vec3 uCold;
varying vec3 vWorld;
void main() {
  float d = length(vUv - 0.5) * 2.0;
  float a = pow(clamp(1.0 - d, 0.0, 1.0), 2.6) * 0.5;
  gl_FragColor = vec4(uCold * 1.8, a * clamp(uGain, 0.0, 1.0));
}
`,
        uniforms: this.uniforms,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      }),
    );
    this.mesh.renderOrder = 24;
    this.halo.renderOrder = 23;
    this.curve = curve;
  }

  update(time: number, progress: number, gain: number): void {
    this.uniforms.uTime.value = time;
    this.uniforms.uGain.value = gain;
    const p = Math.max(0, Math.min(1, progress));
    const at = this.curve.getPointAt(p);
    this.mesh.position.copy(at);
    this.halo.position.copy(at);
    const visible = gain > 0.002;
    this.mesh.visible = visible;
    this.halo.visible = visible;
  }
}

/** A stroke of light painted along a curve — the arc the water is drawn back up. */
export class LightArc {
  readonly mesh: THREE.Mesh;
  private readonly uniforms: Record<string, THREE.IUniform>;

  constructor(curve: THREE.CatmullRomCurve3, radius: number) {
    this.uniforms = {
      uTime: { value: 0 },
      uPaint: { value: 0 },
      uHead: { value: 0 },
      uHot: { value: rawColor(0xd9fff2) },
      uCold: { value: rawColor(0x0f4f4a) },
      uGlowGain: { value: 0 },
      uAlpha: { value: 1 },
    };
    this.mesh = new THREE.Mesh(
      new THREE.TubeGeometry(curve, 200, radius, 14, false),
      new THREE.ShaderMaterial({
        vertexShader: BASIC_VERT,
        fragmentShader: /* glsl */ `
precision highp float;
uniform float uTime;
uniform float uPaint;
uniform float uHead;
uniform vec3 uHot;
uniform vec3 uCold;
uniform float uGlowGain;
uniform float uAlpha;
varying vec2 vUv;

void main() {
  float taper = smoothstep(0.0, 0.1, vUv.x) * smoothstep(1.0, 0.7, vUv.x);
  float bristles = 0.74 + 0.26 * sin(vUv.y * 76.0 + vUv.x * 14.0);
  float painted = step(vUv.x, uPaint);
  float heat = exp(-pow((vUv.x - uHead) / 0.05, 2.0));
  vec3 col = mix(uCold, uHot, heat * 0.9) * bristles;
  col += uHot * heat * 1.6;
  float a = painted * taper * (0.5 + 0.5 * bristles) * (0.3 + uGlowGain) * uAlpha;
  a *= 0.62 + 0.38 * (0.5 + 0.5 * sin(uTime * 0.9 + vUv.x * 8.0));
  gl_FragColor = vec4(col, clamp(a, 0.0, 1.0));
}
`,
        uniforms: this.uniforms,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      }),
    );
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 22;
  }

  update(time: number, paint: number, head: number, glow: number, alpha: number): void {
    this.uniforms.uTime.value = time;
    this.uniforms.uPaint.value = paint;
    this.uniforms.uHead.value = head;
    this.uniforms.uGlowGain.value = glow;
    this.uniforms.uAlpha.value = alpha;
    this.mesh.visible = paint > 0.002 && alpha > 0.002;
  }
}

/** The dawn sun: a warm disc with a wide halo, parked low over the eastern country. */
export class SunDisc {
  readonly mesh: THREE.Mesh;
  private readonly uniforms: Record<string, THREE.IUniform>;

  constructor(radius: number, distance: number, direction: THREE.Vector3) {
    this.uniforms = {
      uTime: { value: 0 },
      uGain: { value: 0 },
      uColor: { value: rawColor(0xffd9a0) },
    };
    this.mesh = new THREE.Mesh(
      new THREE.SphereGeometry(radius, 32, 24),
      new THREE.ShaderMaterial({
        vertexShader: /* glsl */ `
varying vec3 vNormal;
varying vec3 vLocal;
void main() {
  vNormal = normalize(normalMatrix * normal);
  vLocal = position;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`,
        fragmentShader: /* glsl */ `
precision highp float;
uniform float uTime;
uniform float uGain;
uniform vec3 uColor;
varying vec3 vNormal;
varying vec3 vLocal;
void main() {
  float core = smoothstep(0.0, 0.62, dot(normalize(vNormal), vec3(0.0, 0.0, 1.0)));
  float breathe = 0.94 + 0.06 * sin(uTime * 0.8);
  vec3 col = mix(uColor, vec3(1.0, 0.98, 0.92), core * 0.75) * (1.5 * breathe);
  gl_FragColor = vec4(col, clamp(uGain, 0.0, 1.0) * (0.24 + 0.76 * core));
}
`,
        uniforms: this.uniforms,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      }),
    );
    const d = direction.clone().normalize().multiplyScalar(distance);
    this.mesh.position.copy(d);
    this.mesh.renderOrder = 21;
  }

  update(time: number, gain: number, direction: THREE.Vector3, distance: number): void {
    this.uniforms.uTime.value = time;
    this.uniforms.uGain.value = gain;
    this.mesh.position.copy(direction.clone().normalize().multiplyScalar(distance));
    this.mesh.visible = gain > 0.004;
  }
}

/**
 * The mist collar: a broad horizontal sheet the valley wears between the coarse country and the
 * fine precinct. Two crossed bands of animated value noise so it never reads as a flat plane.
 */
export class MistCollar {
  readonly mesh: THREE.Mesh;
  private readonly uniforms: Record<string, THREE.IUniform>;

  constructor(radius: number, y: number) {
    this.uniforms = {
      uTime: { value: 0 },
      uGain: { value: 0 },
      uColor: { value: rawColor(0xbcd4dd) },
      uY: { value: y },
    };
    this.mesh = new THREE.Mesh(
      new THREE.PlaneGeometry(radius * 2, radius * 2, 1, 1),
      new THREE.ShaderMaterial({
        vertexShader: /* glsl */ `
varying vec2 vUv;
varying vec3 vWorld;
void main() {
  vUv = uv;
  vec4 w = modelMatrix * vec4(position, 1.0);
  vWorld = w.xyz;
  gl_Position = projectionMatrix * viewMatrix * w;
}
`,
        fragmentShader: /* glsl */ `
precision highp float;
uniform float uTime;
uniform float uGain;
uniform vec3 uColor;
varying vec2 vUv;
varying vec3 vWorld;

float h(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float n(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(h(i), h(i + vec2(1.0, 0.0)), u.x), mix(h(i + vec2(0.0, 1.0)), h(i + vec2(1.0, 1.0)), u.x), u.y);
}

void main() {
  vec2 p = vWorld.xz * 0.018;
  float f1 = n(p + vec2(uTime * 0.012, -uTime * 0.007));
  float f2 = n(p * 2.7 - vec2(uTime * 0.02, uTime * 0.011));
  float bank = smoothstep(0.42, 0.95, f1 * 0.66 + f2 * 0.34);
  // thin at the centre so the precinct reads clear, thick toward the country
  float rim = smoothstep(0.1, 0.5, length(vUv - 0.5));
  float edge = smoothstep(0.98, 0.72, length(vUv - 0.5));
  float a = bank * (0.22 + 0.78 * rim) * edge * uGain * 0.62;
  gl_FragColor = vec4(uColor * (0.9 + 0.35 * f2), clamp(a, 0.0, 1.0));
}
`,
        uniforms: this.uniforms,
        transparent: true,
        depthWrite: false,
        side: THREE.DoubleSide,
      }),
    );
    this.mesh.rotation.x = -Math.PI / 2;
    this.mesh.position.y = y;
    this.mesh.renderOrder = 19;
  }

  update(time: number, gain: number): void {
    this.uniforms.uTime.value = time;
    this.uniforms.uGain.value = gain;
    this.mesh.visible = gain > 0.004;
  }
}

/** The bow the veil throws up in the gorge: a quarter arc of separated colour. */
export class BowArc {
  readonly mesh: THREE.Mesh;
  private readonly uniforms: Record<string, THREE.IUniform>;

  constructor(radius: number, center: THREE.Vector3) {
    this.uniforms = {
      uTime: { value: 0 },
      uGain: { value: 0 },
    };
    const geo = new THREE.TorusGeometry(radius, radius * 0.055, 10, 96, Math.PI);
    this.mesh = new THREE.Mesh(
      geo,
      new THREE.ShaderMaterial({
        vertexShader: /* glsl */ `
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`,
        fragmentShader: /* glsl */ `
precision highp float;
uniform float uTime;
uniform float uGain;
varying vec2 vUv;
void main() {
  // spectral band across the tube's thickness, fading at both ends of the arc
  vec3 warm = vec3(1.0, 0.62, 0.35);
  vec3 mid = vec3(1.0, 0.94, 0.6);
  vec3 cool = vec3(0.45, 0.85, 1.0);
  float band = vUv.y;
  vec3 col = mix(warm, mid, smoothstep(0.15, 0.5, band));
  col = mix(col, cool, smoothstep(0.5, 0.9, band));
  float ends = smoothstep(0.0, 0.16, vUv.x) * smoothstep(1.0, 0.84, vUv.x);
  float shimmer = 0.75 + 0.25 * sin(uTime * 1.7 + vUv.x * 26.0);
  gl_FragColor = vec4(col * 1.3, ends * 0.34 * shimmer * clamp(uGain, 0.0, 1.0));
}
`,
        uniforms: this.uniforms,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide,
      }),
    );
    this.mesh.position.copy(center);
    this.mesh.renderOrder = 25;
  }

  update(time: number, gain: number): void {
    this.uniforms.uTime.value = time;
    this.uniforms.uGain.value = gain;
    this.mesh.visible = gain > 0.004;
  }
}
