/**
 * JADEFALL — shared geometry of the valley.
 *
 * Five authored lattices, all aligned so a coarser cell always contains an exact number of
 * finer ones. The monument is built on the `FINE` lattice at 0.2 units per voxel — a third of
 * the INKFALL/GILTTHRONE hero block — so a single roof can carry ribbed tiles, bracket sets,
 * railings and hanging lanterns as separate cells. Everything the valley needs (lake bed,
 * ridge, gorges, terraces, forest) is authored at 0.6, distant ranges at 4.8.
 *
 *   FAR    4.8  the ring of peaks, plateaus and the far sea horizon
 *   MID    0.6  the valley floor, the lake bed, the Dragon Ridge, terraces, roads, groves
 *   WATER  0.6  the same lattice, water cells only — meshed into its own translucent material
 *   FINE   0.2  the island precinct: court walls, marble podium, the nine-tier padoga
 *   SHEET  0.3  the falling water: the great veil, the secondary falls, the plunge foam
 *
 * Plan axes: the padoga axis is the plan origin. The Dragon Ridge runs along -z, its notch at
 * (-32, -46); the lake wraps the island to the south and east.
 */

export const CELL = { far: 4.8, mid: 0.6, water: 0.6, fine: 0.2, sheet: 0.3 } as const;

export const FAR = { sx: 168, sy: 104, sz: 168, origin: [-403.2, -134.4, -403.2] } as const;
/**
 * The valley lattice. Its floor sits just under the deepest carved pool (`-12.1`) so no column is
 * wasted on rock nobody can see, and `sy` 124 puts the ceiling at `61.2` — above the tallest ridge
 * knoll (`56.9`), so nothing that `groundY` promises is ever cut off by the lattice.
 */
export const MID = { sx: 224, sy: 124, sz: 224, origin: [-67.2, -13.2, -67.2] } as const;
export const WATER = { sx: 224, sy: 44, sz: 224, origin: [-67.2, -21.6, -67.2] } as const;
export const FINE = { sx: 222, sy: 244, sz: 156, origin: [-27.6, 7.2, -15.6] } as const;
/**
 * The falling-water lattice. It has to hold the river on the rim, both veils, and the whole foam
 * ring the great veil churns in the pool — the ring reaches two units south of `POOL`'s centre
 * plus its own radius, so the span runs from behind the sill to `z = -24`.
 */
export const SHEET = { sx: 96, sy: 180, sz: 128, origin: [-46.8, -1.2, -62.4] } as const;

/** MID lattice → world units. */
export const wx = (col: number) => MID.origin[0] + col * CELL.mid;
export const wy = (row: number) => MID.origin[1] + row * CELL.mid;
export const wz = (row: number) => MID.origin[2] + row * CELL.mid;

/** FINE lattice → world units. */
export const fx = (col: number) => FINE.origin[0] + col * CELL.fine;
export const fy = (row: number) => FINE.origin[1] + row * CELL.fine;
export const fz = (row: number) => FINE.origin[2] + row * CELL.fine;

/** SHEET lattice → world units. */
export const sx = (col: number) => SHEET.origin[0] + col * CELL.sheet;
export const sy = (row: number) => SHEET.origin[1] + row * CELL.sheet;
export const sz = (row: number) => SHEET.origin[2] + row * CELL.sheet;

/**
 * World → FINE cell. `u` is the world-plan coordinate, `origin` the lattice origin. Used by
 * `scene.ts` to place a hero object authored in fine cells from a world-space anchor.
 */
export const fineCol = (worldX: number) => Math.round((worldX - FINE.origin[0]) / CELL.fine);
export const fineRow = (worldY: number) => Math.round((worldY - FINE.origin[1]) / CELL.fine);
export const fineLane = (worldZ: number) => Math.round((worldZ - FINE.origin[2]) / CELL.fine);

/** World → MID cell. */
export const midCol = (worldX: number) => Math.round((worldX - MID.origin[0]) / CELL.mid);
export const midRow = (worldY: number) => Math.round((worldY - MID.origin[1]) / CELL.mid);
export const midLane = (worldZ: number) => Math.round((worldZ - MID.origin[2]) / CELL.mid);

// ------------------------------------------------------------------ the water

/** Lake surface, in world units. The water sheet's top face lands exactly on this plane. */
export const LAKE_Y = 0;
/** The water lattice row whose *top* face is the lake surface. */
export const LAKE_ROW = 35;

/**
 * The lake, as an ellipse in plan with a carved arm north-west toward the plunge pool and a
 * channel south-east out of the valley. Builders carve against `lakeDepth`, which answers how
 * many water rows a plan point should hold.
 */
export const LAKE = { cx: -9, cz: 3, rx: 34, rz: 32 } as const;

/** Plunge pool centre, directly under the lip of the great falls. */
export const POOL = { x: -31, z: -35, r: 11 } as const;

// ------------------------------------------------------------------ the ridge

/** The Dragon Ridge: the cliff the river pours from. `rim` is the crest height in world units. */
export const RIDGE = { z0: -66, z1: -34, rim: 39 } as const;

/**
 * The falls. `lipRow`/`lipZ` is where the river leaves the rim, `toZ` where the veil lands.
 * Three ribs of water share the gorge; `width` is the whole cut in world units.
 */
export const FALLS = {
  x: -32.4,
  width: 21,
  lipY: 33.6,
  lipZ: -45.6,
  toZ: -36.6,
  /** the side falls, smaller, in the next gorge to the east */
  east: { x: -21.6, width: 5.4, lipY: 30.6, lipZ: -49.8, toZ: -44.4 },
} as const;

// ------------------------------------------------------------------ the precinct

/** The island precinct, authored on the FINE lattice. `half` is the court's half-span in world. */
export const COURT = {
  /** plan centre of the island — the padoga stands on the podium at this axis */
  x: 1.2,
  z: 0,
  /** outer face of the island sea wall, half-span along x and z */
  hx: 12.6,
  hz: 12.6,
  /** top of the sea wall / island ground plane */
  deckY: 7.2,
} as const;

/** The marble podium: three octagonal-ish tiers, each with its own balustrade and stair runs. */
export const PODIUM = {
  tiers: [
    { half: 9.4, y: 8.4 },
    { half: 7.4, y: 10.8 },
    { half: 5.4, y: 13.2 },
  ],
  top: 13.2,
} as const;

/**
 * The padoga itself, on the podium. Every tier is `rise` rows of storey plus a roof; the
 * finial crowns the ninth. `baseY` is where the first storey stands, `topY` the roof ridge.
 */
export const PAGODA = {
  x: 1.2,
  z: 0,
  baseY: PODIUM.top,
  tiers: 9,
  storeyRise: 2.6,
  roofRise: 1.6,
  baseHalf: 4.2,
  taper: 0.87,
  /** world y of the tip of the finial — the camera's ceiling for the spiral beat */
  get topY(): number {
    return this.baseY + this.tiers * (this.storeyRise + this.roofRise) + 3.4;
  },
} as const;

/** The causeway: a red moon bridge off the west face of the island onto the shore. */
export const BRIDGE = {
  z: 0,
  /** plan x of the two abutments; the arch peaks midway */
  x0: -11.4,
  x1: -25.4,
  deckY: 7.8,
  rise: 3.4,
} as const;

// ------------------------------------------------------------------ anchors

/** Plan anchors the composer and the camera both read, in world units. */
export const ANCHOR = {
  /** the shore landing the great stair arrives at, on the arm of the lake */
  plaza: { x: -37.6, z: -8 },
  /** the mountain gate across the high road on the worked east plateau */
  gate: { x: 36, z: 0 },
  /** the lakeside village below the high road */
  village: { x: 45, z: -15 },
  /** the reed marsh in the south bay */
  marsh: { x: 15, z: 25 },
  /** the terrace pavilion above the bridge head */
  pavilion: { x: -31, z: 8.4 },
  /** the bell house at the bridge landing inside the court */
  bell: { x: -9.9, z: 4.8 },
  /** the lotus pond, sheltered in the south bay */
  lotus: { x: 4, z: 28 },
  /** the foot of the great veil, where the golden koi turns and climbs */
  koiFalls: { x: -31, z: -32.4 },
} as const;

/** World-space targets the camera beats are written against. */
export const LOOK = {
  /** the pool where the veil lands */
  plunge: [-31, 12, -37] as const,
  /** the sill the river spills over */
  lip: [-32.4, FALLS.lipY + 2.4, -45.6] as const,
  /** the padoga's middle eaves */
  eaves: [PAGODA.x, 30, PAGODA.z] as const,
  /** the finial */
  crown: [PAGODA.x, PAGODA.topY - 4, PAGODA.z] as const,
  /** mid-lake, at water height, for the skim beat */
  lake: [-6, 2.4, 10] as const,
} as const;

/** Centre of the great stair's foot, on the shore plaza — the walk curve starts here. */
export const STAIR_FOOT = { x: -27, z: 12 } as const;
