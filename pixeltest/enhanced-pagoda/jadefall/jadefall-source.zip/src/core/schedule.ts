/**
 * One clock drives everything: the voxel reveal, the sky, the water, the camera, the UI. `T` is
 * the single source of truth so a frame can be reproduced from a number alone (render/capture.mjs
 * relies on this). Every phase is {start, dur} in seconds and the whole thing wraps at LOOP.
 *
 * The story is a *pouring*, not a smelting: a jade pearl falls out of the stars and strikes the
 * Dragon Gate at the rim; the basin fills, the great veil starts to pour, the island precinct and
 * the nine-tier padoga are raised out of the water, the groves come into leaf and blossom, the
 * koi wake and circle, one koi takes the falls and turns — the dragon coils up the padoga and
 * carries the light to every lantern in the valley — and then the water is drawn back up the veil
 * into the pearl, so the loop closes on the frame it opened with.
 */
import { clamp } from './palette';

export interface Phase {
  start: number;
  dur: number;
}

export const T = {
  /** the jade pearl falls through the stars toward the rim */
  fall: { start: 0.0, dur: 3.6 },
  /** it strikes the Dragon Gate; light blooms along the ridge */
  strike: { start: 3.4, dur: 1.4 },
  /** the basin carves and the lake fills from the deep centre outward */
  basin: { start: 4.0, dur: 2.8 },
  /** the veil pours: lip to pool, the side falls, spray at the foot */
  falls: { start: 6.2, dur: 2.6 },
  /** terraces, roads, the great stair, the causeway, the paddies */
  terraces: { start: 8.4, dur: 2.8 },
  /** the podium tiers and the padoga's storeys, course by course */
  tiers: { start: 10.8, dur: 3.6 },
  /** roofs unfurl eave-tip first, ridge last */
  roofs: { start: 14.0, dur: 3.2 },
  /** balustrades, bracket sets, gilt trim, finial, hanging lanterns */
  trim: { start: 16.8, dur: 2.6 },
  /** the groves stand up: maple, cherry, bamboo, pine, lotus, reeds */
  gardens: { start: 19.0, dur: 3.4 },
  /** the lakeside village, the waterwheel, the boats, the pavilions, the gate */
  village: { start: 22.0, dur: 2.6 },
  /** the water wakes: the school rises, ripples spread, mist gathers */
  life: { start: 24.2, dur: 3.0 },
  /** the camera skims the lake with the school */
  swim: { start: 26.8, dur: 4.2 },
  /** the golden koi takes the fall and climbs the veil */
  leap: { start: 30.6, dur: 3.4 },
  /** it turns: the dragon coils up the padoga and lights the valley */
  dragon: { start: 33.6, dur: 4.4 },
  /** sunrise breaks over the ridge in full colour */
  dawn: { start: 37.6, dur: 3.4 },
  /** the water is drawn back up the veil into the pearl; the loop closes */
  draw: { start: 41.0, dur: 3.0 },
} as const satisfies Record<string, Phase>;

export const LOOP = 44.0;

export type PhaseName = keyof typeof T;

/** Named phases with a per-phase reveal length used when a builder does not pick one. */
const DEFAULT_DUR: Partial<Record<PhaseName, number>> = {
  basin: 0.55,
  falls: 0.4,
  terraces: 0.5,
  tiers: 0.45,
  roofs: 0.4,
  trim: 0.34,
  gardens: 0.55,
  village: 0.5,
  life: 0.6,
  swim: 0.6,
  leap: 0.5,
  dragon: 0.6,
  dawn: 0.8,
};

/**
 * Builds reveal times for voxels. `step(phase, key)` spreads placements across the phase:
 * key 0 lands at the front of the window, key 1 at the back, so a builder can stream its
 * geometry in a readable order (deep-to-shallow, eave-inward, foot-to-crest…).
 */
export interface Schedule {
  step(phase: PhaseName, key: number, dur?: number): number;
  /** progress 0..1 through a phase, clamped — for non-voxel actors */
  at(phase: PhaseName, t: number): number;
}

export function makeSchedule(): Schedule {
  return {
    step: (phase, key, dur) => {
      const p = T[phase];
      const d = dur ?? DEFAULT_DUR[phase] ?? 0.4;
      return p.start + clamp(key, 0, 1) * Math.max(p.dur - d, 0.001);
    },
    at: (phase, t) => clamp((t - T[phase].start) / T[phase].dur, 0, 1),
  };
}

/** Wrap a wall-clock time into the loop. */
export const wrap = (t: number) => {
  const m = t % LOOP;
  return m < 0 ? m + LOOP : m;
};
