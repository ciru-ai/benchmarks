/**
 * JADEFALL palette: a dawn valley in full spectrum.
 *
 * The two-family discipline of the earlier pieces (one cold family, one hot) is replaced by a
 * five-family scheme that has to stay legible at once — jade/turquoise water, teal-glazed roofs,
 * vermilion-and-gold timber, plum-and-maple blossom, limestone-and-marble stone. The keys of the
 * INKFALL/GILTTHRONE library are kept verbatim so every reused builder repaints with the new
 * values; `flourosh*` is repurposed as the luminous gorge algae, `ink*` as pre-dawn rock.
 *
 * Baked lighting keeps upper faces bright and undersides dark, so anything that must read inside
 * a soffit or under an eave is authored near-white (`goldPale`, `marbleLite`).
 */

export const C = {
  // rock & ground — wet limestone, pre-dawn in the shade
  inkDeep: 0x0b1016,
  ink: 0x16222c,
  inkSoft: 0x2a3d47,
  slate: 0x465a63,
  stone: 0x6b7d78,
  stoneLite: 0x93a294,
  gravel: 0xb0aa93,
  sand: 0xd8c08a,
  soil: 0x4a3a2c,
  soilDark: 0x332618,

  // timber & lacquer — vermilion pillars, ironwood beams
  wood: 0x7a4a2c,
  woodDark: 0x53301d,
  ironwood: 0x3a2a22,
  ironwoodLite: 0x584133,
  bark: 0x4e382a,
  barkLite: 0x6f5439,
  vermilion: 0xd9452f,
  vermilionDeep: 0xa12c1e,
  lacquer: 0x8f2a1d,
  lacquerLite: 0xef6a48,

  // gold — leaf on the trim, light in the lanterns
  gold: 0xe6b23c,
  goldLite: 0xffd873,
  goldPale: 0xfff2c9,
  goldHot: 0xffe9a8,
  goldDeep: 0xa97a24,
  bronze: 0x8d6a34,
  gilt: 0xd99a2b,

  // roof — teal glaze with gilt eave discs
  tile: 0x1f6f6a,
  tileDeep: 0x124b4c,
  tileRim: 0xd7a545,

  // flora — evergreen, bamboo, maple and blossom in the same grove
  pine: 0x2f6b4a,
  pineDeep: 0x1d4a35,
  moss: 0x5d8f4a,
  mossDeep: 0x3c6737,
  mossLite: 0x86b862,
  leaf: 0x6fa149,
  bamboo: 0x7fb84a,
  bambooLite: 0xa9d96b,
  bambooDeep: 0x4f8236,
  plum: 0xe88fb2,
  plumLite: 0xffc6dc,
  plumDeep: 0xc25f8e,
  cherry: 0xf3a8c4,
  cherryLite: 0xffe0ec,
  cherryDeep: 0xcf6f96,
  maple: 0xd4552a,
  mapleRed: 0xb02a2c,
  mapleOrange: 0xe8813a,
  mapleGold: 0xf2b93f,
  ginkgo: 0xf0c93f,
  wisteria: 0x9a76c9,
  lotusPink: 0xf58fb0,
  lotusCream: 0xfff0e0,
  lotusLeaf: 0x4f8f6a,

  // gorge algae — the cold light family, kept to the wet rock under the veil
  flourosh: 0x53f0c8,
  flouroshLite: 0xb6ffe8,
  flouroshDeep: 0x2a8f88,
  flouroshRose: 0x7fd8ff,
  spore: 0xd8ffe8,

  // water, sky and lamplight
  water: 0x1d6f86,
  waterLite: 0x49c6c0,
  waterGlow: 0x8ff0e0,
  foam: 0xeaf7f4,
  mist: 0xbcd4dd,
  lantern: 0xffb257,
  lanternCore: 0xffe7b4,
  ember: 0xff8f42,
  jade: 0x2f9e78,
  jadeLite: 0x62d6a4,
  jadeDeep: 0x1a6b57,
  jadePale: 0xbdfbe4,
  ruby: 0xff4a63,
  paper: 0xf6ead0,
  night: 0x060a12,
  moon: 0xe6f0fb,
  marble: 0xcfc9bb,
  marbleLite: 0xe9e3d4,
  marbleDeep: 0xa39d8f,
  velvet: 0x6d1a3a,
  sun: 0xffd9a0,
  sunDeep: 0xff9f5c,
  dawn: 0xffb98a,
  azure: 0x2f7fbf,

  // the stock: the koi, the silver school, the dragon
  koiWhite: 0xf7f2e6,
  koiOrange: 0xf06a28,
  koiRed: 0xd02a24,
  koiBlack: 0x1b1b22,
  koiGold: 0xffc94d,
  koiCream: 0xf6ddae,
  koiSilver: 0xcfd8de,
  dragonJade: 0x3fd6a8,
  dragonJadeDeep: 0x1c7f68,
  dragonGold: 0xffd473,
  dragonBelly: 0xf3e2b3,
  pearl: 0xbfffe8,
} as const;

export type Key = keyof typeof C;

/** Deterministic 3D hash in 0..1 — grain, scatter and AO jitter all key off this. */
export function hash3(x: number, y: number, z: number, seed = 0): number {
  let h = (x | 0) * 374761393 + (y | 0) * 668265263 + (z | 0) * 2147483647 + seed * 1274126177;
  h = (h ^ (h >>> 13)) >>> 0;
  h = Math.imul(h, 1274126177) >>> 0;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967295;
}

/** Small deterministic PRNG for author-time scatter. */
export function rng(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

export const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const smoothstep = (e0: number, e1: number, x: number) => {
  const t = clamp((x - e0) / (e1 - e0), 0, 1);
  return t * t * (3 - 2 * t);
};
/** Blend two packed hex colours, returns hex. */
export function mixHex(a: number, b: number, t: number): number {
  const ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
  const br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
  return (Math.round(lerp(ar, br, t)) << 16) | (Math.round(lerp(ag, bg, t)) << 8) | Math.round(lerp(ab, bb, t));
}
/** Multiply a packed hex colour's brightness, clamped. */
export function shade(hex: number, k: number): number {
  const r = clamp(Math.round(((hex >> 16) & 255) * k), 0, 255);
  const g = clamp(Math.round(((hex >> 8) & 255) * k), 0, 255);
  const b = clamp(Math.round((hex & 255) * k), 0, 255);
  return (r << 16) | (g << 8) | b;
}
