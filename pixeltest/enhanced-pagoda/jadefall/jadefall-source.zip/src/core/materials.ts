import * as THREE from 'three';
import { rawColor } from './color';

/**
 * The one material language of the piece.
 *
 * A voxel owns its reveal window, so the geometry is static and the *material* does the
 * choreography: each cube scales out of its own centre, spins down from above, sways in a
 * travelling wind field, and — in the draw-back — spirals up into the veil. Colour is graded in
 * the fragment stage: the valley is lit in moonlight first, and pigment spreads outward from the
 * strike point along the water as if the lake were carrying the colour inland.
 *
 * Two rendering modes share this program:
 *   `solid`   — opaque worlds (valley, precinct, distant ranges); alpha is always 1.
 *   `water`   — the water lattice, drawn translucent so the bed, the fish and the wet rock read
 *               through the sheet. `Kind.Water` cells use `aAnim.w` as authored depth 0..1,
 *               `Kind.Flow` cells use it as aeration 0..1.
 *
 * One material per authored world (`uCell` differs), all driven from a single state object by
 * `VoxelMaterials.update`, so a frame is still a pure function of time.
 */

const VERT = /* glsl */ `
attribute vec3 aOrigin;
attribute vec4 aAnim;
attribute vec3 aColor;
attribute vec3 aNormal;
attribute float aKind;

uniform float uTime;
uniform float uCell;
uniform float uRise;
uniform float uSway;
uniform float uDissolve;
uniform float uDissolveMask;
uniform float uSwirl;
uniform vec3 uVortex;
uniform float uLowY;
uniform float uHighY;
uniform float uWater;

varying vec3 vColor;
varying vec3 vWorld;
varying float vDepth;
varying float vGlow;
varying float vKind;
varying float vUp;

void main() {
  float seed = fract(sin(dot(aOrigin.xz + aOrigin.y * 0.37, vec2(12.9898, 78.233))) * 43758.5453);

  // ---- reveal: pop into place, easing out, arriving from above
  float prog = clamp((uTime - aAnim.x) / max(aAnim.y, 0.001), 0.0, 1.0);
  float e = 1.0 - pow(1.0 - prog, 3.0);
  float pop = sin(prog * 3.14159265) * 0.16;
  float s = clamp(e + pop * (1.0 - e), 0.0, 1.25);

  // ---- draw-back: crest first, jittered, spiralling into the vortex
  float h = clamp((aOrigin.y - uLowY) / max(uHighY - uLowY, 1.0), 0.0, 1.0);
  float key = (1.0 - h) * 0.85 + seed * 0.15;
  // The per-cell key is keyed on height, so the lowest cells — the lake bed and the water surface —
  // carry a key nearly as long as the draw-back itself and never finish their spiral. The second term
  // closes the last fifth of the draw-back on everything that is still standing.
  float d = max(
    clamp((uDissolve * uDissolveMask - key) / 0.42, 0.0, 1.0),
    smoothstep(0.8, 1.0, uDissolve * uDissolveMask)
  );

  vec3 local = (position - aOrigin) * s * (1.0 - d);

  float lift = 1.0 - e;
  float ang = lift * (seed - 0.5) * 5.0 + d * uSwirl * (0.7 + seed * 0.6);
  float ca = cos(ang);
  float sa = sin(ang);
  local = vec3(local.x * ca - local.z * sa, local.y, local.x * sa + local.z * ca);
  local.y += lift * lift * uRise * uCell * (0.5 + seed);

  vec3 toV = uVortex - aOrigin;
  local += toV * (d * d * 1.15);
  local.xz += vec2(-toV.z, toV.x) * (d * uSwirl * 0.02) * (seed - 0.5) * 90.0;

  // ---- water: the sheet breathes. A surface cell bobs; a veil cell is dragged sideways.
  float isWater = step(1.5, aKind) * step(aKind, 2.5);
  float isFlow = step(3.5, aKind) * step(aKind, 4.5);
  local.y += isWater * uWater * uCell * 0.55
           * sin(uTime * 1.35 + aOrigin.x * 0.34 + aOrigin.z * 0.27 + aOrigin.y * 1.7);
  local.x += isFlow * uWater * uCell * 0.4 * sin(uTime * 3.1 + aOrigin.y * 0.9 + aOrigin.x * 0.5);

  vec4 world = modelMatrix * vec4(aOrigin + local, 1.0);

  // ---- wind: one travelling field so every crown breathes together
  if (aAnim.z > 0.0) {
    float w = sin(uTime * 1.05 + world.x * 0.018 + world.z * 0.014)
            + 0.45 * sin(uTime * 2.15 + world.x * 0.047 + world.z * 0.03);
    float amp = aAnim.z * uSway * uCell;
    world.x += w * amp;
    world.z += w * amp * 0.42;
  }

  vec4 mv = viewMatrix * world;
  gl_Position = projectionMatrix * mv;

  vColor = aColor;
  vWorld = world.xyz;
  vDepth = -mv.z;
  vGlow = aAnim.w;
  vKind = aKind;
  vUp = aNormal.y;
}
`;

const FRAG = /* glsl */ `
precision highp float;

uniform float uTime;
uniform float uInk;
uniform float uColorFront;
uniform vec3 uColorOrigin;
uniform vec3 uInkTint;
uniform vec3 uFogColor;
uniform float uFogNear;
uniform float uFogFar;
uniform float uWater;
uniform float uGlowGain;
uniform float uExposure;
uniform float uCell;
uniform float uInkGain;
uniform vec4 uLampA;
uniform float uGainA;
uniform vec4 uLampB;
uniform float uGainB;
uniform float uRoomDim;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform float uSunGain;
uniform vec3 uWaterDeep;
uniform vec3 uWaterShallow;
uniform vec2 uRippleAt;
uniform float uRippleR;
uniform float uRippleGain;
uniform vec3 uFoamAt;
uniform float uFoamGain;
uniform float uAlphaWater;
uniform float uAlphaFlow;

varying vec3 vColor;
varying vec3 vWorld;
varying float vDepth;
varying float vGlow;
varying float vKind;
varying float vUp;

float hash21(vec2 p) {
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

/** Value noise on a lattice — foam speckle, wet rock, cloud bands in the pool. */
float noise2(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

void main() {
  float isWater = step(1.5, vKind) * step(vKind, 2.5);
  float isFlow = step(3.5, vKind) * step(vKind, 4.5);

  // ---- moonlight grade: luminance of the baked colour, cool first
  float luma = dot(vColor, vec3(0.2126, 0.7152, 0.0722));
  vec3 inky = mix(vec3(0.026, 0.038, 0.052), uInkTint, pow(clamp(luma, 0.0, 1.0), 0.85));

  // ---- pigment bleeding outward along the water from the strike point
  float dist = distance(vWorld.xz, uColorOrigin.xz);
  float cmix = 1.0 - smoothstep(uColorFront - 16.0, uColorFront + 30.0, dist);
  float inkMix = clamp(uInk * uInkGain, 0.0, 1.0);
  vec3 col = mix(inky, vColor, cmix * (1.0 - inkMix));
  col *= uRoomDim;

  float alpha = 1.0;

  // ---------------------------------------------------------------- lake
  if (isWater > 0.5) {
    // authored depth 0..1 in the glow slot: shallow reads pale jade, deep reads ink-teal
    float depth = clamp(vGlow, 0.0, 1.0);

    // two crossed swell trains, quantised into bands so it reads as painted water
    float a = sin(vWorld.x * 0.42 + vWorld.z * 0.24 + uTime * 1.25) * 0.5 + 0.5;
    float b = sin(vWorld.x * 0.16 - vWorld.z * 0.5 + uTime * 0.72) * 0.5 + 0.5;
    float swell = smoothstep(0.35, 0.95, a * b);

    vec3 body = mix(uWaterShallow, uWaterDeep, clamp(depth * 1.7, 0.0, 1.0));
    col = mix(col, body, 0.82);
    col *= 0.78 + 0.42 * swell * (1.0 - 0.5 * depth);

    // the sun's path across the water: a specular band along the reflection axis
    vec3 v = normalize(cameraPosition - vWorld);
    vec3 h = normalize(normalize(uSunDir) + v);
    float path = pow(max(dot(vec3(h.x, abs(h.y), h.z), vec3(0.0, 1.0, 0.0)), 0.0), 26.0);
    col += uSunColor * path * uSunGain * (0.5 + 0.9 * swell) * max(vUp, 0.0);
    col += uWaterShallow * pow(max(swell - 0.72, 0.0) / 0.28, 3.0) * 0.4 * max(vUp, 0.0);

    // the sky lying on the water: grazing angles lift toward the horizon colour, so a wide lake
    // reads wet rather than painted, and the far shore dissolves instead of cutting a hard line
    float fres = pow(1.0 - clamp(v.y, 0.0, 1.0), 3.2);
    col = mix(col, mix(uFogColor, uWaterShallow, 0.3), fres * 0.6);
    // slow currents at a scale the wide beats can actually see
    float current = noise2(vWorld.xz * 0.045 + vec2(uTime * 0.05, -uTime * 0.035));
    col *= 0.9 + 0.2 * smoothstep(0.3, 0.78, current);

    // a ring of ripples travelling out from wherever the water was just broken
    float rr = abs(length(vWorld.xz - uRippleAt) - uRippleR);
    col += uWaterShallow * exp(-rr * rr * 0.22) * uRippleGain;

    // foam where the veil lands
    float fd = length(vWorld.xz - uFoamAt.xz) / max(uFoamAt.y, 1.0);
    float fleck = noise2(vWorld.xz * 1.7 + vec2(uTime * 0.9, uTime * 0.4));
    float foam = (1.0 - smoothstep(0.35, 1.0, fd)) * (0.45 + 0.55 * fleck);
    col = mix(col, vec3(0.93, 0.98, 0.97), clamp(foam, 0.0, 1.0) * uFoamGain);

    // the sheet is thin where it is shallow: the shore reads through, the deep reads as jade
    alpha = mix(uAlphaWater * 0.72, uAlphaWater, 0.25 + 0.75 * depth);
    alpha = max(alpha, clamp(foam * uFoamGain, 0.0, 1.0));
  }

  // ---------------------------------------------------------------- the veil
  if (isFlow > 0.5) {
    float aer = clamp(vGlow, 0.0, 1.0);
    // bands travelling downward, three wavelengths so the sheet never looks static
    float s1 = fract(vWorld.y * 0.55 + uTime * 2.4);
    float s2 = fract(vWorld.y * 1.31 - uTime * 3.6 + 0.37);
    float streak = smoothstep(0.15, 0.95, s1) * 0.65 + smoothstep(0.35, 1.0, s2) * 0.35;
    float thread = noise2(vec2(vWorld.x * 2.4 + vWorld.z * 1.1, vWorld.y * 0.35 - uTime * 2.2));

    vec3 body = mix(vec3(0.36, 0.78, 0.82), vec3(0.96, 1.0, 1.0), aer);
    col = mix(col, body, 0.72 + 0.24 * streak);
    col *= 0.72 + 0.55 * streak;
    col += vec3(0.85, 0.97, 1.0) * pow(thread, 3.0) * 0.5 * aer;

    alpha = mix(uAlphaFlow * 0.6, uAlphaFlow, 0.35 + 0.65 * aer);
    alpha *= 0.62 + 0.38 * streak;
  }

  // ---------------------------------------------------------------- lamplight
  if (vKind > 2.5 && vKind < 3.5 && vGlow > 0.0) {
    float flicker = 0.86 + 0.14 * sin(uTime * 7.3 + vWorld.x * 0.6 + vWorld.z * 0.4);
    col += vColor * min(vGlow, 1.0) * uGlowGain * flicker * 0.46;
  }

  // ---- the two authored lamps: sunrise on the water, the gorge's cold algae
  float lampA = 1.0 - smoothstep(uLampA.w * 0.18, uLampA.w, distance(vWorld, uLampA.xyz));
  col += vColor * vec3(1.0, 0.78, 0.46) * uGainA * lampA * 0.3 * (0.34 + 0.66 * max(vUp, 0.0));
  float lampB = 1.0 - smoothstep(uLampB.w * 0.18, uLampB.w, distance(vWorld, uLampB.xyz));
  col += vColor * vec3(0.4, 1.0, 0.86) * uGainB * lampB * 0.34 * (0.3 + 0.7 * max(vUp, 0.0));

  // ---- the sun itself, at last: a warm lift on everything facing the ridge
  col += vColor * uSunColor * uSunGain * (0.12 + 0.78 * max(dot(vec3(0.0, 1.0, 0.0), uSunDir), 0.0) * 0.5);

  float fog = smoothstep(uFogNear, uFogFar, vDepth);
  col = mix(col, uFogColor, fog);

  vec3 lit = col * uExposure;
  // Soft knee at 0.7, ceiling 1.0: stacked lantern pigment, foam and the dawn sky roll off
  // together, and tonal separation survives above the knee instead of flattening to white.
  float hi = max(lit.r, max(lit.g, lit.b));
  if (hi > 0.7) lit *= (0.7 + 0.3 * (hi - 0.7) / (hi - 0.4)) / hi;
  gl_FragColor = vec4(lit, clamp(alpha, 0.0, 1.0));
}
`;

/** Per-frame grading state, identical for every authored world. */
export interface VoxelState {
  time: number;
  /** 1 = moonlit monochrome, 0 = full pigment */
  ink: number;
  /** radius (world units) the pigment has reached from `colorOrigin` */
  colorFront: number;
  colorOrigin: THREE.Vector3;
  /** 0..1 how far the water has been drawn back up the veil */
  dissolve: number;
  vortex: THREE.Vector3;
  swirl: number;
  sway: number;
  /** 0..1 how alive the water is — swells, bob, veil streaks */
  water: number;
  glowGain: number;
  exposure: number;
  /** reserved for any interior beat (1 = outside) */
  roomDim: number;
  /** warm lamp: world position, reach, gain */
  lampA: THREE.Vector4;
  gainA: number;
  /** cold lamp: world position, reach, gain */
  lampB: THREE.Vector4;
  gainB: number;
  /** the sun: direction from the world, colour, gain */
  sunDir: THREE.Vector3;
  sunColor: THREE.Color;
  sunGain: number;
  /** ripple ring: centre, current radius, strength */
  rippleAt: THREE.Vector2;
  rippleR: number;
  rippleGain: number;
  /** foam field: x/z centre, y radius, strength */
  foamAt: THREE.Vector3;
  foamGain: number;
  fogColor: THREE.Color;
  fogNear: number;
  fogFar: number;
}

export interface MaterialOptions {
  /** translucent mode for the water lattice */
  water?: boolean;
  alphaWater?: number;
  alphaFlow?: number;
}

export class VoxelMaterials {
  readonly materials: THREE.ShaderMaterial[] = [];

  /**
   * One material per authored world: `cell` scales the fly-in and the wind, `dissolveMask` 0
   * keeps a world out of the draw-back, `inkGain` dials how hard the moonlight grade bites it.
   */
  create(
    cell: number,
    lowY: number,
    highY: number,
    dissolveMask = 1,
    inkGain = 1,
    opts: MaterialOptions = {},
  ): THREE.ShaderMaterial {
    const material = new THREE.ShaderMaterial({
      vertexShader: VERT,
      fragmentShader: FRAG,
      uniforms: {
        uTime: { value: 0 },
        uCell: { value: cell },
        uRise: { value: 9 },
        uSway: { value: 0 },
        uDissolve: { value: 0 },
        uDissolveMask: { value: dissolveMask },
        uSwirl: { value: 0 },
        uVortex: { value: new THREE.Vector3(0, 260, 0) },
        uLowY: { value: lowY },
        uHighY: { value: highY },
        uWater: { value: 0 },
        uInk: { value: 1 },
        uInkGain: { value: inkGain },
        uColorFront: { value: 0 },
        uColorOrigin: { value: new THREE.Vector3(0, 0, 0) },
        uInkTint: { value: rawColor(0x9fb2cc) },
        uFogColor: { value: rawColor(0x0a0c14) },
        uFogNear: { value: 200 },
        uFogFar: { value: 1200 },
        uGlowGain: { value: 0 },
        uExposure: { value: 1 },
        uLampA: { value: new THREE.Vector4(0, 0, 0, 1) },
        uGainA: { value: 0 },
        uLampB: { value: new THREE.Vector4(0, 0, 0, 1) },
        uGainB: { value: 0 },
        uRoomDim: { value: 1 },
        uSunDir: { value: new THREE.Vector3(0.55, 0.62, 0.55) },
        uSunColor: { value: rawColor(0xffd9a0) },
        uSunGain: { value: 0 },
        uWaterDeep: { value: rawColor(0x052c3c) },
        uWaterShallow: { value: rawColor(0x2fa8ab) },
        uRippleAt: { value: new THREE.Vector2(0, 0) },
        uRippleR: { value: 0 },
        uRippleGain: { value: 0 },
        uFoamAt: { value: new THREE.Vector3(0, 0, 8) },
        uFoamGain: { value: 0 },
        uAlphaWater: { value: opts.alphaWater ?? 0.74 },
        uAlphaFlow: { value: opts.alphaFlow ?? 0.9 },
      },
      transparent: opts.water === true,
      depthWrite: opts.water === true ? false : true,
    });
    this.materials.push(material);
    return material;
  }

  update(state: VoxelState): void {
    for (const material of this.materials) {
      const u = material.uniforms;
      u.uTime.value = state.time;
      u.uInk.value = state.ink;
      u.uColorFront.value = state.colorFront;
      u.uColorOrigin.value.copy(state.colorOrigin);
      u.uDissolve.value = state.dissolve;
      u.uVortex.value.copy(state.vortex);
      u.uSwirl.value = state.swirl;
      u.uSway.value = state.sway;
      u.uWater.value = state.water;
      u.uGlowGain.value = state.glowGain;
      u.uExposure.value = state.exposure;
      u.uLampA.value.copy(state.lampA);
      u.uGainA.value = state.gainA;
      u.uLampB.value.copy(state.lampB);
      u.uGainB.value = state.gainB;
      u.uRoomDim.value = state.roomDim;
      u.uSunDir.value.copy(state.sunDir);
      u.uSunColor.value.copy(state.sunColor);
      u.uSunGain.value = state.sunGain;
      u.uRippleAt.value.copy(state.rippleAt);
      u.uRippleR.value = state.rippleR;
      u.uRippleGain.value = state.rippleGain;
      u.uFoamAt.value.copy(state.foamAt);
      u.uFoamGain.value = state.foamGain;
      u.uFogColor.value.copy(state.fogColor);
      u.uFogNear.value = state.fogNear;
      u.uFogFar.value = state.fogFar;
    }
  }
}
