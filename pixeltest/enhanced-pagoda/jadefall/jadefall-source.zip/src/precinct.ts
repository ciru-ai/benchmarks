/**
 * JADEFALL 翠瀑 — the island precinct pass. Everything authored on the FINE lattice (0.2 units a
 * cell, row 0 being the temple deck at `COURT.deckY`) is composed here and nowhere else, in reveal
 * order: the causeway first, then the walls, the podium and the temple, and last the screens, the
 * colonnades and the lantern ranges that dress them.
 *
 * Same contract as `scene.ts`: a grid writer only. No THREE, no wall clock, no unseeded random.
 *
 * Where things stand, and why there is room for them. The court wall is half-extent 63 cells about
 * `(COURT.x, COURT.z)`, the lowest podium tier is half-extent 47, so inside the walls the free
 * ground is two 15-cell bands along the north and south faces of the podium plus a narrow strip
 * outside the west wall where the shore rises to 8.6. That gives exactly the composition below:
 *
 *   causeway        the moon bridge over the channel, on the processional axis `BRIDGE.z`
 *   court + podium  the walled court and its three-tier marble podium, both centred on the axis
 *   colonnades      one portico per band, just inside the gate, flanking the entrance court
 *   spirit screens  one per band behind the porticos, closing the side courts
 *   lantern ranges  one per band at its east end, behind the screened wall
 */
import { VoxelWorld } from './core/VoxelWorld';
import { BRIDGE, CELL, COURT, FINE, PAGODA, PODIUM, fineCol, fineLane, fineRow, fy } from './core/layout';
import { makeSchedule } from './core/schedule';
import { type BuilderArgs } from './builds/types';
import { SEED } from './scene';
import * as monument from './builds/monument';

/**
 * Row of the ninth roof's ridge, measured from `greatPagoda` with the knobs used below (nine
 * storeys of 13 rows on a 21-row pitch, standing on the podium crown at row 30). The finial is
 * given the exact height that lands its pearl on `PAGODA.topY`, the camera's ceiling.
 */
const RIDGE_ROW = 219;

/** BuilderArgs for an object standing on a known FINE row at plan (x, z). */
function onFine(
  x: number,
  z: number,
  row: number,
  t: number,
  dt: number,
  seed: number,
  opts?: Record<string, number>,
): BuilderArgs {
  return { x: fineCol(x), z: fineLane(z), y: Math.max(0, Math.round(row)), t, dt, seed, opts };
}

export interface PrecinctReport {
  /** monuments authored */
  placed: number;
  /** world y of the finial pearl, so the stage can point the spiral beat at it */
  crownY: number;
}

/**
 * The island lattice: causeway, court, podium, temple, screens, colonnades, lantern ranges.
 * `report.crownY` is the world height the spire's pearl actually reached.
 */
export function buildPrecinct(): { world: VoxelWorld; report: PrecinctReport } {
  const world = new VoxelWorld(FINE.sx, FINE.sy, FINE.sz);
  const sched = makeSchedule();
  const deck = fineRow(COURT.deckY);
  const crown = fineRow(PODIUM.top);
  let placed = 0;

  // ---- the causeway: it is built first because everything else is approached over it
  monument.moonBridge(
    world,
    onFine(BRIDGE.x1, BRIDGE.z, deck, sched.step('terraces', 0.62), 1.4, SEED + 700, {
      span: Math.round((BRIDGE.x0 - BRIDGE.x1) / CELL.fine),
      arch: 12,
      width: 9,
    }),
  );
  placed++;

  // ---- the walled court, then the podium raised inside it
  monument.islandCourt(
    world,
    onFine(COURT.x, COURT.z, deck, sched.step('tiers', 0.04), 2.0, SEED + 701, { wallH: 22 }),
  );
  monument.marblePodium(
    world,
    onFine(COURT.x, COURT.z, deck, sched.step('tiers', 0.2), 2.4, SEED + 702, { tiers: 3 }),
  );
  placed += 2;

  // ---- the temple: storeys in the tier phase, its finial in the trim phase
  monument.greatPagoda(
    world,
    onFine(PAGODA.x, PAGODA.z, crown, sched.step('tiers', 0.45), 3.2, SEED + 703, {
      tiers: PAGODA.tiers,
      half: Math.round(PAGODA.baseHalf / CELL.fine),
      walkRing: 1,
    }),
  );
  monument.finalSpire(
    world,
    onFine(PAGODA.x, PAGODA.z, RIDGE_ROW, sched.step('trim', 0.55), 1.4, SEED + 704, {
      h: fineRow(PAGODA.topY) - RIDGE_ROW,
    }),
  );
  placed += 2;

  // ---- the bell house beside the landing, inside the gate. `scale` 0.25 puts its contracted
  // footprint exactly in the 11-cell ring between the wall's inner face (col 85) and the lowest
  // podium tier (col 97).
  monument.bellTower(
    world,
    onFine(-9.4, 4.8, deck, sched.step('tiers', 0.72), 2.2, SEED + 705, { floors: 2, scale: 0.25 }),
  );
  placed++;

  // ---- the two bands. Inside the walls the free ground is an eleven-cell band on each flank of
  // the podium (lanes 21-29 north, 127-135 south). Each band carries, west to east: a portico at
  // the entrance court, a screened wall closing the side court, a lantern range beyond it.
  for (const side of [-1, 1]) {
    const z = COURT.z + side * 10.6;
    monument.cloister(
      world,
      onFine(-8.4, z, deck, sched.step('tiers', 0.6 + (side > 0 ? 0.06 : 0)), 2.0, SEED + 710 + side, {
        bays: 3,
        bay: 6,
        h: 14,
      }),
    );
    monument.spiritScreen(
      world,
      onFine(COURT.x + 1.2, z, deck, sched.step('roofs', 0.25 + (side > 0 ? 0.08 : 0)), 1.8, SEED + 720 + side, {
        width: 49,
        h: 26,
      }),
    );
    placed += 2;
  }

  // ---- lantern ranges at the east end of the same bands, behind the screened walls
  for (const side of [-1, 1]) {
    monument.lanternRack(
      world,
      onFine(6.8, COURT.z + side * 10.6, deck, sched.step('trim', 0.2 + (side > 0 ? 0.1 : 0)), 1.2, SEED + 730 + side, {
        count: 3,
        pitch: 8,
        h: 12,
      }),
    );
    placed++;
  }

  return { world, report: { placed, crownY: fy(fineRow(PAGODA.topY)) } };
}
