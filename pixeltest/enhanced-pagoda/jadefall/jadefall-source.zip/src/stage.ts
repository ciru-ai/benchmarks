/**
 * JADEFALL 翠瀑 — the scene graph. One mesh per authored lattice, one material per mesh, and the
 * living things hung on curves. Nothing here authors a voxel grid: the worlds come from `scene.ts`
 * (the valley), `precinct.ts` (the island) and the model factories in `builds/fauna.ts` and
 * `builds/props.ts`.
 *
 * Every actor is a pure function of the loop second: the reveal clocks baked into a model's cells
 * put it on screen at its phase, and its position comes from sampling a curve at a fraction of the
 * clock. Seek to a second, get that frame — which is what the capture harness needs.
 *
 * Movable models are authored at 0.25 world units a cell and face their own +x. `mount` bakes a
 * quarter turn so the model faces +z, which lets `place` steer it with `lookAt` along the curve
 * tangent and roll it about its own axis for banking.
 */
import * as THREE from 'three';
import { Kind, VoxelWorld } from './core/VoxelWorld';
import { VoxelMaterials, type VoxelState } from './core/materials';
import { GlowSprites, ParticleField } from './core/Particles';
import { createSkyDome, createStars } from './core/Atmosphere';
import { BowArc, LightArc, MistCollar, Pearl, SunDisc } from './core/Shell';
import { C, clamp, smoothstep } from './core/palette';
import {
  CELL,
  COURT,
  FALLS,
  FAR,
  FINE,
  MID,
  PAGODA,
  POOL,
  SHEET,
  WATER,
} from './core/layout';
import { T, makeSchedule } from './core/schedule';
import type { Look } from './director';
import { SEED, buildMid } from './scene';
import { buildPrecinct } from './precinct';
import { authorOuter } from './outer';
import { authorLake, authorVeil } from './builds/water';
import * as fauna from './builds/fauna';
import * as props from './builds/props';
import type { MovableModel } from './builds/types';

declare global {
  interface Window {
    /** TEMP DEBUG: the assembled stage group, for isolating layers while the grade is tuned. */
    __group?: THREE.Group;
  }
}

/** Every actor is authored at this cell size, so one material serves all of them. */
const MODEL_CELL = 0.25;

/** One authored lattice: its grid, its mesh, its material. */
interface Layer {
  world: VoxelWorld;
  mesh: THREE.Mesh;
}

interface Actor {
  obj: THREE.Object3D;
  tick(t: number, look: Look): void;
}

/** Movable models are 0.25-cell grids facing +x; bake the turn to +z so `lookAt` can steer them. */
function mount(model: MovableModel, material: THREE.ShaderMaterial, at: number): THREE.Mesh {
  model.world.shiftReveal(at);
  const [cx, cy, cz] = model.center;
  const geo = model.world
    .mesh({
      cell: MODEL_CELL,
      origin: [-cx * MODEL_CELL, -cy * MODEL_CELL, -cz * MODEL_CELL],
      grain: 0.07,
      bake: 1.1,
    })
    .rotateY(-Math.PI / 2);
  const mesh = new THREE.Mesh(geo, material);
  mesh.frustumCulled = false;
  return mesh;
}

const curve = (points: readonly (readonly [number, number, number])[], closed = false) =>
  new THREE.CatmullRomCurve3(points.map(([x, y, z]) => new THREE.Vector3(x, y, z)), closed, 'catmullrom', 0.5);

const _p = new THREE.Vector3();
const _q = new THREE.Vector3();

/** Put a model on a curve at `u`, pointed along the tangent, rolled by `bank`. */
function place(obj: THREE.Object3D, path: THREE.CatmullRomCurve3, u: number, bank = 0): void {
  const k = clamp(u, 0, 1);
  path.getPointAt(k, _p);
  path.getTangentAt(k, _q);
  obj.position.copy(_p);
  obj.lookAt(_p.add(_q));
  if (bank !== 0) obj.rotateZ(bank);
}

/** Filled cells of a world, for the readout. */
function countCells(world: VoxelWorld): number {
  let n = 0;
  for (let x = 0; x < world.sx; x++) {
    for (let y = 0; y < world.sy; y++) {
      for (let z = 0; z < world.sz; z++) if (world.occupied(x, y, z)) n++;
    }
  }
  return n;
}

/** Every glowing cell of a lattice, at its world centre — the halos are drawn where these are. */
function glowCells(world: VoxelWorld, cell: number, origin: readonly number[]): number[] {
  const out: number[] = [];
  for (let x = 0; x < world.sx; x++) {
    for (let y = 0; y < world.sy; y++) {
      for (let z = 0; z < world.sz; z++) {
        if (world.occupied(x, y, z) && world.kindAt(x, y, z) === Kind.Glow) {
          out.push(origin[0] + (x + 0.5) * cell, origin[1] + (y + 0.5) * cell, origin[2] + (z + 0.5) * cell);
        }
      }
    }
  }
  return out;
}

export interface Stage {
  readonly group: THREE.Group;
  readonly stats: {
    inner: number;
    outer: number;
    plants: number;
    movers: number;
    faces: number;
    /** voxels a builder aimed outside a lattice — must read 0 before a build ships */
    overflow: number;
  };
  setPixel(ratio: number): void;
  update(t: number, look: Look, camera: THREE.Vector3): void;
}

/**
 * Assemble the piece: five authored lattices meshed and graded, the sky, the sun, the pearl and its
 * arcs, mist, petals, the rising lanterns, and the shoals, the mill, the boats and the dragon.
 */
export function buildStage(): Stage {
  const group = new THREE.Group();
  const mats = new VoxelMaterials();
  const sched = makeSchedule();

  // ------------------------------------------------------------------ the lattices
  const far = new VoxelWorld(FAR.sx, FAR.sy, FAR.sz);
  authorOuter(far, { seed: SEED + 5, t: sched.step('basin', 0.05), dur: 2.4 });

  const mid = buildMid();
  const fine = buildPrecinct();

  const water = new VoxelWorld(WATER.sx, WATER.sy, WATER.sz);
  authorLake(water, { seed: SEED + 11, t: sched.step('basin', 0.35), dur: 2.2 });

  const sheet = new VoxelWorld(SHEET.sx, SHEET.sy, SHEET.sz);
  authorVeil(sheet, { seed: SEED + 13, t: sched.step('falls', 0), dur: 2.2 });

  const layers: Layer[] = [
    {
      world: far,
      mesh: new THREE.Mesh(
        far.mesh({ cell: CELL.far, origin: [...FAR.origin], grain: 0.05, bake: 0.72 }),
        // The ranges take part in the draw-back. The opening beats are empty sky because nothing has
        // been revealed yet, so a closing that left the horizon standing could never match them.
        mats.create(CELL.far, FAR.origin[1], FAR.origin[1] + FAR.sy * CELL.far, 1, 0.62),
      ),
    },
    {
      world: mid.world,
      mesh: new THREE.Mesh(
        mid.world.mesh({ cell: CELL.mid, origin: [...MID.origin], grain: 0.075, bake: 1 }),
        mats.create(CELL.mid, MID.origin[1], MID.origin[1] + MID.sy * CELL.mid, 1, 1),
      ),
    },
    {
      world: fine.world,
      mesh: new THREE.Mesh(
        fine.world.mesh({ cell: CELL.fine, origin: [...FINE.origin], grain: 0.035, bake: 1.15 }),
        mats.create(CELL.fine, FINE.origin[1], FINE.origin[1] + FINE.sy * CELL.fine, 1, 0.85),
      ),
    },
    {
      world: water,
      mesh: new THREE.Mesh(
        water.mesh({ cell: CELL.water, origin: [...WATER.origin], grain: 0.03, bake: 0.5 }),
        mats.create(CELL.water, WATER.origin[1], WATER.origin[1] + WATER.sy * CELL.water, 1, 0.5, {
          water: true,
          alphaWater: 0.82,
        }),
      ),
    },
    {
      world: sheet,
      mesh: new THREE.Mesh(
        sheet.mesh({ cell: CELL.sheet, origin: [...SHEET.origin], grain: 0.02, bake: 0.42 }),
        mats.create(CELL.sheet, SHEET.origin[1], SHEET.origin[1] + SHEET.sy * CELL.sheet, 1, 0.4, {
          water: true,
          alphaWater: 0.62,
          alphaFlow: 0.9,
        }),
      ),
    },
  ];
  for (const l of layers) {
    l.mesh.frustumCulled = false;
    group.add(l.mesh);
  }

  // ------------------------------------------------------------------ sky and light
  const sky = createSkyDome(520);
  group.add(sky.dome);
  const stars = createStars(1400, 500, SEED + 17);
  group.add(stars.points);

  // The jade pearl falls out of the stars onto the sill, where the river spills.
  const pearl = new Pearl(
    2.1,
    curve([
      [-26, 156, -86],
      [-29, 96, -68],
      [-31, 58, -56],
      [-32.2, 39.5, -47.6],
      [FALLS.x, FALLS.lipY + 1.4, FALLS.lipZ + 0.4],
    ]),
  );
  group.add(pearl.mesh);

  // Light along the ridge crest when the pearl strikes, and the arc the water climbs at the end.
  const crest = curve([
    [-58, 41, -52],
    [-40, 44, -58],
    [-18, 42.5, -56],
    [4, 40, -52],
    [26, 37, -46],
    [44, 34, -38],
  ]);
  const ridgeArc = new LightArc(crest, 1.5);
  group.add(ridgeArc.mesh);

  const drawArc = new LightArc(
    curve([
      [POOL.x, 0.6, POOL.z],
      [POOL.x + 0.6, 12, POOL.z - 3.4],
      [FALLS.x + 0.4, 24, FALLS.lipZ + 3.2],
      [FALLS.x, FALLS.lipY + 1.4, FALLS.lipZ + 0.4],
    ]),
    2.4,
  );
  group.add(drawArc.mesh);

  const sun = new SunDisc(9.5, 330, new THREE.Vector3(1, 0.2, 0.4));
  group.add(sun.mesh);

  const collar = new MistCollar(300, 5.5);
  group.add(collar.mesh);

  const bow = new BowArc(27, new THREE.Vector3(POOL.x - 2, 1.5, POOL.z + 2));
  group.add(bow.mesh);

  // ------------------------------------------------------------------ air
  const mist = new ParticleField(
    {
      count: 1100,
      span: 26,
      radius: 17,
      size: 3.6,
      colorA: C.foam,
      colorB: C.waterGlow,
      spin: 0.05,
      drift: 2.6,
      fall: 0.24,
      soft: 0.55,
    },
    SEED + 21,
  );
  mist.points.position.set(POOL.x, 0, POOL.z + 1);
  group.add(mist.points);

  const petals = new ParticleField(
    {
      count: 1500,
      span: 34,
      radius: 52,
      size: 2.3,
      colorA: C.plumLite,
      colorB: C.cherryLite,
      spin: 0.02,
      drift: 5.4,
      fall: 0.5,
      soft: 0.42,
    },
    SEED + 23,
  );
  petals.points.position.set(COURT.x - 6, 26, 6);
  group.add(petals.points);

  const lanterns = new ParticleField(
    {
      count: 240,
      span: 62,
      radius: 58,
      size: 3.1,
      colorA: C.lanternCore,
      colorB: C.goldPale,
      spin: 0.014,
      drift: 3.2,
      fall: -0.42,
      soft: 0.34,
    },
    SEED + 25,
  );
  lanterns.points.position.set(COURT.x, 9, COURT.z);
  group.add(lanterns.points);

  // ------------------------------------------------------------------ halos
  // The lantern wave travels out of the padoga as the reach of the warm lamp, so the halos are
  // grouped by their distance from the temple and each group lights as the wave passes it.
  const authored = [...glowCells(fine.world, CELL.fine, FINE.origin), ...glowCells(mid.world, CELL.mid, MID.origin)];
  const floatLamps: number[] = [];
  for (let i = 0; i < 30; i++) {
    const a = (i / 30) * Math.PI * 2;
    const r = 15 + (i % 3) * 4.5;
    const x = COURT.x + Math.cos(a) * r * 1.35;
    const z = COURT.z + Math.sin(a) * r;
    floatLamps.push(x, 0.42, z);
  }
  const ringOf = (p: number[]) => Math.hypot(p[0] - PAGODA.x, p[2] - PAGODA.z);
  const buckets: number[][] = [[], [], [], []];
  const sizes: number[][] = [[], [], [], []];
  const midRing: number[] = [16, 42, 84, 1e9];
  for (let i = 0; i < authored.length; i += 3) {
    const p = [authored[i], authored[i + 1], authored[i + 2]];
    const d = ringOf(p);
    const b = d < midRing[0] ? 0 : d < midRing[1] ? 1 : d < midRing[2] ? 2 : 3;
    buckets[b].push(p[0], p[1], p[2]);
    sizes[b].push(b === 0 ? 2.1 : 2.6);
  }
  for (let i = 0; i < floatLamps.length; i += 3) {
    const p = [floatLamps[i], floatLamps[i + 1], floatLamps[i + 2]];
    const d = ringOf(p);
    const b = d < midRing[1] ? 1 : d < midRing[2] ? 2 : 3;
    buckets[b].push(p[0], p[1], p[2]);
    sizes[b].push(1.9);
  }
  const halos: [GlowSprites, number][] = [];
  for (let b = 0; b < 4; b++) {
    if (!buckets[b].length) continue;
    const sprites = new GlowSprites(buckets[b], sizes[b], C.lanternCore);
    group.add(sprites.points);
    halos.push([sprites, b === 0 ? 4 : midRing[b - 1] + 10]);
  }

  // ------------------------------------------------------------------ the living things
  const modelMat = mats.create(MODEL_CELL, -1.6, 6.4, 1, 0.95);
  const actors: Actor[] = [];

  // The koi circuit: down from the pool under the falls, through the nine-unit channel between the
  // west bank and the island mesa, into the south basin and back.
  const koiWay = curve(
    [
      [-24, -0.45, -30],
      [-19, -0.45, -19],
      [-16, -0.45, -8],
      [-15, -0.45, 2],
      [-16, -0.45, 10],
      [-19, -0.45, 4],
      [-22, -0.45, -8],
      [-23, -0.45, -20],
    ],
    true,
  );
  const koiGeos = [0, 1, 3, 5].map((coat, i) => mount(fauna.makeKoi(SEED + 40 + i * 7, coat), modelMat, T.life.start));
  for (let i = 0; i < 9; i++) {
    const mesh = koiGeos[i % koiGeos.length].clone();
    const side = (i % 3) - 1;
    const depth = -0.35 - 0.28 * ((i >> 2) % 3);
    const lead = i / 9;
    const roll = 0.1 + 0.06 * (i % 4);
    group.add(mesh);
    actors.push({
      obj: mesh,
      tick: (t, lk) => {
        if (lk.shoal < 0.004) return;
        const u = ((t - T.life.start) / 34 + lead) % 1;
        place(mesh, koiWay, u, Math.sin(u * Math.PI * 16) * roll);
        mesh.position.y = depth + Math.sin(t * 1.7 + i) * 0.12;
        mesh.translateX(side * 2.1);
        const s = 0.82 + 0.18 * ((i * 5) % 4) / 3;
        mesh.scale.setScalar(s);
      },
    });
  }

  // The silver school in the south basin, tighter and quicker.
  const fryWay = curve(
    [
      [-8, -1.1, 22],
      [2, -1.1, 26],
      [12, -1.1, 24],
      [15, -1.1, 18],
      [9, -1.1, 14],
      [-2, -1.1, 14],
    ],
    true,
  );
  const fryGeo = mount(fauna.makeFry(SEED + 61), modelMat, T.life.start + 0.4);
  for (let i = 0; i < 15; i++) {
    const mesh = fryGeo.clone();
    group.add(mesh);
    const lead = (i % 5) / 5 + Math.floor(i / 5) * 0.045;
    const side = ((i % 3) - 1) * 1.5;
    actors.push({
      obj: mesh,
      tick: (t, lk) => {
        if (lk.shoal < 0.004) return;
        const u = ((t - T.life.start) / 21 + lead) % 1;
        place(mesh, fryWay, u, Math.sin(u * Math.PI * 22 + i) * 0.14);
        mesh.position.y = -0.8 - 0.3 * ((i >> 2) % 3) + Math.sin(t * 2.4 + i * 0.7) * 0.1;
        mesh.translateX(side);
      },
    });
  }

  // The turtle across the channel, under the arch of the moon bridge.
  const turtleWay = curve([
    [-21, -1.3, -6],
    [-18, -1.3, -3],
    [-16, -1.3, 0],
    [-19, -1.3, -2],
  ]);
  const turtle = mount(fauna.makeTurtle(SEED + 71), modelMat, T.life.start + 0.8);
  group.add(turtle);
  actors.push({
    obj: turtle,
    tick: (t, lk) => {
      if (lk.shoal < 0.004) return;
      const u = clamp((t - T.life.start) / 16, 0, 1);
      place(turtle, turtleWay, u, Math.sin(t * 0.9) * 0.05);
    },
  });

  // The golden koi up the veil: pool to sill in one climb, and it is gone when the dragon starts.
  const leapWay = curve([
    [-30.4, -0.4, -30.6],
    [-31.2, 7, -33.4],
    [-31.9, 16, -37],
    [-32.3, 26, -41.6],
    [-32.4, 34.2, -45.2],
  ]);
  const leaper = mount(fauna.makeKoi(SEED + 81, 3), modelMat, T.leap.start - 0.3);
  leaper.scale.setScalar(1.3);
  group.add(leaper);
  actors.push({
    obj: leaper,
    tick: (_t, lk) => {
      const on = lk.leap > 0.001 && lk.leap < 0.999;
      leaper.visible = on;
      if (!on) return;
      const u = lk.leap * lk.leap * (3 - 2 * lk.leap);
      place(leaper, leapWay, u, Math.sin(lk.leap * Math.PI * 3) * 0.5);
    },
  });

  // The dragon: a helix off the pool, one turn and a third around the temple, ending above the
  // finial. Segments trail the head by a fixed arc length, so the body keeps its spacing.
  const dragonPts: [number, number, number][] = [];
  const dragonTurns = 1.34;
  for (let i = 0; i <= 150; i++) {
    const s = i / 150;
    const a = -2.41 + s * Math.PI * 2 * dragonTurns;
    const r = 15.5 - 8.4 * s;
    const y = 0.6 + (PAGODA.topY + 8.5 - 0.6) * (s * s * (3 - 2 * s));
    dragonPts.push([PAGODA.x + Math.sin(a) * r, y, PAGODA.z + Math.cos(a) * r]);
  }
  const dragonWay = curve(dragonPts);
  const dragonLen = dragonWay.getLength();
  const segStep = 2.3 / dragonLen;
  const head = mount(fauna.makeDragonHead(SEED + 91), modelMat, T.dragon.start);
  const segGeo = mount(fauna.makeDragonSegment(SEED + 92), modelMat, T.dragon.start);
  const tail = mount(fauna.makeDragonTail(SEED + 93), modelMat, T.dragon.start);
  group.add(head);
  const SEGS = 18;
  const segs: THREE.Mesh[] = [];
  for (let i = 0; i < SEGS; i++) {
    const m = segGeo.clone();
    group.add(m);
    segs.push(m);
  }
  group.add(tail);
  actors.push({
    obj: head,
    tick: (_t, lk) => {
      const u = lk.dragon;
      place(head, dragonWay, u, -0.22 * Math.sin(u * Math.PI * dragonTurns * 2));
      for (let i = 0; i < SEGS; i++) {
        const ui = u - (i + 1) * segStep;
        segs[i].visible = ui > 0;
        if (ui > 0) place(segs[i], dragonWay, ui, -0.22 * Math.sin(ui * Math.PI * dragonTurns * 2));
      }
      const ut = u - (SEGS + 1) * segStep;
      tail.visible = ut > 0;
      if (ut > 0) place(tail, dragonWay, ut, -0.22 * Math.sin(ut * Math.PI * dragonTurns * 2));
    },
  });

  // Two cranes over the water at first light.
  const craneWay = curve([
    [-34, 27, -18],
    [-22, 23, -6],
    [-13, 19, 8],
    [-3, 17, 20],
    [9, 16, 31],
  ]);
  const craneSpan = T.dawn.start + 2.2 - (T.dragon.start + 1.2);
  const cranes: [THREE.Mesh, number, number][] = [];
  for (let i = 0; i < 2; i++) {
    const mesh = mount(fauna.makeCrane(SEED + 101 + i * 13), modelMat, T.dragon.start + 0.6);
    group.add(mesh);
    cranes.push([mesh, i === 0 ? 0 : -0.055, i === 0 ? 0 : -3.6]);
  }
  actors.push({
    obj: cranes[0][0],
    tick: (t) => {
      const u = clamp((t - (T.dragon.start + 1.2)) / craneSpan, 0, 1);
      for (const [mesh, off, lateral] of cranes) {
        const uu = clamp(u + off, 0, 1);
        place(mesh, craneWay, uu, -0.3 * Math.sin(uu * Math.PI * 2) + (lateral ? 0.12 : 0));
        if (lateral !== 0) mesh.translateX(lateral);
      }
    },
  });

  // The mill wheel in the channel below the arrival terrace, and two canopied boats.
  const wheel = mount(props.makeWaterwheel(SEED + 111), modelMat, T.village.start + 0.2);
  wheel.position.set(-23.6, 2.6, -7.2);
  group.add(wheel);
  actors.push({
    obj: wheel,
    tick: (t) => {
      wheel.rotation.x = -t * 0.55;
    },
  });

  const sailWay = curve(
    [
      [-6, 0, 20],
      [4, 0, 25],
      [14, 0, 22],
      [12, 0, 15],
      [1, 0, 16],
    ],
    true,
  );
  const sailer = mount(props.makeBoatModel(SEED + 121), modelMat, T.village.start + 0.6);
  group.add(sailer);
  actors.push({
    obj: sailer,
    tick: (t) => {
      const u = ((t - T.village.start) / 46 + 0.2) % 1;
      place(sailer, sailWay, u, Math.sin(u * Math.PI * 10) * 0.05);
      sailer.position.y = 0.1 + Math.sin(t * 1.1) * 0.07;
    },
  });

  const moored = mount(props.makeBoatModel(SEED + 122), modelMat, T.village.start + 0.9);
  group.add(moored);
  actors.push({
    obj: moored,
    tick: (t) => {
      moored.position.set(-15.4, 0.1, -9.2);
      moored.rotation.set(0, 1.15 + Math.sin(t * 0.5) * 0.06, Math.sin(t * 0.8) * 0.035);
    },
  });

  // TEMP DEBUG: name the children and hand the group to the console for layer isolation.
  group.children.forEach((c, i) => (c.name = `${i}:${c.type}`));
  window.__group = group;
  (window as unknown as { __overflow?: unknown }).__overflow = layers.map((l) => [l.world.dropped, l.world.dropSample.slice(0, 12)]);
  (window as unknown as { __lattice?: unknown }).__lattice = ['FAR', 'MID', 'FINE', 'WATER', 'SHEET'];
  (window as unknown as { __worlds?: unknown }).__worlds = layers.map((l) => l.world);
  // ------------------------------------------------------------------ state
  const state: VoxelState = {
    time: 0,
    ink: 0,
    colorFront: 0,
    colorOrigin: new THREE.Vector3(PAGODA.x, 0, PAGODA.z),
    dissolve: 0,
    vortex: new THREE.Vector3(0, 150, 0),
    swirl: 0,
    sway: 0,
    water: 0,
    glowGain: 0,
    exposure: 1,
    roomDim: 1,
    lampA: new THREE.Vector4(PAGODA.x, 30, PAGODA.z, 6),
    gainA: 0,
    lampB: new THREE.Vector4(POOL.x, 7, POOL.z, 46),
    gainB: 0,
    sunDir: new THREE.Vector3(1, 0.2, 0.4),
    sunColor: new THREE.Color(C.sun),
    sunGain: 0,
    rippleAt: new THREE.Vector2(FALLS.x, FALLS.lipZ),
    rippleR: 0,
    rippleGain: 0,
    foamAt: new THREE.Vector3(POOL.x, 13, POOL.z),
    foamGain: 0,
    fogColor: new THREE.Color(C.night),
    fogNear: 40,
    fogFar: 120,
  };

  const faces = layers.reduce((n, l) => n + (l.mesh.geometry.index ? l.mesh.geometry.index.count / 3 : 0), 0);
  const overflow = layers.reduce((n, l) => n + l.world.dropped, 0);
  const stats = {
    inner: countCells(fine.world),
    outer: countCells(mid.world),
    plants: mid.report.trees + mid.report.wetland,
    movers: actors.length,
    faces,
    overflow,
  };

  return {
    group,
    stats,
    setPixel(ratio: number): void {
      for (const [sprites] of halos) sprites.setPixel(ratio);
    },
    update(t: number, lk: Look): void {
      state.time = t;
      state.ink = lk.ink;
      state.colorFront = lk.colorFront * 190;
      state.dissolve = lk.dissolve;
      state.swirl = lk.swirl;
      state.sway = lk.sway;
      state.water = lk.water;
      state.glowGain = lk.glowGain;
      state.exposure = lk.exposure;
      // The warm lamp's reach *is* the lantern wave climbing out of the temple.
      state.lampA.set(PAGODA.x, 30, PAGODA.z, Math.max(6, lk.lanternWave));
      state.gainA = lk.glowGain;
      state.lampB.set(POOL.x, 7, POOL.z, 46);
      state.gainB = lk.foam * 0.55;
      state.sunDir.set(lk.sun[0], lk.sun[1], lk.sun[2]);
      state.sunColor.setHex(lk.sunHex, THREE.LinearSRGBColorSpace);
      state.sunGain = lk.sunGain;
      state.rippleAt.set(lk.rippleAt[0], lk.rippleAt[1]);
      state.rippleR = lk.rippleR;
      state.rippleGain = lk.rippleGain;
      state.foamAt.set(POOL.x, 12.5 + 3.5 * lk.foam, POOL.z);
      state.foamGain = lk.foam;
      state.fogColor.setHex(lk.fogHex, THREE.LinearSRGBColorSpace);
      state.fogNear = lk.fogNear;
      state.fogFar = lk.fogFar;
      pearl.update(t, lk.pearl, lk.pearlGlow);
      state.vortex.copy(pearl.mesh.position);
      mats.update(state);

      sky.material.uniforms.uTop.value.setHex(lk.sky.top, THREE.LinearSRGBColorSpace);
      sky.material.uniforms.uHorizon.value.setHex(lk.sky.horizon, THREE.LinearSRGBColorSpace);
      sky.material.uniforms.uBottom.value.setHex(lk.sky.bottom, THREE.LinearSRGBColorSpace);
      sky.material.uniforms.uHaze.value = lk.sky.haze;
      stars.material.uniforms.uStars.value = lk.sky.stars;

      const struck = smoothstep(T.strike.start, T.strike.start + T.strike.dur, t) * (1 - lk.dissolve);
      ridgeArc.update(t, struck, clamp(struck * 1.05, 0, 1), 0.5 + lk.glowGain * 0.6, 1 - lk.dissolve);
      // The climb empties as it finishes. The draw-back ends early so the wrap opens on bare sky, and
      // a ribbon still lit at 44 would be the one thing left in the cut.
      const drained = 1 - smoothstep(T.draw.start + 2.4, T.draw.start + T.draw.dur, t);
      drawArc.update(t, lk.dissolve, clamp(lk.dissolve * 1.04, 0, 1), 1, lk.dissolve * drained);

      sun.update(t, lk.sunGain, state.sunDir, 330);
      collar.update(t, lk.mist * 0.55 + lk.sky.haze * 0.25);
      bow.update(t, lk.mist * smoothstep(T.dawn.start + 0.4, T.dawn.start + 2.4, t) * (1 - lk.dissolve));

      mist.update(t, lk.mist);
      petals.update(t, lk.petals);
      lanterns.update(t, lk.skyLanterns);

      for (const [sprites, ring] of halos) {
        sprites.update(t, lk.glowGain * clamp((lk.lanternWave - ring) / 7 + 1, 0, 1));
      }

      for (const a of actors) a.tick(t, lk);
    },
  };
}
