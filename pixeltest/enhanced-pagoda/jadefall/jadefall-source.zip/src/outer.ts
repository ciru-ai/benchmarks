import { VoxelWorld } from './core/VoxelWorld';
import { C, clamp, hash3, mixHex, shade, smoothstep } from './core/palette';
import { CELL, FAR } from './core/layout';

/**
 * The far range: the mountains the valley sits inside, authored on the coarse FAR lattice (4.8
 * units per column) so a huge horizon costs few cells. Only the range's *surface* is meshed, so
 * each column is filled from a row below any camera height rather than down to the lattice floor.
 *
 * The height field is a sum of angular bands — one per range — multiplied by a ridged noise, so
 * the crests read as chains rather than blobs. `r` is measured from the world origin: inside `r
 * = 62` nothing is written, because the MID lattice owns the valley. `groundY` hands the country's
 * height back before that lattice's own edge, and the near belt below stands above what is left,
 * so the two lattices overlap instead of leaving a cliff at the valley's edge.
 */

export interface OuterArgs {
  seed: number;
  /** reveal start of the nearest belt */
  t: number;
  /** seconds the whole horizon takes to stand up, near range first */
  dur: number;
}

/** One mountain range: an angular window about north, a crest radius, a crest height. */
interface Band {
  /** centre azimuth, radians; 0 = north (-z), +π/2 = east (+x) */
  a: number;
  /** half-width of the angular window */
  w: number;
  /** plan radius of the crest line */
  r: number;
  /** spread of the crest along the radius */
  spread: number;
  /** height of the crest above the lattice floor, world units */
  h: number;
}

/**
 * Nine overlapping windows ring the valley, so no azimuth in a wide beat opens onto sky at the
 * horizon. Crest radii stay outside `r = 232` where the range is tall, and `authorOuter` caps
 * whatever stands inside the shell the wide camera beats orbit in.
 */
const BANDS: Band[] = [
  // the wall behind the sill the river pours over, due north, tallest of all
  { a: -0.18, w: 1.05, r: 232, spread: 84, h: 92 },
  // north-east shoulder, closing the head of the valley
  { a: 0.62, w: 0.85, r: 256, spread: 86, h: 80 },
  // the eastern range behind the high road and the paddies
  { a: 1.5, w: 0.8, r: 290, spread: 90, h: 66 },
  // south-east, folding the marsh in
  { a: 2.32, w: 0.8, r: 266, spread: 88, h: 74 },
  // south: the low range the marsh drains toward
  { a: Math.PI, w: 0.9, r: 312, spread: 94, h: 58 },
  // south-west, behind the camera's wide beat
  { a: -2.32, w: 0.85, r: 274, spread: 90, h: 78 },
  // west: the wall along the arrival terrace
  { a: -1.5, w: 0.8, r: 242, spread: 84, h: 86 },
  // north-west spur, joining the west wall to the falls
  { a: -0.85, w: 0.7, r: 262, spread: 80, h: 82 },
  // a far second wave straight north, seen over the sill
  { a: 0.12, w: 0.6, r: 306, spread: 84, h: 70 },
];

/** Bilinear value noise on the integer lattice, smoothed so no cell-sized steps survive. */
function vnoise(x: number, z: number, seed: number): number {
  const ix = Math.floor(x);
  const iz = Math.floor(z);
  const fx = x - ix;
  const fz = z - iz;
  const u = fx * fx * (3 - 2 * fx);
  const v = fz * fz * (3 - 2 * fz);
  const a = hash3(ix, 0, iz, seed);
  const b = hash3(ix + 1, 0, iz, seed);
  const c = hash3(ix, 0, iz + 1, seed);
  const d = hash3(ix + 1, 0, iz + 1, seed);
  return (a + (b - a) * u) * (1 - v) + (c + (d - c) * u) * v;
}

/** Three octaves, and the ridged form (1 − |2n−1|) that gives sharp crests. */
function ridge(x: number, z: number, seed: number): number {
  let sum = 0;
  let amp = 0.55;
  let f = 1;
  let norm = 0;
  for (let o = 0; o < 3; o++) {
    sum += amp * (1 - Math.abs(2 * vnoise(x * f, z * f, seed + o * 31) - 1));
    norm += amp;
    amp *= 0.5;
    f *= 2.1;
  }
  return sum / norm;
}

const floorRow = Math.round((-24 - FAR.origin[1]) / CELL.far);

/** The range's crest height at a plan point, world units above the lattice floor. */
function crestHeight(x: number, z: number, r: number, seed: number): number {
  const ang = Math.atan2(x, -z);
  let h = 0;
  for (const b of BANDS) {
    let d = ang - b.a;
    while (d > Math.PI) d -= Math.PI * 2;
    while (d < -Math.PI) d += Math.PI * 2;
    const along = 1 - smoothstep(b.w * 0.55, b.w, Math.abs(d));
    const across = Math.exp(-(((r - b.r) / b.spread) ** 2));
    h = Math.max(h, b.h * along * across);
  }
  // n is the ridged relief, 0 in the saddles and 1 on the sharpest crest
  const n = ridge(x / 74, z / 74, seed) * 0.72 + ridge(x / 26, z / 26, seed + 17) * 0.28;
  // Between the ranges the ground keeps its own foothills: a constant floor anywhere would
  // read as a plain laid under the valley, which is the one thing a horizon must never do.
  const low = 5 + 20 * Math.pow(n, 1.35);
  // No wall is kept up here for the MID lattice's benefit: `groundY` hands the country's height
  // back before that lattice's rim, so the two surfaces meet near level and the coarse FAR cells
  // only have to cover a step of a few units.
  return Math.max(h * (0.45 + 0.62 * n) + r * 0.04 - 4, low);
}

/** Rock, tree line, then pale cold caps — distance haze is left to the scene fog. */
function crestColor(y: number, n: number): number {
  if (y < 14) return mixHex(C.pineDeep, C.mossDeep, 0.25 + 0.5 * n);
  if (y < 34) return mixHex(C.pine, C.pineDeep, 0.3 + 0.55 * (1 - n));
  if (y < 58) return mixHex(C.slate, C.pineDeep, 0.25 + 0.4 * n);
  if (y < 76) return mixHex(C.stone, C.slate, 0.3 + 0.4 * n);
  return mixHex(C.mist, C.stoneLite, 0.25 + 0.5 * n);
}

/**
 * Write the horizon. Footprint: the whole FAR lattice outside `r = 62`. Inside the shell the tour
 * orbits in (`r = 96` → `214`) every height is scaled to between a third and its full value, so
 * no pose can pass through a crest and the near country stays low enough to look *into* the
 * valley rather than over a wall.
 */
export function authorOuter(world: VoxelWorld, a: OuterArgs): void {
  const cell = CELL.far;
  for (let c = 0; c < FAR.sx; c++) {
    const x = FAR.origin[0] + (c + 0.5) * cell;
    for (let l = 0; l < FAR.sz; l++) {
      const z = FAR.origin[2] + (l + 0.5) * cell;
      const r = Math.hypot(x, z);
      if (r < 62) continue;

      // Everything inside the orbit shell is scaled down rather than sliced off: a hard cap
      // leaves flat-topped blocks in exactly the frames where the horizon matters most.
      const shell = 0.34 + 0.66 * smoothstep(96, 214, r);
      const h = crestHeight(x, z, r, a.seed) * shell;
      const top = Math.floor((h - FAR.origin[1]) / cell);
      if (top < floorRow) continue;

      // the near belt stands up first, the far range last
      const f = clamp((r - 62) / 300, 0, 1);
      const t0 = a.t + f * a.dur * 0.8;
      const n = ridge(x / 74, z / 74, a.seed);
      for (let y = floorRow; y <= top; y++) {
        const wy = FAR.origin[1] + (y + 1) * cell;
        const grain = 0.86 + 0.22 * hash3(c, y, l, a.seed + 5);
        world.set(
          c,
          y,
          l,
          shade(crestColor(wy, n), grain),
          { t: t0 + (top - y) * 0.012, dur: 0.5 },
        );
      }
    }
  }
}
