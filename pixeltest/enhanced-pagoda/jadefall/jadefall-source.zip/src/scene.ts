/**
 * JADEFALL composer. One pass per lattice, in reveal order: the valley is carved, then the
 * precinct, then everything that stands on the land, then the water. Nothing here touches the
 * scene graph — `scene.ts` only writes cells and hands back the sites the animated actors need.
 */

import { VoxelWorld } from './core/VoxelWorld';
import { clamp, hash3, lerp, rng, smoothstep } from './core/palette';
import { ANCHOR, CELL, COURT, FALLS, LAKE_ROW, MID, POOL, RIDGE, midCol, midLane, midRow } from './core/layout';
import * as props from './builds/props';
import { makeSchedule, type Schedule } from './core/schedule';
import { type BuilderArgs } from './builds/types';
import { authorGorge, authorValley, groundY, islet, lakeQ } from './builds/terrain';
import * as flora from './builds/flora';

/** Master seed for every deterministic stream in the piece. */
export const SEED = 20261110;

/** Report the composer hands to the stage: how much was placed, and where the actors live. */
export interface MidReport {
  trees: number;
  wetland: number;
  props: number;
}

/** BuilderArgs for an object standing on the land at plan (x, z). */
function standing(
  x: number,
  z: number,
  t: number,
  dt: number,
  seed: number,
  opts?: Record<string, number>,
): BuilderArgs {
  const c = midCol(x);
  const l = midLane(z);
  const row = Math.ceil((groundY(x, z) - MID.origin[1]) / CELL.mid);
  return { x: c, z: l, y: Math.max(0, row), t, dt, seed, opts };
}

/** BuilderArgs for an object standing on an explicit deck height instead of the land. */
function onDeck(
  x: number,
  z: number,
  deckY: number,
  t: number,
  dt: number,
  seed: number,
  opts?: Record<string, number>,
): BuilderArgs {
  return { x: midCol(x), z: midLane(z), y: Math.max(0, midRow(deckY)), t, dt, seed, opts };
}

// ------------------------------------------------------------------ habitat

/**
 * What wants to grow at a plan point: the wet margin, the shade of the ridge, the dry knolls.
 * Returns a species key, or `null` where the ground is bare rock, water or worked land.
 */
function habitat(x: number, z: number, h: number): string | null {
  const q = lakeQ(x, z);
  if (h > 26) return null; // the crest of the Dragon Ridge stays bare rock
  // Nothing dry roots below the lake surface: the water itself belongs to the wetland pass,
  // which authors lotus, reeds and iris on their own rows.
  if (h < 0.35) return null;
  const onRidge = z < RIDGE.z1 + 6 && h > 14;
  const dryKnoll = h > 9 && z > RIDGE.z1 + 6;

  if (q > 0.86 && h < 1.9) return 'shore';
  if (onRidge) return 'crag';
  if (dryKnoll) return 'knoll';
  if (x < -18 && z > 12) return 'grove';
  return 'mixed';
}

/** Species weights per habitat, resolved with a per-site hash. */
const SPECIES: Record<string, readonly [string, number][]> = {
  shore: [
    ['willow', 3],
    ['reed', 5],
    ['iris', 2],
  ],
  crag: [
    ['pine', 6],
    ['rock', 3],
    ['fern', 2],
  ],
  knoll: [
    ['pine', 3],
    ['maple', 3],
    ['ginkgo', 2],
    ['cherry', 1],
    ['fern', 1],
  ],
  grove: [
    ['maple', 4],
    ['cherry', 3],
    ['bamboo', 3],
    ['ginkgo', 2],
    ['willow', 1],
    ['azalea', 2],
  ],
  mixed: [
    ['maple', 3],
    ['cherry', 2],
    ['pine', 2],
    ['ginkgo', 2],
    ['bamboo', 2],
    ['azalea', 2],
    ['fern', 1],
  ],
};

function pick(table: readonly [string, number][], r: number): string {
  let total = 0;
  for (const [, w] of table) total += w;
  let k = clamp(r, 0, 0.999999) * total;
  for (const [name, w] of table) {
    if (k < w) return name;
    k -= w;
  }
  return table[0][0];
}

/**
 * One habitat scale translated into the knobs a given species actually reads. Every flora builder
 * takes its own height and count knobs with its own clamps, so the composer converts once here
 * instead of handing every one of them a meaningless size number.
 */
function knobsFor(species: string, k: number): Record<string, number> {
  switch (species) {
    case 'pine':
      return { h: Math.round(lerp(16, 31, k)), whorls: 4 + Math.round(k * 2) };
    case 'maple':
      return { h: Math.round(lerp(14, 32, k)), hot: k };
    case 'cherry':
      return { h: Math.round(lerp(15, 27, k)) };
    case 'ginkgo':
      return { h: Math.round(lerp(13, 29, k)), clouds: 5 + Math.round(k * 5) };
    case 'bamboo':
      return { h: Math.round(lerp(18, 33, k)), count: 5 + Math.round(k * 8) };
    case 'willow':
      return { h: Math.round(lerp(18, 33, k)), strands: 14 + Math.round(k * 16) };
    case 'reed':
      return { count: 8 + Math.round(k * 14) };
    case 'iris':
      return { crowns: 3 + Math.round(k * 4), blooms: 2 + Math.round(k * 5) };
    case 'azalea':
      return { r: lerp(2.2, 4.4, k), flecks: Math.round(k * 12) };
    case 'fern':
      return { crowns: 2 + Math.round(k * 5), len: 4 + Math.round(k * 4) };
    case 'rock':
      return { r: 2 + Math.round(k * 3), fern: k > 0.55 ? 1 : 0 };
    default:
      return { r: lerp(2.4, 8, k) };
  }
}

/**
 * The groves: a jittered lattice over the whole valley, each site asked what it wants to grow.
 * Density falls off with the habitat so the forest has clearings instead of a hedge.
 */
function plantGrove(mid: VoxelWorld, sched: Schedule): number {
  const rand = rng(SEED + 7);
  let planted = 0;
  const step = 2.4;
  // Nine units of inset: the jitter is ±1.8 and the widest crown — the ginkgo and the cherry — is
  // ±2.6, so a tree planted closer to the rim than this has its crown sawn off by the lattice wall.
  const inset = 9;
  for (let x = MID.origin[0] + inset; x < -MID.origin[0] - inset; x += step) {
    for (let z = MID.origin[0] + inset; z < -MID.origin[0] - inset; z += step) {
      const px = x + (rand() - 0.5) * step * 1.5;
      const pz = z + (rand() - 0.5) * step * 1.5;
      const h = groundY(px, pz);
      const hab = habitat(px, pz, h);
      if (!hab) continue;

      // Settled ground stays clear of forest: the west arrival terrace, the corridor the great
      // stair runs down the north-west slope, and the worked east plateau. The settlement then
      // reads as a clearing cut out of the wood instead of furniture dropped on top of it.
      if (Math.hypot(px - COURT.x, pz - COURT.z) < 16 && h > 6) continue;
      if (px < -22 && Math.abs(pz - 3) < 12 && h > 6) continue;
      if (pz < -4 && pz > -12 && px < -34 && h > 1) continue;
      if (px > 30.5 && h > 14.5) continue;

      // Beyond the valley's own shore is what the wide beats are made of: a thin wood out there
      // turns the whole frame into an empty quarry bowl, so the outer ring is planted thicker.
      const outer = 1 + 0.45 * smoothstep(32, 50, Math.hypot(px, pz));
      const density = clamp((hab === 'shore' ? 0.52 : hab === 'crag' ? 0.46 : hab === 'grove' ? 0.68 : 0.56) * outer, 0, 1);
      if (rand() > density) continue;
      if (rand() < 0.12) continue; // clearings

      const species = pick(SPECIES[hab], hash3(Math.round(px * 3), 1, Math.round(pz * 3), SEED + 11));
      const vig = hash3(Math.round(px), 3, Math.round(pz), SEED + 13);
      // Full height belongs to the outer wood. Within reach of the precinct the trees stay low,
      // so the sea wall, the causeway and the pagoda read through the grove instead of under it.
      const rim = clamp((Math.hypot(px - COURT.x, pz - COURT.z) - 24) / 30, 0, 1);
      const k = clamp(vig * (0.3 + 0.7 * rim), 0, 1);
      const key = clamp((px + 67) / 134 + (pz + 67) / 134 - 1 + hash3(1, 1, Math.round(px + pz), 5) * 0.12, 0, 1);
      const t = sched.step('gardens', key);
      const a = standing(px, pz, t, 0.45, SEED + planted * 3);
      a.opts = knobsFor(species, k);

      switch (species) {
        case 'pine':
          flora.pineTree(mid, a);
          break;
        case 'maple':
          flora.mapleTree(mid, a);
          break;
        case 'cherry':
          flora.cherryTree(mid, a);
          break;
        case 'ginkgo':
          flora.ginkgoTree(mid, a);
          break;
        case 'bamboo':
          flora.bambooGrove(mid, a);
          break;
        case 'willow':
          flora.willow(mid, a);
          break;
        case 'reed':
          flora.reedClump(mid, a);
          break;
        case 'iris':
          flora.irisPatch(mid, a);
          break;
        case 'azalea':
          flora.azaleaBush(mid, a);
          break;
        case 'fern':
          flora.fernPatch(mid, a);
          break;
        case 'rock':
          flora.mossBoulder(mid, a);
          break;
        default:
          flora.mossPatch(mid, a);
          break;
      }
      planted++;
    }
  }
  return planted;
}

/**
 * The wet margin: lotus beds in the two sheltered coves, reeds all the way round the marsh, and
 * boulders dressed in moss where the gorge meets the pool.
 */
function plantWetland(mid: VoxelWorld, sched: Schedule): number {
  let n = 0;
  const rand = rng(SEED + 29);

  // lotus and iris in the calm water east and south of the island
  const beds: readonly [number, number, number][] = [
    [16, 14, 7.5],
    [6, 30, 5.5],
    [-8, 26, 6.5],
    [-19, 17, 5.0],
    [ANCHOR.lotus.x, ANCHOR.lotus.z, 6.0],
  ];
  for (let i = 0; i < beds.length; i++) {
    const [bx, bz, br] = beds[i];
    const t = sched.step('gardens', 0.5 + i * 0.08);
    flora.lotusBed(
      mid,
      onDeck(bx, bz, -0.6, t, 0.5, SEED + 400 + i, {
        r: clamp(br / CELL.mid, 4, 10),
        pads: Math.round(br * 2.2),
        flowers: 3 + (i % 2),
        seeds: 2,
      }),
    );
    n++;
    // iris only lands where the water is shallow enough for a marsh plant to stand in it
    const ix = bx + br * 0.9;
    const iz = bz + br * 0.6;
    const ih = groundY(ix, iz);
    if (ih > -1.3 && ih < 1.6) {
      flora.irisPatch(mid, standing(ix, iz, t + 0.2, 0.4, SEED + 460 + i));
    }
  }

  // reeds ringing the marsh and the mouth of the arm
  for (let i = 0; i < 46; i++) {
    const ang = (i / 46) * Math.PI * 2;
    const rx = ANCHOR.marsh.x + Math.cos(ang) * (7 + rand() * 8);
    const rz = ANCHOR.marsh.z + Math.sin(ang) * (6 + rand() * 7);
    if (lakeQ(rx, rz) > 1.12) continue;
    const rh = groundY(rx, rz);
    if (rh < -1.1 || rh > 2.4) continue; // reeds root in the margin, not in deep water
    flora.reedClump(
      mid,
      standing(rx, rz, sched.step('gardens', clamp((rx + 40) / 70, 0, 1)), 0.4, SEED + 520 + i),
    );
    n++;
  }

  // mossy boulders where the spray lands, and along the gorge walls
  for (let i = 0; i < 26; i++) {
    const u = i / 25;
    const bx = lerp(FALLS.x, POOL.x, u) + (rand() - 0.5) * 12;
    const bz = lerp(FALLS.lipZ + 3, POOL.z + 4, u) + (rand() - 0.5) * 7;
    if (groundY(bx, bz) < -1) continue;
    flora.mossBoulder(
      mid,
      standing(bx, bz, sched.step('falls', 0.4 + 0.5 * u), 0.4, SEED + 600 + i),
    );
    n++;
  }
  return n;
}

/** BuilderArgs for a thing that floats on the lake surface. */
function floating(
  x: number,
  z: number,
  t: number,
  dt: number,
  seed: number,
  opts?: Record<string, number>,
): BuilderArgs {
  return { x: midCol(x), z: midLane(z), y: LAKE_ROW, t, dt, seed, opts };
}

/**
 * The human works. Three settled places, each on ground the heightfield actually holds level:

 *  - the west arrival terrace at 8.6 (road, market, pavilion, lamps, the dock on the channel);
 *  - the north-west slope, where the ground falls for 30 units and the great stair can run with it;
 *  - the worked east plateau at 15.8 (gate across the high road, paddies, the village below it).
 *
 * Every static builder here is a MID object placed by `standing`, so its footing is the authored
 * surface; the dock and the boat are the two exceptions, seated on explicit rows over the water.
 */
function placeHumanWorks(mid: VoxelWorld, sched: Schedule): number {
  let placed = 0;

  // ---- west arrival terrace
  props.rockPath(
    mid,
    standing(-52, 0, sched.step('terraces', 0.05), 0.8, SEED + 900, { len: 44, wid: 5 }),
  );
  props.terraceWall(
    mid,
    standing(-52, 9.6, sched.step('terraces', 0.3), 0.7, SEED + 901, { len: 34, h: 4 }),
  );
  props.lanternLine(
    mid,
    standing(-51, -3.6, sched.step('village', 0.15), 0.6, SEED + 902, { count: 6, pitch: 5 }),
  );
  props.marketStall(
    mid,
    standing(-53, 5.4, sched.step('village', 0.3), 0.5, SEED + 903),
  );
  props.marketStall(
    mid,
    standing(-43.5, 5.4, sched.step('village', 0.36), 0.5, SEED + 904),
  );
  props.pavilion(
    mid,
    standing(-31, 8.4, sched.step('village', 0.45), 0.9, SEED + 905, { half: 6, h: 16, cols: 4 }),
  );
  props.stoneLantern(
    mid,
    standing(-28.5, 3.6, sched.step('village', 0.5), 0.4, SEED + 906, { h: 9 }),
  );
  props.stoneLantern(
    mid,
    standing(-28.5, -3.6, sched.step('village', 0.5), 0.4, SEED + 907, { h: 9 }),
  );
  props.signPost(
    mid,
    standing(-34, 1.8, sched.step('village', 0.52), 0.4, SEED + 908, { h: 7 }),
  );
  placed += 9;

  // ---- the great stair, running with the north-west slope down to the arm of the lake
  props.stairRun(
    mid,
    standing(-58, -8, sched.step('terraces', 0.45), 1.1, SEED + 910, { len: 34, width: 9, drop: 11 }),
  );
  placed++;

  // ---- the dock and a moored boat in the channel between the terrace and the island
  props.dock(
    mid,
    onDeck(-24, -8, -1.8, sched.step('village', 0.6), 0.7, SEED + 912, { len: 18, wid: 5 }),
  );
  props.boatStatic(
    mid,
    floating(-18.5, -10.4, sched.step('village', 0.75), 0.5, SEED + 913, { len: 12 }),
  );
  placed += 2;

  // ---- the worked east plateau
  props.rockPath(
    mid,
    standing(31, 0, sched.step('terraces', 0.15), 0.8, SEED + 915, { len: 34, wid: 5 }),
  );
  props.mountainGate(
    mid,
    standing(36, 0, sched.step('village', 0.55), 1.0, SEED + 916, { dir: 1, span: 10, h: 22 }),
  );
  props.bannerPole(
    mid,
    standing(44, 3.6, sched.step('village', 0.66), 0.5, SEED + 917, { h: 12 }),
  );
  props.bannerPole(
    mid,
    standing(44, -3.6, sched.step('village', 0.66), 0.5, SEED + 918, { h: 12 }),
  );
  props.fenceRun(
    mid,
    standing(30.5, 5.4, sched.step('terraces', 0.55), 0.5, SEED + 919, { len: 28, h: 3 }),
  );
  props.paddyRidge(
    mid,
    standing(42, 10, sched.step('terraces', 0.62), 0.9, SEED + 920, { wid: 28, dep: 16 }),
  );
  props.paddyRidge(
    mid,
    standing(42, 24, sched.step('terraces', 0.68), 0.9, SEED + 921, { wid: 28, dep: 16 }),
  );
  props.house(
    mid,
    standing(40, -12, sched.step('village', 0.7), 0.6, SEED + 922, { thatch: 1 }),
  );
  props.house(
    mid,
    standing(50, -12, sched.step('village', 0.74), 0.6, SEED + 923, { thatch: 0 }),
  );
  props.house(
    mid,
    standing(45, -22, sched.step('village', 0.78), 0.6, SEED + 924, { thatch: 1 }),
  );
  props.granary(
    mid,
    standing(57, -24, sched.step('village', 0.84), 0.7, SEED + 925),
  );
  placed += 11;

  return placed;
}

// ------------------------------------------------------------------ entry points

/**
 * The valley lattice: landform, gorge, islets, groves, wetland, terraces. Returns what was placed
 * so the stage knows how many actors to route.
 */
export function buildMid(): { world: VoxelWorld; report: MidReport } {
  const world = new VoxelWorld(MID.sx, MID.sy, MID.sz);
  const sched = makeSchedule();

  authorValley(world, { seed: SEED, t: sched.step('basin', 0), dur: 1.9 });
  authorGorge(world, { seed: SEED + 3, t: sched.step('falls', 0.1), dur: 1.3 });

  // the two isles: one carries the tea pavilion, the other a single pine
  islet(world, -20.4, 22.8, 5.4, 2.4, { t: sched.step('basin', 0.55), dur: 0.6, seed: SEED + 31 });
  islet(world, 13.2, -16.8, 4.2, 1.8, { t: sched.step('basin', 0.62), dur: 0.6, seed: SEED + 37 });

  const trees = plantGrove(world, sched);
  const wetland = plantWetland(world, sched);
  const propsPlaced = placeHumanWorks(world, sched);

  return { world, report: { trees, wetland, props: propsPlaced } };
}
