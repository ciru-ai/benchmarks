# JADEFALL 翠瀑 — builder contract (read before writing a builder)

Project root: `/home/crown/Documents/ChatGPT/padoga game` — a voxel padoga film, third in the line
after `padogas/inkfall-20261106` and `padogas/giltthrone-20261107`. A builder is a grid writer and
nothing else.

The piece: dawn breaks over a valley. A jade pearl strikes the Dragon Gate at the rim of the
Dragon Ridge, the lake fills, a great veil pours into a plunge pool, and on an island in the middle
of that lake a walled precinct is raised: a three-tier marble podium and a **nine-tier padoga**,
with a red moon bridge off its west wall to the shore. The koi wake, one of them takes the falls
and turns into a dragon that coils up the padoga and carries fire to every lantern.

## Hard rules

1. A builder is a **pure grid writer**: `export function name(world: VoxelWorld, a: BuilderArgs): void`.
   It never creates geometry, never touches the scene graph, never reads the clock or `Math.random`.
2. All randomness comes from `dice(a)` (per-object stream) or `hash3(x, y, z, seed)`.
3. Reveal order is always **support first, ornament last**: pass `f` (0..1) through `reveal(a, f)`
   as `t`, and `dur: FADE` — both from `../builds/types` (i.e. `./types` inside `src/builds`).
4. Emissive cells use `{ kind: Kind.Glow, glow: 0.4..1 }`. Every Glow cell costs a glow sprite
   downstream — stay inside the glow budget named in your task.
5. `Kind.Foliage` is for anything that should breathe in the wind (canopy, blossom, bamboo, reeds).
   `Kind.Water` / `Kind.Flow` belong to the water lattices only — do not use them in your worlds.
6. Never write below `a.y` (the surface the object stands on). Out-of-bounds writes are dropped
   silently, but keep footprints inside the size you document.
7. TypeScript is `strict` + `noUnusedLocals` + `noUnusedParameters`. No `any`, no unused imports.
8. Baked lighting is fixed at author time: **upper faces read bright, undersides read dark**.
   Anything that must read inside a soffit or under an eave is authored near-white
   (`C.goldPale`, `C.marbleLite`, `C.paper`).
9. Comment style: one doc comment per exported builder stating knobs, defaults, clamped ranges and
   the footprint in grid cells. Terse, no emoji.
10. Check your work with the **scoped** type check (the rest of the tree is being rewritten at the
    same time — never run `npx vite build`, never launch a browser, never run the capturer):

    ```sh
    cd "/home/crown/Documents/ChatGPT/padoga game"
    npx tsc --noEmit --strict --noUnusedLocals --noUnusedParameters --target ES2022 \
      --module ESNext --moduleResolution bundler --skipLibCheck src/builds/<your file>.ts
    ```

## API you may use

```ts
// core/VoxelWorld.ts
Kind.Solid | Kind.Foliage | Kind.Water | Kind.Glow | Kind.Flow
world.set(x, y, z, colorHex, { kind?, t?, dur?, sway?, glow? }): void   // last write wins
world.occupied(x, y, z): boolean
world.heightAt(x, z): number
world.inside(x, y, z): boolean
world.box(x0, y0, z0, x1, y1, z1, color, put)          // inclusive solid box
world.shell(x0, y0, z0, x1, y1, z1, color, put)        // six walls only
world.cylinder(cx, cz, r, y0, y1, color, put)          // vertical disc column
world.disc(cx, cz, r, y, color, put)                   // horizontal disc
world.blob(cx, cy, cz, rx, ry, rz, color, put, noise)  // ellipsoid
world.beam([ax,ay,az], [bx,by,bz], r, color, put)      // straight run, r³ cross-section

// builds/types.ts
interface BuilderArgs { x: number; z: number; y: number; t: number; dt: number; seed: number; opts?: Record<string, number> }
opt(a, name, fallback): number      // read a numeric knob
dice(a): () => number               // deterministic stream for this object
reveal(a, f): number                // a.t + clamp(f)*a.dt*0.72
FADE                                // 0.34 s per-voxel fade
swayAt(heightAboveBase, total, strength): number
noise2(x, z, seed): number

// core/palette.ts — see src/core/palette.ts for the full key list
C.* , clamp, lerp, smoothstep, mixHex(a, b, t), shade(hex, k), hash3(x, y, z, seed), rng(seed)

// core/layout.ts — world units and lattice conversions (read it, do not hard-code these)
CELL = { far: 4.8, mid: 0.6, water: 0.6, fine: 0.2, sheet: 0.3 }
wx/wy/wz(col|row)     MID lattice  → world      midCol/midRow/midLane(world) → MID cells
fx/fy/fz(col|row)     FINE lattice → world      fineCol/fineRow/fineLane(world) → FINE cells
COURT, PODIUM, PAGODA, BRIDGE, FALLS, RIDGE, LAKE, POOL, ANCHOR, LOOK
```

`BuilderArgs.x/.z/.y` are **cells of the lattice the target world uses**. `scene.ts` converts
world anchors with `fineCol()/fineRow()/fineLane()` for FINE objects and `midCol()/midRow()/midLane()`
for MID objects.

## The lattices

| lattice | cell | grid | world span | what lives there |
| --- | --- | --- | --- | --- |
| `FINE` | 0.2 | 222 × 244 × 156 | x −27.6…16.8, y 7.2…56.0, z −15.6…15.6 | island court, marble podium, the padoga, bell tower, cloister, moon bridge |
| `MID` | 0.6 | 224 × 124 × 224 | x −67.2…67.2, y −21.6…52.8, z −67.2…67.2 | valley, lake bed, ridge, terraces, groves, village, roads |
| `WATER` | 0.6 | 224 × 44 × 224 | same plan, y −21.6…4.8 | the lake sheet and the foam (owned by the composer) |
| `SHEET` | 0.3 | 96 × 180 × 96 | x −46.8…−18.0, y −1.2…52.8, z −60.6…−31.8 | the falling veil (owned by the composer) |
| `FAR` | 4.8 | 168 × 104 × 168 | ±403 plan | distant ranges (owned by the composer) |

Key world heights: lake surface `y = 0`; island deck `y = 7.2`; podium tiers `y = 8.4 / 10.8 / 13.2`;
padoga base `y = 13.2`, eaves up to `y ≈ 51`, finial tip `y ≈ 55.6`; ridge crest `y = 39`; the veil's
lip `y = 33.6`.

Because FINE is 0.2, **5 fine cells = 1 world unit**: a lacquered post is 2×2 cells (0.4 units), a
roof-tile rib is 1–2 cells, a balustrade sill 1 cell, a step riser 1 cell (0.2 units). Do not carry
over the 1-cell-equals-1-unit proportions from the earlier projects.

## Plan of the valley

```
                        -z  (north: the Dragon Ridge, crest y 39)
              ┌─────────────────────────────────────┐
              │   ridge plateau        ║ veil 21 wide ║→ plunge pool (-31,-35)
              └───────────────┬─────────┘   FALLS.x -32.4, lip z -45.6
        lake ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
              ~~~~~~~~~~~~   ┌───────────────┐   ~~~~~~~~~~~~
     ~~~~~~~~~~~~~~~~~~~~~~~ │ island court  │  ~~~~~~~~~~~~~~
   ~~~~~~~~~~~~~~~~~~~~~~~~~ │  PODIUM 3-tier│ ~~~~~~~~~~~~~~~~
  ~~~~~ lake, r 45×37 ~~~~~~ │  PADOGA 9 tier │ ~~~~~ east shore ~~~
   ~~~~~~~~~~~~~~~~~~~~~~~~~ └───────────────┘ ~~~~~~~~~~~~~~~~~~
     ~~~~~~~~~~~~~~  ≋ channel ≋   zigzag bridge (12, 18…31)
              marsh  ~~~~  lotus pond (22,-12)  ~~~~  village (30, 24)
     west shore: gate (-27, 0) ←── moon bridge ←── court west wall (-11.4, 0)
                        +z  (south: the valley mouth, sunrise)
```

## What each file owns

Only touch the file named in your task. `src/scene.ts`, `src/stage.ts`, `src/outer.ts`,
`src/builds/terrain.ts` and `src/builds/water.ts` belong to the composer (the parent session).

Reusable library that already exists — read it before writing your own version, reuse where the cell
counts already make sense, and write new functions where they do not:

- `src/builds/pagoda.ts` — `curvedRoof(world, a, spec)` (the ogee roof with lifted corners),
  `roofHeight`, `stoneSteps`, `stoneStair`, `masonry`, `balustrade`, `brackets`, `timberStorey`,
  `finial`. These are written in cells, so they work on any lattice; the sizes they were called with
  were tuned for 1-unit cells, so re-derive the cell counts for 0.2.
- `src/builds/flora.ts`, `src/builds/props.ts` — same note.

## Palette families (see `src/core/palette.ts` for every key)

- water/jade: `jade jadeLite jadeDeep jadePale water waterLite waterGlow foam mist pearl`
- roofs: `tile tileDeep tileRim` (teal glaze, gilt eave discs)
- timber: `vermilion vermilionDeep lacquer lacquerLite wood woodDark ironwood ironwoodLite bark barkLite`
- metal/gild: `gold goldLite goldPale goldHot goldDeep bronze gilt`
- stone: `marble marbleLite marbleDeep stone stoneLite slate gravel sand soil soilDark`
- foliage: `pine pineDeep moss mossLite mossDeep leaf bamboo bambooLite bambooDeep maple mapleRed
  mapleOrange mapleGold ginkgo plum plumLite plumDeep cherry cherryLite cherryDeep wisteria
  lotusPink lotusCream lotusLeaf`
- light: `lantern lanternCore ember ruby paper sun sunDeep dawn`
- koi/dragon: `koiWhite koiOrange koiRed koiBlack koiGold koiCream koiSilver dragonJade
  dragonJadeDeep dragonGold dragonBelly`

Colour is the point of this piece: a saturated jade-and-teal valley, vermilion-and-gold timber,
pink blossom and orange maple against green bamboo and pine. Do not author grey scenes.
