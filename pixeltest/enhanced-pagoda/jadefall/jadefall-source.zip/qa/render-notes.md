# JADEFALL 翠瀑 — lattice and render notes

Measured on the shipped build (`npx vite build` → `dist/index.html`, single file), Node 26,
chromium headless with ANGLE/Vulkan. Seed `SEED = 20261110`, loop `LOOP = 44.0` s, 30 fps.

## Lattices

| Lattice | Cell | Dims (cells) | Origin | What it carries | Tris | Out-of-bounds writes |
| --- | --- | --- | --- | --- | --- | --- |
| FAR | 4.8 | 168 × 104 × 168 | −403.2, −134.4, −403.2 | ranges and foothills | 154 732 | 0 |
| MID | 0.6 | 224 × 124 × 224 | −67.2, −13.2, −67.2 | landform, groves, village | 987 908 | 0 |
| FINE | 0.2 | 222 × 244 × 156 | −27.6, 7.2, −15.6 | island precinct, padoga | 458 864 | 0 |
| WATER | 0.6 | 224 × 44 × 224 | −67.2, −21.6, −67.2 | lake and pool surface | 41 360 | 0 |
| SHEET | 0.3 | 96 × 180 × 128 | −46.8, −1.2, −62.4 | the veil, side falls, foam | 112 088 | 0 |

Total 1 754 952 triangles. `VoxelWorld.dropped` reads **0 on all five lattices**, which is the
contract's stop condition — the last 49 dropped writes were ginkgo and cherry crowns clipped by the
MID rim, fixed by widening the grove inset to 9 units (`plantGrove`).

Authoring cost (FAR + MID + FINE, Node, no meshing): **327 ms**.

Placements: 739 trees, 18 wetland plantings, 23 props, 12 precinct pieces; the padoga crown sits at
world y 54.4.

## Terrain rules that the camera depends on

- The shore is the lake's ellipse (`lakeQ`) wandering ±8 % through long-wavelength noise, so water
  meets land on a coast rather than on a drawn ellipse.
- The island is a **superellipse** mesa on the court's own square. An elliptical mesa left the sea
  wall's corners hanging over water.
- The country's hills and noise are gated by `outside = smoothstep(1.0, 1.3, q)`: nothing grows out
  of the lake bed.
- `edge = 1 − 0.78 · smoothstep(52, 66, r)` carries every gain — hill ring, base ramp, east bench,
  and the Dragon Ridge plateau. The MID lattice is a square with a hard rim; whatever height is
  still standing there shows as a rectangular cliff in every wide beat, so the country hands its
  height back before the rim and the FAR's own foothills (which are deliberately scaled to a third
  inside the orbit shell) stand above what is left.
- The cuts (`armCut`, `poolCut`, `gorgeCut`) rise past any reachable height outside their corridor.
  With a constant far value they plane the whole country down to the sill of the deepest cut — that
  is what produced the flat plain the wide beats were showing.
- East of `x = 24` the ground is clamped into a bench band (`benchLo … benchHi`). The terraces,
  stalls and houses are flat-footed builders: on a slope their floors hang over the neighbour's
  ground.
- Heights are kneeled at 40 with slope 0.32 before the return, because the MID lattice ceiling is
  61.2 and a clipped column opens a hole in the ridge. Measured maximum over the lattice: 43.9.

## Loop closure

`dissolve = smoothstep(draw.start, draw.start + draw.dur, s)` reaches 1 **exactly at t = 44**, and
every tail gain (`water`, `glowGain`, `pour`, `foam`, `mist`, `petals`, `shoal`, `rippleGain`)
multiplies by `hold = 1 − dissolve` instead of subtracting a fraction. Subtracting left a blue pond
and a bright spray field on screen at the wrap — a hard pop back to the empty opening sky.

## Camera

21 beats over 44 s (`src/journey.ts`). Two poses were moved after reading rendered frames rather
than numbers:

- `t = 22` "the village wakes" — the old pose sat inside the paddy platforms and the wood; it now
  runs at `pos [8, 40, 34]`, above the crowns, looking down the bench.
- `t = 26.8` "past the causeway" — raised to `pos [-11.5, 18.5, 18.5]`, clear of the reed and
  bamboo margin, which reaches twelve units.

## Exposure checks

Gray mean and the fraction of pixels above 96 % on 1280 × 720 frames:

| t | mean | >96 % |
| --- | --- | --- |
| 0.07 | 0.298 | 0 |
| 4.3 | 0.679 | 1.75 % |
| 6.2 | 0.506 | 0.55 % |
| 20 | 0.583 | 0.28 % |
| 29 | 0.612 | ~0 |
| 33.6 | 0.605 | 0.90 % |
| 39.6 | 0.631 | 0.94 % |
| 42.4 | 0.546 | 0.02 % |
| 43.6 | 0.472 | ~0 |

The only frame above 1 % clipping is the strike, where the pearl's bloom is the subject.

## Loop continuity

`PSNR(frame 1319, frame 0)` = **45.2 dB**. A pair of consecutive frames elsewhere in the opening
measures 75.6 dB, and the residual is camera travel — the pose at t = 44.0 is the pose at t = 0.0,
and 43.967 is one thirtieth of a second before it. Both frames are night sky.

Two changes were needed to get there, both found by rendering the wrap and looking at it:

- The FAR material was authored with `dissolveMask = 0`, so the ranges stood while everything else
  spiralled away, leaving a terraced bowl and a blue pond on screen at the cut. The opening beats are
  empty sky only because nothing has been revealed yet, so the ranges now take part in the draw-back.
  The low cells of every lattice also needed a closing term in the vertex shader: their per-cell key is
  keyed on height, so the lake bed never finished its spiral (`materials.ts`).
- `LightArc`'s draw arc was driven by `alpha = dissolve`, i.e. brightest at the end. It now drains over
  the last sixth of the draw phase (`drained` in `stage.ts`).

## Reproducing

```sh
npx tsc --noEmit && npx vite build
node render/capture.mjs --url "file://$PWD/dist/index.html?capture=1" --out /tmp/frames \
  --fps 30 --duration 44 --width 1920 --height 1080
magick /tmp/frames/frame-01188.png -colorspace gray -format "%[fx:mean]\n" info:
```

Frame review drove every terrain, camera and loop change above; the numbers were only ever used to
confirm what a frame already showed.
