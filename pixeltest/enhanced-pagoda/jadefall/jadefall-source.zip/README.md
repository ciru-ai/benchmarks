# JADEFALL 翠瀑

A single-shot voxel film: dawn over a jade valley. A pearl falls out of the stars and strikes the
Dragon Gate on the ridge; the basin carved under it fills, a great veil starts to pour into a plunge
pool, and on the island in the middle of that lake a walled precinct is raised — three tiers of
marble podium and a nine-tier padoga, with a red moon bridge off the west wall. The groves come into
leaf and blossom, the village wakes on the east bench, the koi rise, one koi takes the falls and
turns: the dragon coils up the padoga and carries fire to every lantern in the valley. Then the water
is drawn back up the veil into the pearl, and the loop closes on the frame it opened with.

44 seconds, 21 camera beats, one clock. Seed `20261110`.

Third in the line after `padogas/inkfall-20261106` and `padogas/giltthrone-20261107`. The voxel
engine (five lattices, one shader, one schedule) is inherited from giltthrone; the geography, the
builders, the score of the reveal and the camera are new.

## Watch it

```sh
npm install
npm run dev        # http://localhost:5173
```

`?capture=1` hides the overlay, and `window.__seek(t)` renders any second of the loop on demand —
that is what the capturer drives. Drag orbits freely, the wheel zooms, Space pauses, ←/→ step 0.2 s
(Shift 1 s), `o` returns to the authored camera.

## Render the film

```sh
npm run build
node render/capture.mjs --url "file://$PWD/dist/index.html?capture=1" \
  --out /tmp/jadefall --fps 30 --duration 44 --width 1920 --height 1080
ffmpeg -framerate 30 -start_number 0 -i /tmp/jadefall/frame-%05d.png \
  -c:v libx264 -pix_fmt yuv420p -crf 18 -movflags +faststart jadefall.mp4
```

Frames are produced by seeking, never by waiting on wall-clock animation, so a re-run reproduces the
same frames.

## Shape of the code

| File | Owns |
| --- | --- |
| `src/core/layout.ts` | the five lattices, their cells and origins, world↔cell helpers |
| `src/core/schedule.ts` | one clock: every phase as `{start, dur}`, `LOOP = 44` |
| `src/core/VoxelWorld.ts` | the grid, the fill/reveal record, the face-culled mesher |
| `src/core/materials.ts` | one shader for every authored world, plus the ink→colour grade |
| `src/director.ts` | the `Look` every frame is graded from: sky, sun, fog, water, dissolve |
| `src/journey.ts` | the 21 camera beats |
| `src/outer.ts` | the FAR ranges |
| `src/builds/terrain.ts` | `groundY`, the valley, the gorge, the ridge |
| `src/builds/water.ts` | the lake surface and the falling sheet |
| `src/builds/flora.ts` | trees, bamboo, reeds, lotus, moss, rock |
| `src/builds/props.ts` | the village: stalls, houses, granary, gate, paddies, dock, boats |
| `src/builds/monument.ts` | the podium, the court wall, the padoga, cloister, moon bridge |
| `src/builds/fauna.ts` | movable models: koi, fry, turtle, dragon segments, crane |
| `src/scene.ts` | the MID composer: landform, groves, wetland, human works |
| `src/precinct.ts` | the FINE composer: the island precinct |
| `src/stage.ts` | the scene graph: meshes, sky, sun, actors, particles, camera |

Builders stay pure grid writers — see `qa/builder-contract.md`. Lattice budgets, the seam rules the
terrain obeys, and the exposure measurements are in `qa/render-notes.md`.

## Deliverables

`jadefall.mp4` — 1920 × 1080, 30 fps, 1320 frames, 44.000 s, 90 MB (x264 crf 22, yuv420p, faststart).
`jadefall-poster.jpg` — 1920 × 1080, the frame at t = 39.6 s, "every roof alight".
