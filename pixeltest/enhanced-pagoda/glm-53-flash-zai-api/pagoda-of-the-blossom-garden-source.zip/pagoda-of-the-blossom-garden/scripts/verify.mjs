#!/usr/bin/env node
/**
 * Browser verification harness.
 *
 * Loads the running dev page in Chromium (software GL by default), waits for
 * window.__voxel.ready, optionally drives the day cycle / camera preset, then
 * writes a PNG to shots/ and prints the scene stats + any console errors.
 *
 *   node scripts/verify.mjs --tag 01-terrain --phase 1 --time 0.42
 */
import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';

const argv = process.argv.slice(2);
function flag(name, def = undefined) {
  // support both `--name value` and `--name=value`
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === `--${name}`) {
      const next = argv[i + 1];
      if (next === undefined || next.startsWith('--')) return true;
      return next;
    }
    if (a.startsWith(`--${name}=`)) return a.slice(name.length + 3);
  }
  return def;
}

const base = flag('url', 'http://127.0.0.1:5178/');
const tag = flag('tag', 'scene');
const phase = flag('phase');
const time = flag('time');
const preset = flag('preset');
const fly = flag('fly');
const width = Number(flag('width', 1600));
const height = Number(flag('height', 1000));
const settle = Number(flag('settle', 2600));
const warm = Number(flag('warm', 900));
const outDir = path.resolve('shots');
fs.mkdirSync(outDir, { recursive: true });
const out = path.join(outDir, `${tag}.png`);
const url = new URL(base);
if (phase) url.searchParams.set('phase', String(phase));

const gpuMode = flag('gpu', 'swiftshader');
const launchArgs =
  gpuMode === 'native'
    ? ['--enable-gpu-rasterization', '--ignore-gpu-blocklist']
    : ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--no-sandbox'];

const browser = await chromium.launch({
  args: launchArgs,
  headless: flag('headed') ? false : true,
});

const ctx = await browser.newContext({ viewport: { width, height }, deviceScaleFactor: 1 });
const page = await ctx.newPage();

const consoleErrors = [];
const pageErrors = [];
page.on('console', (m) => {
  if (m.type() === 'error' || m.type() === 'warning') consoleErrors.push(`[${m.type()}] ${m.text()}`);
});
page.on('pageerror', (e) => pageErrors.push(String(e)));
page.on('requestfailed', (r) => consoleErrors.push(`[net] ${r.url()} ${r.failure()?.errorText}`));

console.log(`→ loading ${url.toString()}`);
await page.goto(url.toString(), { waitUntil: 'load', timeout: 90000 });

try {
  await page.waitForFunction(() => window.__voxel && window.__voxel.ready === true, null, {
    timeout: 240000,
  });
} catch (err) {
  const stuck = await page.evaluate(() => ({
    phase: window.__voxel?.phase ?? '(no api)',
    errors: window.__voxel?.errors ?? [],
  }));
  console.log('✗ never became ready:', JSON.stringify(stuck, null, 2));
}

if (time !== undefined) {
  await page.evaluate((t) => window.__voxel?.setTime(Number(t)), time);
}
if (preset !== undefined) {
  await page.evaluate((p) => window.__voxel?.preset(Number.isNaN(Number(p)) ? String(p) : Number(p)), preset);
}
if (fly !== undefined && fly !== true) {
  // --fly=x,y,z : x2,y2,z2
  const [a, b] = String(fly).split(':');
  const pos = a.split(',').map(Number);
  const tgt = (b ?? '0,24,0').split(',').map(Number);
  await page.evaluate(([p, t]) => window.__voxel?.flyTo(p, t), [pos, tgt]);
}

await page.waitForTimeout(warm);
if (preset !== undefined) await page.waitForTimeout(1500);
await page.waitForTimeout(settle);

const report = await page.evaluate(() => {
  const api = window.__voxel;
  if (!api) return null;
  return {
    ready: api.ready,
    phase: api.phase,
    stats: api.stats,
    dayT: +api.dayT.toFixed(3),
    cameraPos: api.cameraPos,
    layers: api.assembly
      ? Object.fromEntries(
          Object.entries(api.assembly.stats.perLayer).map(([k, v]) => [
            k,
            { voxels: v.voxels, faces: v.faces },
          ]),
        )
      : null,
    errors: api.errors,
  };
});

await page.screenshot({ path: out });

console.log(`✓ screenshot → ${out}`);
console.log(JSON.stringify(report, null, 2));
if (pageErrors.length) console.log('PAGE ERRORS:\n' + pageErrors.join('\n'));
if (consoleErrors.length) console.log('CONSOLE:\n' + consoleErrors.slice(0, 25).join('\n'));

await browser.close();
if (pageErrors.length) process.exitCode = 2;
