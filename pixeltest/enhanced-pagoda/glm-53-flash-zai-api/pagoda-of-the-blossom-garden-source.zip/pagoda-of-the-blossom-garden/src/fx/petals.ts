/**
 * Petals — the blossom blizzard.
 *
 * One Points cloud of ~1100 tumbling sakura petals. Each carries a colour, a
 * sway phase and a spin rate; the vertex shader animates the fall and drift,
 * and the fragment shader rotates a petal-shaped sprite so the storm shimmers
 * without touching the CPU.
 */

import * as THREE from 'three';
import { PALETTE, C } from '../core/palette';
import { Rng } from '../core/rng';
import type { Actor, FrameInfo } from '../scene/actors';

const PETAL_COLORS = [C.blossom1, C.blossom2, C.blossom3, C.blossomWhite, C.blossom4];

export function createPetals(count = 1100): { points: THREE.Points; actor: Actor } {
  const rng = new Rng(2718);
  const pos = new Float32Array(count * 3);
  const color = new Float32Array(count * 3);
  const seed = new Float32Array(count);

  const tmp = new THREE.Color();
  for (let i = 0; i < count; i++) {
    const r = Math.sqrt(rng.float()) * 88;
    const a = rng.float() * Math.PI * 2;
    pos[i * 3] = Math.cos(a) * r;
    pos[i * 3 + 1] = rng.range(-8, 68);
    pos[i * 3 + 2] = Math.sin(a) * r;
    tmp.setHex(PALETTE[rng.pick(PETAL_COLORS)], THREE.SRGBColorSpace);
    color[i * 3] = tmp.r;
    color[i * 3 + 1] = tmp.g;
    color[i * 3 + 2] = tmp.b;
    seed[i] = rng.float() * 1000;
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  geo.setAttribute('aColor', new THREE.BufferAttribute(color, 3));
  geo.setAttribute('aSeed', new THREE.BufferAttribute(seed, 1));
  geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 24, 0), 160);

  const uniforms = {
    uTime: { value: 0 },
    uPixelScale: { value: Math.min(window.devicePixelRatio, 2) },
  };

  const material = new THREE.ShaderMaterial({
    uniforms,
    transparent: true,
    depthWrite: false,
    vertexShader: /* glsl */ `
      attribute vec3 aColor;
      attribute float aSeed;
      uniform float uTime;
      uniform float uPixelScale;
      varying vec3 vColor;
      varying float vFade;
      varying float vSpin;

      void main() {
        vColor = aColor;
        float s = aSeed;
        vec3 p = position;
        // gentle fall with per-petal sway
        float fall = mod(s * 7.13 + uTime * (1.1 + fract(s) * 1.3), 82.0);
        p.y = 66.0 - fall;
        p.x += sin(uTime * 0.8 + s) * 2.6 + sin(uTime * 0.23 + s * 2.0) * 5.0;
        p.z += cos(uTime * 0.7 + s * 1.3) * 2.6;
        vFade = smoothstep(66.0, 58.0, p.y) * smoothstep(-12.0, -2.0, p.y);
        vSpin = uTime * (1.5 + fract(s * 3.7) * 3.0) + s;
        vec4 mv = modelViewMatrix * vec4(p, 1.0);
        gl_PointSize = (2.2 + fract(s * 5.1) * 2.2) * uPixelScale * (140.0 / max(1.0, -mv.z));
        gl_Position = projectionMatrix * mv;
      }
    `,
    fragmentShader: /* glsl */ `
      precision highp float;
      varying vec3 vColor;
      varying float vFade;
      varying float vSpin;

      void main() {
        // rotating petal sprite: a notched disc
        vec2 d = gl_PointCoord - 0.5;
        float cs = cos(vSpin);
        float sn = sin(vSpin);
        d = mat2(cs, -sn, sn, cs) * d;
        float r = length(d);
        float petal = smoothstep(0.5, 0.32, r) * smoothstep(0.12, 0.34, r);
        // notch at the top of the petal
        petal *= smoothstep(0.16, 0.30, abs(d.x) + d.y * 0.6 + 0.06);
        float a = petal * vFade * 0.92;
        if (a < 0.02) discard;
        gl_FragColor = vec4(vColor, a);
      }
    `,
  });

  const points = new THREE.Points(geo, material);
  points.name = 'petals';
  points.frustumCulled = false;

  return {
    points,
    actor: {
      name: 'petals',
      update: (info: FrameInfo) => {
        uniforms.uTime.value = info.time;
      },
    },
  };
}
