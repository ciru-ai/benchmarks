/**
 * Fireflies — the night shift.
 *
 * Sleeping by day, igniting at dusk: a swarm of soft-glow points that wander
 * low over the meadows and pond shore, each blinking on its own clock. Alpha
 * is driven by the day cycle's night factor, so the whole swarm fades out at
 * dawn without any special-casing.
 */

import * as THREE from 'three';
import { PALETTE, C } from '../core/palette';
import { Rng } from '../core/rng';
import type { Actor, FrameInfo } from '../scene/actors';

const GLOW_COLORS = [C.spiritGreen, C.lanternGlow, C.magicCyan, C.pollen];

export function createFireflies(count = 170): { points: THREE.Points; actor: Actor } {
  const rng = new Rng(1618);
  const base = new Float32Array(count * 3);
  const color = new Float32Array(count * 3);
  const seed = new Float32Array(count);

  const tmp = new THREE.Color();
  for (let i = 0; i < count; i++) {
    // favour the garden heart and pond shore
    let x: number;
    let z: number;
    if (rng.chance(0.45)) {
      const a = rng.float() * Math.PI * 2;
      const r = rng.range(6, 40);
      x = Math.cos(a) * r;
      z = Math.sin(a) * r * 0.9 + 14;
    } else {
      const a = rng.float() * Math.PI * 2;
      const r = Math.sqrt(rng.float()) * 62;
      x = Math.cos(a) * r;
      z = Math.sin(a) * r;
    }
    base[i * 3] = x;
    base[i * 3 + 1] = rng.range(15, 30);
    base[i * 3 + 2] = z;
    tmp.setHex(PALETTE[rng.pick(GLOW_COLORS)], THREE.SRGBColorSpace);
    color[i * 3] = tmp.r;
    color[i * 3 + 1] = tmp.g;
    color[i * 3 + 2] = tmp.b;
    seed[i] = rng.float() * 100;
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(base, 3));
  geo.setAttribute('aColor', new THREE.BufferAttribute(color, 3));
  geo.setAttribute('aSeed', new THREE.BufferAttribute(seed, 1));
  geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 20, 10), 90);

  const uniforms = {
    uTime: { value: 0 },
    uNight: { value: 0 },
    uPixelScale: { value: Math.min(window.devicePixelRatio, 2) },
  };

  const material = new THREE.ShaderMaterial({
    uniforms,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    vertexShader: /* glsl */ `
      attribute vec3 aColor;
      attribute float aSeed;
      uniform float uTime;
      uniform float uPixelScale;
      varying vec3 vColor;
      varying float vBlink;

      void main() {
        vColor = aColor;
        float s = aSeed;
        vec3 p = position;
        p.x += sin(uTime * 0.35 + s * 3.1) * 3.4;
        p.y += sin(uTime * 0.5 + s * 1.7) * 1.9 + cos(uTime * 0.23 + s) * 1.2;
        p.z += cos(uTime * 0.31 + s * 2.3) * 3.4;
        // each firefly breathes on its own rhythm
        float pulse = pow(max(0.0, sin(uTime * (0.9 + fract(s) * 1.6) + s * 6.0)), 3.0);
        vBlink = 0.25 + 0.75 * pulse;
        vec4 mv = modelViewMatrix * vec4(p, 1.0);
        gl_PointSize = (1.6 + pulse * 2.4) * uPixelScale * (120.0 / max(1.0, -mv.z));
        gl_Position = projectionMatrix * mv;
      }
    `,
    fragmentShader: /* glsl */ `
      precision highp float;
      uniform float uNight;
      varying vec3 vColor;
      varying float vBlink;

      void main() {
        vec2 d = gl_PointCoord - 0.5;
        float glow = smoothstep(0.5, 0.0, length(d));
        float a = glow * vBlink * uNight;
        if (a < 0.01) discard;
        gl_FragColor = vec4(vColor * (0.7 + glow * 0.9), a);
      }
    `,
  });

  const points = new THREE.Points(geo, material);
  points.name = 'fireflies';
  points.frustumCulled = false;

  return {
    points,
    actor: {
      name: 'fireflies',
      update: (info: FrameInfo) => {
        uniforms.uTime.value = info.time;
        uniforms.uNight.value = info.night;
      },
    },
  };
}
