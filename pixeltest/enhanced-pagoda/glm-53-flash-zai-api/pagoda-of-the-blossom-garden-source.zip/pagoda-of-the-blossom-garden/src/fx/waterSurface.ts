/**
 * WaterSurface — the pond, stream and channel rendered as one connected sheet.
 *
 * Not voxels: liquid wants to move. The mesh is one quad per wet cell (footprint
 * taken from the site's water field so shores match the terrain exactly), and a
 * shader does the rest — layered waves with analytic normals, sky reflection by
 * fresnel, sun glint for the bloom pass, shore foam, and manual exp² fog matched
 * to the scene's.
 */

import * as THREE from 'three';
import { ISLAND_R, shoreFactor, waterSurfaceY } from '../world/site';
import { SKY_GLSL } from './sky';

export interface WaterHandle {
  mesh: THREE.Mesh;
  uniforms: Record<string, THREE.IUniform>;
  cells: number;
}

const WAVE_GLSL = /* glsl */ `
  float waveH(vec2 p, float t) {
    return 0.10 * sin(0.90 * p.x + 1.30 * t)
         + 0.08 * sin(1.10 * p.y - 1.10 * t)
         + 0.06 * sin(1.70 * (p.x + p.y) + 2.10 * t)
         + 0.03 * sin(2.60 * (p.x - p.y) - 3.10 * t);
  }
  vec2 waveGrad(vec2 p, float t) {
    float e = 0.35;
    float hx = waveH(p + vec2(e, 0.0), t) - waveH(p - vec2(e, 0.0), t);
    float hz = waveH(p + vec2(0.0, e), t) - waveH(p - vec2(0.0, e), t);
    return vec2(hx, hz) / (2.0 * e);
  }
`;

const VERT = /* glsl */ `
  uniform float uTime;
  uniform float uAmp;
  attribute float aShore;
  attribute float aRand;
  varying vec3 vWorld;
  varying float vShore;
  varying float vRand;
  ${WAVE_GLSL}
  void main() {
    vec3 p = position;
    p.y += waveH(p.xz, uTime) * uAmp * (0.45 + 0.55 * aShore);
    vWorld = p;
    vShore = aShore;
    vRand = aRand;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
  }
`;

const FRAG = /* glsl */ `
  precision highp float;
  uniform float uTime;
  uniform vec3 uDeep;
  uniform vec3 uShallow;
  uniform vec3 uSkyTop;
  uniform vec3 uSkyMid;
  uniform vec3 uSkyHorizon;
  uniform vec3 uSunDir;
  uniform vec3 uSunColor;
  uniform vec3 uFogColor;
  uniform float uFogDensity;
  uniform float uNight;
  varying vec3 vWorld;
  varying float vShore;
  varying float vRand;
  ${WAVE_GLSL}
  ${SKY_GLSL}

  float hash21(vec2 p) {
    p = fract(p * vec2(234.34, 435.345));
    p += dot(p, p + 34.23);
    return fract(p.x * p.y);
  }

  void main() {
    vec2 g = waveGrad(vWorld.xz, uTime);
    vec3 N = normalize(vec3(-g.x, 1.0, -g.y));
    vec3 V = normalize(cameraPosition - vWorld);

    // body colour: deep ink in the middle, translucent jade at the shores
    vec3 base = mix(uDeep, uShallow, vShore * vShore);

    // sky reflection, stronger at grazing angles
    vec3 R = reflect(-V, N);
    R.y = abs(R.y);
    vec3 sky = skyColor(R, uSkyTop, uSkyMid, uSkyHorizon) * 0.82;
    float fres = pow(1.0 - max(dot(N, V), 0.0), 3.0);
    vec3 col = mix(base, sky, 0.14 + 0.48 * fres);

    // sun glint — this is what the bloom pass turns into glitter
    vec3 H = normalize(normalize(uSunDir) + V);
    float spec = pow(max(dot(N, H), 0.0), 140.0);
    col += uSunColor * spec * (2.6 + uNight * 0.8);

    // travelling shimmer
    float shimmer = sin(vWorld.x * 3.1 + uTime * 1.7 + vRand * 6.28) * sin(vWorld.z * 2.7 - uTime * 1.3);
    col += uShallow * max(0.0, shimmer) * 0.05;

    // shore foam: noisy lace that breathes with the waves
    float lace = hash21(floor(vWorld.xz * 2.0) + floor(uTime * 1.4));
    float foam = smoothstep(0.62, 0.95, vShore + lace * 0.25 + g.x * 2.0);
    col = mix(col, vec3(0.92, 0.97, 1.0), foam * 0.55);

    // exp2 fog, matched to the scene fog
    float dist = length(cameraPosition - vWorld);
    float fog = 1.0 - exp(-pow(uFogDensity * dist, 2.0));
    col = mix(col, uFogColor, clamp(fog, 0.0, 1.0));

    gl_FragColor = vec4(col, 0.94);
  }
`;

export function buildWaterSurface(): WaterHandle {
  const positions: number[] = [];
  const shores: number[] = [];
  const rands: number[] = [];
  let cells = 0;
  let seed = 7;

  const rand = (): number => {
    seed = (seed * 16807) % 2147483647;
    return seed / 2147483647;
  };

  const R = ISLAND_R + 4;
  for (let x = -R; x <= R; x++) {
    for (let z = -R; z <= R; z++) {
      const surface = waterSurfaceY(x, z);
      if (surface === null) continue;
      const shore = shoreFactor(x, z);
      const y = surface - 0.22;
      const r = rand();
      // two CCW triangles viewed from above
      const quad: [number, number, number][] = [
        [x - 0.5, y, z - 0.5],
        [x + 0.5, y, z - 0.5],
        [x + 0.5, y, z + 0.5],
        [x - 0.5, y, z - 0.5],
        [x + 0.5, y, z + 0.5],
        [x - 0.5, y, z + 0.5],
      ];
      for (const v of quad) {
        positions.push(v[0], v[1], v[2]);
        shores.push(shore);
        rands.push(r);
      }
      cells++;
    }
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  const normals = new Float32Array(positions.length);
  for (let i = 0; i < normals.length; i += 3) {
    normals[i + 1] = 1;
  }
  geometry.setAttribute('normal', new THREE.BufferAttribute(normals, 3));
  geometry.setAttribute('aShore', new THREE.Float32BufferAttribute(shores, 1));
  geometry.setAttribute('aRand', new THREE.Float32BufferAttribute(rands, 1));
  geometry.computeBoundingSphere();

  const uniforms: Record<string, THREE.IUniform> = {
    uTime: { value: 0 },
    uAmp: { value: 0.5 },
    uDeep: { value: new THREE.Color(0x14527e) },
    uShallow: { value: new THREE.Color(0x5fc4d8) },
    uSkyTop: { value: new THREE.Color(0x2b5fa8) },
    uSkyMid: { value: new THREE.Color(0x7fb2e0) },
    uSkyHorizon: { value: new THREE.Color(0xd8e8f5) },
    uSunDir: { value: new THREE.Vector3(0.4, 0.8, 0.3) },
    uSunColor: { value: new THREE.Color(0xfff0cf) },
    uFogColor: { value: new THREE.Color(0xd8e8f5) },
    uFogDensity: { value: 0.0015 },
    uNight: { value: 0 },
  };

  const material = new THREE.ShaderMaterial({
    uniforms,
    vertexShader: VERT,
    fragmentShader: FRAG,
    transparent: true,
    depthWrite: true,
    side: THREE.DoubleSide,
  });

  const mesh = new THREE.Mesh(geometry, material);
  mesh.name = 'water';
  mesh.renderOrder = 1;
  mesh.receiveShadow = false;
  return { mesh, uniforms, cells };
}

/** per-frame sync: mirrors the sky/fog state so reflections always agree */
export function syncWater(water: WaterHandle, sky: {
  uniforms: Record<string, { value: unknown }>;
}, fog: THREE.FogExp2, night: number, sunDir: THREE.Vector3, sunColor: THREE.Color, time: number): void {
  const u = water.uniforms;
  u.uTime.value = time;
  u.uSkyTop.value = sky.uniforms.uTop.value;
  u.uSkyMid.value = sky.uniforms.uMid.value;
  u.uSkyHorizon.value = sky.uniforms.uHorizon.value;
  u.uSunDir.value = sunDir;
  u.uSunColor.value = sunColor;
  u.uFogColor.value = fog.color;
  u.uFogDensity.value = fog.density;
  u.uNight.value = night;
  (u.uDeep.value as THREE.Color).setHex(0x14527e).lerp(new THREE.Color(0x060d24), night * 0.8);
}
