/**
 * Birds — a small parliament of cranes circling the pagoda.
 *
 * Each crane is a two-wing voxel silhouette flying a tilted circular orbit;
 * wings flap by scaling, banking comes from the turn. Cheap, tiny, and it
 * makes the sky feel owned.
 */

import * as THREE from 'three';
import { C } from '../core/palette';
import { Rng } from '../core/rng';
import { VoxelWorld } from '../voxel/VoxelWorld';
import { buildVoxelMeshes } from '../voxel/mesher';
import { box } from '../voxel/brushes';
import type { Actor, FrameInfo } from '../scene/actors';

function craneGeometry(fork: number): THREE.BufferGeometry {
  void fork;
  const world = new VoxelWorld();
  // body + outstretched neck + head, all in the flight line (+x)
  box(world, -2, 0, 0, 1, 0, 0, C.white);
  world.set(2, 0, 0, C.white); // neck
  world.set(3, 0, 0, C.white); // head
  world.set(3, 1, 0, C.koiRed); // crown
  world.set(4, 0, 0, C.onyx); // beak
  box(world, -4, 1, 0, -3, 1, 0, C.onyx); // raised tail
  const mat = new THREE.MeshLambertMaterial({ vertexColors: true });
  const built = buildVoxelMeshes(world, () => mat, { solid: { aoStrength: 0.5, jitter: 0 } });
  return built.meshes.solid!.geometry;
}

function wingGeometry(side: 1 | -1): THREE.BufferGeometry {
  const world = new VoxelWorld();
  // wing extends along +z or -z, tapering
  for (let i = 0; i < 4; i++) {
    const w = 2 - Math.floor(i / 2);
    for (let b = -w; b <= w; b++) {
      world.set(b, 0, side * (i + 1), i > 2 ? C.onyx : C.white);
    }
  }
  const mat = new THREE.MeshLambertMaterial({ vertexColors: true });
  const built = buildVoxelMeshes(world, () => mat, { solid: { aoStrength: 0.4, jitter: 0 } });
  return built.meshes.solid!.geometry;
}

export function createBirds(count = 7): { group: THREE.Group; actor: Actor } {
  const group = new THREE.Group();
  group.name = 'birds';
  const rng = new Rng(31415);
  const bodyGeo = craneGeometry(1);
  const wingL = wingGeometry(1);
  const wingR = wingGeometry(-1);
  const sharedMat = new THREE.MeshLambertMaterial({ vertexColors: true });

  interface Bird {
    root: THREE.Group;
    wingL: THREE.Mesh;
    wingR: THREE.Mesh;
    radius: number;
    height: number;
    speed: number;
    phase: number;
    tilt: number;
    flap: number;
  }
  const birds: Bird[] = [];

  for (let i = 0; i < count; i++) {
    const root = new THREE.Group();
    root.add(new THREE.Mesh(bodyGeo, sharedMat));
    const wl = new THREE.Mesh(wingL, sharedMat);
    const wr = new THREE.Mesh(wingR, sharedMat);
    root.add(wl, wr);
    group.add(root);
    birds.push({
      root,
      wingL: wl,
      wingR: wr,
      radius: rng.range(16, 42),
      height: rng.range(52, 72),
      speed: rng.range(0.12, 0.22) * (rng.chance(0.7) ? 1 : -1),
      phase: rng.float() * Math.PI * 2,
      tilt: rng.range(0.86, 0.98),
      flap: rng.range(5.5, 8.5),
    });
  }

  return {
    group,
    actor: {
      name: 'birds',
      update: (info: FrameInfo) => {
        const t = info.time;
        for (const b of birds) {
          const a = b.phase + t * b.speed;
          const x = Math.cos(a) * b.radius;
          const z = Math.sin(a) * b.radius;
          b.root.position.set(x, b.height + Math.sin(t * 0.7 + b.phase) * 2.4, z);
          // face travel direction; bank into the turn
          const dirSign = Math.sign(b.speed);
          b.root.rotation.y = Math.atan2(-dirSign * Math.sin(a), -dirSign * Math.cos(a)) + Math.PI / 2;
          b.root.rotation.z = dirSign * 0.22;
          const flap = Math.sin(t * b.flap + b.phase);
          b.wingL.scale.y = 0.25 + Math.abs(flap) * 0.75 * b.tilt;
          b.wingR.scale.y = 0.25 + Math.abs(flap) * 0.75 * b.tilt;
        }
      },
    },
  };
}
