/**
 * Clouds — slow voxel rafts drifting through and beneath the island.
 *
 * Flat-bottomed, dome-topped clumps built from their own mini voxel worlds,
 * drawn unlit and slightly translucent. A few cruise the cloud sea below the
 * keel; a few graze the rim so the peaks play hide-and-seek.
 */

import * as THREE from 'three';
import { C } from '../core/palette';
import { Rng } from '../core/rng';
import { ellipsoid } from '../voxel/brushes';
import { VoxelWorld } from '../voxel/VoxelWorld';
import { buildVoxelMeshes } from '../voxel/mesher';
import type { Actor, FrameInfo } from '../scene/actors';

interface CloudActor extends Actor {
  mesh: THREE.Mesh;
  speed: number;
  radius: number;
  phase: number;
  yBase: number;
  vertical: number;
}

function buildCloudGeometry(rng: Rng): THREE.BufferGeometry {
  const world = new VoxelWorld();
  const puffs = rng.int(3, 6);
  for (let i = 0; i < puffs; i++) {
    const ox = rng.range(-6, 6);
    const oz = rng.range(-3.5, 3.5);
    const r = rng.range(2.6, 5.2);
    ellipsoid(
      world,
      ox,
      Math.max(0, rng.range(-0.5, 1.6)),
      oz,
      r,
      rng.range(1.4, 2.4),
      r * rng.range(0.7, 1),
      (px, py, _pz) => {
        void px;
        // flat-ish bottom, billowing top
        if (py < -0.6 && rng.chance(0.7)) return 0;
        return rng.weighted([
          [C.white, 6],
          [C.ice, 3],
          [C.foam, 1],
        ]);
      },
    );
  }
  const mat = new THREE.MeshBasicMaterial({ vertexColors: true });
  const built = buildVoxelMeshes(world, () => mat, { solid: { aoStrength: 0.35, jitter: 0.03 } });
  return built.meshes.solid!.geometry;
}

export function createClouds(count = 14): { group: THREE.Group; actor: Actor } {
  const group = new THREE.Group();
  group.name = 'clouds';
  const rng = new Rng(5150);
  const actors: CloudActor[] = [];

  for (let i = 0; i < count; i++) {
    const below = i < count * 0.55;
    const geo = buildCloudGeometry(rng.fork(i));
    const mat = new THREE.MeshBasicMaterial({
      vertexColors: true,
      transparent: true,
      opacity: below ? 0.88 : 0.8,
      depthWrite: false,
      fog: false,
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.renderOrder = below ? -1 : 2;
    const radius = rng.range(95, 150);
    const yBase = below ? rng.range(-52, -26) : rng.range(24, 46);
    mesh.scale.setScalar(rng.range(1.1, 2.4) * (below ? 1.6 : 1));
    group.add(mesh);
    actors.push({
      mesh,
      speed: rng.range(0.008, 0.02) * (rng.chance(0.5) ? 1 : -1),
      radius,
      phase: rng.float() * Math.PI * 2,
      yBase,
      vertical: rng.range(1.5, 4),
      update(info: FrameInfo): void {
        const a = this.phase + info.time * this.speed;
        this.mesh.position.set(
          Math.cos(a) * this.radius,
          this.yBase + Math.sin(info.time * 0.11 + this.phase) * this.vertical,
          Math.sin(a) * this.radius,
        );
        this.mesh.rotation.y = -a + Math.PI / 2;
      },
    });
  }

  return {
    group,
    actor: {
      name: 'clouds',
      update: (info) => {
        for (const a of actors) a.update(info);
      },
    },
  };
}
