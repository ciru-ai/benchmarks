/**
 * Post — bloom, vignette, grain.
 *
 * The composer chain is: scene → bloom (lanterns, glints, the jewel) →
 * vignette+grain (a tiny custom pass that also adds a whisper of chromatic
 * aberration) → output. Bloom strength breathes with the day cycle — a noon
 * scene needs almost none, a lantern-lit night wants lots.
 */

import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import type { Viewer } from '../scene/viewer';

const VignetteShader = {
  uniforms: {
    tDiffuse: { value: null as THREE.Texture | null },
    uStrength: { value: 0.42 },
    uGrain: { value: 0.05 },
    uTime: { value: 0 },
  },
  vertexShader: /* glsl */ `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: /* glsl */ `
    precision highp float;
    uniform sampler2D tDiffuse;
    uniform float uStrength;
    uniform float uGrain;
    uniform float uTime;
    varying vec2 vUv;

    float hash(vec2 p) {
      return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
    }

    void main() {
      vec2 uv = vUv;
      vec2 d = uv - 0.5;
      float r = length(d);

      // whisper of chromatic aberration toward the corners
      float ca = 0.0026 * smoothstep(0.35, 0.85, r);
      vec3 col;
      col.r = texture2D(tDiffuse, uv + d * ca).r;
      col.g = texture2D(tDiffuse, uv).g;
      col.b = texture2D(tDiffuse, uv - d * ca).b;

      // vignette
      col *= 1.0 - uStrength * smoothstep(0.42, 0.95, r);

      // animated grain
      float g = hash(uv * vec2(1920.0, 1080.0) + fract(uTime) * 37.0) - 0.5;
      col += g * uGrain;

      gl_FragColor = vec4(col, 1.0);
    }
  `,
};

export interface PostHandle {
  composer: EffectComposer;
  setBloom(on: boolean): void;
  setBloomStrength(v: number): void;
  bloomOn: boolean;
  update(dt: number): void;
  resize(w: number, h: number): void;
}

export function createPost(viewer: Viewer, day: {
  state: { night: number };
}): PostHandle {
  const size = new THREE.Vector2();
  viewer.renderer.getSize(size);
  const composer = new EffectComposer(viewer.renderer);
  composer.setSize(size.x, size.y);
  composer.addPass(new RenderPass(viewer.scene, viewer.camera));

  const bloom = new UnrealBloomPass(new THREE.Vector2(size.x, size.y), 0.55, 0.7, 0.86);
  composer.addPass(bloom);

  const vignette = new ShaderPass(VignetteShader);
  composer.addPass(vignette);

  composer.addPass(new OutputPass());

  const handle: PostHandle = {
    composer,
    bloomOn: true,
    setBloom(on: boolean): void {
      this.bloomOn = on;
      bloom.enabled = on;
    },
    setBloomStrength(v: number): void {
      bloom.strength = v;
    },
    update(dt: number): void {
      // night wants glow; noon wants clarity
      const night = day.state.night;
      bloom.strength = 0.34 + night * 0.75;
      bloom.threshold = 0.86 - night * 0.14;
      vignette.uniforms.uTime.value += dt;
    },
    resize(w: number, h: number): void {
      composer.setSize(w, h);
      bloom.setSize(w, h);
    },
  };

  viewer.onRender = () => composer.render();
  return handle;
}
