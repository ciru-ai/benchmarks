/**
 * Smoke — incense coils and tea-steam.
 *
 * A handful of CPU particles per emitter, rising with a curl, growing and
 * fading. Drawn as soft additive-ish sprites in a dusty lavender so they read
 * against both sky and timber.
 */

import * as THREE from 'three';
import { Rng } from '../core/rng';
import type { Actor, FrameInfo } from '../scene/actors';

interface Emitter {
  origin: THREE.Vector3;
  next: number;
  parts: {
    p: THREE.Vector3;
    v: THREE.Vector3;
    age: number;
    life: number;
    size: number;
  }[];
}

const MAX_PARTS = 60;

export class Smoke implements Actor {
  readonly points: THREE.Points;
  private emitters: Emitter[] = [];
  private rng = new Rng(9021);
  private pos: Float32Array;
  private size: Float32Array;
  private alpha: Float32Array;
  private posAttr: THREE.BufferAttribute;
  private sizeAttr: THREE.BufferAttribute;
  private alphaAttr: THREE.BufferAttribute;
  private rate: number;

  constructor(anchors: [number, number, number][], rate = 0.16) {
    this.rate = rate;
    for (const a of anchors) {
      this.emitters.push({ origin: new THREE.Vector3(...a), next: 0, parts: [] });
    }
    const n = MAX_PARTS * this.emitters.length;
    this.pos = new Float32Array(n * 3);
    this.size = new Float32Array(n);
    this.alpha = new Float32Array(n);

    const geo = new THREE.BufferGeometry();
    this.posAttr = new THREE.BufferAttribute(this.pos, 3);
    this.sizeAttr = new THREE.BufferAttribute(this.size, 1);
    this.alphaAttr = new THREE.BufferAttribute(this.alpha, 1);
    geo.setAttribute('position', this.posAttr);
    geo.setAttribute('aSize', this.sizeAttr);
    geo.setAttribute('aAlpha', this.alphaAttr);
    geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 30, 0), 120);

    const material = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      uniforms: {
        uPixelScale: { value: Math.min(window.devicePixelRatio, 2) },
      },
      vertexShader: /* glsl */ `
        attribute float aSize;
        attribute float aAlpha;
        uniform float uPixelScale;
        varying float vA;
        void main() {
          vA = aAlpha;
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          gl_PointSize = aSize * uPixelScale * (220.0 / max(1.0, -mv.z));
          gl_Position = projectionMatrix * mv;
        }
      `,
      fragmentShader: /* glsl */ `
        precision highp float;
        varying float vA;
        void main() {
          vec2 d = gl_PointCoord - 0.5;
          float g = smoothstep(0.5, 0.08, length(d));
          float a = g * vA;
          if (a < 0.01) discard;
          gl_FragColor = vec4(vec3(0.82, 0.78, 0.88), a * 0.5);
        }
      `,
    });

    this.points = new THREE.Points(geo, material);
    this.points.name = 'smoke';
    this.points.frustumCulled = false;
  }

  private spawn(e: Emitter): void {
    const rng = this.rng;
    e.parts.push({
      p: e.origin.clone().add(new THREE.Vector3(rng.gauss() * 0.4, 0, rng.gauss() * 0.4)),
      v: new THREE.Vector3(rng.gauss() * 0.25, rng.range(1.4, 2.4), rng.gauss() * 0.25),
      age: 0,
      life: rng.range(2.4, 4.2),
      size: rng.range(1.4, 2.2),
    });
  }

  update(info: FrameInfo): void {
    const dt = Math.min(info.dt, 0.05);
    let idx = 0;
    for (const e of this.emitters) {
      e.next -= dt;
      if (e.next <= 0 && e.parts.length < MAX_PARTS) {
        this.spawn(e);
        e.next = 1 / this.rate * this.rng.range(0.6, 1.4);
      }
      for (let i = e.parts.length - 1; i >= 0; i--) {
        const pt = e.parts[i];
        pt.age += dt;
        if (pt.age > pt.life) {
          e.parts.splice(i, 1);
          continue;
        }
        // curl: sway sideways as it rises
        pt.v.x += Math.sin(info.time * 2.2 + pt.age * 3.0) * 0.14 * dt * 10;
        pt.v.z += Math.cos(info.time * 1.7 + pt.age * 2.6) * 0.12 * dt * 10;
        pt.v.y += 0.05 * dt;
        pt.p.addScaledVector(pt.v, dt);
      }
      for (const pt of e.parts) {
        const t = pt.age / pt.life;
        this.pos[idx * 3] = pt.p.x;
        this.pos[idx * 3 + 1] = pt.p.y;
        this.pos[idx * 3 + 2] = pt.p.z;
        this.size[idx] = pt.size * (0.5 + t * 2.6);
        this.alpha[idx] = Math.sin(Math.min(1, t) * Math.PI) * 0.85;
        idx++;
      }
    }
    // hide unused slots
    for (let i = idx; i < this.pos.length / 3; i++) this.alpha[i] = 0;
    this.posAttr.needsUpdate = true;
    this.sizeAttr.needsUpdate = true;
    this.alphaAttr.needsUpdate = true;
  }
}
