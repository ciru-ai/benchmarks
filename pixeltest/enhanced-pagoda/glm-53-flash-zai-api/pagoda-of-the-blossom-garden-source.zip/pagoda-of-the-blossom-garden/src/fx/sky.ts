/**
 * Sky — a single shader dome that does the heavy atmospheric lifting.
 *
 * One gradient pass gives: horizon haze, zenith depth, a warm sun cone,
 * a crescent moon that trades places with the sun, and a procedural star field
 * that fades in after dusk. Sun and moon are drawn *in* the dome (bright,
 * unsaturated) so the bloom pass turns them into real glare.
 */

import * as THREE from 'three';

export interface SkyHandle {
  mesh: THREE.Mesh;
  uniforms: {
    uTop: { value: THREE.Color };
    uMid: { value: THREE.Color };
    uHorizon: { value: THREE.Color };
    uSunDir: { value: THREE.Vector3 };
    uSunColor: { value: THREE.Color };
    uMoonDir: { value: THREE.Vector3 };
    uMoonColor: { value: THREE.Color };
    uNight: { value: number };
    uTime: { value: number };
    uStarStrength: { value: number };
  };
}

const VERT = /* glsl */ `
  varying vec3 vDir;
  void main() {
    vDir = normalize(position);
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    gl_Position = projectionMatrix * mv;
  }
`;

const FRAG = /* glsl */ `
  precision highp float;
  varying vec3 vDir;
  uniform vec3 uTop;
  uniform vec3 uMid;
  uniform vec3 uHorizon;
  uniform vec3 uSunDir;
  uniform vec3 uSunColor;
  uniform vec3 uMoonDir;
  uniform vec3 uMoonColor;
  uniform float uNight;
  uniform float uTime;
  uniform float uStarStrength;

  // cheap hash / value noise for stars and faint galactic banding
  float hash13(vec3 p) {
    p = fract(p * 0.3183099 + vec3(0.71, 0.113, 0.419));
    p *= 17.0;
    return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
  }

  float starfield(vec3 d) {
    vec3 q = d * 260.0;
    vec3 cell = floor(q);
    float h = hash13(cell);
    if (h < 0.986) return 0.0;
    vec3 c = cell + 0.5 + (hash13(cell + 3.1) - 0.5) * 0.7;
    float dist = length(q - c);
    float mag = pow(hash13(cell + 7.7), 3.0);
    float twinkle = 0.72 + 0.28 * sin(uTime * (1.4 + mag * 6.0) + h * 40.0);
    return smoothstep(0.42, 0.0, dist) * (0.35 + mag * 2.1) * twinkle;
  }

  void main() {
    vec3 d = normalize(vDir);
    float up = clamp(d.y, -1.0, 1.0);

    // three-band vertical gradient
    float t1 = smoothstep(-0.06, 0.30, up);
    float t2 = smoothstep(0.22, 0.86, up);
    vec3 col = mix(uHorizon, uMid, t1);
    col = mix(col, uTop, t2);

    // ground haze just under the horizon line
    col = mix(col, uHorizon * 0.78, smoothstep(0.02, -0.35, up));

    // sun: tight disc + wide scattering cone
    float sd = max(dot(d, normalize(uSunDir)), 0.0);
    float disc = smoothstep(0.9987, 0.9994, sd);
    float halo = pow(sd, 380.0) * 0.9 + pow(sd, 14.0) * 0.22 + pow(sd, 3.0) * 0.05;
    col += uSunColor * (disc * 14.0 + halo);

    // moon: slightly smaller disc, cool halo, waning crescent
    float md = max(dot(d, normalize(uMoonDir)), 0.0);
    float mdisc = smoothstep(0.9990, 0.99955, md);
    float bite = smoothstep(0.99918, 0.99975, max(dot(d, normalize(uMoonDir) + vec3(0.0022, 0.0011, 0.0)), 0.0));
    float moonShape = clamp(mdisc - bite * 0.86, 0.0, 1.0);
    col += uMoonColor * (moonShape * 9.0 * uNight + pow(md, 90.0) * 0.5 * uNight);

    // stars + faint milky band
    float band = pow(max(0.0, 1.0 - abs(dot(d, normalize(vec3(0.42, 0.22, -0.88)))) * 2.6), 2.4);
    float stars = starfield(d) * uStarStrength * (1.0 + band * 1.5);
    col += vec3(0.92, 0.95, 1.0) * stars;
    col += uMid * band * 0.10 * uNight;

    gl_FragColor = vec4(col, 1.0);
  }
`;

export function createSky(radius = 900): SkyHandle {
  const uniforms = {
    uTop: { value: new THREE.Color(0x2b5fa8) },
    uMid: { value: new THREE.Color(0x7fb2e0) },
    uHorizon: { value: new THREE.Color(0xd8e8f5) },
    uSunDir: { value: new THREE.Vector3(0.4, 0.7, 0.3) },
    uSunColor: { value: new THREE.Color(0xfff0cf) },
    uMoonDir: { value: new THREE.Vector3(-0.4, -0.7, -0.3) },
    uMoonColor: { value: new THREE.Color(0xdfe9ff) },
    uNight: { value: 0 },
    uTime: { value: 0 },
    uStarStrength: { value: 0 },
  };

  const material = new THREE.ShaderMaterial({
    uniforms,
    vertexShader: VERT,
    fragmentShader: FRAG,
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
  });

  const mesh = new THREE.Mesh(new THREE.SphereGeometry(radius, 48, 32), material);
  mesh.name = 'sky';
  mesh.frustumCulled = false;
  mesh.renderOrder = -10;
  return { mesh, uniforms };
}

/** shared GLSL for the sky gradient, reused by the water reflection */
export const SKY_GLSL = /* glsl */ `
  vec3 skyColor(vec3 d, vec3 top, vec3 mid, vec3 horizon) {
    float up = clamp(d.y, -1.0, 1.0);
    float t1 = smoothstep(-0.06, 0.30, up);
    float t2 = smoothstep(0.22, 0.86, up);
    vec3 col = mix(horizon, mid, t1);
    col = mix(col, top, t2);
    return col;
  }
`;
