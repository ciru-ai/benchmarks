/**
 * Waterfall — where the garden's water changes level, dramatically.
 *
 * Two falls exist: the spring pool pouring off its terrace into the stream
 * gorge, and the pond's overflow ribbon diving off the island rim into the
 * clouds. Both are built the same way: a notch carved through the rock, an
 * additive voxel curtain that curves as it falls, mist pooled at the base, and
 * a CPU-simulated spray of points that the bloom pass lights up.
 */

import * as THREE from 'three';
import { C } from '../core/palette';
import { Rng } from '../core/rng';
import { smoothstep } from '../core/noise';
import { ellipsoid } from '../voxel/brushes';
import { VoxelWorld } from '../voxel/VoxelWorld';
import type { Actor, FrameInfo } from '../scene/actors';
import { STREAM_PATH, CHANNEL_PATH, landHeight, SPRING_Y, WATER_Y } from '../world/site';

function samplePolyline(pts: [number, number][], t: number): { x: number; z: number } {
  const segs = pts.length - 1;
  const f = Math.min(0.9999, Math.max(0, t)) * segs;
  const i = Math.floor(f);
  const u = f - i;
  return {
    x: pts[i][0] + (pts[i + 1][0] - pts[i][0]) * u,
    z: pts[i][1] + (pts[i + 1][1] - pts[i][1]) * u,
  };
}

/**
 * Find where the stream drops off the spring terrace: walk the upper reach,
 * watching for the ground to fall away beneath the waterline.
 */
function findSpringLip(): { x: number; z: number; top: number } {
  for (let i = 0; i <= 40; i++) {
    const t = i / 40;
    const p = samplePolyline(STREAM_PATH.slice(0, 4), t);
    const y = landHeight(Math.round(p.x), Math.round(p.z));
    if (y < SPRING_Y - 3.5) {
      const prev = samplePolyline(STREAM_PATH.slice(0, 4), Math.max(0, t - 0.03));
      return { x: Math.round(prev.x), z: Math.round(prev.z), top: SPRING_Y - 1 };
    }
  }
  return { x: -60, z: -26, top: SPRING_Y - 1 };
}

/** an aura curtain falling from (x, yTop, z) down to yBottom, curving outward */
function pourCurtain(
  world: VoxelWorld,
  x: number,
  z: number,
  yTop: number,
  yBottom: number,
  width: number,
  dir: { x: number; z: number },
  rng: Rng,
): void {
  const dx = dir.x;
  const dz = dir.z;
  for (let y = yTop; y >= yBottom; y--) {
    const fall = (yTop - y) / Math.max(1, yTop - yBottom);
    // the jet stretches and frays as it falls
    const reach = fall * fall * 7;
    const sway = Math.sin(fall * 9) * 0.5 * fall;
    const w = width * (1 - fall * 0.35);
    for (let s = -Math.ceil(w); s <= Math.ceil(w); s++) {
      const dens = 1 - Math.abs(s) / (w + 1);
      if (rng.float() > dens * 0.95 + 0.05) continue;
      const px = Math.round(x + dx * reach + -dz * s + sway);
      const pz = Math.round(z + dz * reach + dx * s + sway);
      const c = rng.weighted([
        [C.foam, 6],
        [C.ice, 4],
        [C.waterLight, 2],
        [C.white, 2],
      ]);
      world.aura(px, y, pz, c);
      if (rng.chance(0.12)) world.glow(px, y, pz, C.ice);
      // erode terrain that would swallow the jet
      world.erase('solid', px, y, pz);
    }
  }
}

/** soft mist breathing at the base of a fall */
function addMist(world: VoxelWorld, x: number, y: number, z: number, rng: Rng): void {
  for (let i = 0; i < 5; i++) {
    ellipsoid(
      world,
      x + rng.range(-3, 3),
      y + rng.range(0, 2.4),
      z + rng.range(-3, 3),
      rng.range(2.4, 4.6),
      rng.range(0.9, 1.7),
      rng.range(2.4, 4.6),
      (_px, py, _pz) =>
        rng.chance(0.55 - Math.abs(py - y) * 0.12)
          ? rng.weighted([[C.foam, 5], [C.ice, 3], [C.white, 2]])
          : 0,
      'aura',
    );
  }
}

/**
 * Animated spray: a small CPU particle system, respawned at the lip, flung
 * down and outward, fading as it dies. Drawn as additive points.
 */
export class Spray implements Actor {
  readonly points: THREE.Points;
  private vel: Float32Array;
  private life: Float32Array;
  private origin: THREE.Vector3;
  private dir: THREE.Vector3;
  private rng: Rng;
  private count: number;
  private spread: number;
  private pos: Float32Array;
  private alpha: Float32Array;
  private posAttr: THREE.BufferAttribute;
  private alphaAttr: THREE.BufferAttribute;

  constructor(origin: THREE.Vector3, dir: THREE.Vector3, count = 150, spread = 1.6, seed = 5) {
    this.count = count;
    this.spread = spread * 0.85;
    this.origin = origin.clone();
    this.dir = dir.clone().normalize();
    this.rng = new Rng(seed);
    this.pos = new Float32Array(count * 3);
    this.alpha = new Float32Array(count);
    this.vel = new Float32Array(count * 3);
    this.life = new Float32Array(count);
    for (let i = 0; i < count; i++) this.respawn(i, true);

    const geo = new THREE.BufferGeometry();
    this.posAttr = new THREE.BufferAttribute(this.pos, 3);
    this.alphaAttr = new THREE.BufferAttribute(this.alpha, 1);
    geo.setAttribute('position', this.posAttr);
    geo.setAttribute('aAlpha', this.alphaAttr);
    geo.boundingSphere = new THREE.Sphere(origin, 60);

    const mat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      uniforms: {
        uColor: { value: new THREE.Color(0xdff4ff) },
        uPixelScale: { value: 1 },
      },
      vertexShader: /* glsl */ `
        attribute float aAlpha;
        varying float vA;
        void main() {
          vA = aAlpha;
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          gl_PointSize = (2.6 + aAlpha * 2.2) * (300.0 / max(1.0, -mv.z)) * uPixelScale;
          gl_Position = projectionMatrix * mv;
        }
      `,
      fragmentShader: /* glsl */ `
        precision highp float;
        uniform vec3 uColor;
        varying float vA;
        void main() {
          vec2 d = gl_PointCoord - 0.5;
          float a = smoothstep(0.5, 0.05, length(d)) * vA;
          gl_FragColor = vec4(uColor, a);
        }
      `,
    });
    mat.uniforms.uPixelScale.value = Math.min(window.devicePixelRatio, 2);

    this.points = new THREE.Points(geo, mat);
    this.points.name = 'spray';
    this.points.frustumCulled = false;
  }

  private respawn(i: number, scatter = false): void {
    const rng = this.rng;
    const j = i * 3;
    const spread = this.spread;
    this.pos[j] = this.origin.x + rng.range(-spread, spread);
    this.pos[j + 1] = this.origin.y + (scatter ? rng.range(-4, 0) : rng.range(0, 1.4));
    this.pos[j + 2] = this.origin.z + rng.range(-spread, spread);
    this.vel[j] = this.dir.x * rng.range(1.5, 4.5) + rng.gauss() * 0.7;
    this.vel[j + 1] = -rng.range(3.5, 8.5);
    this.vel[j + 2] = this.dir.z * rng.range(1.5, 4.5) + rng.gauss() * 0.7;
    this.life[i] = rng.range(0.5, 1.25);
  }

  update(info: FrameInfo): void {
    const pos = this.pos;
    const alpha = this.alpha;
    const dt = Math.min(info.dt, 0.05);
    for (let i = 0; i < this.count; i++) {
      const j = i * 3;
      this.life[i] -= dt;
      if (this.life[i] <= 0) {
        this.respawn(i);
        continue;
      }
      pos[j] += this.vel[j] * dt;
      pos[j + 1] += this.vel[j + 1] * dt;
      pos[j + 2] += this.vel[j + 2] * dt;
      this.vel[j + 1] -= 9.8 * dt * 0.5;
      alpha[i] = Math.min(1, this.life[i] * 1.6) * 0.85;
    }
    this.posAttr.needsUpdate = true;
    this.alphaAttr.needsUpdate = true;
  }
}

/** the spring pool's exit falls, into the stream gorge */
export function addSpringFalls(world: VoxelWorld, actors: { add(a: Actor): Actor }): void {
  const rng = new Rng(3113);
  const lip = findSpringLip();
  const bottom = WATER_Y + 1;

  // frame the fall with a mossy lip so the jet reads against stone
  for (let s = -3; s <= 3; s++) {
    world.set(lip.x + s, lip.top, lip.z, rng.weighted([[C.granite, 4], [C.stone3, 3], [C.mossStone, 3]]));
  }

  pourCurtain(world, lip.x, lip.z + 1, lip.top, bottom, 4.2, { x: 0.15, z: 1 }, rng);
  addMist(world, lip.x, bottom, lip.z + 3, rng);

  const spray = new Spray(
    new THREE.Vector3(lip.x, lip.top - 1, lip.z + 2),
    new THREE.Vector3(0.2, 0, 1),
    130,
    1.4,
    71,
  );
  actors.add(spray);
}

/** the pond overflow, flung off the island rim in a long silver ribbon */
export function addRimCascade(world: VoxelWorld, actors: { add(a: Actor): Actor }): void {
  const rng = new Rng(6262);
  const end = CHANNEL_PATH[CHANNEL_PATH.length - 1];
  const before = CHANNEL_PATH[CHANNEL_PATH.length - 2];
  const dx = end[0] - before[0];
  const dz = end[1] - before[1];
  const len = Math.hypot(dx, dz) || 1;
  const dir = { x: dx / len, z: dz / len };
  const x = end[0];
  const z = end[1];

  // the water sheet only reaches where the island does; ribbon the rest
  pourCurtain(world, x, z, WATER_Y - 1, -34, 4.6, dir, rng);
  addMist(world, x + dir.x * 6, -30, z + dir.z * 6, rng);

  const spray = new Spray(
    new THREE.Vector3(x, WATER_Y - 2, z),
    new THREE.Vector3(dir.x, 0, dir.z),
    170,
    2.0,
    99,
  );
  actors.add(spray);

  // a few “cloudbreak” wisps where the ribbon vanishes into the cloud sea
  for (let i = 0; i < 4; i++) {
    const t = i / 4;
    ellipsoid(
      world,
      x + dir.x * (6 + t * 10) + rng.range(-4, 4),
      -30 - t * 6,
      z + dir.z * (6 + t * 10) + rng.range(-4, 4),
      rng.range(4, 7),
      rng.range(1, 1.8),
      rng.range(4, 7),
      (px, _py, _pz) =>
        rng.chance(smoothstep(0.9, 0.2, Math.abs(px)) * 0.5)
          ? rng.weighted([[C.white, 4], [C.ice, 2], [C.foam, 2]])
          : 0,
      'aura',
    );
  }
}
