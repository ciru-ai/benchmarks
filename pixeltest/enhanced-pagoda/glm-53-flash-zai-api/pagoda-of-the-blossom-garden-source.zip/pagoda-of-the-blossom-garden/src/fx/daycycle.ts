/**
 * DayCycle — one slider drives the whole mood of the diorama.
 *
 * Palette keyframes run from midnight through dawn, noon, golden hour and dusk;
 * colours are interpolated in linear space. Everything else (lantern brightness,
 * fireflies, water tint, bloom strength, window glow) subscribes through
 * `addListener`, so new systems can react to time of day without importing this
 * module back.
 */

import * as THREE from 'three';
import { smoothstep } from '../core/noise';
import type { SkyHandle } from './sky';

export interface DayState {
  dayT: number;
  /** 0 = full day, 1 = full night */
  night: number;
  sunDir: THREE.Vector3;
  moonDir: THREE.Vector3;
  sunColor: THREE.Color;
  fogColor: THREE.Color;
  /** how bright self-lit voxels render (lanterns burn hotter at night) */
  glow: number;
}

interface Stop {
  t: number;
  top: number;
  mid: number;
  horizon: number;
  sun: number;
  sunIntensity: number;
  ambient: number;
  hemi: number;
  fogDensity: number;
  exposure: number;
  glow: number;
}

const STOPS: Stop[] = [
  { t: 0.0, top: 0x060a1e, mid: 0x0b1030, horizon: 0x151a3c, sun: 0x2a3560, sunIntensity: 0.1, ambient: 0.16, hemi: 0.22, fogDensity: 0.0032, exposure: 0.92, glow: 2.3 },
  { t: 0.17, top: 0x152050, mid: 0x2d3170, horizon: 0x5a4272, sun: 0x6d4a6a, sunIntensity: 0.18, ambient: 0.22, hemi: 0.3, fogDensity: 0.0036, exposure: 0.98, glow: 2.0 },
  { t: 0.24, top: 0x2e5390, mid: 0x9c6f8e, horizon: 0xf0a05c, sun: 0xffb066, sunIntensity: 1.5, ambient: 0.3, hemi: 0.5, fogDensity: 0.003, exposure: 1.06, glow: 1.05 },
  { t: 0.31, top: 0x2f6fb8, mid: 0x8fc0e4, horizon: 0xf5dcae, sun: 0xffe2b0, sunIntensity: 2.6, ambient: 0.34, hemi: 0.62, fogDensity: 0.0021, exposure: 1.05, glow: 0.72 },
  { t: 0.5, top: 0x1e63b4, mid: 0x79b6e6, horizon: 0xd9ecf7, sun: 0xfff4dd, sunIntensity: 3.15, ambient: 0.4, hemi: 0.75, fogDensity: 0.0015, exposure: 1.02, glow: 0.6 },
  { t: 0.68, top: 0x2a6bb0, mid: 0xa8bcd8, horizon: 0xf6cf9a, sun: 0xffd79a, sunIntensity: 2.75, ambient: 0.36, hemi: 0.66, fogDensity: 0.0022, exposure: 1.05, glow: 0.8 },
  { t: 0.77, top: 0x35528f, mid: 0xc07a78, horizon: 0xff8a48, sun: 0xff9347, sunIntensity: 1.85, ambient: 0.3, hemi: 0.5, fogDensity: 0.0032, exposure: 1.1, glow: 1.35 },
  { t: 0.85, top: 0x1c2a63, mid: 0x53376e, horizon: 0xb0577a, sun: 0x8a4a6a, sunIntensity: 0.42, ambient: 0.24, hemi: 0.34, fogDensity: 0.0038, exposure: 1.02, glow: 1.9 },
  { t: 1.0, top: 0x060a1e, mid: 0x0b1030, horizon: 0x151a3c, sun: 0x2a3560, sunIntensity: 0.1, ambient: 0.16, hemi: 0.22, fogDensity: 0.0032, exposure: 0.92, glow: 1.75 },
];

const PRESETS = {
  dawn: 0.245,
  morning: 0.33,
  noon: 0.5,
  golden: 0.705,
  dusk: 0.8,
  night: 0.02,
} as const;

export type DayListener = (state: DayState) => void;

export class DayCycle {
  readonly sun: THREE.DirectionalLight;
  readonly moonLight: THREE.DirectionalLight;
  readonly hemi: THREE.HemisphereLight;
  ambient: THREE.AmbientLight;

  dayT = 0.42;
  readonly state: DayState;
  readonly sceneRef: THREE.Scene;

  private sky: SkyHandle;
  private listeners: DayListener[] = [];
  private tmpTop = new THREE.Color();
  private tmpMid = new THREE.Color();
  private tmpHorizon = new THREE.Color();
  private tmpSun = new THREE.Color();
  private a = new THREE.Color();
  private b = new THREE.Color();

  constructor(
    private renderer: THREE.WebGLRenderer,
    scene: THREE.Scene,
    sky: SkyHandle,
  ) {
    this.sky = sky;
    this.sceneRef = scene;
    this.state = {
      dayT: this.dayT,
      night: 0,
      sunDir: new THREE.Vector3(0, 1, 0),
      moonDir: new THREE.Vector3(0, -1, 0),
      sunColor: new THREE.Color(),
      fogColor: new THREE.Color(),
      glow: 1,
    };

    scene.fog = new THREE.FogExp2(0xd9ecf7, 0.0015);

    this.sun = new THREE.DirectionalLight(0xffffff, 3);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(4096, 4096);
    const cam = this.sun.shadow.camera;
    cam.left = -120;
    cam.right = 120;
    cam.top = 120;
    cam.bottom = -120;
    cam.near = 1;
    cam.far = 520;
    this.sun.shadow.bias = -0.0004;
    this.sun.shadow.normalBias = 0.55;
    scene.add(this.sun);
    scene.add(this.sun.target);

    this.moonLight = new THREE.DirectionalLight(0xbfd4ff, 0.12);
    this.moonLight.castShadow = false;
    scene.add(this.moonLight);
    scene.add(this.moonLight.target);

    this.hemi = new THREE.HemisphereLight(0xbfdcff, 0x54603a, 0.7);
    scene.add(this.hemi);

    this.ambient = new THREE.AmbientLight(0xffffff, 0.35);
    scene.add(this.ambient);

    this.apply();
  }

  addListener(fn: DayListener): void {
    this.listeners.push(fn);
    fn(this.state);
  }

  set(t: number): void {
    this.dayT = ((t % 1) + 1) % 1;
    this.apply();
  }

  add(dt: number, speed = 0.008): void {
    this.set(this.dayT + dt * speed);
  }

  preset(name: keyof typeof PRESETS): void {
    this.set(PRESETS[name]);
  }

  static get presetNames(): (keyof typeof PRESETS)[] {
    return Object.keys(PRESETS) as (keyof typeof PRESETS)[];
  }

  private sample(out: {
    top: THREE.Color;
    mid: THREE.Color;
    horizon: THREE.Color;
    sun: THREE.Color;
  }): { sunIntensity: number; ambient: number; hemi: number; fogDensity: number; exposure: number; glow: number } {
    const t = this.dayT;
    let i = 0;
    while (i < STOPS.length - 2 && STOPS[i + 1].t < t) i++;
    const s0 = STOPS[i];
    const s1 = STOPS[i + 1];
    const f = (t - s0.t) / (s1.t - s0.t || 1);

    this.a.setHex(s0.top, THREE.SRGBColorSpace);
    this.b.setHex(s1.top, THREE.SRGBColorSpace);
    out.top.copy(this.a).lerp(this.b, f);
    this.a.setHex(s0.mid, THREE.SRGBColorSpace);
    this.b.setHex(s1.mid, THREE.SRGBColorSpace);
    out.mid.copy(this.a).lerp(this.b, f);
    this.a.setHex(s0.horizon, THREE.SRGBColorSpace);
    this.b.setHex(s1.horizon, THREE.SRGBColorSpace);
    out.horizon.copy(this.a).lerp(this.b, f);
    this.a.setHex(s0.sun, THREE.SRGBColorSpace);
    this.b.setHex(s1.sun, THREE.SRGBColorSpace);
    out.sun.copy(this.a).lerp(this.b, f);

    return {
      sunIntensity: s0.sunIntensity + (s1.sunIntensity - s0.sunIntensity) * f,
      ambient: s0.ambient + (s1.ambient - s0.ambient) * f,
      hemi: s0.hemi + (s1.hemi - s0.hemi) * f,
      fogDensity: s0.fogDensity + (s1.fogDensity - s0.fogDensity) * f,
      exposure: s0.exposure + (s1.exposure - s0.exposure) * f,
      glow: s0.glow + (s1.glow - s0.glow) * f,
    };
  }

  apply(): void {
    const t = this.dayT;
    const out = { top: this.tmpTop, mid: this.tmpMid, horizon: this.tmpHorizon, sun: this.tmpSun };
    const p = this.sample(out);

    // sun rides an inclined arc: east at dawn, overhead at noon, west at dusk
    const angle = (t - 0.25) * Math.PI * 2;
    const elev = Math.sin(angle);
    const azim = Math.cos(angle);
    this.state.sunDir.set(azim * 0.86, Math.abs(elev) < 0.02 ? 0.02 : elev, 0.34).normalize();
    this.state.moonDir.copy(this.state.sunDir).multiplyScalar(-1);

    const day = smoothstep(-0.06, 0.22, elev);
    const night = 1 - day;
    this.state.night = night;
    this.state.dayT = t;
    this.state.sunColor.copy(this.tmpSun);

    // keep the shadow frustum tight around the island
    const sunHigh = Math.max(0.12, Math.abs(elev));
    this.sun.shadow.camera.far = 620;
    this.sun.intensity = p.sunIntensity * (elev > -0.05 ? 1 : 0.15);
    this.sun.color.copy(this.tmpSun);
    this.sun.position.copy(this.state.sunDir).multiplyScalar(230 / sunHigh * 0.62);
    this.sun.target.position.set(0, 12, 0);
    this.sun.updateMatrixWorld();

    this.moonLight.intensity = 0.05 + night * 0.42;
    this.moonLight.position.copy(this.state.moonDir).multiplyScalar(240);
    this.moonLight.target.position.set(0, 12, 0);

    this.hemi.intensity = p.hemi;
    this.hemi.color.copy(this.tmpMid).lerp(new THREE.Color(0xffffff), 0.35);
    this.hemi.groundColor.setHex(0x4a5636, THREE.SRGBColorSpace);
    this.ambient.intensity = p.ambient * (1 + night * 0.35);
    this.ambient.color.copy(this.tmpMid).lerp(new THREE.Color(0xffffff), 0.5);

    // fog matches the horizon so the island edge dissolves into the sky
    this.state.fogColor.copy(this.tmpHorizon).lerp(this.tmpMid, 0.35);
    const fog = this.sceneRef.fog as THREE.FogExp2 | null;
    if (fog) {
      fog.color.copy(this.state.fogColor);
      fog.density = p.fogDensity;
    }

    this.renderer.toneMappingExposure = p.exposure;

    const u = this.sky.uniforms;
    u.uTop.value.copy(this.tmpTop);
    u.uMid.value.copy(this.tmpMid);
    u.uHorizon.value.copy(this.tmpHorizon);
    u.uSunDir.value.copy(this.state.sunDir);
    u.uSunColor.value.copy(this.tmpSun);
    u.uMoonDir.value.copy(this.state.moonDir);
    u.uNight.value = night;
    u.uStarStrength.value = Math.pow(night, 1.4);

    this.state.glow = p.glow;
    for (const l of this.listeners) l(this.state);
  }
}
