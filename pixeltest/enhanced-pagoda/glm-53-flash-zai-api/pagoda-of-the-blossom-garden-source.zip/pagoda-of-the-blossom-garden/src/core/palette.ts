/**
 * The colour chart for the whole diorama.
 *
 * Colours are declared in sRGB hex (what a human picks in a paint dialog) and
 * converted once to three.js's linear working space by the mesher. Keeping one
 * flat list means the merged voxel geometry only ever needs a palette index per
 * voxel instead of a colour, which makes authoring terse and the mesh cheap.
 */

const defs = {
  // ---- turf & groundcover -------------------------------------------------
  grass1: 0x6fa84a,
  grass2: 0x7fbb57,
  grass3: 0x5c9440,
  grassDeep: 0x47793a,
  moss: 0x4e7a3a,
  mossLight: 0x8bb95f,
  dryGrass: 0xadb566,
  fern: 0x3c6833,
  clover: 0x93cc63,
  bambooLeaf: 0x77b44d,

  // ---- earth, sand, gravel ------------------------------------------------
  dirt: 0x7a5a3f,
  soilDark: 0x55402e,
  clay: 0x9c6b4a,
  sand: 0xdcc696,
  sandLight: 0xeddcb2,
  gravel: 0xbdb4a3,
  gravelDark: 0x8d8578,
  zenSand: 0xe4dcc6,
  pebble: 0x93897a,

  // ---- stone --------------------------------------------------------------
  stone1: 0x9ea4aa,
  stone2: 0x828a91,
  stone3: 0x697077,
  granite: 0x535a60,
  stoneWarm: 0xb3a795,
  mossStone: 0x7e8b73,
  slateBlue: 0x64758c,

  // ---- timber -------------------------------------------------------------
  woodDark: 0x4a3527,
  wood: 0x6b4a30,
  woodLight: 0x8b6343,
  timber: 0x3a2a1e,
  bark: 0x59422f,
  cedar: 0x9e6d4c,
  bamboo: 0xcbb26a,
  bambooDark: 0xa08a4b,

  // ---- lacquer & vermilion ------------------------------------------------
  vermilion: 0xdb5133,
  vermilionDeep: 0xb03a24,
  vermilionLight: 0xef6f48,
  lacquerRed: 0x8f2020,
  onyx: 0x21232a,

  // ---- metal --------------------------------------------------------------
  gold: 0xe8b13c,
  goldLight: 0xffdc7c,
  goldDeep: 0xb9862a,
  brass: 0xc9a24a,
  iron: 0x4a4f57,
  ironDark: 0x30353c,
  copper: 0xb06a3f,
  bronze: 0x8c6a3f,

  // ---- roofs --------------------------------------------------------------
  jade: 0x2f7d6b,
  jadeDark: 0x245248,
  jadeLight: 0x48a790,
  tealRoof: 0x21707c,
  roofBlue: 0x2c5180,
  roofDeep: 0x1b3452,
  roofTileRed: 0xa4432c,

  // ---- plaster & cloth ----------------------------------------------------
  plaster: 0xf2e7d3,
  plasterShade: 0xdccfb8,
  white: 0xfdfaf4,
  cream: 0xf8ebd1,
  indigo: 0x2d3f6b,
  clothTeal: 0x2f7d84,
  norenCream: 0xefe3cd,
  paper: 0xfff4dd,

  // ---- sakura -------------------------------------------------------------
  blossom1: 0xffdbe8,
  blossom2: 0xffc2d9,
  blossom3: 0xf99dc2,
  blossom4: 0xe8779f,
  blossomDeep: 0xcf5f88,
  blossomWhite: 0xfff3f7,

  // ---- other foliage colour ------------------------------------------------
  pineGreen: 0x2f5c46,
  pineDark: 0x23453a,
  pineLight: 0x43805f,
  mapleRed: 0xd4462f,
  mapleOrange: 0xe8823a,
  mapleGold: 0xf0b93f,
  willow: 0x88b45c,
  willowDark: 0x5d8c46,
  plumPink: 0xf4a7c3,
  wisteria: 0xa98bd6,
  wisteriaLight: 0xcab4ec,
  lavender: 0xb58fd6,
  iris: 0x7a63c9,

  // ---- flowers ------------------------------------------------------------
  poppyOrange: 0xf07818,
  tulipRed: 0xe2413f,
  tulipYellow: 0xf7cf3f,
  tulipPink: 0xf28bc0,
  bluebell: 0x6f86d8,
  sunflower: 0xf2b32a,
  pollen: 0xffe89a,
  reed: 0xbfae7c,

  // ---- water --------------------------------------------------------------
  water: 0x2f7fa8,
  waterDeep: 0x1c5578,
  waterLight: 0x66c2da,
  ice: 0xcdeef7,
  foam: 0xe8f7fb,

  // ---- creatures -----------------------------------------------------------
  koiOrange: 0xf47a2f,
  koiWhite: 0xfdf6ee,
  koiRed: 0xd8342b,
  koiGold: 0xf6c445,
  koiInk: 0x2b2b33,
  tortoise: 0x6b7a4a,

  // ---- light-emitting ------------------------------------------------------
  lanternPaper: 0xffd9a0,
  lanternGlow: 0xffb457,
  ember: 0xff7b3d,
  magicCyan: 0x8ff0ff,
  spiritGreen: 0xa9f7c0,
  jadeGlow: 0x6fe6c8,
  spiritPink: 0xffb0d2,
  sunCore: 0xfff2c4,
  moonCore: 0xeaf2ff,
  starCore: 0xffffff,

  // ---- misc ---------------------------------------------------------------
  snow: 0xf4f8ff,
  shadow: 0x1d2026,
  rust: 0x9a5b34,
} as const;

export type ColorName = keyof typeof defs;

/** palette index lookups: `C.blossom2` */
export const C = Object.fromEntries(Object.keys(defs).map((k, i) => [k, i])) as Record<
  ColorName,
  number
>;

/** sRGB hex per palette index */
export const PALETTE: number[] = Object.values(defs);

/** hand-curated blend ladders, used by gradient brushes */
export const LADDER = {
  sakura: [C.blossomDeep, C.blossom4, C.blossom3, C.blossom2, C.blossom1, C.blossomWhite],
  sakuraPale: [C.blossom4, C.blossom2, C.blossom1, C.blossomWhite],
  jade: [C.jadeDark, C.jade, C.jadeLight],
  stone: [C.granite, C.stone3, C.stone2, C.stone1],
  gold: [C.goldDeep, C.gold, C.goldLight],
  pine: [C.pineDark, C.pineGreen, C.pineLight],
  grass: [C.grassDeep, C.grass3, C.grass1, C.grass2],
  ember: [C.ember, C.lanternGlow, C.lanternPaper],
  water: [C.waterDeep, C.water, C.waterLight],
  maple: [C.mapleRed, C.mapleOrange, C.mapleGold],
  bamboo: [C.bambooDark, C.bamboo],
} as const;

/** pick a ladder entry for a normalised height t (0..1) */
export function ladderRamp(ladder: readonly number[], t: number): number {
  const n = ladder.length - 1;
  const i = Math.round(Math.min(1, Math.max(0, t)) * n);
  return ladder[i];
}
