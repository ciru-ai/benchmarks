/**
 * Smooth scalar noise fields + shaping helpers.
 *
 * Value noise on an integer lattice, sampled with quintic fade and layered
 * into fBm. Cheap, dependency-free, and deterministic (see rng.ts).
 */

import { hash3 } from './rng';

const SEED_BASE = 0x51ab7c;

function fade(t: number): number {
  return t * t * t * (t * (t * 6 - 15) + 10);
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

/** 2D value noise in [0,1] */
export function noise2(x: number, z: number, seed = 0): number {
  const xi = Math.floor(x);
  const zi = Math.floor(z);
  const xf = x - xi;
  const zf = z - zi;
  const u = fade(xf);
  const v = fade(zf);

  const n00 = hash3(xi, 0, zi, SEED_BASE + seed);
  const n10 = hash3(xi + 1, 0, zi, SEED_BASE + seed);
  const n01 = hash3(xi, 0, zi + 1, SEED_BASE + seed);
  const n11 = hash3(xi + 1, 0, zi + 1, SEED_BASE + seed);

  return lerp(lerp(n00, n10, u), lerp(n01, n11, u), v);
}

/** 3D value noise in [0,1] */
export function noise3(x: number, y: number, z: number, seed = 0): number {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const zi = Math.floor(z);
  const u = fade(x - xi);
  const v = fade(y - yi);
  const w = fade(z - zi);

  const c = (ix: number, iy: number, iz: number) => hash3(ix, iy, iz, SEED_BASE + seed);

  const x00 = lerp(c(xi, yi, zi), c(xi + 1, yi, zi), u);
  const x10 = lerp(c(xi, yi + 1, zi), c(xi + 1, yi + 1, zi), u);
  const x01 = lerp(c(xi, yi, zi + 1), c(xi + 1, yi, zi + 1), u);
  const x11 = lerp(c(xi, yi + 1, zi + 1), c(xi + 1, yi + 1, zi + 1), u);

  const y0 = lerp(x00, x10, v);
  const y1 = lerp(x01, x11, v);
  return lerp(y0, y1, w);
}

/** fractal brownian motion, 2D, in [0,1] */
export function fbm2(x: number, z: number, octaves = 4, seed = 0): number {
  let sum = 0;
  let amp = 0.5;
  let norm = 0;
  let fx = x;
  let fz = z;
  for (let o = 0; o < octaves; o++) {
    sum += amp * noise2(fx, fz, seed + o * 31);
    norm += amp;
    amp *= 0.5;
    fx *= 2.02;
    fz *= 2.02;
  }
  return sum / norm;
}

/** ridged multifractal — produces sharp mountainy crests, in [0,1] */
export function ridge2(x: number, z: number, octaves = 4, seed = 0): number {
  let sum = 0;
  let amp = 0.5;
  let norm = 0;
  let fx = x;
  let fz = z;
  for (let o = 0; o < octaves; o++) {
    const n = 1 - Math.abs(noise2(fx, fz, seed + o * 17) * 2 - 1);
    sum += amp * n * n;
    norm += amp;
    amp *= 0.5;
    fx *= 2.07;
    fz *= 1.93;
  }
  return sum / norm;
}

export function smoothstep(edge0: number, edge1: number, x: number): number {
  const t = Math.min(1, Math.max(0, (x - edge0) / (edge1 - edge0 || 1e-6)));
  return t * t * (3 - 2 * t);
}

export function clamp(x: number, lo: number, hi: number): number {
  return x < lo ? lo : x > hi ? hi : x;
}

export function lerpN(a: number, b: number, t: number): number {
  return a + (b - a) * clamp(t, 0, 1);
}

/** terracing: quantises a continuous field into flat bands with soft edges */
export function terrace(value: number, steps: number, softness = 0.35): number {
  const scaled = value * steps;
  const base = Math.floor(scaled);
  const frac = scaled - base;
  const k = smoothstep(0.5 - softness * 0.5, 0.5 + softness * 0.5, frac);
  return (base + k * 0.5) / steps;
}

/** distance from a point to a superellipse (used for organic pond basins) */
export function superellipseDist(x: number, z: number, rx: number, rz: number, exponent = 2.4): number {
  const u = Math.abs(x / rx);
  const v = Math.abs(z / rz);
  return Math.pow(Math.pow(u, exponent) + Math.pow(v, exponent), 1 / exponent);
}
