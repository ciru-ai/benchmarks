/**
 * Deterministic pseudo-random utilities.
 *
 * Every generator in the scene pulls from a seeded RNG so the diorama is
 * byte-for-byte reproducible: the same seed always grows the same garden.
 */

/** mulberry32 — tiny, fast, good enough distribution for scenery. */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function next(): number {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Hash of an integer lattice point → [0,1). Used by the noise field. */
export function hash3(x: number, y: number, z: number, seed: number): number {
  let h = seed ^ (Math.imul(x, 374761393) ^ Math.imul(y, 668265263) ^ Math.imul(z, 1274126177));
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

export class Rng {
  readonly seed: number;
  private next: () => number;

  constructor(seed = 20260112) {
    this.seed = seed;
    this.next = mulberry32(seed);
  }

  /** child stream with an independent sequence */
  fork(tag: number): Rng {
    return new Rng((this.seed ^ Math.imul(tag + 1, 0x9e3779b1)) >>> 0);
  }

  float(): number {
    return this.next();
  }

  range(min: number, max: number): number {
    return min + (max - min) * this.next();
  }

  int(min: number, max: number): number {
    return Math.floor(this.range(min, max + 1));
  }

  /** true with probability p */
  chance(p: number): boolean {
    return this.next() < p;
  }

  pick<T>(items: readonly T[]): T {
    return items[Math.min(items.length - 1, Math.floor(this.next() * items.length))];
  }

  /** weighted pick: [item, weight][] */
  weighted<T>(entries: readonly (readonly [T, number])[]): T {
    let total = 0;
    for (const [, w] of entries) total += w;
    let r = this.next() * total;
    for (const [item, w] of entries) {
      r -= w;
      if (r <= 0) return item;
    }
    return entries[entries.length - 1][0];
  }

  /** roughly gaussian, mean 0 sigma 1 */
  gauss(): number {
    let u = 0;
    let v = 0;
    while (u === 0) u = this.next();
    while (v === 0) v = this.next();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }
}
