/**
 * Pagoda — the five-storied reliquary tower, the heart of the diorama.
 *
 * Built bottom-up from authored parts: stone double terrace, grand stair,
 * komainu guardians, then five stories of vermilion colonnade and plaster
 * lattice, each crowned by a concave tile roof with upswept corner bells, and
 * finally the sōrin finial with its nine rings and a jewel that glows after
 * dusk. Story size, roof radius and rise all scale from one table, so the
 * proportions stay classical.
 */

import { C } from '../core/palette';
import { Rng } from '../core/rng';
import { smoothstep } from '../core/noise';
import { box, column, disc, ellipsoid, line, plate } from '../voxel/brushes';
import { VoxelWorld } from '../voxel/VoxelWorld';
import { eaveBell, stoneLantern, bannerPole } from './structures';
import type { TerrainField } from './terrain';
import { SITE } from './site';

interface StorySpec {
  half: number;
  wallHeight: number;
  roofRise: number;
  roofOverhang: number;
  balcony: boolean;
}

const STORIES: StorySpec[] = [
  { half: 7, wallHeight: 8, roofRise: 5.0, roofOverhang: 5, balcony: false },
  { half: 6, wallHeight: 6, roofRise: 4.4, roofOverhang: 4, balcony: true },
  { half: 5, wallHeight: 5, roofRise: 3.8, roofOverhang: 3, balcony: true },
  { half: 4, wallHeight: 4.5, roofRise: 3.2, roofOverhang: 3, balcony: true },
  { half: 3, wallHeight: 4, roofRise: 2.8, roofOverhang: 2, balcony: false },
];

export interface PagodaParts {
  baseY: number;
  topY: number;
  incensePos: [number, number, number];
  doorPos: [number, number, number];
}

export function buildPagoda(world: VoxelWorld, field: TerrainField): PagodaParts {
  const rng = new Rng(777);
  const cx = SITE.pagoda.x;
  const cz = SITE.pagoda.z;
  const gy = field.top(cx, cz + 14); // terrace surface in front of the stairs
  const stone = (): number =>
    rng.weighted([[C.stone1, 5], [C.stoneWarm, 4], [C.stone2, 3], [C.gravel, 1]]);

  // ---- double stone terrace ------------------------------------------------
  plate(world, cx - 12, cz - 12, cx + 12, cz + 12, gy + 1, stone);
  plate(world, cx - 12, cz - 12, cx + 12, cz + 12, gy + 2, stone);
  plate(world, cx - 10, cz - 10, cx + 10, cz + 10, gy + 3, stone);
  const deckY = gy + 4;
  plate(world, cx - 10, cz - 10, cx + 10, cz + 10, deckY, stone);

  // carved edge course + corner posts with golden caps
  for (let o = -12; o <= 12; o++) {
    world.force('solid', cx + o, gy + 2, cz - 12, o % 4 === 0 ? C.stoneWarm : C.stone2);
    world.force('solid', cx + o, gy + 2, cz + 12, o % 4 === 0 ? C.stoneWarm : C.stone2);
    world.force('solid', cx - 12, gy + 2, cz + o, o % 4 === 0 ? C.stoneWarm : C.stone2);
    world.force('solid', cx + 12, gy + 2, cz + o, o % 4 === 0 ? C.stoneWarm : C.stone2);
  }
  for (const [sx, sz] of [[-12, -12], [12, -12], [-12, 12], [12, 12]] as const) {
    column(world, cx + sx, cz + sz, gy + 1, gy + 5, () => 1.2, C.stoneWarm);
    world.set(cx + sx, gy + 6, cz + sz, C.gold);
  }
  // balustrade around the upper deck (gap at the stair, south side)
  for (let o = -10; o <= 10; o++) {
    if (Math.abs(o) <= 3) continue; // stair opening
    const posts: [number, number][] = [
      [cx + o, cz - 10],
      [cx + o, cz + 10],
      [cx - 10, cz + o],
      [cx + 10, cz + o],
    ];
    for (const [x, z] of posts) {
      if (Math.abs(x - cx) === 10 && Math.abs(z - cz) === 10) continue;
      world.set(x, deckY + 1, z, C.stoneWarm);
      world.set(x, deckY + 2, z, C.stone1);
      if ((o + 10) % 2 === 0) world.set(x, deckY + 3, z, C.goldLight);
    }
  }

  // ---- grand stair (south) --------------------------------------------------
  for (let i = 0; i < 4; i++) {
    const top = deckY - 1 - i;
    const z = cz + 11 + i;
    box(world, cx - 3, gy - 1, z, cx + 3, top, z, stone);
  }
  // stair side walls (kyakumon) with sloped stone
  for (const sx of [-4, 4]) {
    for (let i = 0; i < 4; i++) {
      const z = cz + 11 + i;
      const top = deckY - i;
      column(world, cx + sx, z, gy - 1, top, () => 0.8, C.stoneWarm);
    }
  }

  // ---- komainu guardians -----------------------------------------------------
  komainu(world, cx - 6, cz + 15, gy + 1, rng.fork(1), true);
  komainu(world, cx + 6, cz + 15, gy + 1, rng.fork(2), false);

  // ---- banner poles and incense burner ---------------------------------------
  bannerPole(world, cx - 5, cz + 18, gy + 1, 9);
  bannerPole(world, cx + 5, cz + 18, gy + 1, 9);
  const incensePos: [number, number, number] = [cx, gy + 1, cz + 17];
  incenseBurner(world, incensePos[0], incensePos[1], incensePos[2]);
  stoneLantern(world, cx - 8, cz + 14, gy + 1, 'tall');
  stoneLantern(world, cx + 8, cz + 14, gy + 1, 'tall');

  // ---- stories ----------------------------------------------------------------
  let y = deckY + 1;
  for (let s = 0; s < STORIES.length; s++) {
    const spec = STORIES[s];
    buildStory(world, cx, cz, y, s, spec);
    y += Math.ceil(spec.wallHeight) + 2; // wall + bracket band
    y += buildRoof(world, cx, cz, y, spec, rng.fork(20 + s));
  }

  // finial
  const topY = addFinial(world, cx, cz, y - 1);

  return {
    baseY: deckY,
    topY,
    incensePos,
    doorPos: [cx, deckY + 2, cz + STORIES[0].half],
  };
}

/** one story: floor, colonnade, lattice walls, openings, bracket band */
function buildStory(
  world: VoxelWorld,
  cx: number,
  cz: number,
  y0: number,
  index: number,
  spec: StorySpec,
): void {
  const h = Math.ceil(spec.wallHeight);
  const half = spec.half;

  // floor
  if (spec.balcony) {
    plate(world, cx - half - 2, cz - half - 2, cx + half + 2, cz + half + 2, y0, C.woodDark);
    plate(world, cx - half, cz - half, cx + half, cz + half, y0, C.wood);
    // railing
    for (let o = -half - 2; o <= half + 2; o++) {
      const posts: [number, number][] = [
        [cx + o, cz - half - 2],
        [cx + o, cz + half + 2],
        [cx - half - 2, cz + o],
        [cx + half + 2, cz + o],
      ];
      for (const [x, z] of posts) {
        if (Math.abs(x - cx) === half + 2 && Math.abs(z - cz) === half + 2) continue;
        world.set(x, y0 + 1, z, C.vermilionDeep);
        if ((o + half + 2) % 2 === 0) world.set(x, y0 + 2, z, C.gold);
      }
    }
  } else {
    plate(world, cx - half, cz - half, cx + half, cz + half, y0, C.wood);
  }

  // columns at corners + regular bays
  const colOffsets: number[] = [];
  for (let o = -half; o <= half; o += Math.max(2, Math.floor(half / 2.2))) colOffsets.push(o);
  if (colOffsets[colOffsets.length - 1] !== half) colOffsets.push(half);
  for (const o of colOffsets) {
    for (const [x, z] of [
      [cx + o, cz - half],
      [cx + o, cz + half],
      [cx - half, cz + o],
      [cx + half, cz + o],
    ]) {
      column(world, x, z, y0 + 1, y0 + h, () => 0.6, C.vermilion);
    }
  }

  // walls: plaster infill with dark lattice courses, door + windows
  for (let dy = 1; dy <= h; dy++) {
    for (let o = -half; o <= half; o++) {
      const lattice = dy === 2 || (dy === h - 1 && h > 4);
      const fill = lattice ? C.woodDark : C.plaster;
      for (const [x, z] of [
        [cx + o, cz - half],
        [cx + o, cz + half],
        [cx - half, cz + o],
        [cx + half, cz + o],
      ]) {
        world.set(x, y0 + dy, z, fill);
      }
    }
  }

  // shoji panes: warm paper that burns bright after dusk
  for (let dy = 2; dy <= 3; dy++) {
    for (const o of [-5, -4, 4, 5]) {
      if (Math.abs(o) > half) continue;
      if (dy > h) continue;
      for (const [x, z] of [
        [cx + o, cz + half],
        [cx + o, cz - half],
        [cx + half, cz + o],
        [cx - half, cz + o],
      ]) {
        world.erase('solid', x, y0 + dy, z);
        world.glow(x, y0 + dy, z, C.paper);
      }
    }
  }

  // south entrance (story 1 only gets the full door; upper stories get windows)
  if (index === 0) {
    for (let dy = 1; dy <= Math.min(5, h); dy++)
      for (let o = -1; o <= 1; o++) {
        world.erase('solid', cx + o, y0 + dy, cz + half);
        world.erase('solid', cx + o, y0 + dy, cz + half - (dy < 4 ? 1 : 0));
      }
    // door frame + plaque
    for (const o of [-2, 2]) column(world, cx + o, cz + half, y0 + 1, y0 + 6, () => 0.6, C.vermilionDeep);
    box(world, cx - 2, y0 + 6, cz + half, cx + 2, y0 + 6, cz + half, C.woodDark);
    world.set(cx, y0 + 6, cz + half, C.gold);
    world.set(cx - 1, y0 + 6, cz + half, C.goldLight);
    world.set(cx + 1, y0 + 6, cz + half, C.goldLight);
  } else {
    // circular windows on each face — glowing paper at their hearts
    for (const face of [-1, 1]) {
      for (let o = -2; o <= 2; o++)
        for (let dy = 2; dy <= 4; dy++) {
          const isOnXFaces = Math.abs(o) + Math.abs(dy - 3) <= 2;
          if (!isOnXFaces) continue;
          if (Math.abs(o) === 2 && Math.abs(dy - 3) === 2) continue;
          world.erase('solid', cx + o, y0 + dy, cz + face * half);
          world.erase('solid', cx + face * half, y0 + dy, cz + o);
          if (Math.abs(o) + Math.abs(dy - 3) <= 1) {
            world.glow(cx + o, y0 + dy, cz + face * half, C.paper);
            world.glow(cx + face * half, y0 + dy, cz + o, C.paper);
          } else {
            world.set(cx + o, y0 + dy, cz + face * half, C.woodDark);
            world.set(cx + face * half, y0 + dy, cz + o, C.woodDark);
          }
        }
    }
  }

  // interior: shrine fittings on the ground floor
  if (index === 0) {
    column(world, cx, cz, y0 + 1, y0 + h, () => 1.1, C.timber); // shinbashira
    world.set(cx, y0 + 1, cz, C.gold);
    // reliquary glow at the pillar foot
    world.glow(cx - 1, y0 + 1, cz - 1, C.jadeGlow);
    world.glow(cx + 1, y0 + 1, cz - 1, C.jadeGlow);
    world.glow(cx - 1, y0 + 1, cz + 1, C.jadeGlow);
    world.glow(cx + 1, y0 + 1, cz + 1, C.jadeGlow);
    // altar
    box(world, cx - 2, y0 + 1, cz - half + 2, cx + 2, y0 + 2, cz - half + 2, C.lacquerRed);
    world.glow(cx, y0 + 3, cz - half + 2, C.spiritPink);
    world.set(cx - 1, y0 + 3, cz - half + 2, C.gold);
    world.set(cx + 1, y0 + 3, cz - half + 2, C.gold);
  } else {
    // upper chambers keep a paper lantern burning
    world.glow(cx, y0 + h, cz, C.lanternPaper);
  }

  // bracket band (tokyō): projecting gold teeth under the eaves
  const bandY = y0 + h + 1;
  for (let o = -half - 1; o <= half + 1; o++) {
    const pattern = ((o + half + 1) % 3 + 3) % 3;
    const color = pattern === 0 ? C.gold : pattern === 1 ? C.vermilionLight : C.vermilionDeep;
    for (const [x, z] of [
      [cx + o, cz - half - 1],
      [cx + o, cz + half + 1],
      [cx - half - 1, cz + o],
      [cx + half + 1, cz + o],
    ]) {
      world.set(x, bandY, z, color);
    }
  }
}

/**
 * Concave tiled roof with upswept corners. Square rings rise by a soft power
 * curve; cells near the diagonals get an extra lift, which is what sweeps the
 * hips skyward. The eave course carries a gold trim and a dark soffit.
 * Returns the roof height (stories stack from the returned y).
 */
function buildRoof(
  world: VoxelWorld,
  cx: number,
  cz: number,
  yBase: number,
  spec: StorySpec,
  rng: Rng,
): number {
  const rMax = spec.half + spec.roofOverhang;
  const rTop = Math.max(1, Math.round(spec.half * 0.5));
  const rise = spec.roofRise;
  let apex = 0;

  for (let r = rMax; r >= rTop; r--) {
    const t = (rMax - r) / Math.max(1, rMax - rTop);
    const y = yBase + Math.round(rise * Math.pow(t, 1.28));
    apex = Math.max(apex, y - yBase);
    for (let dx = -r; dx <= r; dx++) {
      for (let dz = -r; dz <= r; dz++) {
        const cheb = Math.max(Math.abs(dx), Math.abs(dz));
        if (cheb !== r) continue;
        const diag = Math.min(Math.abs(dx), Math.abs(dz));
        // corner sweep: strong at the eave corner, fading inward
        const cornerT = smoothstep(rTop * 0.4, rMax, diag);
        const lift = Math.round(cornerT * 2.6 * (1 - t * 0.3));
        const yy = y + lift;
        const isEave = r === rMax;
        const isRidge = r <= rTop + 1;
        let color: number;
        if (isEave) color = C.jadeLight;
        else if (isRidge) color = C.gold;
        else color = ((yy + dx + dz) % 4 < 2 ? C.jade : C.jadeDark);
        if (rng.chance(0.05)) color = C.tealRoof; // occasional moss-taken tile
        world.set(cx + dx, yy, cz + dz, color);
        // soffit under the eave overhang
        if (isEave) world.set(cx + dx, yy - 1, cz + dz, C.woodDark);
        // hip roll: gold ridge line along the diagonals
        if (!isEave && !isRidge && diag === r) world.set(cx + dx, yy, cz + dz, C.goldDeep);
      }
    }
    // corner bells hang from the four eave tips
    if (r === rMax) {
      for (const [sx, sz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]] as const) {
        const bx = cx + sx * rMax;
        const bz = cz + sz * rMax;
        eaveBell(world, bx, yBase - 1 + 3, bz, rng);
      }
    }
  }

  // hanging lanterns under the first roof's corners
  if (spec.half >= 7) {
    for (const [sx, sz] of [[-1, 0], [1, 0], [0, -1], [0, 1]] as const) {
      const lx = cx + sx * (spec.half + 2);
      const lz = cz + sz * (spec.half + 2);
      world.set(lx, yBase - 1, lz, C.ironDark);
      world.glow(lx, yBase - 2, lz, C.lanternPaper);
      world.glow(lx, yBase - 3, lz, C.lanternGlow);
    }
  }

  return apex + 1;
}

/** the sōrin: mast, nine rings, wind-catchers and the sacred jewel */
function addFinial(world: VoxelWorld, cx: number, cz: number, y: number): number {
  const mast = 7;
  column(world, cx, cz, y, y + mast, () => 0.55, C.gold);
  for (let i = 0; i < 9; i++) {
    const ry = y + 1 + i * 0.66;
    const r = i < 4 ? 2 : 1.4;
    disc(world, cx, cz, Math.round(ry), r, i % 2 ? C.goldLight : C.brass);
    world.set(cx, Math.round(ry), cz, C.gold);
  }
  const jewelY = y + mast + 1;
  world.glow(cx, jewelY, cz, C.jadeGlow);
  world.glow(cx, jewelY + 1, cz, C.spiritGreen);
  world.set(cx, jewelY + 2, cz, C.goldLight);
  // flame-like flames around the jewel (kaen renge)
  for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
    world.set(cx + dx, jewelY, cz + dz, C.gold);
  }
  return jewelY + 2;
}

/** guardian lion-dog (komainu) — one speaks, one keeps silence */
function komainu(
  world: VoxelWorld,
  x: number,
  z: number,
  y: number,
  rng: Rng,
  mouthOpen: boolean,
): void {
  const stone = (): number =>
    rng.weighted([[C.stoneWarm, 5], [C.stone1, 4], [C.stone2, 2]]);
  // pedestal
  box(world, x - 2, y, z - 2, x + 2, y + 1, z + 2, stone);
  // seated body
  ellipsoid(world, x, y + 3.2, z - 0.4, 1.9, 1.9, 1.6, stone);
  // chest and front legs
  ellipsoid(world, x, y + 2.4, z + 0.9, 1.3, 1.2, 1.0, stone);
  world.set(x - 1, y + 2, z + 2, stone());
  world.set(x + 1, y + 2, z + 2, stone());
  // mane: rough collar of voxels
  for (const [dx, dz] of [[-2, -1], [2, -1], [-2, 0], [2, 0], [-1, -2], [1, -2], [0, -2]] as const) {
    world.set(x + dx, y + 4, z + dz, stone());
    if (rng.chance(0.6)) world.set(x + dx, y + 5, z + dz, stone());
  }
  // head
  ellipsoid(world, x, y + 5.4, z + 0.3, 1.3, 1.1, 1.2, stone);
  // ears
  world.set(x - 1, y + 6, z - 0.4, stone());
  world.set(x + 1, y + 6, z - 0.4, stone());
  // face
  world.set(x, y + 5, z + 1, stone());
  world.set(x - (mouthOpen ? 1 : 0), y + 5, z + 1, C.onyx);
  if (mouthOpen) world.set(x + 1, y + 5, z + 1, C.onyx);
  world.set(x, y + 6, z + 1, C.onyx); // eyes shadow
  // curled tail
  world.set(x, y + 4, z - 2, stone());
  world.set(x, y + 5, z - 2, stone());
  // horn (some komainu have one)
  world.set(x, y + 6, z - 1, C.stone1);
}

/** bronze incense burner with live embers (smoke handled by the fx layer) */
function incenseBurner(world: VoxelWorld, x: number, y: number, z: number): void {
  box(world, x - 1, y, z - 1, x + 1, y, z + 1, C.stone2);
  for (const [dx, dz] of [[-1, -1], [1, -1], [-1, 1], [1, 1], [0, 0]] as const) {
    world.set(x + dx, y + 1, z + dz, C.bronze);
  }
  box(world, x - 2, y + 2, z - 2, x + 2, y + 3, z + 2, C.bronze);
  for (let dx = -2; dx <= 2; dx++)
    for (let dz = -2; dz <= 2; dz++) {
      if (Math.abs(dx) === 2 || Math.abs(dz) === 2) world.set(x + dx, y + 4, z + dz, C.goldDeep);
    }
  world.glow(x, y + 3, z, C.ember);
  world.glow(x - 1, y + 3, z, C.ember);
  world.glow(x + 1, y + 3, z + 1, C.ember);
  void line;
  void disc;
}
