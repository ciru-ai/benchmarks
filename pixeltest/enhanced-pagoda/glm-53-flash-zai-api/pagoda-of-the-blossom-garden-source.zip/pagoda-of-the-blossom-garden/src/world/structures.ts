/**
 * Structures — reusable garden furniture.
 *
 * Stone lanterns, banners, fences, wells: small multi-part builds that more
 * than one district places, kept here so a lantern by the pond and one on the
 * temple terrace are literally the same sculpture.
 */

import { C } from '../core/palette';
import { Rng } from '../core/rng';
import { box, column, disc, ellipsoid, line, plate } from '../voxel/brushes';
import { VoxelWorld } from '../voxel/VoxelWorld';

/** classic stone tōrō: base, post, light box, lotus cap, finial */
export function stoneLantern(
  world: VoxelWorld,
  x: number,
  z: number,
  y: number,
  scale: 'small' | 'tall' = 'small',
  lit = true,
): number {
  const rng = new Rng(x * 733 + z * 191 + 7);
  const stone = (): number =>
    rng.weighted([[C.stone1, 5], [C.stoneWarm, 4], [C.stone2, 3], [C.mossStone, 1]]);
  const h = scale === 'tall' ? 6 : 4;

  box(world, x - 1, y, z - 1, x + 1, y, z + 1, stone); // footing
  column(world, x, z, y + 1, y + h, () => 0.7, stone); // post
  box(world, x - 1, y + h + 1, z - 1, x + 1, y + h + 1, z + 1, stone); // platform
  // light box: glow slits with a bright core
  for (let dy = 0; dy < 2; dy++)
    for (let dx = -1; dx <= 1; dx++)
      for (let dz = -1; dz <= 1; dz++) {
        const edge = Math.abs(dx) === 1 || Math.abs(dz) === 1;
        if (dy === 1 && dx === 0 && dz === 0) continue;
        if (edge && dy === (dx === 0 || dz === 0 ? 0 : 1)) {
          if (lit) world.glow(x + dx, y + h + 2 + dy, z + dz, C.lanternPaper);
          else world.set(x + dx, y + h + 2 + dy, z + dz, C.onyx);
        } else if (!edge || dy === 1) {
          world.set(x + dx, y + h + 2 + dy, z + dz, stone());
        }
      }
  if (lit) world.glow(x, y + h + 2, z, C.lanternGlow);
  box(world, x - 2, y + h + 4, z - 2, x + 2, y + h + 4, z + 2, stone); // wide cap
  box(world, x - 1, y + h + 5, z - 1, x + 1, y + h + 5, z + 1, stone);
  world.set(x, y + h + 6, z, rng.chance(0.5) ? C.stone3 : C.mossStone); // finial
  return y + h + 7;
}

/** a pole with a long vertical banner (nobori); returns pole top y */
export function bannerPole(
  world: VoxelWorld,
  x: number,
  z: number,
  y: number,
  height: number,
  cloth: number = C.vermilion,
): number {
  column(world, x, z, y, y + height, () => 0.4, C.woodDark);
  world.set(x, y + height + 1, z, C.gold);
  // crossbar + hanging cloth
  world.set(x, y + height - 1, z + 1, C.woodDark);
  world.set(x, y + height - 1, z - 1, C.woodDark);
  for (let dy = 0; dy < height - 2; dy++) {
    world.set(x, y + height - 2 - dy, z + 1, dy % 3 === 2 ? C.goldLight : cloth);
  }
  world.set(x, y + height - 1 - (height - 2), z + 1, C.paper);
  return y + height + 2;
}

/** low wooden fence segment along a line (tamagaki) */
export function fenceLine(
  world: VoxelWorld,
  ax: number,
  az: number,
  bx: number,
  bz: number,
  y: number,
): void {
  const len = Math.ceil(Math.hypot(bx - ax, bz - az));
  for (let i = 0; i <= len; i++) {
    const t = i / Math.max(1, len);
    const x = Math.round(ax + (bx - ax) * t);
    const z = Math.round(az + (bz - az) * t);
    const post = i % 3 === 0;
    world.set(x, y + 1, z, post ? C.woodDark : C.wood);
    world.set(x, y + 2, z, C.wood);
    if (post) world.set(x, y + 3, z, C.woodDark);
  }
}

/** rectangular fence ring with a gap on one side */
export function fenceRing(
  world: VoxelWorld,
  cx: number,
  cz: number,
  half: number,
  y: number,
  gap?: { side: 'n' | 's' | 'e' | 'w'; from: number; to: number },
): void {
  for (let o = -half; o <= half; o++) {
    const cells: [number, number][] = [
      [cx + o, cz - half],
      [cx + o, cz + half],
      [cx - half, cz + o],
      [cx + half, cz + o],
    ];
    for (const [x, z] of cells) {
      const isNS = Math.abs(z - cz) === half;
      const along = isNS ? x - cx : z - cz;
      if (gap) {
        const onGapSide =
          (gap.side === 'n' && z === cz - half) ||
          (gap.side === 's' && z === cz + half) ||
          (gap.side === 'w' && x === cx - half) ||
          (gap.side === 'e' && x === cx + half);
        if (onGapSide && along >= gap.from && along <= gap.to) continue;
      }
      const post = ((along + half) % 3 + 3) % 3 === 0;
      world.set(x, y + 1, z, post ? C.woodDark : C.wood);
      world.set(x, y + 2, z, C.wood);
      if (post) {
        world.set(x, y + 3, z, C.woodDark);
        world.set(x, y + 4, z, C.goldLight); // finial knob
      }
    }
  }
}

/** weathered rock cluster (arranged, iwa-otoshi style) */
export function rockCluster(
  world: VoxelWorld,
  x: number,
  z: number,
  y: number,
  size: number,
  rng: Rng,
): void {
  const n = 2 + Math.floor(rng.float() * 3);
  for (let i = 0; i < n; i++) {
    const rx = rng.range(size * 0.5, size);
    const ry = rng.range(size * 0.4, size * 0.8);
    const ox = rng.range(-size, size);
    const oz = rng.range(-size, size);
    ellipsoid(world, x + ox, y + ry, z + oz, rx, ry, rx * rng.range(0.7, 1.1), (_px, py, _pz) =>
      rng.weighted([
        [C.stone2, 5],
        [C.stone3, 4],
        [C.granite, 3],
        [py > y + ry * 0.6 ? C.stone1 : C.mossStone, 2],
      ]),
    );
  }
}

/** lily pad cluster on open water */
export function lilyPad(world: VoxelWorld, x: number, z: number, y: number, rng: Rng): void {
  const r = rng.chance(0.3) ? 1.4 : 1;
  disc(world, x, z, y, r, rng.weighted([[C.pineGreen, 5], [C.fern, 3], [C.moss, 2]]));
  if (rng.chance(0.35)) {
    world.set(x, y + 1, z, rng.weighted([[C.blossom1, 4], [C.blossom2, 3], [C.white, 2]]));
    if (rng.chance(0.4)) world.set(x, y + 2, z, C.blossomDeep);
  }
}

/** wooden well with a little shingled roof */
export function well(world: VoxelWorld, x: number, z: number, y: number): void {
  box(world, x - 1, y + 1, z - 1, x + 1, y + 2, z + 1, C.stone2);
  world.set(x, y + 1, z, C.waterDeep);
  column(world, x - 2, z, y + 1, y + 5, () => 0.4, C.woodDark);
  column(world, x + 2, z, y + 1, y + 5, () => 0.4, C.woodDark);
  box(world, x - 3, y + 6, z, x + 3, y + 6, z, C.tealRoof);
  box(world, x - 2, y + 7, z, x + 2, y + 7, z, C.jade);
  world.set(x, y + 8, z, C.gold);
  // windlass
  world.set(x, y + 5, z, C.woodDark);
  world.set(x, y + 4, z, C.cedar);
  world.set(x, y + 3, z, C.cedar);
}

/** simple wooden bench */
export function bench(world: VoxelWorld, x: number, z: number, y: number, alongX: boolean): void {
  if (alongX) {
    box(world, x - 2, y + 1, z, x + 2, y + 1, z, C.woodLight);
    world.set(x - 2, y, z, C.woodDark);
    world.set(x + 2, y, z, C.woodDark);
  } else {
    box(world, x, y + 1, z - 2, x, y + 1, z + 2, C.woodLight);
    world.set(x, y, z - 2, C.woodDark);
    world.set(x, y, z + 2, C.woodDark);
  }
}

/** flower bed ring (for around structures) */
export function flowerBed(
  world: VoxelWorld,
  cx: number,
  cz: number,
  y: number,
  rx: number,
  rz: number,
  rng: Rng,
): void {
  const blooms = [C.tulipRed, C.tulipYellow, C.tulipPink, C.bluebell, C.poppyOrange, C.white];
  for (let dx = -rx; dx <= rx; dx++)
    for (let dz = -rz; dz <= rz; dz++) {
      const d = Math.hypot(dx / rx, dz / rz);
      if (d > 1) continue;
      world.set(cx + dx, y, cz + dz, C.soilDark);
      if (rng.chance(0.4)) world.set(cx + dx, y + 1, cz + dz, C.fern);
      if (rng.chance(0.34)) world.set(cx + dx, y + 1, cz + dz, rng.pick(blooms));
    }
}

/** hanging wind chime / bell under an eave tip */
export function eaveBell(world: VoxelWorld, x: number, y: number, z: number, rng: Rng): void {
  world.set(x, y, z, C.ironDark); // hook
  world.set(x, y - 1, z, C.iron);
  world.set(x, y - 2, z, C.bronze);
  if (rng.chance(0.7)) world.set(x, y - 3, z, C.goldLight); // chime strip
}

/** rope with paper streamers (shimenawa) strung between two points */
export function sacredRope(
  world: VoxelWorld,
  ax: number,
  ay: number,
  az: number,
  bx: number,
  by: number,
  bz: number,
): void {
  const len = Math.ceil(Math.hypot(bx - ax, by - ay, bz - az));
  for (let i = 0; i <= len; i++) {
    const t = i / Math.max(1, len);
    const x = Math.round(ax + (bx - ax) * t);
    const z = Math.round(az + (bz - az) * t);
    const sag = Math.round(Math.sin(t * Math.PI) * -2);
    const y = Math.round(ay + (by - ay) * t) + sag;
    world.set(x, y, z, i % 4 === 2 ? C.cedar : C.woodDark);
    if (i % 5 === 2) world.set(x, y - 1, z, C.paper);
  }
}

/**stepping stone path across shallow water or gravel */
export function steppingStones(
  world: VoxelWorld,
  points: [number, number][],
  y: number | ((x: number, z: number) => number),
): void {
  for (const [x, z] of points) {
    const yy = typeof y === 'function' ? y(x, z) : y;
    plate(world, x - 1, z - 1, x + 1, z + 1, yy, C.stone2);
    world.set(x, yy, z, C.stone1);
  }
  void line;
}
