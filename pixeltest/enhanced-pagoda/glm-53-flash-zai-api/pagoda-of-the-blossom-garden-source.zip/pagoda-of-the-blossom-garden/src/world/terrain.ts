/**
 * Terrain — a floating island of layered stone under a living skin.
 *
 * Each column is written top-down: turf or gravel or snow on the surface,
 * a few cells of earth, then stratified rock that fades to a rugged keel
 * underneath the island. Surface material is chosen from slope, altitude and
 * proximity to water, so cliffs, beaches, alpine snow and mossy hollows all
 * fall out of the same height field instead of being painted by hand.
 */

import { C } from '../core/palette';
import { fbm2, noise2, noise3, smoothstep, clamp, lerpN } from '../core/noise';
import { Rng } from '../core/rng';
import { VoxelWorld } from '../voxel/VoxelWorld';
import { ISLAND_R, SITE, WATER_Y, landHeight, pondField, riverField } from './site';

export interface TerrainField {
  /** integer top-cell height of the natural ground */
  top(x: number, z: number): number;
  /** how vertical the surface is here (0 flat … 1 cliff) */
  slope(x: number, z: number): number;
  isWater(x: number, z: number): boolean;
  /** organic island outline, 1 inside 0 outside */
  islandMask(x: number, z: number): number;
  /** lowest natural rock cell under a column */
  underside(x: number, z: number): number;
  radius: number;
}

function islandNoise(x: number, z: number): number {
  return (fbm2(x * 0.034 + 40, z * 0.034 - 17, 3, 611) - 0.5) * 18;
}

export function islandMask(x: number, z: number): number {
  const r = Math.hypot(x, z) + islandNoise(x, z);
  return 1 - smoothstep(ISLAND_R - 5, ISLAND_R + 5, r);
}

function underside(x: number, z: number): number {
  const r = Math.hypot(x, z);
  const t = clamp(1 - r / (ISLAND_R + 4), 0, 1);
  const keel = lerpN(0, -40, Math.pow(t, 1.45));
  const ridges = (fbm2(x * 0.06 - 9, z * 0.06 + 21, 4, 313) - 0.5) * 16 * t;
  return Math.round(keel + ridges);
}

function topHeight(x: number, z: number): number {
  return Math.round(landHeight(x, z));
}

function slopeAt(x: number, z: number): number {
  const h = landHeight(x, z);
  let d = 0;
  for (const [ox, oz] of [
    [1, 0],
    [-1, 0],
    [0, 1],
    [0, -1],
    [1, 1],
    [-1, -1],
  ]) {
    d = Math.max(d, Math.abs(landHeight(x + ox, z + oz) - h));
  }
  return clamp(d / 3.2, 0, 1);
}

/** pick the surface palette index for one cell */
function surfaceColor(x: number, z: number, h: number, sl: number, rng: Rng): number {
  const nearWater = Math.max(pondField(x, z), riverField(x, z));

  // snow line on the sacred peak
  if (h > 33 && sl < 0.6) return h > 42 ? C.snow : rng.chance(0.55) ? C.snow : C.stone1;

  // cliffs and scree
  if (sl > 0.62) return rng.weighted([[C.stone2, 4], [C.stone3, 3], [C.granite, 2], [C.mossStone, 2]]);
  if (sl > 0.4) {
    // slopes green over as they ease down
    const green = smoothstep(0.4, 0.55, 1 - sl) * smoothstep(34, 20, h);
    return rng.weighted(
      green > 0.5
        ? [[C.mossStone, 3], [C.grassDeep, 3], [C.stone1, 2], [C.moss, 2]]
        : [[C.mossStone, 2], [C.stone1, 3], [C.gravel, 2], [C.grassDeep, 1]],
    );
  }

  // beaches and shallows
  if (nearWater > 0.05) {
    return rng.weighted([[C.sand, 5], [C.sandLight, 3], [C.pebble, 3], [C.gravel, 2]]);
  }

  // zen raked sand court
  const zen = Math.hypot((x - SITE.zenGarden.x) * 1.25, z - SITE.zenGarden.z);
  if (zen < 13) return rng.chance(0.05) ? C.gravel : C.zenSand;

  // temple terrace
  const plaza = Math.hypot(x - SITE.plaza.x, (z - SITE.plaza.z) * 1.08);
  if (plaza < 15) return rng.weighted([[C.stoneWarm, 4], [C.stone1, 3], [C.gravel, 2]]);

  // upland meadow → mossy hollow
  const meadow = fbm2(x * 0.045, z * 0.045, 3, 77);
  if (h > 24) return rng.weighted([[C.dryGrass, 4], [C.grass3, 2], [C.mossLight, 1]]);
  if (meadow > 0.62) return rng.weighted([[C.moss, 3], [C.mossLight, 2], [C.grassDeep, 2]]);
  return rng.weighted([
    [C.grass1, 6],
    [C.grass2, 4],
    [C.grass3, 3],
    [C.clover, 1],
  ]);
}

const STRATA: { band: number; colors: number[] }[] = [
  { band: 0, colors: [C.dirt, C.soilDark, C.clay] },
  { band: 1, colors: [C.stoneWarm, C.stone1, C.dirt] },
  { band: 2, colors: [C.stone2, C.stone3, C.stone1] },
  { band: 3, colors: [C.granite, C.stone3, C.slateBlue] },
  { band: 4, colors: [C.granite, C.onyx, C.stone3] },
];

export function generateTerrain(world: VoxelWorld, field: TerrainField): void {
  const rng = new Rng(4242);
  const R = field.radius;

  for (let x = -R; x <= R; x++) {
    for (let z = -R; z <= R; z++) {
      const mask = islandMask(x, z);
      if (mask < 0.04) continue;

      const h = topHeight(x, z);
      const sl = slopeAt(x, z);
      const surf = surfaceColor(x, z, h, sl, rng);
      const bottom = Math.min(h - 2, underside(x, z));

      // living skin
      world.set(x, h, z, surf);

      // earth band: thicker on gentle ground, pinched out on cliffs
      const soilDepth = Math.round(lerpN(1, 4, 1 - sl));
      for (let d = 1; d <= soilDepth; d++) {
        const y = h - d;
        if (y <= bottom) break;
        const t = 1 - d / (soilDepth + 1);
        world.set(x, y, z, rng.weighted([[C.dirt, 4 * t + 1], [C.soilDark, 2], [C.clay, 1]]));
      }

      // stratified rock: bands wander with low-frequency noise so strata curve
      for (let y = h - soilDepth - 1; y >= bottom; y--) {
        const bandNoise = noise3(x * 0.06, y * 0.11, z * 0.06, 88) * 2.4;
        const band = clamp(Math.floor((h - y) / 7 + bandNoise * 0.5), 0, STRATA.length - 1);
        let color = rng.pick(STRATA[band].colors);
        // mineral seams — a hint of buried amber and jade
        const vein = noise3(x * 0.24, y * 0.3, z * 0.24, 404);
        if (vein > 0.86) color = rng.chance(0.5) ? C.goldDeep : C.jadeDark;
        world.set(x, y, z, color);
      }
    }
  }

  // beach foam line: a rim of pale stone right at the waterline
  for (let x = -R; x <= R; x++) {
    for (let z = -R; z <= R; z++) {
      if (pondField(x, z) > 0.02 && riverField(x, z) < 0.3) {
        const h = topHeight(x, z);
        if (h >= WATER_Y - 1 && h <= WATER_Y + 1) {
          world.force('solid', x, h, z, rng.chance(0.45) ? C.sandLight : C.pebble);
        }
      }
    }
  }
}

export function makeField(): TerrainField {
  return {
    top: topHeight,
    slope: slopeAt,
    isWater: (x, z) => topHeight(x, z) < WATER_Y - 0.4,
    islandMask,
    underside,
    radius: ISLAND_R + 2,
  };
}

/** dangling roots and hanging soil under the island's rim — sells the float */
export function addIslandKeelDetail(world: VoxelWorld, field: TerrainField): void {
  const rng = new Rng(909);
  const R = field.radius;
  for (let x = -R; x <= R; x += 1) {
    for (let z = -R; z <= R; z += 1) {
      const r = Math.hypot(x, z);
      if (r > ISLAND_R + 3 || r < 26) continue;
      if (!world.has('solid', x, topHeight(x, z), z)) continue;
      const bottom = underside(x, z);
      const t = clamp((r - 26) / (ISLAND_R - 24), 0, 1);
      if (!rng.chance(0.02 + t * 0.05)) continue;
      const len = rng.int(2, 9);
      for (let i = 1; i <= len; i++) {
        const y = bottom - i;
        if (y < -56) break;
        world.set(x, y, z, i > len - 3 ? C.bark : C.granite);
        if (rng.chance(0.15)) world.set(x + 1, y, z, C.bark);
      }
    }
  }
}

/** moss and lichen patches creeping over stone-heavy ground */
export function addMossPatches(world: VoxelWorld, rng: Rng): void {
  const spots = rng.int(260, 340);
  for (let i = 0; i < spots; i++) {
    const a = rng.float() * Math.PI * 2;
    const r = Math.sqrt(rng.float()) * (ISLAND_R - 6);
    const cx = Math.round(Math.cos(a) * r);
    const cz = Math.round(Math.sin(a) * r);
    const y = topHeight(cx, cz);
    if (y < WATER_Y) continue;
    const size = rng.int(1, 3);
    for (let dx = -size; dx <= size; dx++)
      for (let dz = -size; dz <= size; dz++) {
        if (dx * dx + dz * dz > size * size) continue;
        const c = world.get(cx + dx, y, cz + dz);
        if (c === undefined) continue;
        if (c === C.stone1 || c === C.stone2 || c === C.stone3 || c === C.stoneWarm) {
          world.force('solid', cx + dx, y, cz + dz, rng.chance(0.4) ? C.moss : C.mossStone);
        }
      }
  }
}

/** grass tufts and wildflowers poking out of the turf */
export function addGroundFlora(world: VoxelWorld, field: TerrainField, rng: Rng): void {
  const counts = 2100;
  const flowers = [
    C.poppyOrange,
    C.tulipRed,
    C.tulipYellow,
    C.tulipPink,
    C.bluebell,
    C.pollen,
    C.blossom1,
    C.white,
  ];
  for (let i = 0; i < counts; i++) {
    const a = rng.float() * Math.PI * 2;
    const r = Math.sqrt(rng.float()) * (ISLAND_R - 8);
    const x = Math.round(Math.cos(a) * r);
    const z = Math.round(Math.sin(a) * r);
    const y = field.top(x, z);
    if (y < WATER_Y + 1) continue;
    if (field.slope(x, z) > 0.45) continue;
    // keep the temple terrace and the raked court clean
    if (Math.hypot(x, z - 8) < 19) continue;
    if (Math.hypot((x - SITE.zenGarden.x) * 1.25, z - SITE.zenGarden.z) < 15) continue;
    // flowers grow in drifts, not confetti
    const n = noise2(x * 0.085, z * 0.085, 555) * 0.72 + noise2(x * 0.3, z * 0.3, 777) * 0.28;
    if (n < 0.56) continue;
    if (rng.chance(0.68)) continue;
    const h = rng.int(1, 2);
    for (let d = 1; d <= h; d++) world.set(x, y + d, z, d === h ? C.fern : C.grassDeep);
    if (rng.chance(0.42)) {
      world.set(x, y + h + 1, z, rng.pick(flowers));
      if (rng.chance(0.2)) world.set(x + 1, y + h, z, rng.pick(flowers));
    }
  }
}
