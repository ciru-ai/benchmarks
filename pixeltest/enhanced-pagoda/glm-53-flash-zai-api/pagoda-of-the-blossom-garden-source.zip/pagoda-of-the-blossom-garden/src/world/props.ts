/**
 * Props — the furniture that makes the garden feel tended.
 *
 * Torii gates, an arched bridge, a bell tower, the tea house, a raked zen
 * court, lantern rows, a well, stupas, a wisteria trellis, lily pads, turtles,
 * a string of festival lanterns across the avenue. Each is small; together
 * they give the eye a dozen little stories to find.
 */

import { C } from '../core/palette';
import { Rng } from '../core/rng';
import { box, column, disc, ellipsoid, line, plate } from '../voxel/brushes';
import { VoxelWorld } from '../voxel/VoxelWorld';
import {
  bench,
  fenceLine,
  flowerBed,
  lilyPad,
  rockCluster,
  sacredRope,
  steppingStones,
  stoneLantern,
  well,
} from './structures';
import type { TerrainField } from './terrain';
import { SITE, WATER_Y, pondField, shoreFactor } from './site';

export interface PropAnchors {
  festivalLanterns: [number, number, number][];
  teaSmoke: [number, number, number];
  bellPos: [number, number, number];
  incenseSmoke: [number, number, number];
}

/** vermilion torii gate with upswept kasagi */
export function toriiGate(
  world: VoxelWorld,
  cx: number,
  cz: number,
  groundY: number,
  scale: 'grand' | 'small' = 'grand',
): void {
  const rng = new Rng(cx * 13 + cz * 71);
  const red = (): number => rng.weighted([[C.vermilion, 6], [C.vermilionDeep, 2], [C.vermilionLight, 1]]);
  const h = scale === 'grand' ? 11 : 7;
  const half = scale === 'grand' ? 6 : 4;

  // pillars (slightly inclined inward)
  for (const s of [-1, 1]) {
    for (let dy = 0; dy < h; dy++) {
      const inn = Math.round(dy * 0.08);
      column(world, cx + s * (half - inn), cz, groundY + dy, groundY + dy, () => 0.8, red);
    }
    // pillar bases
    box(world, cx + s * half - 1, groundY, cz - 1, cx + s * half + 1, groundY, cz + 1, C.stoneWarm);
  }

  // nuki (lower beam) passing through the pillars
  box(world, cx - half - 1, groundY + h - 4, cz, cx + half + 1, groundY + h - 3, cz, red);
  // gakuzuka + plaque between the beams
  world.set(cx, groundY + h - 2, cz, C.vermilionDeep);
  box(world, cx - 1, groundY + h - 2, cz + 1, cx + 1, groundY + h - 2, cz - 1, C.woodDark);
  world.set(cx, groundY + h - 2, cz, C.gold);

  // kasagi (top beam) with upturned ends + shimaki underneath
  for (let dx = -half - 2; dx <= half + 2; dx++) {
    const endLift = Math.round(Math.pow(Math.abs(dx) / (half + 2), 3) * 3);
    const y = groundY + h + endLift;
    world.set(cx + dx, y, cz, red());
    world.set(cx + dx, y, cz - 1, red());
    world.set(cx + dx, y - 1, cz, dx % 3 === 0 ? C.vermilionDeep : C.vermilionLight);
  }
  // gold cap on the very ends
  for (const s of [-1, 1]) {
    world.set(cx + s * (half + 2), groundY + h + 3, cz, C.goldLight);
  }
  // hanging festival lanterns from the kasagi
  if (scale === 'grand') {
    for (const s of [-4, 0, 4]) {
      const lx = cx + s;
      const ly = groundY + h - 1;
      world.set(lx, ly, cz + 1, C.ironDark);
      world.glow(lx, ly - 1, cz + 1, C.lanternPaper);
      world.glow(lx, ly - 2, cz + 1, C.lanternGlow);
    }
  }
}

/** arched drum bridge (taikobashi) with vermilion railing */
export function archedBridge(
  world: VoxelWorld,
  cx: number,
  cz: number,
  groundY: number,
  spanHalf: number,
  rise: number,
  width: number,
): void {
  const hw = Math.floor(width / 2);
  for (let i = -spanHalf; i <= spanHalf; i++) {
    const t = i / spanHalf;
    const h = Math.round(rise * (1 - t * t) * (1 - t * t * 0.15));
    for (let dz = -hw; dz <= hw; dz++) {
      world.set(cx + i, groundY + 1 + h, cz + dz, i % 4 === 0 ? C.wood : C.woodLight);
    }
    // approach ramps fill to the ground at the ends
    if (Math.abs(i) > spanHalf - 2) {
      for (let dy = 0; dy <= h; dy++) {
        for (let dz = -hw; dz <= hw; dz++) world.set(cx + i, groundY + 1 + dy, cz + dz, C.woodDark);
      }
    }
    // railings: posts + top rail
    if (i % 2 === 0 || Math.abs(i) === spanHalf) {
      for (const s of [-1, 1]) {
        const rz = cz + s * (hw + 1);
        world.set(cx + i, groundY + 2 + h, rz, C.vermilion);
        world.set(cx + i, groundY + 3 + h, rz, i % 4 === 0 ? C.goldLight : C.vermilionDeep);
      }
    } else {
      for (const s of [-1, 1]) {
        world.set(cx + i, groundY + 3 + h, cz + s * (hw + 1), C.vermilionDeep);
      }
    }
  }
}

/** bell tower (shōrō) with a swinging bronze bonshō */
export function bellTower(
  world: VoxelWorld,
  cx: number,
  cz: number,
  groundY: number,
): [number, number, number] {
  const h = 7;
  // stone base + steps
  plate(world, cx - 4, cz - 4, cx + 4, cz + 4, groundY + 1, C.stone2);
  plate(world, cx - 3, cz - 3, cx + 3, cz + 3, groundY + 2, C.stone1);
  for (let i = 0; i < 3; i++) box(world, cx - 1, groundY + 1, cz + 3 + i, cx + 1, groundY + 1, cz + 3 + i, C.stone2);
  const deckY = groundY + 2;

  // corner posts
  for (const [sx, sz] of [[-3, -3], [3, -3], [-3, 3], [3, 3]] as const) {
    column(world, cx + sx, cz + sz, deckY + 1, deckY + h, () => 0.7, C.vermilionDeep);
  }
  // railings + beam heads with gold caps
  for (let o = -3; o <= 3; o++) {
    for (const [x, z] of [
      [cx + o, cz - 3],
      [cx + o, cz + 3],
      [cx - 3, cz + o],
      [cx + 3, cz + o],
    ]) {
      if (Math.abs(o) === 3) continue;
      world.set(x, deckY + 1, z, C.wood);
      world.set(x, deckY + 2, z, C.woodDark);
    }
  }
  for (const [sx, sz] of [[-3, -3], [3, -3], [-3, 3], [3, 3]] as const) {
    world.set(cx + sx, deckY + h + 1, cz + sz, C.gold);
  }

  // hip roof of dark tile
  for (let r = 6; r >= 2; r--) {
    const t = (6 - r) / 4;
    const y = deckY + h + 2 + Math.round(t * 3.2);
    for (let dx = -r; dx <= r; dx++)
      for (let dz = -r; dz <= r; dz++) {
        if (Math.max(Math.abs(dx), Math.abs(dz)) !== r) continue;
        const diag = Math.min(Math.abs(dx), Math.abs(dz));
        const lift = Math.round((diag / Math.max(1, r)) * 1.8 * (1 - t * 0.3));
        world.set(cx + dx, y + lift, cz + dz, r === 6 ? C.tealRoof : r <= 3 ? C.gold : C.roofBlue);
        if (r === 6) world.set(cx + dx, y + lift - 1, cz + dz, C.woodDark);
      }
  }

  // the bell, hung from the roof king post
  const beamY = deckY + h + 2;
  world.set(cx, beamY, cz, C.woodDark);
  const bellTop = beamY - 1;
  // bell body: flared
  for (let dy = 0; dy < 4; dy++) {
    const r = dy < 1 ? 0.8 : dy < 3 ? 1.3 : 1.6;
    disc(world, cx, cz, bellTop - dy, r, C.bronze);
  }
  world.set(cx, bellTop - 4, cz, C.goldDeep); // clapper edge
  world.set(cx, bellTop - 5, cz, C.ironDark);
  world.glow(cx, bellTop - 4, cz + 1, C.goldLight);
  return [cx, bellTop - 2, cz];
}

/** open-sided tea pavilion with a thatped hip roof and paper lanterns */
export function teaHouse(
  world: VoxelWorld,
  cx: number,
  cz: number,
  groundY: number,
  rng: Rng,
): [number, number, number] {
  const half = 5;
  const deckY = groundY + 2;
  // raised deck on stone piers
  plate(world, cx - half - 1, cz - half - 1, cx + half + 1, cz + half + 1, deckY, C.woodLight);
  for (const [sx, sz] of [[-half, -half], [half, -half], [-half, half], [half, half], [0, 0]] as const) {
    column(world, cx + sx, cz + sz, groundY, deckY, () => 0.7, C.stone2);
  }

  // posts + low plaster walls on three sides (open to the pond)
  for (const [sx, sz] of [[-half, -half], [half, -half], [-half, half], [half, half]] as const) {
    column(world, cx + sx, cz + sz, deckY + 1, deckY + 5, () => 0.7, C.timber);
  }
  for (let o = -half + 1; o <= half - 1; o++) {
    // back wall (north) + one side
    world.set(cx + o, deckY + 1, cz - half, C.plaster);
    world.set(cx + o, deckY + 2, cz - half, o % 2 ? C.plaster : C.woodDark);
    world.set(cx + o, deckY + 3, cz - half, C.plaster);
    world.set(cx - half, deckY + 1, cz + o, C.plaster);
    world.set(cx - half, deckY + 2, cz + o, o % 2 ? C.plaster : C.woodDark);
    world.set(cx - half, deckY + 3, cz + o, C.plaster);
    // rail on the open pond side
    world.set(cx + o, deckY + 2, cz + half, C.woodDark);
  }
  // noren curtain over the entrance
  for (let o = -2; o <= 2; o++) {
    world.set(cx + o, deckY + 4, cz + half, o === 0 ? C.norenCream : o === 2 ? C.indigo : C.clothTeal);
  }

  // interior: tea table, cushions, hanging lantern
  box(world, cx - 1, deckY + 1, cz, cx + 1, deckY + 1, cz + 2, C.woodDark);
  world.set(cx, deckY + 2, cz + 1, C.paper);
  world.set(cx - 2, deckY + 1, cz - 1, C.vermilion);
  world.set(cx + 2, deckY + 1, cz - 1, C.vermilion);
  world.glow(cx, deckY + 4, cz, C.lanternPaper);

  // thatch hip roof
  for (let r = half + 3; r >= 1; r--) {
    const t = (half + 3 - r) / (half + 2);
    const y = deckY + 6 + Math.round(t * 3.4);
    for (let dx = -r; dx <= r; dx++)
      for (let dz = -r; dz <= r; dz++) {
        if (Math.max(Math.abs(dx), Math.abs(dz)) !== r) continue;
        const diag = Math.min(Math.abs(dx), Math.abs(dz));
        const lift = Math.round((diag / Math.max(1, r)) * 1.6 * (1 - t * 0.3));
        const c =
          r === half + 3
            ? C.cedar
            : ((dx + dz + y) % 5 < 2 ? C.tealRoof : C.jadeDark);
        world.set(cx + dx, y + lift, cz + dz, c);
        if (r === half + 3) world.set(cx + dx, y + lift - 1, cz + dz, C.woodDark);
      }
  }
  world.set(cx, deckY + 10, cz, C.gold);

  // stone lantern and bench outside
  stoneLantern(world, cx + half + 3, cz - half, groundY + 1, 'small');
  bench(world, cx - half - 2, cz + half - 1, groundY + 1, false);
  // tsukubai water basin with bamboo spout
  const bx = cx - half - 4;
  const bz = cz + half + 1;
  world.set(bx, groundY + 1, bz, C.stone2);
  world.set(bx, groundY + 2, bz, C.water);
  column(world, bx - 2, bz, groundY + 1, groundY + 3, () => 0.4, C.bamboo);
  world.set(bx - 1, groundY + 3, bz, C.bambooDark);
  world.set(bx, groundY + 3, bz, C.waterLight);

  // wisteria trellis beside the tea house
  wisteriaTrellis(world, cx + 7, cz + 6, groundY, 5, 3, rng.fork(88));

  return [cx, deckY + 5, cz]; // smoke anchor
}

/** wisteria pergola: posts, beams, hanging purple racemes */
export function wisteriaTrellis(
  world: VoxelWorld,
  cx: number,
  cz: number,
  groundY: number,
  halfX: number,
  halfZ: number,
  rng: Rng,
): void {
  const H = 6;
  for (let ix = -halfX; ix <= halfX; ix += halfX * 2)
    for (let iz = -halfZ; iz <= halfZ; iz += halfZ * 2) {
      column(world, cx + ix, cz + iz, groundY + 1, groundY + H, () => 0.5, C.woodDark);
    }
  for (let ix = -halfX; ix <= halfX; ix++) {
    world.set(cx + ix, groundY + H, cz - halfZ, C.wood);
    world.set(cx + ix, groundY + H, cz + halfZ, C.wood);
    if (ix % 2 === 0) {
      for (let iz = -halfZ + 1; iz < halfZ; iz++) world.set(cx + ix, groundY + H, cz + iz, C.wood);
    }
  }
  // canopy of wisteria with hanging racemes
  for (let dx = -halfX; dx <= halfX; dx++)
    for (let dz = -halfZ; dz <= halfZ; dz++) {
      if (rng.chance(0.25)) continue;
      world.set(cx + dx, groundY + H - 1 + (rng.chance(0.4) ? 1 : 0), cz + dz,
        rng.weighted([[C.wisteria, 5], [C.wisteriaLight, 3], [C.grass2, 1]]));
      if (rng.chance(0.3)) {
        const len = rng.int(1, 3);
        for (let d = 1; d <= len; d++) {
          world.set(cx + dx, groundY + H - d, cz + dz, d === len ? C.lavender : C.wisteriaLight);
        }
      }
    }
}

/** raked sand court with rock arrangement */
export function zenGarden(world: VoxelWorld, field: TerrainField, rng: Rng): void {
  const { x: cx, z: cz } = SITE.zenGarden;
  const R = 13;
  for (let dx = -R; dx <= R; dx++)
    for (let dz = -R; dz <= R; dz++) {
      const x = cx + dx;
      const z = cz + dz;
      const d = Math.hypot(dx, dz);
      if (d > R) continue;
      const y = field.top(x, z);
      if (y < 10) continue;
      // raked furrows: concentric rings around the rock group
      const rake = Math.abs((d * 1.05) % 2.2);
      world.force('solid', x, y, z, rake < 0.45 ? C.gravel : C.zenSand);
    }
  // the rock islands
  rockCluster(world, cx - 2, cz - 1, field.top(cx - 2, cz - 1) + 1, 2.4, rng.fork(31));
  // moss mounds + one old pine companion
  for (const [ox, oz] of [[4, 3], [-5, 4], [3, -5]] as const) {
    const x = cx + ox;
    const z = cz + oz;
    ellipsoid(world, x, field.top(x, z) + 0.5, z, 2.2, 1.1, 2.2, (_px, py, _pz) =>
      rng.chance(0.85) ? (py > field.top(x, z) ? C.mossLight : C.moss) : C.grassDeep,
    );
  }
  // a low wooden fence keeps the court serene
  fenceLine(world, cx - R - 1, cz - R - 1, cx + R + 1, cz - R - 1, field.top(cx, cz - R));
  fenceLine(world, cx - R - 1, cz + R + 1, cx + R + 1, cz + R + 1, field.top(cx, cz + R));
  fenceLine(world, cx - R - 1, cz - R, cx - R - 1, cz + R, field.top(cx - R, cz));
  fenceLine(world, cx + R + 1, cz - R, cx + R + 1, cz + R, field.top(cx + R, cz));
}

/** miniature stone stupas along the terrace walk */
export function stupaRow(world: VoxelWorld, field: TerrainField, rng: Rng): void {
  const { x, z } = SITE.stupaRow;
  for (let i = 0; i < 3; i++) {
    const sx = x + i * 4;
    const sz = z + (i % 2) * 2;
    const y = field.top(sx, sz) + 1;
    const h = 6 - i;
    box(world, sx - 1, y, sz - 1, sx + 1, y, sz + 1, C.stone2);
    column(world, sx, sz, y + 1, y + h - 2, () => 0.9, C.stone1);
    for (let r = 2; r >= 1; r--) disc(world, sx, sz, y + h - 2 + (3 - r), r, C.stoneWarm);
    world.set(sx, y + h + 1, sz, C.gold);
    world.set(sx, y + h + 2, sz, C.goldLight);
    if (rng.chance(0.8)) world.set(sx + 1, y, sz + 1, C.moss);
  }
}

/** string of festival lanterns slung across the avenue */
export function festivalLanterns(
  world: VoxelWorld,
  field: TerrainField,
  ax: number,
  az: number,
  bx: number,
  bz: number,
): [number, number, number][] {
  const ay = field.top(ax, az) + 9;
  const by = field.top(bx, bz) + 9;
  column(world, ax, az, field.top(ax, az) + 1, ay, () => 0.4, C.woodDark);
  column(world, bx, bz, field.top(bx, bz) + 1, by, () => 0.4, C.woodDark);
  world.set(ax, ay + 1, az, C.gold);
  world.set(bx, by + 1, bz, C.gold);
  sacredRope(world, ax, ay, az, bx, by, bz);
  const anchors: [number, number, number][] = [];
  const len = Math.ceil(Math.hypot(bx - ax, bz - az));
  for (let i = 2; i < len; i += 2) {
    const t = i / len;
    const x = Math.round(ax + (bx - ax) * t);
    const z = Math.round(az + (bz - az) * t);
    const y = Math.round(ay + (by - ay) * t) - Math.round(Math.sin(t * Math.PI) * 2) - 1;
    world.set(x, y - 1, z, C.ironDark);
    world.glow(x, y - 2, z, C.lanternPaper);
    world.glow(x, y - 3, z, C.lanternGlow);
    anchors.push([x, y - 2, z]);
  }
  return anchors;
}

/** everything the garden needs, placed */
export function buildProps(
  world: VoxelWorld,
  field: TerrainField,
  rng: Rng,
): PropAnchors {
  // pond helpers
  const shoreY = (x: number, z: number): number => field.top(x, z);

  // --- gates ---
  const gateY = shoreY(0, 62);
  toriiGate(world, SITE.southGate.x, SITE.southGate.z, gateY, 'grand');
  // mossy mini torii on the pond island
  const islY = shoreY(SITE.pondIsland.x, SITE.pondIsland.z);
  if (islY > WATER_Y) {
    toriiGate(world, SITE.pondIsland.x, SITE.pondIsland.z, islY, 'small');
    stoneLantern(world, SITE.pondIsland.x + 3, SITE.pondIsland.z + 2, islY + 1, 'small');
    flowerBed(world, SITE.pondIsland.x - 2, SITE.pondIsland.z - 2, islY + 1, 2, 2, rng.fork(5));
  }

  // --- bridge over the overflow channel ---
  const bridgeY = field.top(0, 44);
  archedBridge(world, SITE.bridge.x, SITE.bridge.z, bridgeY, 7, 4, 5);

  // --- bell tower + tea house ---
  const bellPos = bellTower(world, SITE.bellTower.x, SITE.bellTower.z, field.top(SITE.bellTower.x, SITE.bellTower.z));
  const teaSmoke = teaHouse(world, SITE.teahouse.x, SITE.teahouse.z, field.top(SITE.teahouse.x, SITE.teahouse.z), rng);

  // --- zen garden, well, stupas ---
  zenGarden(world, field, rng);
  well(world, SITE.wellShrine.x, SITE.wellShrine.z, field.top(SITE.wellShrine.x, SITE.wellShrine.z) + 1);
  bench(world, SITE.wellShrine.x + 4, SITE.wellShrine.z + 3, field.top(SITE.wellShrine.x + 4, SITE.wellShrine.z + 3) + 1, true);
  stupaRow(world, field, rng);

  // --- lantern row along the avenue ---
  const lanternSpots: [number, number][] = [
    [4, 70], [-5, 60], [4, 52], [-5, 40], [5, 33], [-5, 24], [6, 16],
  ];
  for (const [x, z] of lanternSpots) {
    stoneLantern(world, x, z, shoreY(x, z) + 1, 'tall');
  }
  // pond shore lanterns
  for (const [x, z] of [[-52, 8], [-28, 30], [-54, 34], [-24, 12]] as const) {
    const y = shoreY(x, z);
    if (y > WATER_Y) stoneLantern(world, x, z, y + 1, 'small');
  }

  // --- festival lantern rope across the avenue ---
  const festivalLanterns1 = festivalLanterns(world, field, -8, 44, 8, 44);

  // --- viewing platform on maple ridge ---
  const vpX = SITE.viewpoint.x;
  const vpZ = SITE.viewpoint.z;
  const vpY = field.top(vpX, vpZ);
  plate(world, vpX - 3, vpZ - 3, vpX + 3, vpZ + 3, vpY + 1, C.woodLight);
  for (const [sx, sz] of [[-3, -3], [3, -3], [-3, 3], [3, 3]] as const) {
    column(world, vpX + sx, vpZ + sz, vpY, vpY + 1, () => 0.7, C.stone2);
  }
  fenceLine(world, vpX - 3, vpZ - 3, vpX - 3, vpZ + 3, vpY + 1);
  fenceLine(world, vpX + 3, vpZ - 3, vpX + 3, vpZ + 3, vpY + 1);
  bench(world, vpX, vpZ - 2, vpY + 2, true);

  // --- stepping stones across the pond shallows to the island ---
  const steps: [number, number][] = [
    [-32, 32], [-35, 30], [-38, 29], [-40, 28], [-42, 27],
  ];
  steppingStones(world, steps, WATER_Y);

  // --- lily pads ---
  for (let i = 0; i < 90; i++) {
    const a = rng.float() * Math.PI * 2;
    const r = Math.sqrt(rng.float()) * 17;
    const x = Math.round(SITE.pond.x + Math.cos(a) * r);
    const z = Math.round(SITE.pond.z + Math.sin(a) * r * 0.75);
    if (pondField(x, z) < 0.3) continue;
    if (shoreFactor(x, z) < 0.15) continue;
    lilyPad(world, x, z, WATER_Y, rng.fork(i * 13));
  }

  // --- turtles on a basking rock ---
  const rockX = SITE.pond.x + 6;
  const rockZ = SITE.pond.z - 4;
  rockCluster(world, rockX, rockZ, WATER_Y, 2.0, rng.fork(41));
  turtle(world, rockX - 1, WATER_Y + 3, rockZ + 1, rng.fork(1));
  turtle(world, rockX + 2, WATER_Y + 3, rockZ, rng.fork(2));

  // --- riverside reeds and irises ---
  for (let i = 0; i < 160; i++) {
    const a = rng.float() * Math.PI * 2;
    const r = rng.range(18, 24);
    const x = Math.round(SITE.pond.x + Math.cos(a) * r);
    const z = Math.round(SITE.pond.z + Math.sin(a) * r * 0.8);
    const y = shoreY(x, z);
    if (y !== WATER_Y && y !== WATER_Y + 1) continue;
    if (rng.chance(0.5)) {
      world.set(x, y + 1, z, C.reed);
      world.set(x, y + 2, z, rng.chance(0.5) ? C.reed : C.iris);
    } else {
      world.set(x, y + 1, z, rng.weighted([[C.iris, 3], [C.tulipPink, 2], [C.white, 1]]));
    }
  }

  // --- moss boulders scattered in the lawn ---
  for (let i = 0; i < 26; i++) {
    const a = rng.float() * Math.PI * 2;
    const r = rng.range(26, 66);
    const x = Math.round(Math.cos(a) * r);
    const z = Math.round(Math.sin(a) * r);
    const y = field.top(x, z);
    if (y <= WATER_Y || field.slope(x, z) > 0.5) continue;
    rockCluster(world, x, z, y + 1, rng.range(1.2, 2.2), rng.fork(i * 3));
  }

  return {
    festivalLanterns: festivalLanterns1,
    teaSmoke,
    bellPos,
    incenseSmoke: [0, gateY + 3, 5],
  };
}

/** a little voxel turtle */
function turtle(world: VoxelWorld, x: number, y: number, z: number, _rng: Rng): void {
  ellipsoid(world, x, y, z, 1.6, 0.9, 1.3, (px, _py, pz) => {
    const shellPattern = (Math.abs(px - x) + Math.abs(pz - z)) % 2 === 0;
    return shellPattern ? C.tortoise : C.pineDark;
  });
  world.set(x + 2, y, z, C.tortoise); // head
  world.set(x + 2, y, z + 1, C.pineDark); // eye... small liberties taken
  world.set(x + 3, y, z, C.onyx);
  world.set(x, y, z + 2, C.tortoise);
  world.set(x, y, z - 2, C.tortoise);
  world.set(x - 2, y, z + 1, C.tortoise);
  world.set(x - 2, y, z - 1, C.tortoise);
  void line;
}
