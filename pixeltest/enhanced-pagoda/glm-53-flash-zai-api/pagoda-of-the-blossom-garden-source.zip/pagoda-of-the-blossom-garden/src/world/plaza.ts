/**
 * Plaza — the temple courtyard: paved terraces, the processional avenue and
 * the courtyard fence. Paving is patterned (checker courses with radial
 * compass rings around the pagoda) rather than one flat colour, so the ground
 * reads as masonry from the aerial presets.
 */

import { C } from '../core/palette';
import { Rng } from '../core/rng';
import { sweepCurve } from '../voxel/brushes';
import * as THREE from 'three';
import { VoxelWorld } from '../voxel/VoxelWorld';
import { flowerBed, fenceRing } from './structures';
import type { TerrainField } from './terrain';
import { AVENUE, SITE } from './site';

export function buildPlaza(world: VoxelWorld, field: TerrainField, rng: Rng): void {
  const px = SITE.plaza.x;
  const pz = SITE.plaza.z;
  const pagX = SITE.pagoda.x;
  const pagZ = SITE.pagoda.z;

  // ---- paved temple courtyard ------------------------------------------------
  // an ellipse embracing both the pagoda platform and the south lawn
  const RX = 26;
  const RZ = 24;
  for (let dx = -RX; dx <= RX; dx++) {
    for (let dz = -RZ; dz <= RZ; dz++) {
      const x = px + dx;
      const z = pz - 6 + dz; // courtyard centre sits between pagoda and lawn
      const d = Math.hypot(dx / RX, dz / RZ);
      if (d > 1) continue;
      const y = field.top(x, z);
      if (y < 10) continue;
      // don't pave under the pagoda platform
      if (Math.abs(x - pagX) <= 13 && Math.abs(z - pagZ) <= 13) continue;

      const ring = Math.floor(d * 14) % 5;
      let color: number;
      if (d > 0.955) color = C.granite; // border course
      else if (ring === 0) color = C.stone3; // ring seam
      else if ((x + z) % 2 === 0) color = C.stoneWarm;
      else color = C.stone1;
      if (rng.chance(0.04)) color = C.mossStone;
      world.force('solid', x, y, z, color);
    }
  }

  // compass rose around the pagoda: gold ring + four petals
  const cy = field.top(pagX, pagZ + 16);
  for (let dx = -9; dx <= 9; dx++) {
    for (let dz = -6; dz <= 6; dz++) {
      const d = Math.hypot(dx * 1.0, dz * 1.5);
      const x = pagX + dx;
      const z = pagZ + 14 + dz;
      if (Math.abs(x - pagX) <= 12 && z > pagZ + 10) continue; // stair area
      if (Math.abs(d - 5.2) < 0.42) world.force('solid', x, cy, z, C.goldDeep);
      else if (d < 0.8) world.force('solid', x, cy, z, C.gold);
    }
  }

  // ---- processional avenue ------------------------------------------------
  const points = AVENUE.map(([x, z]) => new THREE.Vector3(x, 0, z));
  sweepCurve(world, points, C.stoneWarm, {
    width: 5,
    samplesPerSegment: 10,
    follow: (x, z) => field.top(x, z),
    onSample: (p) => {
      // edging + centre course
      const y = field.top(p.x, p.z);
      world.force('solid', p.x, y, p.z, C.stone1);
      for (const s of [-3, 3]) {
        const side = new THREE.Vector3(p.z, 0, -p.x).normalize();
        const ex = Math.round(p.x + side.x * s);
        const ez = Math.round(p.z + side.z * s);
        world.force('solid', ex, field.top(ex, ez), ez, C.gravelDark);
      }
    },
  });

  // ---- courtyard fence with a south gap ---------------------------------------
  // ringed wide enough to clear the pagoda platform on the north side
  fenceRing(world, px, pz - 6, 28, field.top(px, pz - 6), {
    side: 's',
    from: -6,
    to: 6,
  });

  // ---- corner plantings ---------------------------------------------------------
  const corners: [number, number][] = [
    [px - 24, pz - 24],
    [px + 24, pz - 24],
    [px - 24, pz + 22],
    [px + 24, pz + 22],
  ];
  for (const [x, z] of corners) {
    const y = field.top(x, z);
    flowerBed(world, x, z, y, 3, 3, rng.fork(x * 31 + z));
  }
}
