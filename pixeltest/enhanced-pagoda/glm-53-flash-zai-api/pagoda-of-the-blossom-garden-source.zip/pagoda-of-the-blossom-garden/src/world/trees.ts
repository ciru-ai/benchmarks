/**
 * Trees — the planted soul of the garden.
 *
 * Every tree grows from the same recursive trunk algorithm: a tapering trunk
 * that leans, kinks and forks, with branches re-diced into twigs, and foliage
 * deposited as cloudbanks of voxels along the branch tips. Species differ by
 * their growth parameters (lean, forking angle, droop) and their canopy
 * painter — which is how sakura clouds, pine pads, maple lace and bamboo
 * columns all come from one engine.
 */

import { C, LADDER, ladderRamp } from '../core/palette';
import { Rng } from '../core/rng';
import { fbm2 } from '../core/noise';
import { ellipsoid, disc } from '../voxel/brushes';
import { VoxelWorld } from '../voxel/VoxelWorld';
import type { TerrainField } from './terrain';
import { WATER_Y } from './site';

export interface TreeParams {
  trunkHeight: number;
  lean: number;
  forkingAngle: number;
  branchCount: number;
  droop: number;
  trunkColor: () => number;
  /** paints a canopy cloud around a branch tip */
  canopy: (world: VoxelWorld, x: number, y: number, z: number, r: number, rng: Rng) => void;
  /** radius of a canopy cloud */
  canopyRadius: number;
  rootFlare: number;
}

type Vec = [number, number, number];

/** recursive branch grower */
function growBranch(
  world: VoxelWorld,
  pos: Vec,
  dir: Vec,
  length: number,
  thickness: number,
  params: TreeParams,
  rng: Rng,
  depth: number,
): void {
  let [x, y, z] = pos;
  let [dx, dy, dz] = dir;

  for (let i = 0; i < length; i++) {
    const t = i / Math.max(1, length);
    const r = Math.max(0.35, thickness * (1 - t * 0.55));
    // wind kink: the trunk wanders a little as it climbs
    dx += rng.gauss() * 0.06;
    dz += rng.gauss() * 0.06;
    dy += params.droop * -0.045 + (depth === 0 ? 0.16 : -0.02);
    const n = Math.hypot(dx, dy, dz) || 1;
    dx /= n;
    dy /= n;
    dz /= n;
    x += dx;
    y += dy;
    z += dz;

    // trunk voxels: cross-section shrinks as the branch tapers
    const ir = Math.ceil(r);
    for (let ox = -ir; ox <= ir; ox++)
      for (let oz = -ir; oz <= ir; oz++) {
        if (ox * ox + oz * oz > r * r) continue;
        world.set(Math.round(x) + ox, Math.round(y), Math.round(z) + oz, params.trunkColor());
      }

    // fork near the end (or mid-way for the main trunk)
    const forkAt = depth === 0 ? length * rng.range(0.55, 0.85) : length * rng.range(0.6, 0.95);
    if (i > forkAt && depth < 3) {
      const kids = depth === 0 ? params.branchCount : rng.chance(0.75) ? 2 : 1;
      for (let k = 0; k < kids; k++) {
        const ang = rng.float() * Math.PI * 2;
        const spread = params.forkingAngle * rng.range(0.55, 1.25);
        const nd: Vec = [
          dx + Math.cos(ang) * spread + rng.gauss() * 0.08,
          dy * rng.range(0.4, 1.0) + rng.gauss() * 0.06,
          dz + Math.sin(ang) * spread + rng.gauss() * 0.08,
        ];
        const nl = Math.max(2, length * rng.range(0.5, 0.78));
        growBranch(
          world,
          [x, y, z],
          nd,
          Math.round(nl),
          Math.max(0.4, r * 0.72),
          params,
          rng,
          depth + 1,
        );
      }
      return; // this branch's job is done once it forks
    }
  }

  // terminal canopy cloud
  params.canopy(world, x, y, z, params.canopyRadius * rng.range(0.8, 1.25), rng);
}

function plant(
  world: VoxelWorld,
  x: number,
  z: number,
  groundY: number,
  params: TreeParams,
  rng: Rng,
): void {
  // root flare
  if (params.rootFlare > 0) {
    disc(world, x, z, groundY, params.rootFlare, params.trunkColor());
  }
  const leanAng = rng.float() * Math.PI * 2;
  const lean = params.lean * rng.range(0.3, 1);
  const dir: Vec = [Math.cos(leanAng) * lean, 1, Math.sin(leanAng) * lean];
  growBranch(
    world,
    [x, groundY + 1, z],
    dir,
    params.trunkHeight,
    Math.max(1.1, params.rootFlare * 0.8),
    params,
    rng,
    0,
  );
}

// ---------------------------------------------------------------------------
// canopy painters
// ---------------------------------------------------------------------------

/** sakura: layered pink clouds, lighter toward the sky, dark hearts beneath */
function sakuraCanopy(world: VoxelWorld, cx: number, cy: number, cz: number, r: number, rng: Rng): void {
  ellipsoid(world, cx, cy, cz, r, r * 0.72, r, (px, py, pz) => {
    const inner = Math.hypot(px - cx, (py - cy) * 1.35, pz - cz) / Math.max(0.5, r);
    if (inner > 1) return 0;
    const t = 1 - inner;
    // vertical light gradient + dapple noise
    const up = (py - (cy - r * 0.72)) / (r * 1.44);
    const dapple = fbm2(px * 0.31 + cz * 0.13, pz * 0.27 - py * 0.21, 2, 47);
    const shade = t * 0.62 + up * 0.38 + dapple * 0.3;
    if (t < 0.24 && rng.chance(0.55)) return 0; // airy gaps
    return ladderRamp(LADDER.sakura, shade * 0.9 + rng.float() * 0.14);
  });
}

/** pine: flat needle pads stacked up the branch */
function pineCanopy(world: VoxelWorld, cx: number, cy: number, cz: number, r: number, rng: Rng): void {
  for (let pad = 0; pad < 2; pad++) {
    const py = cy - pad;
    const pr = r * (1 - pad * 0.42);
    disc(world, cx, cz, Math.round(py), pr, (px, _py, pz) => {
      const d = Math.hypot(px - cx, pz - cz) / Math.max(0.5, pr);
      if (d > 1) return 0;
      if (d > 0.7 && rng.chance(0.6)) return 0;
      return ladderRamp(LADDER.pine, d * 0.55 + rng.float() * 0.25);
    });
  }
  if (rng.chance(0.6)) world.set(cx, Math.round(cy) + 1, cz, C.pineLight);
}

/** maple: airy lace of reds and golds */
function mapleCanopy(world: VoxelWorld, cx: number, cy: number, cz: number, r: number, rng: Rng): void {
  ellipsoid(world, cx, cy, cz, r, r * 0.62, r, (px, py, pz) => {
    const inner = Math.hypot(px - cx, (py - cy) * 1.6, pz - cz) / Math.max(0.5, r);
    if (inner > 1 || (inner > 0.5 && rng.chance(0.5))) return 0;
    const up = (py - (cy - r * 0.62)) / (r * 1.24);
    return ladderRamp(LADDER.maple, 1 - inner * 0.7 + up * 0.35 + rng.float() * 0.2);
  });
}

/** willow: curtains of yellow-green falling from a dome */
function willowCanopy(world: VoxelWorld, cx: number, cy: number, cz: number, r: number, rng: Rng): void {
  ellipsoid(world, cx, cy, cz, r, r * 0.6, r, (px, py, pz) => {
    const inner = Math.hypot(px - cx, (py - cy) * 1.5, pz - cz) / Math.max(0.5, r);
    if (inner > 1 || rng.chance(0.22)) return 0;
    return rng.weighted([[C.willow, 5], [C.willowDark, 3], [C.grass2, 2]]);
  });
  // falling strands
  const strands = Math.round(r * 3);
  for (let i = 0; i < strands; i++) {
    const a = rng.float() * Math.PI * 2;
    const rr = r * rng.range(0.55, 1.02);
    const sx = Math.round(cx + Math.cos(a) * rr);
    const sz = Math.round(cz + Math.sin(a) * rr);
    const len = rng.int(2, 6);
    for (let d = 0; d < len; d++) {
      world.set(sx, Math.round(cy) - d, sz, d === len - 1 ? C.willowDark : C.willow);
    }
  }
}

/** bamboo: tall slender columns with leaf sprays */
function bambooTree(world: VoxelWorld, x: number, z: number, groundY: number, rng: Rng): void {
  const h = rng.int(13, 22);
  const leanX = rng.gauss() * 0.4;
  const leanZ = rng.gauss() * 0.4;
  for (let y = 0; y <= h; y++) {
    const wx = Math.round(x + leanX * (y / h) * 3);
    const wz = Math.round(z + leanZ * (y / h) * 3);
    world.set(wx, groundY + y, wz, y % 4 === 0 ? C.bambooDark : C.bamboo);
    // node rings
    if (y % 4 === 0) {
      world.set(wx + 1, groundY + y, wz, C.bambooDark);
      world.set(wx - 1, groundY + y, wz, C.bambooDark);
      world.set(wx, groundY + y, wz + 1, C.bambooDark);
      world.set(wx, groundY + y, wz - 1, C.bambooDark);
    }
    // leaf sprays on the upper half
    if (y > h * 0.45 && rng.chance(0.34)) {
      const la = rng.float() * Math.PI * 2;
      for (let l = 0; l < rng.int(2, 5); l++) {
        world.set(
          wx + Math.round(Math.cos(la) * (l + 1) * 0.8),
          groundY + y + (rng.chance(0.3) ? 1 : 0),
          wz + Math.round(Math.sin(la) * (l + 1) * 0.8),
          rng.weighted([[C.bambooLeaf, 5], [C.grass2, 3], [C.fern, 2]]),
        );
      }
    }
  }
}

/** plum: gnarled and dark, with sparse candy-pink blossoms */
function plumCanopy(world: VoxelWorld, cx: number, cy: number, cz: number, r: number, rng: Rng): void {
  ellipsoid(world, cx, cy, cz, r, r * 0.6, r, (px, py, pz) => {
    const inner = Math.hypot(px - cx, (py - cy) * 1.4, pz - cz) / Math.max(0.5, r);
    if (inner > 1) return 0;
    if (inner > 0.3 && rng.chance(0.72)) return 0; // sparse!
    return rng.weighted([[C.plumPink, 5], [C.blossom3, 3], [C.blossomDeep, 2], [C.woodDark, 1]]);
  });
}

// ---------------------------------------------------------------------------
// species presets
// ---------------------------------------------------------------------------

export const SPECIES = {
  sakura: (rng: Rng): TreeParams => ({
    trunkHeight: rng.int(5, 7),
    lean: 0.34,
    forkingAngle: 0.85,
    branchCount: 3,
    droop: 1.4,
    trunkColor: () => rng.weighted([[C.bark, 6], [C.woodDark, 3], [C.cedar, 1]]),
    canopy: sakuraCanopy,
    canopyRadius: rng.range(3.2, 4.4),
    rootFlare: 1.6,
  }),
  sakuraOld: (rng: Rng): TreeParams => ({
    trunkHeight: rng.int(7, 9),
    lean: 0.5,
    forkingAngle: 1.0,
    branchCount: 4,
    droop: 1.8,
    trunkColor: () => rng.weighted([[C.bark, 5], [C.woodDark, 4]]),
    canopy: sakuraCanopy,
    canopyRadius: rng.range(4.2, 5.6),
    rootFlare: 2.2,
  }),
  pine: (rng: Rng): TreeParams => ({
    trunkHeight: rng.int(6, 9),
    lean: 0.22,
    forkingAngle: 0.7,
    branchCount: 3,
    droop: -0.4,
    trunkColor: () => rng.weighted([[C.bark, 6], [C.woodDark, 2]]),
    canopy: pineCanopy,
    canopyRadius: rng.range(2.6, 3.8),
    rootFlare: 1.4,
  }),
  maple: (rng: Rng): TreeParams => ({
    trunkHeight: rng.int(5, 7),
    lean: 0.4,
    forkingAngle: 0.95,
    branchCount: 3,
    droop: 0.8,
    trunkColor: () => rng.weighted([[C.bark, 5], [C.woodDark, 3]]),
    canopy: mapleCanopy,
    canopyRadius: rng.range(3.0, 4.2),
    rootFlare: 1.5,
  }),
  willow: (rng: Rng): TreeParams => ({
    trunkHeight: rng.int(7, 9),
    lean: 0.3,
    forkingAngle: 1.1,
    branchCount: 4,
    droop: 2.2,
    trunkColor: () => rng.weighted([[C.cedar, 5], [C.bark, 4]]),
    canopy: willowCanopy,
    canopyRadius: rng.range(3.4, 4.6),
    rootFlare: 1.8,
  }),
  plum: (rng: Rng): TreeParams => ({
    trunkHeight: rng.int(4, 6),
    lean: 0.55,
    forkingAngle: 1.15,
    branchCount: 3,
    droop: 1.2,
    trunkColor: () => rng.weighted([[C.woodDark, 6], [C.bark, 3]]),
    canopy: plumCanopy,
    canopyRadius: rng.range(2.6, 3.6),
    rootFlare: 1.7,
  }),
} as const;

export type SpeciesName = keyof typeof SPECIES;

/**
 * Plant a whole forest: scattered by noise clusters, kept off water, paths and
 * the temple clearings.
 */
export function plantForest(
  world: VoxelWorld,
  field: TerrainField,
  rng: Rng,
  opts: {
    avoid?: { x: number; z: number; r: number }[];
    density?: number;
  } = {},
): void {
  const avoid = opts.avoid ?? [];
  const tries = 4200;
  const planted: { x: number; z: number }[] = [];

  const clearOf = (x: number, z: number): boolean => {
    for (const a of avoid) {
      if (Math.hypot(x - a.x, z - a.z) < a.r) return false;
    }
    for (const p of planted) {
      if (Math.hypot(x - p.x, z - p.z) < 4.2) return false;
    }
    return true;
  };

  for (let i = 0; i < tries; i++) {
    const a = rng.float() * Math.PI * 2;
    const r = Math.sqrt(rng.float()) * 76;
    const x = Math.round(Math.cos(a) * r);
    const z = Math.round(Math.sin(a) * r);

    const gy = field.top(x, z);
    if (gy <= WATER_Y) continue; // no drowned trees
    if (field.slope(x, z) > 0.42) continue; // not on cliffs
    if (!clearOf(x, z)) continue;

    // forest composition: woods cluster by noise, gardens stay open
    const wood = fbm2(x * 0.03 + 91, z * 0.03 - 44, 3, 202);
    if (wood < 0.46) continue;
    if (rng.chance(0.62)) continue;

    // species by district
    const species = chooseSpecies(x, z, rng);
    plant(world, x, z, gy, SPECIES[species](rng.fork(i)), rng.fork(i * 7 + 1));
    planted.push({ x, z });
    if (planted.length >= (opts.density ?? 240)) break;
  }
}

/** district-aware species picker */
function chooseSpecies(x: number, z: number, rng: Rng): SpeciesName {
  const d = (ax: number, az: number): number => Math.hypot(x - ax, z - az);
  // bamboo grove in the north-east
  if (d(40, -30) < 14) return 'pine';
  if (d(44, -22) < 9) return 'pine';
  // maple ridge on the east
  if (d(54, 2) < 16 && rng.chance(0.8)) return 'maple';
  // willows hug the pond
  if (d(-40, 20) < 30 && rng.chance(0.35)) return 'willow';
  // sakura dominates the gardens; old giants near the temple
  if (d(0, -6) < 26 && rng.chance(0.4)) return 'sakuraOld';
  return rng.weighted([
    ['sakura', 6],
    ['pine', 2.4],
    ['maple', 2],
    ['plum', 1.4],
    ['willow', 1],
  ] as const) as SpeciesName;
}

/** hand-placed feature trees: the heroes of the composition */
export function plantFeatureTrees(world: VoxelWorld, field: TerrainField, rng: Rng): void {
  // the great sakura of the south lawn — framed by the avenue
  const heroSpots: [number, number, SpeciesName][] = [
    [16, 30, 'sakuraOld'],
    [-16, 30, 'sakuraOld'],
    [10, 48, 'sakura'],
    [-10, 46, 'sakura'],
    [30, 22, 'sakura'],
    [-28, 38, 'sakura'],
    [-52, 30, 'willow'],
    [-30, 4, 'willow'],
    [52, 8, 'maple'],
    [46, -8, 'maple'],
    [58, -4, 'maple'],
    [36, -36, 'pine'],
    [44, -28, 'pine'],
    [-12, -30, 'pine'],
    [8, -32, 'pine'],
    [-64, 44, 'pine'],
    [22, 40, 'plum'],
    [-20, 52, 'plum'],
  ];
  for (const [x, z, sp] of heroSpots) {
    const gy = field.top(x, z);
    if (gy <= WATER_Y || field.slope(x, z) > 0.5) continue;
    plant(world, x, z, gy, SPECIES[sp](rng.fork(x * 3 + z)), rng.fork(x + z * 3 + 5));
  }
}

/**
 * Bamboo grove: dense culms with fallen leaves, on the north-east slope.
 */
export function plantBambooGrove(
  world: VoxelWorld,
  field: TerrainField,
  rng: Rng,
  cx: number,
  cz: number,
  radius: number,
  count: number,
): void {
  for (let i = 0; i < count; i++) {
    const a = rng.float() * Math.PI * 2;
    const r = Math.sqrt(rng.float()) * radius;
    const x = Math.round(cx + Math.cos(a) * r);
    const z = Math.round(cz + Math.sin(a) * r);
    const gy = field.top(x, z);
    if (gy <= WATER_Y || field.slope(x, z) > 0.5) continue;
    bambooTree(world, x, z, gy, rng.fork(i));
    if (rng.chance(0.3)) world.set(x + 1, gy, z, C.bambooDark); // leaf litter
  }
}
