/**
 * SITE — the garden's blueprint.
 *
 * One place holds every landmark coordinate and every "field" query
 * (how deep is the water here, how flat is the plaza there). Terrain, trees,
 * props and water all read from the same source, so nothing drifts: a lantern
 * placed "on the pond shore" and the shore itself agree on where the shore is.
 */

import * as THREE from 'three';
import { fbm2, ridge2, smoothstep, superellipseDist, clamp, lerpN } from '../core/noise';

export const ISLAND_R = 78;
export const PLATEAU_Y = 11;
export const WATER_Y = 8;
export const BEDROCK_Y = -16;

/** landmark anchors (x, z) — y comes from the terrain field */
export const SITE = {
  pagoda: { x: 0, z: -12 },
  plaza: { x: 0, z: 8 },
  steps: { x: 0, z: 4 },
  southGate: { x: 0, z: 62 },
  outerGate: { x: 0, z: 74 },
  bridge: { x: 0, z: 47 },
  pond: { x: -40, z: 20 },
  pondIsland: { x: -44, z: 26 },
  teahouse: { x: -60, z: 40 },
  streamFall: { x: -58, z: -24 },
  springPool: { x: -54, z: -34 },
  bellTower: { x: 20, z: 54 },
  zenGarden: { x: -26, z: -38 },
  bambooGrove: { x: 40, z: -30 },
  mapleRidge: { x: 54, z: 2 },
  viewpoint: { x: 62, z: 22 },
  cherryRow: { x: 26, z: 34 },
  wellShrine: { x: -18, z: 44 },
  bonsaiPatio: { x: 22, z: 4 },
  lionDogs: { x: 0, z: 2 },
  stupaRow: { x: -14, z: 14 },
  peak: { x: -4, z: -70 },
} as const;

/** the approach avenue, south gate → pagoda steps */
export const AVENUE: [number, number][] = [
  [0, 78],
  [1, 66],
  [-2, 56],
  [1, 44],
  [2, 30],
  [0, 18],
  [0, 8],
];

/** the feed stream: snow-melt pool over the fall, down into Mirror Pond */
export const STREAM_PATH: [number, number][] = [
  [-52, -38],
  [-57, -30],
  [-62, -20],
  [-62, -8],
  [-56, 2],
  [-50, 8],
  [-46, 12],
];

/** the pond's overflow channel, which the arched bridge spans */
export const CHANNEL_PATH: [number, number][] = [
  [-24, 26],
  [-14, 34],
  [-6, 42],
  [0, 47],
  [8, 54],
  [18, 62],
  [26, 70],
];

const STREAM_WIDTH = 4.2;
const CHANNEL_WIDTH = 3.8;

/** surface level of the hanging spring pool (it pours over the falls) */
export const SPRING_Y = PLATEAU_Y + 8;

/** 1 in the middle of the spring pool, 0 outside it */
export function springField(x: number, z: number): number {
  const d = Math.hypot(x - SITE.springPool.x, z - SITE.springPool.z);
  return 1 - smoothstep(4.6, 8.2, d);
}

function polylineField(x: number, z: number, pts: [number, number][], width: number): number {
  let best = Infinity;
  for (let i = 0; i < pts.length - 1; i++) {
    const [ax, az] = pts[i];
    const [bx, bz] = pts[i + 1];
    const vx = bx - ax;
    const vz = bz - az;
    const wx = x - ax;
    const wz = z - az;
    const len2 = vx * vx + vz * vz || 1;
    let t = (wx * vx + wz * vz) / len2;
    t = t < 0 ? 0 : t > 1 ? 1 : t;
    const d = Math.hypot(x - (ax + vx * t), z - (az + vz * t));
    if (d < best) best = d;
  }
  return 1 - smoothstep(0, width, best);
}

/** Mirror Pond basin: 1 at the deepest, 0 at the shore */
export function pondField(x: number, z: number): number {
  const dx = x - SITE.pond.x;
  const dz = z - SITE.pond.z;
  const wob = 0.12 * (fbm2(x * 0.05 + 11, z * 0.05 - 4, 3, 71) - 0.5) * 2;
  const d = superellipseDist(dx, dz, 22 + wob * 14, 16 - wob * 9, 2.6);
  return 1 - smoothstep(0.62, 1.06, d);
}

/** feeding stream + overflow channel */
export function riverField(x: number, z: number): number {
  const a = polylineField(x, z, STREAM_PATH, STREAM_WIDTH);
  const b = polylineField(x, z, CHANNEL_PATH, CHANNEL_WIDTH);
  return Math.max(a, b);
}

/** how much water covers a cell (0 = dry, >0 = submerged depth in voxels) */
export function waterDepth(x: number, z: number): number {
  const wet = wetness(x, z);
  if (wet < 0.16) return 0;
  return Math.max(0, WATER_Y - bedHeight(x, z));
}

/** combined water presence: 1 = mid-channel, 0 = dry */
function wetness(x: number, z: number): number {
  return Math.max(pondField(x, z), riverField(x, z) * 0.95);
}

/** the dug-out floor under a waterway (guaranteed below WATER_Y when wet) */
function bedHeight(x: number, z: number): number {
  const wet = wetness(x, z);
  return WATER_Y - 0.5 - wet * 3.8;
}

/** the rolling land before plazas and water are carved */
export function BASE_LAND(x: number, z: number): number {
  const r = Math.hypot(x, z);
  // broad rolling plateau
  let h = PLATEAU_Y + (fbm2(x * 0.021, z * 0.021, 4, 13) - 0.5) * 7.5;
  // terraced shelves on the eastern flank
  const eastShelf = smoothstep(20, 46, x) * (1 - smoothstep(52, 74, r));
  h += eastShelf * (Math.floor((x + z) / 9) * 0.35);
  // the rim ring: a wall of hills that holds the garden like a bowl — varied
  // around the circumference so some sections dip into grassy passes
  const angle = Math.atan2(z, x);
  const gate = 0.3 + 0.7 * fbm2(Math.cos(angle) * 3 + 7, Math.sin(angle) * 3 - 3, 3, 91);
  const rim = smoothstep(52, 80, r) * ridge2(x * 0.026, z * 0.026, 4, 29);
  h += rim * 26 * gate;
  // a snow-patched sacred peak behind the pagoda
  const peakD = Math.hypot(x - SITE.peak.x, (z - SITE.peak.z) * 1.15);
  h += smoothstep(58, 0, peakD) ** 1.7 * 40;
  // western ridge screens the tea house
  const westRidge = Math.hypot((x + 66) * 0.7, z - 46);
  h += smoothstep(34, 0, westRidge) ** 1.6 * 18;
  // waterways sit in valleys, not canyons: pre-grade the land along them
  h -= 4.5 * polylineField(x, z, STREAM_PATH, 10);
  h -= 3.5 * polylineField(x, z, CHANNEL_PATH, 8);
  h -= 4.0 * Math.pow(pondField(x, z), 1.2);
  return h;
}

/** flat zones: pagoda plaza, temple terrace, tea patio … */
function flattenZones(x: number, z: number): { y: number; w: number }[] {
  return [
    // main temple terrace
    { y: PLATEAU_Y + 3.5, w: 1 - smoothstep(20, 30, Math.hypot(x - SITE.plaza.x, (z - SITE.plaza.z) * 1.08)) },
    // approach avenue: a soft-sided processional walk, south gate → steps
    {
      y: PLATEAU_Y + 2.2,
      w:
        smoothstep(0, 12, z - 2) *
        (1 - smoothstep(70, 82, z)) *
        (1 - smoothstep(6, 13, Math.abs(x))),
    },
    // tea house patio
    { y: PLATEAU_Y + 1.6, w: 1 - smoothstep(11, 20, Math.hypot(x - SITE.teahouse.x, z - SITE.teahouse.z)) },
    // zen raked sand court
    { y: PLATEAU_Y + 2.6, w: 1 - smoothstep(12, 19, Math.hypot((x - SITE.zenGarden.x) * 1.25, z - SITE.zenGarden.z)) },
    // bell tower court
    { y: PLATEAU_Y + 2.0, w: 1 - smoothstep(8, 15, Math.hypot(x - SITE.bellTower.x, z - SITE.bellTower.z)) },
    // bonsai patio
    { y: PLATEAU_Y + 2.4, w: 1 - smoothstep(7, 13, Math.hypot(x - SITE.bonsaiPatio.x, z - SITE.bonsaiPatio.z)) },
    // spring terrace — the raised shelf the waterfall pours off
    { y: PLATEAU_Y + 9.5, w: 1 - smoothstep(8, 16, Math.hypot(x - SITE.springPool.x, z - SITE.springPool.z)) },
  ];
}

/** final walkable ground height, before water carving */
export function landHeight(x: number, z: number): number {
  let h = BASE_LAND(x, z);
  for (const zone of flattenZones(x, z)) {
    const w = clamp(zone.w, 0, 1);
    if (w > 0) h = lerpN(h, zone.y, w * 0.92);
  }
  // the spring pool dents its own terrace
  const spring = springField(x, z);
  if (spring > 0.02) h = lerpN(h, SPRING_Y - 1.7, spring * 0.95);
  // ponds and channels bite into the land
  const wet = wetness(x, z);
  if (wet > 0.02) {
    h = lerpN(h, Math.min(h, bedHeight(x, z)), smoothstep(0.02, 0.45, wet));
  }
  // the island itself ends in sea-cliffs
  const r = Math.hypot(x, z);
  const edge = smoothstep(ISLAND_R - 2, ISLAND_R + 16, r);
  h = lerpN(h, BEDROCK_Y - 4, edge);
  return h;
}

/** true where the cell is open water */
export function isWater(x: number, z: number): boolean {
  return waterSurfaceY(x, z) !== null;
}

/**
 * Water level for a cell, or null when dry. Two bodies exist: the hanging
 * spring pool (level with its terrace) and the pond/stream/channel system
 * (all one level, so the overflow reads as connected water).
 */
export function waterSurfaceY(x: number, z: number): number | null {
  const spring = springField(x, z);
  if (spring > 0.45 && landHeight(x, z) < SPRING_Y - 0.4) return SPRING_Y;
  const wet = Math.max(pondField(x, z), riverField(x, z) * 0.85);
  if (wet < 0.16) return null;
  if (waterDepth(x, z) <= 0.4) return null;
  return WATER_Y;
}

/** normalized shore factor for a wet cell: 1 at the waterline, 0 in the deep */
export function shoreFactor(x: number, z: number): number {
  const wet = Math.max(pondField(x, z), riverField(x, z) * 0.85);
  return 1 - clamp((wet - 0.2) / 0.55, 0, 1);
}

/** ground height used when planting: water surfaces read as the water line */
export function groundHeight(x: number, z: number): number {
  return Math.round(landHeight(x, z));
}

export function pondSurfaceSamples(count: number): THREE.Vector3[] {
  const out: THREE.Vector3[] = [];
  for (let i = 0; i < count; i++) {
    const a = (i / count) * Math.PI * 2;
    out.push(
      new THREE.Vector3(
        SITE.pond.x + Math.cos(a) * 14,
        WATER_Y,
        SITE.pond.z + Math.sin(a) * 10,
      ),
    );
  }
  return out;
}
