/**
 * Per-frame participants. Anything that moves registers an actor; the viewer
 * drives them in insertion order with a clamped delta.
 */
import type * as THREE from 'three';

export interface FrameInfo {
  /** seconds since start */
  time: number;
  /** seconds since last frame (clamped) */
  dt: number;
  /** 0 = midnight, 0.5 = noon */
  dayT: number;
  /** 0..1 "how dark is it" */
  night: number;
  camera: THREE.Camera;
}

export interface Actor {
  name?: string;
  update(info: FrameInfo): void;
  dispose?(): void;
}

export class ActorRegistry {
  private actors: Actor[] = [];

  add(actor: Actor): Actor {
    this.actors.push(actor);
    return actor;
  }

  update(info: FrameInfo): void {
    for (const a of this.actors) a.update(info);
  }

  dispose(): void {
    for (const a of this.actors) a.dispose?.();
    this.actors = [];
  }

  get size(): number {
    return this.actors.length;
  }
}
