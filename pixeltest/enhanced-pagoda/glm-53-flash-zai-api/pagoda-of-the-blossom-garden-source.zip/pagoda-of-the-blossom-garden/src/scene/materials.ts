/**
 * Layer materials.
 *
 * Solids are Lambert (flat, matte, perfect for chunky geometry — the baked AO
 * does the shaping). Self-lit voxels skip lighting entirely: they read as
 * paper lanterns and spirit fire, and their brightness is scaled by the day
 * cycle so lanterns look painted-by-day and blazing-by-night. Aura voxels are
 * additive and depth-write-off, which is how waterfalls, mist and ghostlight
 * blend into the sky without sorting artefacts.
 */

import * as THREE from 'three';
import type { LayerName } from '../voxel/VoxelWorld';

export interface LayerMaterials {
  solid: THREE.MeshLambertMaterial;
  glow: THREE.MeshBasicMaterial;
  aura: THREE.MeshBasicMaterial;
  setGlow(scale: number): void;
  get(layer: LayerName): THREE.Material;
}

export function createLayerMaterials(): LayerMaterials {
  const solid = new THREE.MeshLambertMaterial({ vertexColors: true });

  const glow = new THREE.MeshBasicMaterial({
    vertexColors: true,
    toneMapped: true,
    fog: true,
  });

  const aura = new THREE.MeshBasicMaterial({
    vertexColors: true,
    transparent: true,
    opacity: 0.5,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    side: THREE.DoubleSide,
    fog: false,
  });

  return {
    solid,
    glow,
    aura,
    setGlow(scale: number): void {
      glow.color.setScalar(scale);
      aura.opacity = 0.34 + scale * 0.16;
    },
    get(layer: LayerName): THREE.Material {
      return layer === 'solid' ? solid : layer === 'glow' ? glow : aura;
    },
  };
}
