/**
 * Camera presets — the guided tour of the diorama.
 * Positions are chosen to clear the mature tree canopy so each one frames a
 * different story: the axis approach, the pond at lantern height, the maple
 * overlook, straight up the pagoda eaves, and a low pass skimming the water.
 */
import type { CameraPreset } from './viewer';

export const PRESETS: CameraPreset[] = [
  { name: 'establishing', pos: [104, 78, 126], target: [0, 26, 0], fov: 40 },
  { name: 'avenue', pos: [1, 46, 112], target: [0, 18, -4], fov: 44 },
  { name: 'pagoda-rise', pos: [34, 22, 58], target: [0, 42, -12], fov: 50 },
  { name: 'mirror-pond', pos: [-40, 15, 34], target: [-43, 5, 0], fov: 46 },
  { name: 'lantern-row', pos: [-8, 31, 66], target: [0, 14, 30], fov: 48 },
  { name: 'maple-overlook', pos: [62, 42, 46], target: [6, 22, -4], fov: 42 },
  { name: 'sakura-canopy', pos: [24, 36, 32], target: [16, 24, 26], fov: 46 },
  { name: 'aerial', pos: [38, 118, 62], target: [0, 8, -2], fov: 38 },
  { name: 'keel', pos: [132, -46, 152], target: [0, -8, 0], fov: 46 },
  { name: 'peak-shrine', pos: [26, 56, 8], target: [-6, 40, -66], fov: 40 },
];
