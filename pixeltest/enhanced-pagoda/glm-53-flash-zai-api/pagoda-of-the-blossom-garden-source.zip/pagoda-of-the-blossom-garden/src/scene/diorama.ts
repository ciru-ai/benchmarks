/**
 * Diorama — the build pipeline.
 *
 * The scene is assembled in phases; each phase is a list of named steps that
 * paint onto a shared build context, and the merged voxel meshes are rebuilt
 * after every phase. That gives two things: progress reporting with real labels,
 * and the ability to stop the build early (`?phase=2`) to inspect exactly how far
 * the scene got — which is how this garden was verified piece by piece.
 */

import { Rng } from '../core/rng';
import type { DayCycle } from '../fx/daycycle';
import type { SkyHandle } from '../fx/sky';
import { buildWaterSurface, syncWater, type WaterHandle } from '../fx/waterSurface';
import { addRimCascade, addSpringFalls } from '../fx/waterfall';
import type { Viewer } from '../scene/viewer';
import { Koi } from '../scene/koi';
import { VoxelWorld } from '../voxel/VoxelWorld';
import { buildPagoda } from '../world/pagoda';
import { buildPlaza } from '../world/plaza';
import { plantBambooGrove, plantFeatureTrees, plantForest } from '../world/trees';
import { buildProps, type PropAnchors } from '../world/props';
import { createClouds } from '../fx/clouds';
import { createPetals } from '../fx/petals';
import { createFireflies } from '../fx/fireflies';
import { Smoke } from '../fx/smoke';
import { createBirds } from '../fx/birds';
import {
  addGroundFlora,
  addIslandKeelDetail,
  addMossPatches,
  generateTerrain,
  makeField,
  type TerrainField,
} from '../world/terrain';

export interface BuildContext {
  world: VoxelWorld;
  field: TerrainField;
  scene: import('three').Scene;
  viewer: Viewer;
  day: DayCycle;
  rng: Rng;
  sky: SkyHandle;
  water: WaterHandle | null;
  pagoda: ReturnType<typeof buildPagoda> | null;
  props: PropAnchors | null;
}

export interface BuildStep {
  label: string;
  run(ctx: BuildContext): void;
}

export interface BuildPhase {
  name: string;
  /** loader progress reached when this phase completes */
  pct: number;
  steps: BuildStep[];
}

export function createContext(viewer: Viewer, day: DayCycle, sky: SkyHandle): BuildContext {
  return {
    world: new VoxelWorld(),
    field: makeField(),
    scene: viewer.scene,
    viewer,
    day,
    rng: new Rng(20261012),
    sky,
    water: null,
    pagoda: null,
    props: null,
  };
}

/** phases in build order; main.ts walks this list */
export const PHASES: BuildPhase[] = [
  {
    name: 'land',
    pct: 24,
    steps: [
      { label: 'raising the floating island', run: (c) => generateTerrain(c.world, c.field) },
      { label: 'carving the hanging keel', run: (c) => addIslandKeelDetail(c.world, c.field) },
      { label: 'creeping moss over the stone', run: (c) => addMossPatches(c.world, c.rng.fork(3)) },
      {
        label: 'seeding meadow and wildflowers',
        run: (c) => addGroundFlora(c.world, c.field, c.rng.fork(7)),
      },
    ],
  },
  {
    name: 'water',
    pct: 36,
    steps: [
      {
        label: 'digging the spring falls',
        run: (c) => addSpringFalls(c.world, c.viewer.actors),
      },
      {
        label: 'spilling the pond over the rim',
        run: (c) => addRimCascade(c.world, c.viewer.actors),
      },
      {
        label: 'filling Mirror Pond',
        run: (c) => {
          const water = buildWaterSurface();
          c.water = water;
          c.scene.add(water.mesh);
          // keep reflections, fog and tint locked to the sky every frame
          c.viewer.actors.add({
            name: 'water-sync',
            update: (info) =>
              syncWater(
                water,
                c.sky as unknown as { uniforms: Record<string, { value: unknown }> },
                c.scene.fog as import('three').FogExp2,
                c.day.state.night,
                c.day.state.sunDir,
                c.day.state.sunColor,
                info.time,
              ),
          });
        },
      },
      {
        label: 'releasing the koi',
        run: (c) => {
          const koi = new Koi();
          c.scene.add(koi.group);
          c.viewer.actors.add(koi);
        },
      },
    ],
  },
  {
    name: 'pagoda',
    pct: 52,
    steps: [
      {
        label: 'laying the temple courtyard',
        run: (c) => buildPlaza(c.world, c.field, c.rng.fork(11)),
      },
      {
        label: 'raising the five-storied pagoda',
        run: (c) => {
          c.pagoda = buildPagoda(c.world, c.field);
        },
      },
    ],
  },
  {
    name: 'trees',
    pct: 66,
    steps: [
      {
        label: 'planting the hero trees',
        run: (c) => plantFeatureTrees(c.world, c.field, c.rng.fork(21)),
      },
      {
        label: 'growing the wild forest',
        run: (c) =>
          plantForest(c.world, c.field, c.rng.fork(22), {
            avoid: [
              { x: 0, z: -12, r: 17 }, // pagoda platform
              { x: 0, z: 8, r: 22 }, // temple courtyard
              { x: -40, z: 20, r: 25 }, // Mirror Pond
              { x: -60, z: 40, r: 11 }, // tea house
              { x: 20, z: 54, r: 9 }, // bell tower
              { x: -26, z: -38, r: 14 }, // zen court
              { x: -54, z: -34, r: 9 }, // spring pool
              { x: 40, z: -30, r: 13 }, // bamboo grove
              { x: 0, z: 48, r: 18 }, // the avenue corridor stays walkable
            ],
          }),
      },
      {
        label: 'unrolling the bamboo grove',
        run: (c) => plantBambooGrove(c.world, c.field, c.rng.fork(23), 40, -30, 12, 110),
      },
    ],
  },
  {
    name: 'structures',
    pct: 76,
    steps: [
      {
        label: 'raising gates, bridge and bell tower',
        run: (c) => {
          c.props = buildProps(c.world, c.field, c.rng.fork(31));
          if (c.pagoda) c.props.incenseSmoke = c.pagoda.incensePos;
        },
      },
    ],
  },
  {
    name: 'atmosphere',
    pct: 88,
    steps: [
      {
        label: 'launching the drifting clouds',
        run: (c) => {
          const clouds = createClouds(14);
          c.scene.add(clouds.group);
          c.viewer.actors.add(clouds.actor);
        },
      },
      {
        label: 'stirring the blossom blizzard',
        run: (c) => {
          const petals = createPetals(1100);
          c.scene.add(petals.points);
          c.viewer.actors.add(petals.actor);
        },
      },
      {
        label: 'waking the fireflies',
        run: (c) => {
          const flies = createFireflies(170);
          c.scene.add(flies.points);
          c.viewer.actors.add(flies.actor);
        },
      },
      {
        label: 'lighting the incense',
        run: (c) => {
          const anchors: [number, number, number][] = [];
          if (c.pagoda) anchors.push(c.pagoda.incensePos);
          if (c.props) anchors.push(c.props.teaSmoke);
          const smoke = new Smoke(anchors, 0.14);
          c.scene.add(smoke.points);
          c.viewer.actors.add(smoke);
        },
      },
      {
        label: 'releasing the cranes',
        run: (c) => {
          const birds = createBirds(7);
          c.scene.add(birds.group);
          c.viewer.actors.add(birds.actor);
        },
      },
    ],
  },
];

export type { TerrainField };
