/**
 * Viewer — renderer, camera, orbit rig, cinematic moves, frame loop.
 *
 * The camera rig owns a small critically-damped tween: preset buttons set a
 * target, and every frame the rig eases toward it, so touring the diorama is
 * smooth without a tweening library.
 */

import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { ActorRegistry } from './actors';

export interface CameraPreset {
  name: string;
  pos: [number, number, number];
  target: [number, number, number];
  fov?: number;
}

export interface ViewerOptions {
  container: HTMLElement;
  presets: CameraPreset[];
  onFrame?: (dt: number) => void;
}

export class Viewer {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene: THREE.Scene;
  readonly camera: THREE.PerspectiveCamera;
  readonly controls: OrbitControls;
  readonly actors = new ActorRegistry();

  private clock = new THREE.Clock();
  private presets: CameraPreset[];
  private presetIndex = 0;
  private tween = 0;
  private tweenFrom = { pos: new THREE.Vector3(), target: new THREE.Vector3(), fov: 45 };
  private tweenTo = { pos: new THREE.Vector3(), target: new THREE.Vector3(), fov: 45 };
  private autoOrbit = false;
  private orbitSpeed = 0.045;
  private running = true;
  private fpsHistory: number[] = [];
  private onFrame?: (dt: number) => void;
  private frameHandlers: ((info: { dt: number; elapsed: number }) => void)[] = [];
  /** replaces the plain renderer.render() call (used by the post stack) */
  onRender?: (dt: number) => void;
  private disposers: (() => void)[] = [];

  constructor(opts: ViewerOptions) {
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
      alpha: false,
      stencil: false,
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(opts.container.clientWidth, opts.container.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    opts.container.appendChild(renderer.domElement);
    this.renderer = renderer;
    this.onFrame = opts.onFrame;

    this.scene = new THREE.Scene();

    this.camera = new THREE.PerspectiveCamera(
      42,
      opts.container.clientWidth / Math.max(1, opts.container.clientHeight),
      0.5,
      4000,
    );
    this.camera.position.set(96, 74, 118);

    this.controls = new OrbitControls(this.camera, renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.06;
    this.controls.maxPolarAngle = Math.PI * 0.495;
    this.controls.minDistance = 22;
    this.controls.maxDistance = 320;
    this.controls.target.set(0, 24, 0);
    this.controls.update();

    // the rig slowly orbits until the visitor grabs the scene
    this.controls.addEventListener('start', () => {
      if (this.autoOrbit) this.setAutoOrbit(false);
    });

    this.presets = opts.presets;
    if (this.presets.length) {
      this.camera.position.set(...this.presets[0].pos);
      this.controls.target.set(...this.presets[0].target);
      if (this.presets[0].fov) {
        this.camera.fov = this.presets[0].fov;
        this.camera.updateProjectionMatrix();
      }
      this.controls.update();
      this.tweenTo.pos.copy(this.camera.position);
      this.tweenTo.target.copy(this.controls.target);
      this.tweenTo.fov = this.camera.fov;
      this.tweenFrom.pos.copy(this.camera.position);
      this.tweenFrom.target.copy(this.controls.target);
      this.tweenFrom.fov = this.camera.fov;
    }

    const onResize = () => this.resize(opts.container);
    window.addEventListener('resize', onResize);
    this.disposers.push(() => window.removeEventListener('resize', onResize));
  }

  get fps(): number {
    if (!this.fpsHistory.length) return 0;
    const sum = this.fpsHistory.reduce((a, b) => a + b, 0);
    return sum / this.fpsHistory.length;
  }

  addFrameHandler(fn: (info: { dt: number; elapsed: number }) => void): void {
    this.frameHandlers.push(fn);
  }

  addDisposer(fn: () => void): void {
    this.disposers.push(fn);
  }

  resize(container: HTMLElement): void {
    const w = container.clientWidth || window.innerWidth;
    const h = container.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, true);
    this.camera.aspect = w / Math.max(1, h);
    this.camera.updateProjectionMatrix();
  }

  get currentPreset(): string {
    return this.presets[this.presetIndex]?.name ?? 'free';
  }

  gotoPreset(index: number, seconds = 2.0): void {
    const p = this.presets[index % this.presets.length];
    if (!p) return;
    this.presetIndex = index % this.presets.length;
    this.tweenFrom.pos.copy(this.camera.position);
    this.tweenFrom.target.copy(this.controls.target);
    this.tweenFrom.fov = this.camera.fov;
    this.tweenTo.pos.set(...p.pos);
    this.tweenTo.target.set(...p.target);
    this.tweenTo.fov = p.fov ?? 42;
    this.tween = 1;
    this.tweenDuration = seconds;
    this.autoOrbit = false;
  }

  nextPreset(): string {
    this.gotoPreset(this.presetIndex + 1);
    return this.currentPreset;
  }

  /** jump the rig straight to an arbitrary framing (used by verification) */
  flyTo(pos: [number, number, number], target: [number, number, number]): void {
    this.camera.position.set(...pos);
    this.controls.target.set(...target);
    this.controls.update();
    this.autoOrbit = false;
  }

  get presetNames(): string[] {
    return this.presets.map((p) => p.name);
  }

  /** notified whenever auto-orbit toggles (the HUD button listens) */
  onAutoOrbitChange: ((on: boolean) => void) | null = null;

  setAutoOrbit(on: boolean): void {
    this.autoOrbit = on;
    this.onAutoOrbitChange?.(on);
  }

  get isAutoOrbit(): boolean {
    return this.autoOrbit;
  }

  private tweenDuration = 2.0;

  /** one rendered frame */
  render(dt: number): void {
    if (this.tween > 0) {
      const step = Math.min(1, dt / this.tweenDuration);
      this.tween = Math.max(0, this.tween - step);
      const t = 1 - this.tween;
      const e = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
      this.camera.position.lerpVectors(this.tweenFrom.pos, this.tweenTo.pos, e);
      this.controls.target.lerpVectors(this.tweenFrom.target, this.tweenTo.target, e);
      const fov = this.tweenFrom.fov + (this.tweenTo.fov - this.tweenFrom.fov) * e;
      if (Math.abs(this.camera.fov - fov) > 0.01) {
        this.camera.fov = fov;
        this.camera.updateProjectionMatrix();
      }
    } else if (this.autoOrbit) {
      const offset = this.camera.position.clone().sub(this.controls.target);
      const spherical = new THREE.Spherical().setFromVector3(offset);
      spherical.theta += this.orbitSpeed * dt;
      spherical.phi = Math.max(
        0.35,
        Math.min(1.25, spherical.phi + Math.sin(performance.now() * 0.00012) * 0.0006),
      );
      offset.setFromSpherical(spherical);
      this.camera.position.copy(this.controls.target).add(offset);
    }

    this.controls.update();
    if (this.onRender) this.onRender(dt);
    else this.renderer.render(this.scene, this.camera);

    this.fpsHistory.push(1 / Math.max(1e-3, dt));
    if (this.fpsHistory.length > 45) this.fpsHistory.shift();
    this.onFrame?.(dt);
    for (const h of this.frameHandlers) h({ dt, elapsed: this.clock.elapsedTime });
  }

  /** blocks until the scene has been rendered once */
  frame(): Promise<number> {
    return new Promise((resolve) => {
      requestAnimationFrame(() => {
        const dt = Math.min(0.05, this.clock.getDelta());
        this.render(dt);
        resolve(dt);
      });
    });
  }

  stop(): void {
    this.running = false;
  }

  get isRunning(): boolean {
    return this.running;
  }

  screenshot(): string {
    return this.renderer.domElement.toDataURL('image/png');
  }

  dispose(): void {
    this.stop();
    this.actors.dispose();
    for (const d of this.disposers) d();
    this.controls.dispose();
    this.renderer.dispose();
  }
}
