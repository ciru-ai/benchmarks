/**
 * Koi — living colour under the pond surface.
 *
 * Each fish is a tiny voxel sculpture (body + hinged tail) merged into two
 * geometries, then flown around the pond on a closed Catmull-Rom loop. The tail
 * hinges and the body rolls through the turns, so even six fish make the water
 * feel inhabited.
 */

import * as THREE from 'three';
import { C } from '../core/palette';
import { Rng } from '../core/rng';
import { VoxelWorld } from '../voxel/VoxelWorld';
import { buildVoxelMeshes } from '../voxel/mesher';
import type { Actor, FrameInfo } from './actors';
import { SITE, WATER_Y } from '../world/site';

const BODY_PROFILE = [0.7, 1.15, 1.45, 1.5, 1.3, 1.0, 0.7, 0.42];

interface FishParts {
  body: THREE.BufferGeometry;
}

function buildFish(rng: Rng, patchA: number, patchB: number, base: number): FishParts {
  const world = new VoxelWorld();

  // body: a tapered spindle, patched like a show koi
  for (let i = 0; i < BODY_PROFILE.length; i++) {
    const x = i - 3;
    const r = BODY_PROFILE[i];
    for (let dy = -2; dy <= 2; dy++)
      for (let dz = -2; dz <= 2; dz++) {
        const d = Math.hypot(dy * 1.15, dz);
        if (d > r) continue;
        // organic patches: blobby threshold noise seeded per-fish
        const blob = Math.sin(x * 1.7 + dy * 2.3) * Math.cos(dz * 2.1 + dy) + rng.float() * 0.55;
        let color = base;
        if (blob > 0.75) color = patchA;
        else if (blob > 0.55) color = patchB;
        world.set(x, dy, dz, color);
      }
  }

  // belly highlight and spine shadow
  for (let i = 0; i < BODY_PROFILE.length; i++) {
    const x = i - 3;
    world.set(x, -2, 0, C.koiWhite);
    world.set(x, 2, 0, C.koiInk);
  }

  // tail: a fan hinged at the rear
  for (let dz = -2; dz <= 2; dz++) {
    const spread = 2 - Math.abs(dz);
    for (let dx = 0; dx <= 1 + spread; dx++) {
      world.set(-4 - dx, dz > 0 ? 1 : dz < 0 ? -1 : 0, dz, rng.chance(0.85) ? patchA : base);
    }
  }

  // fins
  world.set(0, 0, 3, patchB);
  world.set(-1, 0, 3, patchB);
  world.set(0, 0, -3, patchB);
  world.set(-1, 0, -3, patchB);
  world.set(1, 2, 0, patchB);
  world.set(2, 2, 0, patchB);

  // eyes
  world.set(3, 1, 1, C.koiInk);
  world.set(3, 1, -1, C.koiInk);

  const solidMat = new THREE.MeshLambertMaterial({ vertexColors: true });
  const built = buildVoxelMeshes(world, () => solidMat);
  return { body: built.meshes.solid!.geometry };
}

const KOI_KINDS: { base: number; a: number; b: number }[] = [
  { base: C.koiWhite, a: C.koiOrange, b: C.koiRed },
  { base: C.koiOrange, a: C.koiWhite, b: C.koiInk },
  { base: C.koiGold, a: C.koiOrange, b: C.koiWhite },
  { base: C.koiWhite, a: C.koiInk, b: C.koiRed },
  { base: C.koiRed, a: C.koiWhite, b: C.koiGold },
  { base: C.koiWhite, a: C.koiGold, b: C.koiOrange },
];

export class Koi implements Actor {
  readonly group = new THREE.Group();
  private fish: {
    root: THREE.Group;
    tail: THREE.Object3D;
    speed: number;
    phase: number;
    curve: THREE.CatmullRomCurve3;
    bobPhase: number;
  }[] = [];

  constructor() {
    const pond = SITE.pond;
    const loops: [number, number][][] = [
      [
        [pond.x + 10, pond.z + 2],
        [pond.x + 4, pond.z + 8],
        [pond.x - 6, pond.z + 5],
        [pond.x - 10, pond.z - 3],
        [pond.x - 2, pond.z - 8],
        [pond.x + 8, pond.z - 5],
      ],
      [
        [pond.x - 12, pond.z + 6],
        [pond.x - 5, pond.z + 10],
        [pond.x + 3, pond.z + 7],
        [pond.x + 7, pond.z],
        [pond.x - 1, pond.z - 6],
        [pond.x - 10, pond.z - 2],
      ],
      [
        [pond.x + 14, pond.z - 6],
        [pond.x + 8, pond.z - 11],
        [pond.x - 2, pond.z - 10],
        [pond.x - 8, pond.z - 5],
        [pond.x - 4, pond.z + 1],
        [pond.x + 6, pond.z + 2],
      ],
    ];

    const rng = new Rng(88991);
    const geos = KOI_KINDS.map((k, i) => buildFish(rng.fork(i + 1), k.a, k.b, k.base));

    KOI_KINDS.forEach((kind, i) => {
      void kind;
      const root = new THREE.Group();
      const bodyMesh = new THREE.Mesh(geos[i].body, this.fishMaterial);
      bodyMesh.castShadow = false;
      bodyMesh.receiveShadow = false;
      root.add(bodyMesh);
      this.group.add(root);

      const curve = new THREE.CatmullRomCurve3(
        loops[i % loops.length].map(([x, z]) => new THREE.Vector3(x, 0, z)),
        true,
        'catmullrom',
        0.6,
      );
      this.fish.push({
        root,
        tail: bodyMesh,
        speed: rng.range(0.014, 0.026) * (rng.chance(0.5) ? 1 : -1),
        phase: rng.float(),
        curve,
        bobPhase: rng.float() * 6.28,
      });
    });

    this.group.name = 'koi';
  }

  private fishMaterial = new THREE.MeshLambertMaterial({ vertexColors: true });

  update(info: FrameInfo): void {
    const t = info.time;
    for (const f of this.fish) {
      const u = (f.phase + t * f.speed) % 1;
      const uu = u < 0 ? u + 1 : u;
      const p = f.curve.getPointAt(uu);
      const tan = f.curve.getTangentAt(uu);
      const bob = Math.sin(t * 2.1 + f.bobPhase) * 0.35;
      f.root.position.set(p.x, WATER_Y - 2.1 + bob, p.z);
      const targetYaw = Math.atan2(tan.x * Math.sign(f.speed), tan.z * Math.sign(f.speed));
      // ease yaw so turns bank instead of snapping
      let dy = targetYaw - f.root.rotation.y;
      while (dy > Math.PI) dy -= Math.PI * 2;
      while (dy < -Math.PI) dy += Math.PI * 2;
      f.root.rotation.y += dy * Math.min(1, info.dt * 4.5);
      f.root.rotation.z = Math.sin(t * 3.2 + f.bobPhase) * 0.06;
      // tail wag: sway the whole fish slightly around its own axis
      f.root.rotation.x = Math.sin(t * 7 + f.bobPhase) * 0.05;
    }
  }
}
