/**
 * Voxel assembly — turns the voxel world into scene meshes.
 *
 * Rebuildable: phases add voxels and then re-merge. Only the geometry is thrown
 * away on a rebuild; materials are shared, so the shader programs (and therefore
 * the frame budget) survive.
 */

import * as THREE from 'three';
import { buildVoxelMeshes } from '../voxel/mesher';
import type { VoxelWorld } from '../voxel/VoxelWorld';
import type { LayerMaterials } from './materials';

export interface Assembly {
  group: THREE.Group;
  stats: { voxels: number; faces: number; perLayer: Record<string, { voxels: number; faces: number }> };
  /** voxel count per 100³ block, for the "where is the geometry" readout */
  density: number;
}

export function assembleVoxels(
  world: VoxelWorld,
  materials: LayerMaterials,
  parent: THREE.Group | THREE.Scene,
): Assembly {
  const prev = parent.getObjectByName('voxel-diorama');
  if (prev instanceof THREE.Group) {
    for (const child of prev.children) {
      const mesh = child as THREE.Mesh;
      mesh.geometry?.dispose();
    }
    parent.remove(prev);
  }

  const group = new THREE.Group();
  group.name = 'voxel-diorama';

  const built = buildVoxelMeshes(
    world,
    (layer) => materials.get(layer),
    {
      solid: { aoStrength: 1, jitter: 0.05 },
      glow: { aoStrength: 0.45, jitter: 0.02 },
      aura: { aoStrength: 0.3, jitter: 0.0, seed: 12 },
    },
  );

  let voxels = 0;
  for (const mesh of Object.values(built.meshes)) {
    if (!mesh) continue;
    mesh.castShadow = mesh.name === 'voxels-solid';
    mesh.receiveShadow = mesh.name !== 'voxels-aura';
    group.add(mesh);
  }
  for (const s of Object.values(built.stats)) voxels += s.voxels;

  parent.add(group);

  const bbox = world.boundingBox;
  const dx = Math.max(1, bbox.max.x - bbox.min.x);
  const dy = Math.max(1, bbox.max.y - bbox.min.y);
  const dz = Math.max(1, bbox.max.z - bbox.min.z);

  return {
    group,
    stats: {
      voxels,
      faces: built.totalFaces,
      perLayer: built.stats as unknown as Assembly['stats']['perLayer'],
    },
    density: voxels / ((dx * dy * dz) / 1000),
  };
}
