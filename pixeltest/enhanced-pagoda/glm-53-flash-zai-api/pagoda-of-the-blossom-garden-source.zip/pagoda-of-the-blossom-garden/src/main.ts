/**
 * Entry point — boots the renderer, walks the build phases, then runs the loop.
 *
 * `window.__voxel` is the verification surface: Playwright reads `ready`,
 * `errors` and `stats` and can drive the day cycle or camera presets from the
 * console. That is how every phase of this garden was screenshot-checked.
 */

import { createSky } from './fx/sky';
import { DayCycle } from './fx/daycycle';
import { PRESETS } from './scene/presets';
import { createContext, PHASES, type BuildPhase } from './scene/diorama';
import { createLayerMaterials } from './scene/materials';
import { Viewer } from './scene/viewer';
import { assembleVoxels, type Assembly } from './scene/voxelAssembly';
import { createPost, type PostHandle } from './fx/postfx';
import { createHud } from './ui/hud';

interface VoxelApi {
  ready: boolean;
  building: boolean;
  phase: string;
  errors: string[];
  stats: { voxels: number; faces: number; drawCalls: number; fps: number };
  dayT: number;
  setTime(t: number): void;
  preset(nameOrIndex: string | number): void;
  flyTo(pos: [number, number, number], target: [number, number, number]): void;
  cameraPos: [number, number, number];
  assembly: Assembly | null;
  viewer: Viewer;
}

declare global {
  interface Window {
    __voxel: VoxelApi;
  }
}

const errors: string[] = [];
window.addEventListener('error', (e) => errors.push(`${e.message} @${e.filename}:${e.lineno}`));
window.addEventListener('unhandledrejection', (e) => errors.push(`promise: ${String(e.reason)}`));

const loaderEl = document.getElementById('loader')!;
const fillEl = document.getElementById('loader-fill')!;
const stageEl = document.getElementById('loader-stage')!;

/** let the browser paint the loader between build phases */
function breathe(): Promise<void> {
  return new Promise((resolve) => requestAnimationFrame(() => resolve()));
}

function progress(pct: number, label: string): void {
  fillEl.style.width = `${Math.min(100, pct)}%`;
  stageEl.textContent = `${label}…`;
}

async function boot(): Promise<void> {
  const app = document.getElementById('app')!;

  progress(4, 'waking the render engine');
  await breathe();

  const viewer = new Viewer({ container: app, presets: PRESETS });
  const sky = createSky(940);
  viewer.scene.add(sky.mesh);
  const day = new DayCycle(viewer.renderer, viewer.scene, sky);
  const materials = createLayerMaterials();

  let api: VoxelApi | null = null;
  day.addListener((s) => {
    materials.setGlow(s.glow ?? 1);
    if (api) api.dayT = s.dayT;
  });

  const ctx = createContext(viewer, day, sky);
  let assembly: Assembly | null = null;

  api = {
    ready: false,
    building: true,
    phase: 'boot',
    errors,
    stats: { voxels: 0, faces: 0, drawCalls: 0, fps: 0 },
    dayT: day.dayT,
    setTime: (t) => day.set(t),
    preset: (nameOrIndex) => {
      const idx =
        typeof nameOrIndex === 'number'
          ? nameOrIndex
          : viewer.presetNames.indexOf(nameOrIndex);
      if (idx >= 0) viewer.gotoPreset(idx, 1.2);
    },
    flyTo: (pos, target) => viewer.flyTo(pos, target),
    cameraPos: [0, 0, 0],
    assembly: null,
    viewer,
  };
  window.__voxel = api;
  const queryPhase = Number(new URLSearchParams(location.search).get('phase') ?? '99');
  const phases: BuildPhase[] = PHASES.slice(0, Math.max(1, Number.isFinite(queryPhase) ? queryPhase : 99));

  let done = 0;
  for (const phase of phases) {
    const stepPct = (phase.pct - done) / Math.max(1, phase.steps.length);
    for (const step of phase.steps) {
      api.phase = step.label;
      progress(done, step.label);
      await breathe();
      const t0 = performance.now();
      step.run(ctx);
      const ms = performance.now() - t0;
      if (ms > 4000) console.warn(`[slow step] ${step.label}: ${ms.toFixed(0)}ms`);
      done += stepPct;
    }
    progress(phase.pct - 2, `merging ${phase.name} voxels`);
    await breathe();
    assembly = assembleVoxels(ctx.world, materials, viewer.scene);
    api.assembly = assembly;
    done = phase.pct;
  }

  progress(94, 'developing the photographs');
  await breathe();
  const post: PostHandle = createPost(viewer, day);
  window.addEventListener('resize', () => {
    post.resize(viewer.renderer.domElement.clientWidth, viewer.renderer.domElement.clientHeight);
  });

  progress(96, 'hanging the lanterns');
  await breathe();
  createHud(app, { viewer, day, post, assembly, stats: api.stats });

  viewer.renderer.info.autoReset = false;

  // ---------------- loop ----------------
  let lastMs = performance.now();
  let elapsed = 0;
  let lastStats = 0;
  let drawCallSnapshot = 0;

  const tick = (): void => {
    const now = performance.now();
    const dt = Math.min(0.05, (now - lastMs) / 1000);
    lastMs = now;
    elapsed += dt;

    sky.uniforms.uTime.value = elapsed;
    viewer.actors.update({
      time: elapsed,
      dt,
      dayT: day.dayT,
      night: day.state.night,
      camera: viewer.camera,
    });

    viewer.render(dt);
    drawCallSnapshot = viewer.renderer.info.render.calls;

    if (elapsed - lastStats > 0.4) {
      lastStats = elapsed;
      Object.assign(api.stats, {
        voxels: assembly?.stats.voxels ?? 0,
        faces: assembly?.stats.faces ?? 0,
        drawCalls: drawCallSnapshot,
        fps: Math.round(viewer.fps),
      });
      viewer.renderer.info.reset();
      api.cameraPos = [
        +viewer.camera.position.x.toFixed(1),
        +viewer.camera.position.y.toFixed(1),
        +viewer.camera.position.z.toFixed(1),
      ];
      api.dayT = day.dayT;
    }
    if (viewer.isRunning) requestAnimationFrame(tick);
  };

  await viewer.frame();
  api.ready = true;
  api.building = false;
  progress(100, 'the blossom garden is open');
  loaderEl.classList.add('done');
  requestAnimationFrame(tick);

  console.info(
    `%cPagoda of the Blossom Garden%c\nvoxels ${assembly?.stats.voxels.toLocaleString()} · tris ${assembly?.stats.faces.toLocaleString()}\nbbox ${JSON.stringify(ctx.world.boundingBox.min)} → ${JSON.stringify(ctx.world.boundingBox.max)}`,
    'color:#ff9ec4;font-weight:600',
    'color:#888',
  );
}

boot().catch((err) => {
  errors.push(String(err));
  stageEl.textContent = `build failed: ${err instanceof Error ? err.message : String(err)}`;
  stageEl.style.color = '#ff8080';
  console.error(err);
});
