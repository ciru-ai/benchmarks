/**
 * HUD — the diorama's control surface.
 *
 * Built from plain DOM (styled in style.css): a title card, a panel with the
 * time-of-day slider / camera tour / toggles, a live stats readout and a key
 * hint bar. Keyboard: [Space] next camera, [T] cycle time presets,
 * [O] auto-orbit, [B] bloom, [P] save a screenshot.
 */

import type { DayCycle } from '../fx/daycycle';
import type { PostHandle } from '../fx/postfx';
import type { Viewer } from '../scene/viewer';
import type { Assembly } from '../scene/voxelAssembly';

export interface HudOptions {
  viewer: Viewer;
  day: DayCycle;
  post: PostHandle;
  assembly: Assembly | null;
  stats: { voxels: number; faces: number; drawCalls: number; fps: number };
}

const TIME_NAMES: [string, number][] = [
  ['dawn', 0.245],
  ['morning', 0.33],
  ['noon', 0.5],
  ['golden', 0.705],
  ['dusk', 0.8],
  ['night', 0.02],
];

export function createHud(app: HTMLElement, opts: HudOptions): void {
  const { viewer, day, post, stats } = opts;

  const hud = document.createElement('div');
  hud.id = 'hud';
  hud.innerHTML = `
    <div id="titlecard" class="card">
      <h1><span class="jp">五重塔</span> Pagoda of the Blossom Garden</h1>
      <p>A floating island diorama grown from ~${Math.round((opts.assembly?.stats.voxels ?? 0) / 1000)}k voxels —
      five tiered roofs, Mirror Pond, a spring falls, bamboo and maples, all under a living day cycle.</p>
    </div>
    <div id="panel" class="card">
      <h2>time of day</h2>
      <div class="field">
        <label><span>midnight</span><span id="time-readout">noon</span><span>midnight</span></label>
        <input id="time-slider" type="range" min="0" max="1" step="0.001" value="${day.dayT}" />
      </div>
      <h2>time presets</h2>
      <div class="row" id="time-presets"></div>
      <h2>camera tour</h2>
      <div class="row" id="camera-presets"></div>
      <div class="row">
        <button class="btn" id="btn-orbit">↻ auto-orbit</button>
        <button class="btn on" id="btn-bloom">✦ bloom</button>
        <button class="btn" id="btn-shot">⬇ png</button>
      </div>
    </div>
    <div id="stats" class="card"></div>
    <div id="hint" class="card">
      <kbd>space</kbd> camera · <kbd>T</kbd> time · <kbd>O</kbd> orbit · <kbd>B</kbd> bloom · <kbd>P</kbd> png
    </div>
    <div id="shotflash"></div>
  `;
  app.appendChild(hud);

  // ---- time presets ---------------------------------------------------------
  const timeRow = hud.querySelector('#time-presets')!;
  for (const [name, t] of TIME_NAMES) {
    const btn = document.createElement('button');
    btn.className = 'btn';
    btn.textContent = name;
    btn.addEventListener('click', () => {
      day.set(t);
      (hud.querySelector('#time-slider') as HTMLInputElement).value = String(t);
    });
    timeRow.appendChild(btn);
  }

  // ---- camera presets -------------------------------------------------------
  const camRow = hud.querySelector('#camera-presets')!;
  viewer.presetNames.forEach((name, i) => {
    const btn = document.createElement('button');
    btn.className = 'btn';
    btn.textContent = name;
    btn.addEventListener('click', () => viewer.gotoPreset(i));
    camRow.appendChild(btn);
  });

  // ---- slider ---------------------------------------------------------------
  const slider = hud.querySelector('#time-slider') as HTMLInputElement;
  const readout = hud.querySelector('#time-readout')!;
  slider.addEventListener('input', () => day.set(Number(slider.value)));
  const timeLabel = (): string => {
    const t = day.dayT;
    const hour = Math.floor(t * 24) % 24;
    return `${String(hour).padStart(2, '0')}:00 · ${TIME_NAMES.reduce((best, [n, v]) =>
      Math.abs(v - t) < Math.abs(best[1] - t) ? [n, v] : best,
    )[0]}`;
  };
  day.addListener(() => {
    slider.value = String(day.dayT);
  });

  // ---- toggles ---------------------------------------------------------------
  const btnOrbit = hud.querySelector('#btn-orbit')!;
  btnOrbit.addEventListener('click', () => {
    viewer.setAutoOrbit(!viewer.isAutoOrbit);
  });
  viewer.onAutoOrbitChange = (on) => btnOrbit.classList.toggle('on', on);
  viewer.setAutoOrbit(true);
  const btnBloom = hud.querySelector('#btn-bloom')!;
  btnBloom.addEventListener('click', () => {
    post.setBloom(!post.bloomOn);
    btnBloom.classList.toggle('on', post.bloomOn);
  });

  // ---- screenshot -------------------------------------------------------------
  const flash = hud.querySelector('#shotflash')!;
  const takeScreenshot = (): void => {
    flash.classList.add('on');
    setTimeout(() => flash.classList.remove('on'), 80);
    const url = viewer.renderer.domElement.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = `pagoda-garden-${Date.now()}.png`;
    a.click();
  };
  hud.querySelector('#btn-shot')!.addEventListener('click', takeScreenshot);

  // ---- keys -------------------------------------------------------------------
  window.addEventListener('keydown', (e) => {
    if (e.target instanceof HTMLInputElement) return;
    switch (e.key.toLowerCase()) {
      case ' ':
        e.preventDefault();
        viewer.nextPreset();
        break;
      case 't': {
        const idx = TIME_NAMES.findIndex(([n]) => n === timeLabel().split('· ')[1]);
        const next = TIME_NAMES[(idx + 1) % TIME_NAMES.length];
        day.set(next[1]);
        slider.value = String(next[1]);
        break;
      }
      case 'o':
        (btnOrbit as HTMLButtonElement).click();
        break;
      case 'b':
        (btnBloom as HTMLButtonElement).click();
        break;
      case 'p':
        takeScreenshot();
        break;
    }
  });

  // ---- stats loop ---------------------------------------------------------------
  const statsEl = hud.querySelector('#stats')!;
  let acc = 0;
  viewer.addFrameHandler(({ dt }) => {
    acc += dt;
    if (acc < 0.33) return;
    acc = 0;
    readout.textContent = timeLabel();
    statsEl.innerHTML =
      `<b>${stats.fps}</b> fps · <b>${stats.drawCalls}</b> draws<br>` +
      `<b>${(stats.voxels / 1000).toFixed(0)}k</b> voxels · <b>${(stats.faces / 1000).toFixed(0)}k</b> tris<br>` +
      `cam ${viewer.camera.position.x.toFixed(0)}, ${viewer.camera.position.y.toFixed(0)}, ${viewer.camera.position.z.toFixed(0)}` +
      ` · ${viewer.currentPreset}`;
  });
}
