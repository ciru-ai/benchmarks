/**
 * Mesher — turns the sparse voxel maps into three compact BufferGeometries.
 *
 * Two classic optimisations, plus the thing that makes voxel art actually look
 * good: baked ambient occlusion.
 *
 *   1. hidden-face removal — a face is only emitted if the neighbouring cell
 *      in its normal direction is empty;
 *   2. one merged mesh per layer, vertex-coloured, so the whole diorama draws
 *      in three draw calls;
 *   3. per-corner AO from the 3-cell neighbourhood of each corner, plus a
 *      fixed directional shade term (skylight from above, less from below),
 *      both multiplied into the vertex colour. Triangulation flips to keep
 *      the AO gradient smooth across long walls.
 */

import * as THREE from 'three';
import { PALETTE } from '../core/palette';
import { hash3 } from '../core/rng';
import { LAYER_NAMES, VoxelWorld, type LayerName, unkeyX, unkeyY, unkeyZ } from './VoxelWorld';

type Triple = readonly [number, number, number];

interface FaceDef {
  dir: Triple;
  u: Triple;
  v: Triple;
  shade: number;
}

/** winding chosen so that u × v === dir (front face CCW from outside) */
const FACES: FaceDef[] = [
  { dir: [1, 0, 0], u: [0, 0, -1], v: [0, 1, 0], shade: 0.74 },
  { dir: [-1, 0, 0], u: [0, 0, 1], v: [0, 1, 0], shade: 0.68 },
  { dir: [0, 1, 0], u: [1, 0, 0], v: [0, 0, -1], shade: 1.0 },
  { dir: [0, -1, 0], u: [1, 0, 0], v: [0, 0, 1], shade: 0.42 },
  { dir: [0, 0, 1], u: [1, 0, 0], v: [0, 1, 0], shade: 0.86 },
  { dir: [0, 0, -1], u: [0, 1, 0], v: [1, 0, 0], shade: 0.62 },
];

/** corner offsets in (u,v) space, matching quad order 0,1,2,3 */
const CORNER_SIGNS: readonly [number, number][] = [
  [-1, -1],
  [1, -1],
  [1, 1],
  [-1, 1],
];

const AO_LEVELS = [0.42, 0.64, 0.83, 1.0];

/** dense occupancy raster of the occluding voxels (solid + same-layer) */
class OccupancyGrid {
  private data: Uint8Array;
  private minX: number;
  private minY: number;
  private minZ: number;
  private sx: number;
  private sy: number;
  private sz: number;

  constructor(min: { x: number; y: number; z: number }, max: { x: number; y: number; z: number }) {
    this.minX = min.x - 1;
    this.minY = min.y - 1;
    this.minZ = min.z - 1;
    this.sx = max.x - min.x + 3;
    this.sy = max.y - min.y + 3;
    this.sz = max.z - min.z + 3;
    this.data = new Uint8Array(this.sx * this.sy * this.sz);
  }

  static from(world: VoxelWorld, layer: LayerName): OccupancyGrid {
    const box = world.boundingBox;
    const grid = new OccupancyGrid(box.min, box.max);
    const put = (map: Map<number, number>) => {
      for (const k of map.keys()) grid.mark(unkeyX(k), unkeyY(k), unkeyZ(k));
    };
    if (layer === 'solid') put(world.maps.solid);
    else {
      put(world.maps.solid);
      put(world.maps[layer]);
    }
    return grid;
  }

  private mark(x: number, y: number, z: number): void {
    const i = (x - this.minX) * this.sy * this.sz + (y - this.minY) * this.sz + (z - this.minZ);
    if (i >= 0 && i < this.data.length) this.data[i] = 1;
  }

  test(x: number, y: number, z: number): boolean {
    const i = (x - this.minX) * this.sy * this.sz + (y - this.minY) * this.sz + (z - this.minZ);
    return i >= 0 && i < this.data.length && this.data[i] === 1;
  }
}

/** growable float buffer holding xyz triples */
class TripleSink {
  private arr: Float32Array;
  private n = 0;

  constructor(capacity: number) {
    this.arr = new Float32Array(Math.max(64, capacity * 3));
  }

  push(a: number, b: number, c: number): void {
    if (this.n + 3 > this.arr.length) {
      const grown = new Float32Array(this.arr.length * 2);
      grown.set(this.arr);
      this.arr = grown;
    }
    this.arr[this.n++] = a;
    this.arr[this.n++] = b;
    this.arr[this.n++] = c;
  }

  get values(): Float32Array {
    return this.arr.subarray(0, this.n);
  }

  get count(): number {
    return this.n / 3;
  }
}

/** linear-space colour cache so we convert sRGB hex exactly once per palette entry */
let linearColors: Float32Array | null = null;
function ensureLinear(): Float32Array {
  if (linearColors) return linearColors;
  linearColors = new Float32Array(PALETTE.length * 3);
  const tmp = new THREE.Color();
  for (let i = 0; i < PALETTE.length; i++) {
    tmp.setHex(PALETTE[i], THREE.SRGBColorSpace);
    linearColors[i * 3] = tmp.r;
    linearColors[i * 3 + 1] = tmp.g;
    linearColors[i * 3 + 2] = tmp.b;
  }
  return linearColors;
}

export interface MeshOptions {
  /** 0 = flat, 1 = full baked AO */
  aoStrength: number;
  /** per-voxel brightness jitter, adds hand-tuned texture */
  jitter: number;
  /** only consider these layers when testing occlusion */
  occluders: LayerName[];
  seed: number;
}

const DEFAULTS: MeshOptions = {
  aoStrength: 1,
  jitter: 0.045,
  occluders: ['solid'],
  seed: 991,
};

function buildLayer(
  world: VoxelWorld,
  layer: LayerName,
  opts: MeshOptions,
): { geometry: THREE.BufferGeometry; faces: number } {
  const src = world.maps[layer];
  const pos = new TripleSink(src.size * 4);
  const nor = new TripleSink(src.size * 4);
  const col = new TripleSink(src.size * 4);
  const linear = ensureLinear();
  const aoMix = opts.aoStrength;

  // Occlusion lookups are the whole cost of meshing (6 faces x 9 probes per
  // voxel), so instead of hashing per probe we rasterise the occluder set into
  // a dense Uint8Array once and read it with plain arithmetic.
  const occ = OccupancyGrid.from(world, layer);
  const blocked = (x: number, y: number, z: number): boolean => occ.test(x, y, z);

  let faces = 0;

  for (const [key, colorIndex] of src) {
    const x = unkeyX(key);
    const y = unkeyY(key);
    const z = unkeyZ(key);
    const ci = Math.min(PALETTE.length - 1, Math.max(0, colorIndex | 0)) * 3;
    const baseR = linear[ci];
    const baseG = linear[ci + 1];
    const baseB = linear[ci + 2];

    // one deterministic brightness wobble per voxel
    const jitter = 1 + (hash3(x, y, z, opts.seed) - 0.5) * opts.jitter * 2;

    for (let f = 0; f < 6; f++) {
      const face = FACES[f];
      const dx = x + face.dir[0];
      const dy = y + face.dir[1];
      const dz = z + face.dir[2];
      if (blocked(dx, dy, dz)) continue;

      const ao: number[] = [];
      for (let c = 0; c < 4; c++) {
        const su = CORNER_SIGNS[c][0];
        const sv = CORNER_SIGNS[c][1];
        const s1 = blocked(dx + face.u[0] * su, dy + face.u[1] * su, dz + face.u[2] * su) ? 1 : 0;
        const s2 = blocked(dx + face.v[0] * sv, dy + face.v[1] * sv, dz + face.v[2] * sv) ? 1 : 0;
        const cn = blocked(
          dx + face.u[0] * su + face.v[0] * sv,
          dy + face.u[1] * su + face.v[1] * sv,
          dz + face.u[2] * su + face.v[2] * sv,
        )
          ? 1
          : 0;
        const level = s1 && s2 ? 0 : 3 - (s1 + s2 + cn);
        ao.push(1 - aoMix * (1 - AO_LEVELS[level]));
      }

      const light = face.shade * jitter;
      const cx = x + 0.5 * face.dir[0];
      const cy = y + 0.5 * face.dir[1];
      const cz = z + 0.5 * face.dir[2];

      // quad corners (CCW)
      const vx: number[] = [];
      const vy: number[] = [];
      const vz: number[] = [];
      for (let c = 0; c < 4; c++) {
        const su = CORNER_SIGNS[c][0] * 0.5;
        const sv = CORNER_SIGNS[c][1] * 0.5;
        vx.push(cx + face.u[0] * su + face.v[0] * sv);
        vy.push(cy + face.u[1] * su + face.v[1] * sv);
        vz.push(cz + face.u[2] * su + face.v[2] * sv);
      }

      // flip the diagonal when it reads better
      const order = ao[0] + ao[2] > ao[1] + ao[3] ? [0, 1, 2, 0, 2, 3] : [1, 2, 3, 1, 3, 0];
      for (let t = 0; t < 6; t++) {
        const i = order[t];
        const l = light * ao[i];
        pos.push(vx[i], vy[i], vz[i]);
        nor.push(face.dir[0], face.dir[1], face.dir[2]);
        col.push(baseR * l, baseG * l, baseB * l);
      }
      faces += 2;
    }
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(pos.values, 3));
  geometry.setAttribute('normal', new THREE.BufferAttribute(nor.values, 3));
  geometry.setAttribute('color', new THREE.BufferAttribute(col.values, 3));
  geometry.computeBoundingSphere();
  return { geometry, faces: faces / 2 };
}

export interface VoxelMeshes {
  meshes: Record<LayerName, THREE.Mesh | null>;
  geometry: THREE.BufferGeometry | null;
  stats: Record<LayerName, { voxels: number; faces: number }>;
  totalFaces: number;
}

/**
 * Build renderable meshes for all layers. `materialFor` lets the caller decide
 * how each layer shades (lit lambert for solids, unlit for glow, …).
 */
export function buildVoxelMeshes(
  world: VoxelWorld,
  materialFor: (layer: LayerName) => THREE.Material,
  options?: Partial<Record<LayerName, Partial<MeshOptions>>>,
): VoxelMeshes {
  const meshes: Record<LayerName, THREE.Mesh | null> = { solid: null, glow: null, aura: null };
  const stats = {
    solid: { voxels: world.maps.solid.size, faces: 0 },
    glow: { voxels: world.maps.glow.size, faces: 0 },
    aura: { voxels: world.maps.aura.size, faces: 0 },
  };
  let totalFaces = 0;

  for (const layer of LAYER_NAMES) {
    if (world.maps[layer].size === 0) continue;
    const opts: MeshOptions = { ...DEFAULTS, ...(options?.[layer] ?? {}) };
    const { geometry, faces } = buildLayer(world, layer, opts);
    if (geometry.attributes.position.count === 0) {
      geometry.dispose();
      continue;
    }
    const mesh = new THREE.Mesh(geometry, materialFor(layer));
    mesh.name = `voxels-${layer}`;
    mesh.castShadow = layer === 'solid';
    mesh.receiveShadow = layer !== 'aura';
    meshes[layer] = mesh;
    stats[layer].faces = faces;
    totalFaces += faces;
  }

  return { meshes, geometry: null, stats, totalFaces };
}

/**
 * Merge an arbitrary set of standalone voxel geometries (used by animated
 * actors: koi, bell clapper, cloud rafts) into one geometry+colour buffer.
 */
export function mergeGeometries(geos: THREE.BufferGeometry[]): THREE.BufferGeometry {
  const out = new THREE.BufferGeometry();
  let verts = 0;
  for (const g of geos) verts += g.attributes.position.count;
  const position = new Float32Array(verts * 3);
  const normal = new Float32Array(verts * 3);
  const color = new Float32Array(verts * 3);
  let o = 0;
  for (const g of geos) {
    const p = g.attributes.position.array as Float32Array;
    const n = g.attributes.normal.array as Float32Array;
    const c = g.attributes.color.array as Float32Array;
    position.set(p, o * 3);
    normal.set(n, o * 3);
    color.set(c, o * 3);
    o += g.attributes.position.count;
  }
  out.setAttribute('position', new THREE.BufferAttribute(position, 3));
  out.setAttribute('normal', new THREE.BufferAttribute(normal, 3));
  out.setAttribute('color', new THREE.BufferAttribute(color, 3));
  out.computeBoundingSphere();
  return out;
}
