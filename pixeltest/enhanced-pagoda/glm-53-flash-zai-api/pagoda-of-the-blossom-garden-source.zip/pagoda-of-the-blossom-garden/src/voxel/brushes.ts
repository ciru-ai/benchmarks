/**
 * Brushes — the vocabulary every builder speaks.
 *
 * Instead of hand-placing voxels, the garden is authored with primitives:
 * boxes, tapered columns, ellipsoids of blossom, swept curves for pathways,
 * arches for bridges. A colour may be a palette index or a callback, which is
 * how gradients (sakura canopies, stone weathering) fall out for free.
 */

import * as THREE from 'three';
import type { LayerName } from './VoxelWorld';
import { VoxelWorld } from './VoxelWorld';

export type ColorFn = (x: number, y: number, z: number) => number;
export type ColorLike = number | ColorFn;

export function shade(c: ColorLike, x: number, y: number, z: number): number {
  return typeof c === 'function' ? c(x, y, z) : c;
}

type Writer = (x: number, y: number, z: number, color: number) => void;

export function writerFor(world: VoxelWorld, layer: LayerName = 'solid'): Writer {
  return (x, y, z, color) => world.write(layer, x, y, z, color);
}

/** solid rectangular prism, inclusive corners */
export function box(
  world: VoxelWorld,
  x0: number,
  y0: number,
  z0: number,
  x1: number,
  y1: number,
  z1: number,
  color: ColorLike,
  layer: LayerName = 'solid',
): void {
  const w = writerFor(world, layer);
  const ax = Math.min(x0, x1);
  const bx = Math.max(x0, x1);
  const ay = Math.min(y0, y1);
  const by = Math.max(y0, y1);
  const az = Math.min(z0, z1);
  const bz = Math.max(z0, z1);
  for (let x = ax; x <= bx; x++)
    for (let y = ay; y <= by; y++)
      for (let z = az; z <= bz; z++) w(x, y, z, shade(color, x, y, z));
}

/** hollow rectangular shell (walls with an empty interior) */
export function boxShell(
  world: VoxelWorld,
  x0: number,
  y0: number,
  z0: number,
  x1: number,
  y1: number,
  z1: number,
  color: ColorLike,
  layer: LayerName = 'solid',
): void {
  const w = writerFor(world, layer);
  const ax = Math.min(x0, x1);
  const bx = Math.max(x0, x1);
  const ay = Math.min(y0, y1);
  const by = Math.max(y0, y1);
  const az = Math.min(z0, z1);
  const bz = Math.max(z0, z1);
  for (let x = ax; x <= bx; x++)
    for (let y = ay; y <= by; y++)
      for (let z = az; z <= bz; z++) {
        const onShell = x === ax || x === bx || y === ay || y === by || z === az || z === bz;
        if (onShell) w(x, y, z, shade(color, x, y, z));
      }
}

/** flat one-voxel plate */
export function plate(
  world: VoxelWorld,
  x0: number,
  z0: number,
  x1: number,
  z1: number,
  y: number,
  color: ColorLike,
  layer: LayerName = 'solid',
): void {
  box(world, x0, y, z0, x1, y, z1, color, layer);
}

/** vertical column whose radius may vary with height (tapered pillars, trunks) */
export function column(
  world: VoxelWorld,
  cx: number,
  cz: number,
  y0: number,
  y1: number,
  radius: (y: number) => number,
  color: ColorLike,
  layer: LayerName = 'solid',
): void {
  const w = writerFor(world, layer);
  const ox = Math.round(cx);
  const oz = Math.round(cz);
  const rMax = Math.ceil(radius(Math.max(y0, y1))) + 1;
  for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) {
    const r = radius(y);
    for (let dx = -rMax; dx <= rMax; dx++)
      for (let dz = -rMax; dz <= rMax; dz++) {
        const px = ox + dx;
        const pz = oz + dz;
        if (Math.hypot(px - cx, pz - cz) <= r) w(px, y, pz, shade(color, px, y, pz));
      }
  }
}

/** round disc (one voxel thick) lying in XZ */
export function disc(
  world: VoxelWorld,
  cx: number,
  cz: number,
  y: number,
  r: number,
  color: ColorLike,
  layer: LayerName = 'solid',
): void {
  column(world, cx, cz, y, y, () => r, color, layer);
}

/** filled ellipsoid — the workhorse for foliage clouds and rocks */
export function ellipsoid(
  world: VoxelWorld,
  cx: number,
  cy: number,
  cz: number,
  rx: number,
  ry: number,
  rz: number,
  color: ColorLike,
  layer: LayerName = 'solid',
): void {
  const w = writerFor(world, layer);
  const ix = Math.ceil(rx);
  const iy = Math.ceil(ry);
  const iz = Math.ceil(rz);
  for (let dx = -ix; dx <= ix; dx++)
    for (let dy = -iy; dy <= iy; dy++)
      for (let dz = -iz; dz <= iz; dz++) {
        const q = (dx * dx) / (rx * rx) + (dy * dy) / (ry * ry) + (dz * dz) / (rz * rz);
        if (q <= 1) w(Math.round(cx) + dx, Math.round(cy) + dy, Math.round(cz) + dz, shade(color, cx + dx, cy + dy, cz + dz));
      }
}

/** hollow ellipsoid shell */
export function ellipsoidShell(
  world: VoxelWorld,
  cx: number,
  cy: number,
  cz: number,
  rx: number,
  ry: number,
  rz: number,
  color: ColorLike,
  layer: LayerName = 'solid',
): void {
  const w = writerFor(world, layer);
  const ix = Math.ceil(rx);
  const iy = Math.ceil(ry);
  const iz = Math.ceil(rz);
  for (let dx = -ix; dx <= ix; dx++)
    for (let dy = -iy; dy <= iy; dy++)
      for (let dz = -iz; dz <= iz; dz++) {
        const q = (dx * dx) / (rx * rx) + (dy * dy) / (ry * ry) + (dz * dz) / (rz * rz);
        if (q <= 1 && q >= 0.55)
          w(Math.round(cx) + dx, Math.round(cy) + dy, Math.round(cz) + dz, shade(color, cx + dx, cy + dy, cz + dz));
      }
}

/** straight line of voxels between two points, thickness t */
export function line(
  world: VoxelWorld,
  ax: number,
  ay: number,
  az: number,
  bx: number,
  by: number,
  bz: number,
  color: ColorLike,
  thickness = 1,
  layer: LayerName = 'solid',
): void {
  const len = Math.ceil(Math.hypot(bx - ax, by - ay, bz - az) * 2) + 1;
  const w = writerFor(world, layer);
  const half = Math.floor((thickness - 1) / 2);
  for (let i = 0; i <= len; i++) {
    const t = i / len;
    const x = Math.round(ax + (bx - ax) * t);
    const y = Math.round(ay + (by - ay) * t);
    const z = Math.round(az + (bz - az) * t);
    for (let d = -half; d <= half; d++) {
      w(x + d, y, z, shade(color, x, y, z));
      w(x, y + d, z, shade(color, x, y, z));
      w(x, y, z + d, shade(color, x, y, z));
    }
  }
}

/**
 * Sweep voxels along a Catmull-Rom spline. Returns the sampled centreline so
 * callers can attach railings, lanterns or paving borders at parameterised
 * positions.
 */
export function sweepCurve(
  world: VoxelWorld,
  points: THREE.Vector3[],
  color: ColorLike,
  opts: {
    width?: number;
    layer?: LayerName;
    samplesPerSegment?: number;
    /** ground follower: given x,z return the y to sit on */
    follow?: (x: number, z: number) => number;
    thicknessY?: number;
    onSample?: (p: THREE.Vector3, t: number) => void;
  } = {},
): THREE.Vector3[] {
  const curve = new THREE.CatmullRomCurve3(
    points.map((p) => p.clone()),
    false,
    'catmullrom',
    0.5,
  );
  const segs = Math.max(1, points.length - 1);
  const steps = Math.max(2, Math.floor(opts.samplesPerSegment ?? 8) * segs);
  const width = opts.width ?? 1;
  const half = (width - 1) / 2;
  const thick = opts.thicknessY ?? 1;
  const layer = opts.layer ?? 'solid';
  const w = writerFor(world, layer);
  const samples: THREE.Vector3[] = [];

  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const p = curve.getPoint(t);
    const tan = curve.getTangent(t);
    const side = new THREE.Vector3(tan.z, 0, -tan.x).normalize();
    const gx = Math.round(p.x);
    const gz = Math.round(p.z);
    let gy = Math.round(p.y);
    if (opts.follow) gy = Math.round(opts.follow(gx, gz));
    for (let s = -half; s <= half; s++) {
      for (let sy = 0; sy < thick; sy++) {
        const px = gx + Math.round(side.x * s);
        const pz = gz + Math.round(side.z * s);
        w(px, gy - sy, pz, shade(color, px, gy - sy, pz));
      }
    }
    samples.push(new THREE.Vector3(gx, gy, gz));
    opts.onSample?.(new THREE.Vector3(gx, gy, gz), t);
  }
  return samples;
}

/** vertical arch band (bridge ribs, gate openings) */
export function arch(
  world: VoxelWorld,
  cx: number,
  cy: number,
  cz: number,
  radius: number,
  thickness: number,
  spanDeg: number,
  axis: 'x' | 'z',
  color: ColorLike,
  layer: LayerName = 'solid',
): void {
  const w = writerFor(world, layer);
  const steps = Math.ceil(radius * 3);
  for (let i = 0; i <= steps; i++) {
    const a = ((-spanDeg / 2 + (spanDeg * i) / steps) * Math.PI) / 180;
    for (let t = 0; t < thickness; t++) {
      const r = radius - t;
      const ox = Math.round(Math.cos(a) * r);
      const oy = Math.round(Math.sin(a) * r);
      if (axis === 'x') w(cx + ox, cy + oy, cz + t, shade(color, cx + ox, cy + oy, cz + t));
      else w(cx + t, cy + oy, cz + ox, shade(color, cx + t, cy + oy, cz + ox));
    }
  }
}

/** scatter N cells across a rectangle, jittered */
export function scatterCells(
  count: number,
  x0: number,
  z0: number,
  x1: number,
  z1: number,
  rand: () => number,
): { x: number; z: number }[] {
  const out: { x: number; z: number }[] = [];
  for (let i = 0; i < count; i++) {
    out.push({
      x: Math.round(x0 + (x1 - x0) * rand()),
      z: Math.round(z0 + (z1 - z0) * rand()),
    });
  }
  return out;
}

/** four-fold symmetric helper: run a callback on all mirrored quadrants */
export function mirror4(x: number, z: number, fn: (sx: number, sz: number) => void, skipDup = true): void {
  const combos: [number, number][] = [
    [x, z],
    [-x, z],
    [x, -z],
    [-x, -z],
  ];
  const seen = new Set<string>();
  for (const [sx, sz] of combos) {
    const k = `${sx},${sz}`;
    if (skipDup && seen.has(k)) continue;
    seen.add(k);
    fn(sx, sz);
  }
}

/** mirror left/right only */
export function mirror2(x: number, fn: (sx: number) => void): void {
  fn(x);
  fn(-x);
}
