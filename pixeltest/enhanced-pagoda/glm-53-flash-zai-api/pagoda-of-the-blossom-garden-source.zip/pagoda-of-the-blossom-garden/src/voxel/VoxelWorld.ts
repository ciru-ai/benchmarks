/**
 * VoxelWorld — sparse voxel storage.
 *
 * Three layers, because a diorama needs more than "on/off":
 *
 *   solid  — opaque, lit by the sun (structure, rock, foliage …)
 *   glow   — unlit and self-bright (lantern cores, spirit lights, embers)
 *   aura   — translucent, additive-ish (waterfall, mist, haze, ghosts)
 *
 * A voxel is keyed by its *centre* integer coordinate; the cube spans ±0.5.
 * Storage is a Map<number, paletteIndex> per layer which keeps memory modest
 * and makes "is this neighbour filled" an O(1) hash probe during meshing.
 */

export type LayerName = 'solid' | 'glow' | 'aura';
export const LAYER_NAMES: readonly LayerName[] = ['solid', 'glow', 'aura'];

const OFF = 1024;

/** unique numeric key for an integer coordinate (no bit ops: stays exact in doubles) */
export function vkey(x: number, y: number, z: number): number {
  return (x + OFF) * 4194304 + (y + OFF) * 2048 + (z + OFF);
}

export function unkeyX(k: number): number {
  return Math.floor(k / 4194304) - OFF;
}
export function unkeyY(k: number): number {
  return Math.floor(k / 2048) % 2048 - OFF;
}
export function unkeyZ(k: number): number {
  return (k % 2048) - OFF;
}

export class VoxelWorld {
  readonly maps: Record<LayerName, Map<number, number>> = {
    solid: new Map(),
    glow: new Map(),
    aura: new Map(),
  };

  private boundsMin = { x: Infinity, y: Infinity, z: Infinity };
  private boundsMax = { x: -Infinity, y: -Infinity, z: -Infinity };

  /** place a solid voxel */
  set(x: number, y: number, z: number, color: number): void {
    this.write('solid', x, y, z, color);
  }

  /** place a self-lit voxel */
  glow(x: number, y: number, z: number, color: number): void {
    this.write('glow', x, y, z, color);
  }

  /** place a translucent voxel */
  aura(x: number, y: number, z: number, color: number): void {
    this.write('aura', x, y, z, color);
  }

  write(layer: LayerName, x: number, y: number, z: number, color: number): void {
    const xi = Math.round(x);
    const yi = Math.round(y);
    const zi = Math.round(z);
    const map = this.maps[layer];
    const k = vkey(xi, yi, zi);
    if (map.has(k)) return;
    map.set(k, color);
    const b = this.boundsMin;
    const d = this.boundsMax;
    if (xi < b.x) b.x = xi;
    if (yi < b.y) b.y = yi;
    if (zi < b.z) b.z = zi;
    if (xi > d.x) d.x = xi;
    if (yi > d.y) d.y = yi;
    if (zi > d.z) d.z = zi;
  }

  /** overwrite regardless of what is there */
  force(layer: LayerName, x: number, y: number, z: number, color: number): void {
    this.maps[layer].set(vkey(Math.round(x), Math.round(y), Math.round(z)), color);
  }

  get(x: number, y: number, z: number): number | undefined {
    return this.maps.solid.get(vkey(Math.round(x), Math.round(y), Math.round(z)));
  }

  has(layer: LayerName, x: number, y: number, z: number): boolean {
    return this.maps[layer].has(vkey(Math.round(x), Math.round(y), Math.round(z)));
  }

  /** an aura/glow voxel is hidden if any solid voxel occupies the cell */
  anySolid(x: number, y: number, z: number): boolean {
    return this.maps.solid.has(vkey(Math.round(x), Math.round(y), Math.round(z)));
  }

  isEmpty(x: number, y: number, z: number): boolean {
    const k = vkey(Math.round(x), Math.round(y), Math.round(z));
    return (
      !this.maps.solid.has(k) && !this.maps.glow.has(k) && !this.maps.aura.has(k)
    );
  }

  /** delete a voxel (used to carve doorways, caves, pond basins) */
  erase(layer: LayerName, x: number, y: number, z: number): void {
    this.maps[layer].delete(vkey(Math.round(x), Math.round(y), Math.round(z)));
  }

  /** carve a box out of a layer */
  carveBox(
    layer: LayerName,
    x0: number,
    y0: number,
    z0: number,
    x1: number,
    y1: number,
    z1: number,
  ): void {
    for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++)
      for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++)
        for (let z = Math.min(z0, z1); z <= Math.max(z0, z1); z++) this.erase(layer, x, y, z);
  }

  get count(): number {
    return this.maps.solid.size + this.maps.glow.size + this.maps.aura.size;
  }

  countOf(layer: LayerName): number {
    return this.maps[layer].size;
  }

  get boundingBox(): { min: { x: number; y: number; z: number }; max: { x: number; y: number; z: number } } {
    return { min: { ...this.boundsMin }, max: { ...this.boundsMax } };
  }
}
