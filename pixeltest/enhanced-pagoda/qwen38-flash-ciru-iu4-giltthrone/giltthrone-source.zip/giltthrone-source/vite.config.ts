import { viteSingleFile } from 'vite-plugin-singlefile';
import { defineConfig } from 'vite';

/** One self-contained `dist/index.html` — the deliverable, openable straight from disk. */
export default defineConfig({
  plugins: [viteSingleFile()],
  build: {
    target: 'es2022',
    cssCodeSplit: false,
    assetsInlineLimit: 100_000_000,
    chunkSizeWarningLimit: 100_000,
    rollupOptions: { output: { inlineDynamicImports: true } },
  },
});
