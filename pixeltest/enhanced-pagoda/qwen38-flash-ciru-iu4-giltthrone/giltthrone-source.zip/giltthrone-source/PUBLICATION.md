# GILTTHRONE — publication information

**Custom prompt.** This project used a custom, multi-turn creative prompt and follow-up directions.
It is not a run of the shared Enhanced Pagoda prompt.

Generated locally with Qwen3.8 Flash CIRU Strix IU4, v5.0 weights, through OMP on Sozo
(AMD Ryzen AI Max+ 395 / Radeon 8060S). Thinking and vision were enabled, with four
parallel slots and MTP depth 3. The final shared context pool was 393,216 tokens,
with a 262,144-token per-request context limit.

The serving build was v5.5.6 with the v5.5.7 recurrent-state reset and v5.5.8
graph-memory corrections. The long session crossed runtime updates, so attribution
does not imply all generation used v5.5.8.

Publication preparation added one missing GLSL uniform declaration to the GiltArc
fragment shader: `uniform float uAlpha;`. Its JavaScript binding and fade updates
already existed. `publication-fixes.patch` records the change; authored layout,
palette and camera sequence are preserved. TypeScript, production build and fresh
browser shader checks passed for the published copy.

Run `npm install`, `npm run check`, then `npm run build -- --base=./` to recreate the
self-contained browser scene. Source dependency versions used for publication:
Three.js 0.186.1, Vite 7.3.7, TypeScript 5.9.3, vite-plugin-singlefile 2.3.4.

Model: https://huggingface.co/jcbtc/Qwen3.8-Flash-CIRU-STRIX-IU4
Runtime: https://github.com/ciru-ai/Qwen3.8-Flash-CIRU-STRIX-IU4/tree/v5.5.8
