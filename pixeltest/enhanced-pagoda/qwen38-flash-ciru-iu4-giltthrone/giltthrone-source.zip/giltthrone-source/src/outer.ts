import { Kind, VoxelWorld } from './core/VoxelWorld';
import { C, clamp, hash3, mixHex, rng, shade } from './core/palette';
import { T } from './core/schedule';

/**
 * The wide world: the coarse grid (170 x 140 x 170 cells at 4 units, origin [-340,-330,-340])
 * that only ever shows up in the pull-back, so it is authored for silhouette — a central mesa
 * the island is plugged into, a dark ring lake at row 22, contour terraces, karst towers, a
 * dead tree belt and one processional stair with a gate at every tenth step.
 *
 * The plug: a cell in row `r` spans world y from -330 + 4r up to -330 + 4(r + 1). Filling
 * column (80, 80) from BASE = 4 to MESA_TOP = 74 therefore tops out at -330 + 4 * 75 = -30,
 * while the inner island's root ends at -36 — the root sinks 1.5 cells into the plateau, so
 * the island reads as seated on a mesa rather than hanging in the sky. The plateau is dead
 * flat for PLATEAU_R = 12 cells around the axis (rows 4..74 solid, i.e. radius 6 covered).
 *
 * This grid is night mass and stays darker than the inner island: the only emissive cells are
 * the warm windows of the lakeside village and the mint flourosh in the valley hollows, capped
 * by GLOW_BUDGET. Footprint: a round basin of radius 78 cells about the axis.
 */

const A = 80; // mesa axis column/row; world x/z 0 sits under the inner island here
const BASE = 4; // lowest authored row
const MESA_TOP = 74; // plateau row — see the plug arithmetic above
const MESA_R = 27; // radius of the mesa mass
const PLATEAU_R = 12; // flat core the island is seated on
const LAKE_ROW = 22; // surface row of the ring lake
const VILLAGE_ROW = 23; // shore row the village boxes stand on
const GLOW_BUDGET = 320;

/** Roof cells of a hut: everything but the corner the lit window occupies. */
const HUT_CAP: Array<[number, number]> = [
  [0, 0],
  [1, 0],
  [0, 1],
];

/** One emissive cell, refused once the budget is spent. */
function lit(world: VoxelWorld, spent: { n: number }, x: number, y: number, z: number, hex: number, glow: number, t: number): void {
  if (spent.n >= GLOW_BUDGET || world.occupied(x, y, z)) return;
  spent.n++;
  world.set(x, y, z, hex, { kind: Kind.Glow, glow: clamp(glow, 0.35, 0.85), t, dur: 0.55 });
}

/** Top row of natural ground: flat plateau, steep wall, terraced mid slope, lake, rim hills. */
function groundRow(x: number, z: number): number {
  const dx = x - A;
  const dz = z - A;
  const d = Math.hypot(dx, dz);
  if (d <= PLATEAU_R) return MESA_TOP;
  if (d <= MESA_R) {
    const t = (d - PLATEAU_R) / (MESA_R - PLATEAU_R);
    const ang = Math.atan2(dz, dx);
    const buttress = 3 * Math.max(0, Math.sin(ang * 7 + 1.2));
    return MESA_TOP - 10 - Math.round(21 * Math.pow(t, 0.62) + buttress * (1 - t));
  }
  if (d <= 49) {
    const k = Math.min(5, Math.floor((d - MESA_R) / 3.7));
    return 40 - 3 * k - Math.round(1.5 * hash3(x >> 2, 0, z >> 2, 5));
  }
  if (d <= 78) {
    if (d >= 60 && d <= 72) return 20; // lake basin floor, water poured over it
    if (d < 59 && hash3(x >> 2, 0, z >> 2, 17) > 0.85) return 21; // scour hollow
    return 23 + Math.round(2 * hash3(x >> 1, 0, z >> 1, 3)); // valley and shore
  }
  return BASE - 1; // outside the basin: nothing
}

/** Dark basalt mass of the whole basin, one column per cell, fill from BASE upward. */
function mass(world: VoxelWorld, cue: (f: number) => number): void {
  for (let x = A - 78; x <= A + 78; x++) {
    for (let z = A - 78; z <= A + 78; z++) {
      const top = groundRow(x, z);
      if (top < BASE) continue;
      const d = Math.hypot(x - A, z - A);
      for (let row = BASE; row <= top; row++) {
        const cap = row === top;
        let hex: number;
        if (row > MESA_TOP - 3 && d <= PLATEAU_R + 2) {
          hex = mixHex(C.marbleLite, C.slate, 0.25 + 0.3 * hash3(x, row, z, 9)); // the plug crown
        } else if (cap && top <= 41) {
          hex = mixHex(C.soilDark, C.mossDeep, 0.16 + 0.22 * hash3(x, row, z, 2));
        } else {
          hex = mixHex(C.night, C.inkSoft, 0.18 + 0.34 * hash3(x, row, z, 15));
        }
        world.set(x, row, z, shade(hex, 0.62 + 0.2 * hash3(x, row, z, 6)), {
          t: cue(1 - (row - BASE) / (MESA_TOP - BASE)),
          dur: 0.5,
        });
      }
    }
  }
}

/** A dead tree: a tapering stack of bare timber, one or two snapped limbs, no foliage. */
function deadTree(
  world: VoxelWorld,
  x: number,
  z: number,
  base: number,
  h: number,
  t: number,
  r: number,
): void {
  for (let k = 0; k < h; k++) {
    const u = k / Math.max(1, h - 1);
    const rad = u < 0.45 ? r : u < 0.8 ? Math.max(0, r - 1) : 0;
    for (let dx = -rad; dx <= rad; dx++) {
      for (let dz = -rad; dz <= rad; dz++) {
        if (rad > 0 && Math.max(Math.abs(dx), Math.abs(dz)) !== rad && hash3(x + dx, k, z + dz, 41) < 0.55) {
          continue;
        }
        world.set(x + dx, base + k, z + dz, shade(C.bark, 0.52 + 0.24 * hash3(x + dx, k, z + dz, 13)), {
          t: t + u * 0.2,
          dur: 0.45,
        });
      }
    }
  }
  const limb = hash3(x, 7, z, 23);
  const sx = limb < 0.25 ? 1 : limb < 0.5 ? -1 : limb < 0.75 ? 0 : 1;
  const sz = sx === 0 ? (limb < 0.88 ? 1 : -1) : 0;
  world.set(x + sx, base + h - 1, z + sz, C.barkLite, { t: t + 0.22, dur: 0.4 });
  world.set(x + 2 * sx, base + h, z + 2 * sz, shade(C.bark, 0.8), { t: t + 0.26, dur: 0.4 });
}

/** Karst tower: a tapering limestone stack, a flat cap wider than the shaft, one dead tree on top. */
function karst(world: VoxelWorld, x: number, z: number, h: number, r: number, t: number): void {
  const g = groundRow(x, z);
  for (let k = 1; k <= h; k++) {
    const u = k / h;
    const rad = Math.max(1, Math.round(r * (1 - 0.66 * u * u)));
    for (let dx = -rad; dx <= rad; dx++) {
      for (let dz = -rad; dz <= rad; dz++) {
        if (Math.hypot(dx, dz) > rad + 0.4) continue;
        if (u > 0.3 && hash3(x + dx, 0, z + dz, 31) < 0.16 * u) continue; // flutes erode out
        const rock = mixHex(C.slate, C.ink, 0.3 + 0.34 * hash3(x + dx, g + k, z + dz, 8));
        world.set(x + dx, g + k, z + dz, shade(rock, 0.56 + 0.24 * hash3(dx, k, dz, 21)), {
          t: t + u * 0.5,
          dur: 0.6,
        });
      }
    }
  }
  const cr = Math.round(r * 0.5) + 1;
  for (let dx = -cr; dx <= cr; dx++) {
    for (let dz = -cr; dz <= cr; dz++) {
      if (Math.hypot(dx, dz) > cr + 0.45) continue;
      world.set(x + dx, g + h + 1, z + dz, shade(C.stoneLite, 0.42 + 0.2 * hash3(x + dx, g + h + 1, z + dz, 11)), {
        t: t + 0.55,
        dur: 0.45,
      });
    }
  }
  deadTree(world, x, z, g + h + 2, 4 + Math.round(2 * hash3(x, 3, z, 5)), t + 0.62, 1);
}

/** Gate astride the stair: two piers, a lintel, one warm lantern in the opening. */
function gate(world: VoxelWorld, spent: { n: number }, x: number, row: number, z: number, t: number): void {
  for (let k = 1; k <= 4; k++) {
    world.set(x - 2, row + k, z, shade(C.inkSoft, 0.72 + 0.2 * hash3(x, k, z, 19)), { t: t + k * 0.06, dur: 0.4 });
    world.set(x + 2, row + k, z, shade(C.inkSoft, 0.72 + 0.2 * hash3(x, k, z, 29)), { t: t + k * 0.06, dur: 0.4 });
  }
  for (let dx = -2; dx <= 2; dx++) {
    world.set(x + dx, row + 5, z, shade(C.slate, 0.5 + 0.12 * ((dx + 2) % 2)), { t: t + 0.3, dur: 0.4 });
  }
  lit(world, spent, x, row + 3, z, C.lantern, 0.5 + 0.2 * hash3(x, 5, z, 7), t + 0.42);
}

export function authorOuter(world: VoxelWorld, seed: number): void {
  const rand = rng(seed + 8123);
  const spent = { n: 0 };
  // One reveal window for the whole wide world: T.lift.start - 0.2 .. T.lift.start + 2.6. `f` is
  // authored order and the exponent front-loads it, so the mass is on screen well before the
  // village lights; helpers add at most 0.62 s of their own, which keeps every cell inside.
  const cue = (f: number) => T.lift.start - 0.2 + 2.0 * Math.pow(clamp(f, 0, 1), 0.62);

  // ---- the mass: mesa plug, terraced mid slope, valley floor, rim hills
  mass(world, (f) => cue(0.3 * f));

  // ---- ring lake: dark water in the basin annulus, displaced wherever anything stands
  for (let x = A - 78; x <= A + 78; x++) {
    for (let z = A - 78; z <= A + 78; z++) {
      const d = Math.hypot(x - A, z - A);
      if (d < 60 || d > 72) continue;
      for (let row = 21; row <= LAKE_ROW; row++) {
        if (world.occupied(x, row, z)) continue;
        const deep = mixHex(C.water, C.waterGlow, 0.08 * (LAKE_ROW - row));
        world.set(x, row, z, shade(deep, 0.5 + 0.22 * hash3(x, row, z, 27)), {
          kind: Kind.Water,
          t: cue(0.26 + 0.04 * (d - 60)),
          dur: 0.6,
        });
      }
    }
  }

  // ---- contour bands: a pale lip where each tread ends, so the slope reads as terraces
  for (let x = A - 49; x <= A + 49; x++) {
    for (let z = A - 49; z <= A + 49; z++) {
      const d = Math.hypot(x - A, z - A);
      if (d <= MESA_R || d > 49 || (d - MESA_R) % 3.7 > 1.05) continue;
      const top = groundRow(x, z);
      for (let row = top - 1; row <= top; row++) {
        if (!world.occupied(x, row, z)) continue;
        world.set(x, row, z, shade(C.gravel, 0.3 + 0.16 * hash3(x, row, z, 33)), {
          t: cue(0.3 + 0.06 * ((49 - d) / 22)),
          dur: 0.45,
        });
      }
    }
  }

  // ---- processional stair up the near face: it crosses the lake as an embankment and lands on
  // the plateau, with a small gate astride it at every tenth step
  const zFrom = A - 74;
  const zTo = A - PLATEAU_R + 1;
  const run = zTo - zFrom;
  for (let s = 0; s <= run; s++) {
    const z = zFrom + s;
    const tread = Math.round(25 + (MESA_TOP + 1 - 25) * (s / run));
    const from = Math.max(21, groundRow(A, z) + 1);
    for (let x = A - 1; x <= A + 1; x++) {
      for (let row = from; row <= tread; row++) {
        const flag = row === tread;
        const stone = flag ? C.stoneLite : C.slate;
        world.set(x, row, z, shade(stone, (flag ? 0.44 : 0.34) + 0.14 * hash3(x, row, z, 37)), {
          t: cue(0.4 + 0.22 * (s / run)),
          dur: 0.5,
        });
      }
    }
    if (s % 10 === 0) gate(world, spent, A, tread, z, cue(0.52 + 0.18 * (s / run)));
    if (s % 5 === 2) {
      for (const side of [-1, 1]) {
        world.set(A + 2 * side, tread + 1, z, shade(C.ironwood, 0.8), { t: cue(0.5 + 0.2 * (s / run)), dur: 0.4 });
        world.set(A + 2 * side, tread + 2, z, shade(C.barkLite, 0.7), { t: cue(0.52 + 0.2 * (s / run)), dur: 0.4 });
      }
    }
  }

  // ---- karst ring: eleven towers scattered on the mid slope, none in the stair corridor
  const perched: Array<[number, number]> = [];
  for (let tries = 0, built = 0; tries < 160 && built < 11; tries++) {
    const ang = rand() * Math.PI * 2;
    const rad = 30 + 17 * rand();
    const x = Math.round(A + Math.cos(ang) * rad);
    const z = Math.round(A + Math.sin(ang) * rad);
    if (Math.abs(x - A) <= 6 && z <= A) continue;
    if (perched.some(([px, pz]) => Math.hypot(px - x, pz - z) < 9)) continue;
    const g = groundRow(x, z);
    if (g < 25 || g > 41) continue;
    perched.push([x, z]);
    karst(world, x, z, 11 + Math.round(13 * rand()), 3 + Math.round(rand()), cue(0.36 + (0.26 * built) / 11));
    built++;
  }

  // ---- dead tree belt: leafless tapering stacks ringing the mesa, no foliage anywhere
  for (let tries = 0, belt = 0; tries < 520 && belt < 118; tries++) {
    const ang = rand() * Math.PI * 2;
    const rad = 29 + 46 * rand();
    const x = Math.round(A + Math.cos(ang) * rad);
    const z = Math.round(A + Math.sin(ang) * rad);
    const g = groundRow(x, z);
    if (g <= LAKE_ROW || world.occupied(x, g + 1, z)) continue; // never in the lake, never on the causeway
    if (perched.some(([px, pz]) => Math.hypot(px - x, pz - z) < 5)) continue;
    deadTree(world, x, z, g + 1, 5 + Math.round(7 * rand()), cue(0.62 + 0.12 * rand()), rand() < 0.28 ? 2 : 1);
    belt++;
  }

  // ---- lakeside village: twenty-four huts on the inner shore, each with one lit window
  const yards: Array<[number, number]> = [];
  for (let tries = 0, huts = 0; tries < 3000 && huts < 24; tries++) {
    const ang = rand() * Math.PI * 2;
    const rad = 53 + 4 * rand();
    const x = Math.round(A + Math.cos(ang) * rad);
    const z = Math.round(A + Math.sin(ang) * rad);
    if (groundRow(x, z) !== VILLAGE_ROW) continue;
    if (world.occupied(x, VILLAGE_ROW + 1, z) || world.occupied(x + 1, VILLAGE_ROW + 2, z + 1)) continue;
    if (yards.some(([px, pz]) => Math.hypot(px - x, pz - z) < 3)) continue;
    yards.push([x, z]);
    for (let dx = 0; dx <= 1; dx++) {
      for (let dz = 0; dz <= 1; dz++) {
        for (let k = 1; k <= 2; k++) {
          if (dx === 1 && dz === 1 && k === 2) continue; // left open for the window
          world.set(x + dx, VILLAGE_ROW + k, z + dz, shade(C.woodDark, 0.5 + 0.22 * hash3(x + dx, k, z + dz, 44)), {
            t: cue(0.74 + 0.05 * (huts / 24)),
            dur: 0.45,
          });
        }
      }
    }
    for (const [dx, dz] of HUT_CAP) {
      world.set(x + dx, VILLAGE_ROW + 3, z + dz, shade(C.tile, 0.6 + 0.25 * ((dx + dz) % 2)), {
        t: cue(0.78 + 0.05 * (huts / 24)),
        dur: 0.4,
      });
    }
    lit(world, spent, x + 1, VILLAGE_ROW + 2, z + 1, huts % 8 === 0 ? C.ember : C.lanternCore, 0.5 + 0.3 * hash3(x, 2, z, 3), cue(0.86));
    huts++;
  }

  // ---- flourosh: mint caps clustering the scour hollows, one rose cap in nine clusters
  const spots: Array<[number, number]> = [];
  for (let tries = 0, crowns = 0; tries < 9000 && crowns < 68; tries++) {
    const x = A - 57 + Math.round(rand() * 114);
    const z = A - 57 + Math.round(rand() * 114);
    if (Math.hypot(x - A, z - A) > 57 || groundRow(x, z) !== 21) continue;
    if (spots.some(([px, pz]) => Math.hypot(px - x, pz - z) < 3)) continue;
    spots.push([x, z]);
    for (let k = 0, n = 2 + Math.round(2 * rand()); k < n; k++) {
      const ox = x + Math.round(2 * rand() - 1);
      const oz = z + Math.round(2 * rand() - 1);
      if (groundRow(ox, oz) !== 21 || world.occupied(ox, 22, oz)) continue;
      const rose = crowns % 9 === 0 && k === 0;
      lit(
        world,
        spent,
        ox,
        22,
        oz,
        rose ? C.flouroshRose : C.flouroshLite,
        0.44 + 0.36 * hash3(ox, 22, oz, 12),
        cue(0.9 + 0.05 * hash3(ox, 0, oz, 61)),
      );
      if (!rose && hash3(ox, 25, oz, 71) > 0.5 && !world.occupied(ox, 23, oz)) {
        lit(world, spent, ox, 23, oz, C.flourosh, 0.4 + 0.28 * hash3(ox, 23, oz, 18), cue(0.94));
      }
    }
    crowns++;
  }
}
