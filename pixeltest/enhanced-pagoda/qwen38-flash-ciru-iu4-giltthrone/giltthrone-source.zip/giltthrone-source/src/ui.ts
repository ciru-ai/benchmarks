import { BEATS, TITLE, SUBTITLE } from './journey';
import { LOOP, T } from './core/schedule';

const CSS = `
html, body { margin: 0; height: 100%; background: #05060a; overflow: hidden; }
canvas { display: block; }
#ui {
  position: fixed; inset: 0; pointer-events: none; z-index: 10;
  font-family: "Hiragino Mincho ProN", "Noto Serif JP", "Songti SC", Georgia, serif;
  color: #e8e2d6;
  text-shadow: 0 1px 18px rgba(0, 0, 0, 0.85);
}
#ui .corner { position: absolute; top: 22px; left: 26px; }
#ui .title { font-size: 21px; letter-spacing: 0.34em; opacity: 0.92; }
#ui .sub { font-size: 11px; letter-spacing: 0.26em; opacity: 0.5; margin-top: 7px; text-transform: uppercase; }
#caption {
  position: absolute; left: 0; right: 0; bottom: 96px; text-align: center;
  font-size: 19px; letter-spacing: 0.12em; opacity: 0; transition: opacity 0.5s linear;
}
#caption .kana { display: block; font-size: 11px; letter-spacing: 0.4em; opacity: 0.55; margin-top: 9px; }
#rail { position: absolute; left: 26px; right: 26px; bottom: 34px; height: 2px; background: rgba(232, 226, 214, 0.14); }
#rail .fill { position: absolute; inset: 0 auto 0 0; width: 0; background: linear-gradient(90deg, #c9a25e, #e7ddc8); }
#rail .tick { position: absolute; bottom: 4px; width: 1px; height: 5px; background: rgba(232, 226, 214, 0.3); }
#hint {
  position: absolute; right: 26px; bottom: 30px; font-size: 10px; letter-spacing: 0.22em;
  opacity: 0.34; text-transform: uppercase;
}
#hint b { font-weight: 400; color: #c9a25e; }
body.capturing #ui { display: none; }
`;

const PHASES = [
  T.fall,
  T.impact,
  T.ground,
  T.tiers,
  T.roofs,
  T.trim,
  T.grove,
  T.hall,
  T.doors,
  T.inside,
  T.life,
  T.lift,
  T.draw,
];

export class Overlay {
  private caption!: HTMLDivElement;
  private fill!: HTMLDivElement;
  private shown = '';
  private captions = true;

  constructor(root: HTMLElement) {
    const style = document.createElement('style');
    style.textContent = CSS;
    document.head.appendChild(style);

    const ui = document.createElement('div');
    ui.id = 'ui';
    ui.innerHTML = `
      <div class="corner">
        <div class="title">${TITLE}</div>
        <div class="sub">${SUBTITLE}</div>
      </div>
      <div id="caption"></div>
      <div id="rail"><div class="fill"></div></div>
      <div id="hint"><b>drag</b> orbit · <b>wheel</b> zoom · <b>space</b> pause · <b>c</b> captions</div>
    `;
    root.appendChild(ui);
    this.caption = ui.querySelector('#caption') as HTMLDivElement;
    this.fill = ui.querySelector('.fill') as HTMLDivElement;

    const rail = ui.querySelector('#rail') as HTMLDivElement;
    for (const phase of PHASES) {
      const tick = document.createElement('div');
      tick.className = 'tick';
      tick.style.left = `${(phase.start / LOOP) * 100}%`;
      rail.appendChild(tick);
    }
  }

  /** Hide the caption layer without stopping the clock. */
  setCaptions(on: boolean): void {
    this.captions = on;
  }

  /** Captions fade in with the beat and out again before the next one lands. */
  update(t: number): void {
    this.fill.style.width = `${(t / LOOP) * 100}%`;

    if (!this.captions) {
      if (this.shown !== '') {
        this.caption.style.opacity = '0';
        this.shown = '';
      }
      return;
    }

    let i = 0;
    while (i < BEATS.length - 2 && t > BEATS[i + 1].t) i++;
    const beat = BEATS[i];
    const span = (BEATS[i + 1] ?? beat).t - beat.t;
    const local = t - beat.t;
    const text = beat.caption ?? '';
    if (!text || local > span - 0.35 || local < 0.12) {
      if (this.shown !== '') {
        this.caption.style.opacity = '0';
        this.shown = '';
      }
      return;
    }
    if (this.shown !== text) {
      this.caption.innerHTML = `${text}<span class="kana">${kanaFor(text)}</span>`;
      this.shown = text;
    }
    this.caption.style.opacity = `${Math.min(1, local / 0.6, (span - 0.35 - local) / 0.6).toFixed(3)}`;
  }
}

/** A short Japanese line under each English caption — the padoga is East Asian, the script belongs. */
const KANA: Record<string, string> = {
  'the sky opens': '空が開く',
  'molten gold lands': '溶けた金が落ちる',
  'lake, terraces, stair': '池、壇、石段',
  'the roofs unfurl': '屋根が広がる',
  'gilt on every course': 'すべての層に金',
  'the grove catches light': '林が光を受ける',
  'the great hall': '大広間',
  'the doors': '扉',
  'in through the doorway': '扉をくぐる',
  'the nave': '身廊',
  'the throne': '玉座',
  'gold on gold': '金の上にも金',
  'the light pours out': '光があふれ出す',
  'back out': '外へ出る',
  'drawn back up': '引き上げられる',
  'the sky closes': '空が閉じる',
};

function kanaFor(text: string): string {
  return KANA[text] ?? '';
}
