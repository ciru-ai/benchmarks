import type { Beat } from './core/CameraRig';
import { THRONE_MID } from './core/layout';

/**
 * The tour, one list of beats. Everything outside is an orbit around the monument axis; the
 * part that goes through the doors is a run of explicit `pos`/`look` track beats, because no
 * orbit can describe a dolly through a doorway. The last beat repeats the first pose (az written
 * one full turn lower) so the loop closes without a seam.
 *
 * World numbers: the lake sits at y 4, the hall's deck at y 33, its ceiling at y 45, and the
 * doorway's centre at z 16.5 — the aisle runs straight down -z onto the throne at z -10.5.
 */
export const BEATS: Beat[] = [
  { t: 0.0, r: 265, az: 5.05, el: 0.44, ty: 42, fov: 38, caption: 'the sky opens' },
  { t: 3.4, r: 215, az: 4.55, el: 0.34, ty: 36, fov: 42, caption: 'molten gold lands' },
  { t: 6.3, r: 165, az: 4.05, el: 0.24, ty: 31, fov: 44, caption: 'lake, terraces, stair' },
  { t: 9.2, r: 130, az: 3.4, el: 0.16, ty: 30, fov: 46, caption: 'the roofs unfurl' },
  { t: 11.6, r: 112, az: 2.6, el: 0.1, ty: 29, fov: 48, caption: 'gilt on every course' },
  { t: 13.6, r: 96, az: 1.7, el: 0.05, ty: 28, fov: 50, caption: 'the grove catches light' },
  { t: 16.2, r: 84, az: 0.95, el: 0.03, ty: 30, fov: 50, caption: 'the great hall' },
  { t: 18.6, r: 62, az: 0.3, el: 0.02, ty: 33, fov: 52, ease: 'out', caption: 'the doors' },
  {
    t: 20.4,
    pos: [0.5, 37.8, 30],
    look: [0.5, 37.2, 4],
    fov: 56,
    ease: 'out',
    caption: 'in through the doorway',
  },
  {
    t: 22.4,
    pos: [0.5, 40.6, 13],
    look: [0.5, 36.2, -12],
    fov: 60,
    ease: 'inout',
    caption: 'the nave',
  },
  {
    t: 24.4,
    pos: [-4.5, 40.4, 16],
    look: [0.5, 37.6, -14],
    fov: 50,
    ease: 'inout',
    caption: 'the throne',
  },
  {
    t: 26.6,
    pos: [3.5, 38.4, 12],
    look: [THRONE_MID[0], THRONE_MID[1] + 1, THRONE_MID[2]],
    fov: 54,
    ease: 'inout',
    caption: 'gold on gold',
  },
  {
    t: 28.6,
    pos: [0.5, 39.2, 24],
    look: [0.5, 36.0, 10],
    fov: 54,
    ease: 'inout',
    caption: 'the light pours out',
  },
  { t: 30.6, pos: [0.5, 42.5, 44], look: [0.5, 36, 12], fov: 48, ease: 'inout', caption: 'back out' },
  { t: 33.0, r: 124, az: -0.4, el: 0.22, ty: 34, fov: 44, caption: 'drawn back up' },
  { t: 36.0, r: 265, az: 5.05 - Math.PI * 2, el: 0.44, ty: 42, fov: 38, caption: 'the sky closes' },
];

export const TITLE = 'GILTTHRONE · 金殿';
export const SUBTITLE = 'a padoga cast in gold, and the grove that lights it';
