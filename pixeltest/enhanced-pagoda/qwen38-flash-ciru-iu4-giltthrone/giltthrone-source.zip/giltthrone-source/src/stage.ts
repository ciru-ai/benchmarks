import * as THREE from 'three';
import { rawColor } from './core/color';
import { Kind, VoxelWorld } from './core/VoxelWorld';
import { C, hash3 } from './core/palette';
import { VoxelMaterials } from './core/materials';
import { createSkyDome, createStars } from './core/Atmosphere';
import { GiltArc, GoldThread, Lake, Reliquary } from './core/Shell';
import { GlowSprites, ParticleField } from './core/Particles';
import { ARC, CELL, HALL, INNER, LAKE_R, LAKE_ROW, MON, OUTER, RELIQUARY, RELIQUARY_TOP, wx, wy, wz } from './core/layout';
import { T, makeSchedule } from './core/schedule';
import type { Look } from './director';
import type { MovableModel } from './builds/types';
import { authorGrove, authorLand, authorMonuments, authorTreasury, PATH } from './scene';
import { authorOuter } from './outer';
import * as props from './builds/props';
import { makeDoorLeaf } from './builds/hall';

/**
 * Scene-graph assembly and the living layer. Every actor is a closed-form function of the
 * loop clock — curves sampled at `t`, rotations integrated from `t`, particles solved in the
 * vertex shader — so seeking to any second yields the identical frame in the viewer and in
 * the frame capturer.
 */

const sched = makeSchedule();

/**
 * The door leaves: how far each hinge sits from the aisle, and how far the leaves swing.
 * The hinge plane is `HALL.doorRow`, one cell in front of the wall face, so the leaves open
 * outward onto the porch rather than into the nave.
 */
const DOORS = {
  /** world x of the two hinges — the leaves meet on the aisle */
  hinge: [wx(MON.col) - HALL.doorHalf - 0.5, wx(MON.col) + HALL.doorHalf + 0.5] as const,
  /** the swing, in radians, at full open */
  swing: 1.745,
};

/**
 * A model with a heading parent and a banking child: the child is yawed so the model's own
 * +x runs along the parent's +z, which is the axis `lookAt` drives.
 */
function mount(model: MovableModel, start: number, material: THREE.ShaderMaterial, yaw = true) {
  model.world.shiftReveal(start);
  const geo = model.world.mesh({
    cell: 1,
    origin: [-model.center[0], -model.center[1], -model.center[2]],
  });
  const mesh = new THREE.Mesh(geo, material);
  // Models face their own +x, so yaw them onto the axis `lookAt` steers. A door leaf opts out:
  // its boards are authored in the local x–y plane and the scene swings the holder about Y.
  if (yaw) mesh.rotation.y = -Math.PI / 2;
  const bank = new THREE.Group();
  bank.add(mesh);
  const holder = new THREE.Group();
  holder.add(bank);
  return { holder, bank, faces: geo.attributes.position.count / 3 };
}

/** Every emissive voxel of an authored world, in world space, for the glow billboards. */
function glowAnchors(world: VoxelWorld, cell: number, origin: readonly number[], cap: number) {
  const positions: number[] = [];
  const sizes: number[] = [];
  let n = 0;
  for (let y = 0; y < world.sy && n < cap; y++) {
    for (let z = 0; z < world.sz && n < cap; z++) {
      for (let x = 0; x < world.sx && n < cap; x++) {
        if (world.kindAt(x, y, z) !== Kind.Glow) continue;
        positions.push(origin[0] + (x + 0.5) * cell, origin[1] + (y + 0.5) * cell, origin[2] + (z + 0.5) * cell);
        sizes.push(4.2 * cell * (0.6 + 0.6 * hash3(x, y, z, 7)));
        n++;
      }
    }
  }
  return { positions, sizes };
}

/** A walk curve that sits on the authored surface, built from the same plan points as the path. */
function walkCurve(world: VoxelWorld, pts: readonly [number, number][]): THREE.CatmullRomCurve3 {
  const v = pts.map(([c, r]) => new THREE.Vector3(wx(c), wy(world.heightAt(c, r)), wz(r)));
  return new THREE.CatmullRomCurve3(v, false, 'catmullrom', 0.35);
}

export interface Stage {
  readonly group: THREE.Group;
  readonly innerMesh: THREE.Mesh;
  readonly outerMesh: THREE.Mesh;
  readonly stats: { inner: number; outer: number; plants: number; movers: number; faces: number };
  /** point sprites track the renderer's device pixel ratio */
  setPixel(ratio: number): void;
  /** drive every layer from the loop clock and the graded look */
  update(t: number, lk: Look, eye: THREE.Vector3): void;
}

export function buildStage(seed = 20261107): Stage {
  // ---------------------------------------------------------------- authored worlds
  const inner = new VoxelWorld(INNER.sx, INNER.sy, INNER.sz);
  authorLand(inner);
  authorMonuments(inner, seed);
  authorTreasury(inner, seed);
  const planted = authorGrove(inner, seed);

  const outer = new VoxelWorld(OUTER.sx, OUTER.sy, OUTER.sz);
  authorOuter(outer, seed);

  const materials = new VoxelMaterials();
  const matInner = materials.create(CELL.inner, wy(0), wy(INNER.sy - 1), 1, 1);
  const matOuter = materials.create(CELL.outer, OUTER.origin[1], OUTER.origin[1] + CELL.outer * (OUTER.sy - 1), 1, 0.62);

  const geoInner = inner.mesh({
    cell: CELL.inner,
    origin: [INNER.origin[0], INNER.origin[1], INNER.origin[2]],
    grain: 0.07,
  });
  const geoOuter = outer.mesh({
    cell: CELL.outer,
    origin: [OUTER.origin[0], OUTER.origin[1], OUTER.origin[2]],
    grain: 0.05,
  });
  const innerMesh = new THREE.Mesh(geoInner, matInner);
  const outerMesh = new THREE.Mesh(geoOuter, matOuter);
  innerMesh.frustumCulled = false;
  outerMesh.frustumCulled = false;

  // ---------------------------------------------------------------- living models
  const actors: { obj: THREE.Object3D; step(t: number): void }[] = [];
  const moverGroup = new THREE.Group();
  let moverFaces = 0;

  // the two door leaves, hinged on the porch face of the doorway
  const leafStart = sched.step('doors', 0, 0.35);
  const leaves = [-1, 1].map((side, i) => {
    const m = mount(
      makeDoorLeaf(seed + 400 + i * 13, { w: HALL.doorHalf + 1, h: HALL.headerRow - HALL.floorRow }),
      leafStart,
      matInner,
      false,
    );
    m.holder.position.set(DOORS.hinge[i], wy(HALL.floorRow) + 0.5, wz(HALL.doorRow) + 0.5);
    if (side > 0) m.holder.rotation.y = Math.PI; // the right-hand leaf boards back across the opening
    moverGroup.add(m.holder);
    moverFaces += m.faces;
    return { holder: m.holder, side };
  });

  // koi: ellipses just under the lake sheet, each on its own phase and depth
  const pond = { x: wx(104), z: wz(100) };
  for (let i = 0; i < 6; i++) {
    const m = mount(props.makeKoi(seed + 900 + i * 31), sched.step('trim', 0.2 + i * 0.1, 0.4), matInner);
    moverGroup.add(m.holder);
    moverFaces += m.faces;
    const rx = 5.5 + (i % 3) * 2.4;
    const rz = 4.5 + ((i + 1) % 3) * 2.1;
    const y = wy(LAKE_ROW - 2) + (i % 2) * 0.6;
    const sp = 0.16 + i * 0.021;
    const ph = i * 1.07;
    const at = (a: number) =>
      new THREE.Vector3(
        pond.x + Math.cos(a) * rx,
        y + Math.sin(a * 2 + ph) * 0.45,
        pond.z + Math.sin(a) * rz,
      );
    actors.push({
      obj: m.holder,
      step: (t) => {
        const a = t * sp + ph;
        const p = at(a);
        m.holder.position.copy(p);
        m.holder.lookAt(at(a + 0.18));
        m.bank.rotation.z = Math.sin(t * 1.6 + ph) * 0.16;
        m.bank.rotation.y = Math.sin(t * 3.1 + ph) * 0.12;
      },
    });
  }

  // pilgrims climbing the processional stair, ping-pong, with a step bob
  const walk = walkCurve(inner, PATH);
  for (let i = 0; i < 2; i++) {
    const m = mount(props.makePilgrim(seed + 500 + i * 17), sched.step('trim', 0.62 + i * 0.1, 0.4), matInner);
    moverGroup.add(m.holder);
    moverFaces += m.faces;
    const sp = 0.031 + i * 0.006;
    const off = i * 0.55;
    actors.push({
      obj: m.holder,
      step: (t) => {
        const s = (t * sp + off) % 2;
        const u = Math.max(0.001, Math.min(0.999, s < 1 ? s : 2 - s));
        const dir = s < 1 ? 1 : -1;
        const p = walk.getPointAt(u);
        m.holder.position.set(p.x, p.y + Math.abs(Math.sin(t * 3.4 + i)) * 0.28, p.z);
        m.holder.lookAt(walk.getPointAt(Math.max(0.001, Math.min(0.999, u + dir * 0.012))));
      },
    });
  }

  // cranes on a high ellipse, banking and pitching so the wing plates read as beating
  for (let i = 0; i < 2; i++) {
    const m = mount(props.makeCrane(seed + 300 + i * 23), T.life.start + 0.6 + i * 1.3, matInner);
    moverGroup.add(m.holder);
    moverFaces += m.faces;
    const r = 52 + i * 9;
    const sp = 0.085 - i * 0.02;
    const ph = i * 2.4;
    const at = (a: number) =>
      new THREE.Vector3(Math.cos(a) * r, 44 + Math.sin(a * 1.5 + ph) * 7 + i * 6, Math.sin(a) * r * 0.82);
    actors.push({
      obj: m.holder,
      step: (t) => {
        const a = t * sp + ph;
        m.holder.position.copy(at(a));
        m.holder.lookAt(at(a + 0.14));
        m.bank.rotation.z = 0.22 * Math.sin(a + 1.2);
        m.bank.rotation.x = Math.sin(t * 2.6 + ph) * 0.14;
      },
    });
  }

  // ---------------------------------------------------------------- reliquary, lake, arc
  const glass = new Reliquary(RELIQUARY.r, new THREE.Vector3(0, RELIQUARY.centreY, 0));
  const lake = new Lake(LAKE_R, wy(LAKE_ROW) + 1);
  const arc = new GiltArc(
    new THREE.CatmullRomCurve3([
      new THREE.Vector3(-ARC.length * 0.55, ARC.fromY - 24, -ARC.length * 0.22),
      new THREE.Vector3(-ARC.length * 0.2, ARC.fromY + 26, -ARC.length * 0.1),
      new THREE.Vector3(0, ARC.topY, 0),
      new THREE.Vector3(ARC.length * 0.24, ARC.fromY + 30, ARC.length * 0.12),
      new THREE.Vector3(ARC.length * 0.55, ARC.fromY - 26, ARC.length * 0.24),
    ]),
    ARC.radius,
  );
  const thread = new GoldThread(new THREE.Vector3(0, ARC.topY - 2, 0), new THREE.Vector3(0, RELIQUARY_TOP - 2, 0), 1.5);

  const sky = createSkyDome(2150);
  const stars = createStars(1500, 1900, seed + 5);

  // ---------------------------------------------------------------- particles and glow
  // spores off the caps: mint on green, held low over the grove
  const spores = new ParticleField(
    {
      count: 1000,
      span: 96,
      radius: 62,
      size: 2.4,
      colorA: C.flourosh,
      colorB: C.flouroshLite,
      spin: 0.06,
      drift: 6,
      fall: -0.35,
      soft: 0.62,
    },
    seed + 61,
  );
  spores.points.position.set(0, wy(72), 0);

  // gold dust in the nave, on a much shorter span so it reads as room air
  const motes = new ParticleField(
    {
      count: 520,
      span: 26,
      radius: 14,
      size: 1.6,
      colorA: C.goldHot,
      colorB: C.goldPale,
      spin: 0.02,
      drift: 2.2,
      fall: -0.15,
      soft: 0.8,
    },
    seed + 83,
  );
  motes.points.position.set(wx(MON.col) + 0.5, wy(HALL.floorRow), wz(MON.row));

  const innerGlow = glowAnchors(inner, CELL.inner, INNER.origin, 260);
  const outerGlow = glowAnchors(outer, CELL.outer, OUTER.origin, 90);
  const glow = new GlowSprites(
    innerGlow.positions.concat(outerGlow.positions),
    innerGlow.sizes.concat(outerGlow.sizes),
    C.goldHot,
  );

  // ---------------------------------------------------------------- assembly
  const group = new THREE.Group();
  group.add(outerMesh, innerMesh, moverGroup, glass.mesh, lake.mesh, arc.mesh, thread.mesh);
  group.add(sky.dome, stars.points, spores.points, motes.points, glow.points);

  const colorOrigin = new THREE.Vector3(wx(MON.col), wy(HALL.floorRow), wz(MON.row));
  const vortex = new THREE.Vector3(0, 240, 0);
  const fogColor = rawColor(C.inkDeep);

  // the two voxel-space lamps: the hall's gold and the grove's fluorescence
  const lampHall = new THREE.Vector4(wx(MON.col) + 0.5, wy(96), wz(74) + 0.5, 34);
  const lampGrove = new THREE.Vector4(wx(56) + 0.5, wy(74), wz(62) + 0.5, 66);

  return {
    group,
    innerMesh,
    outerMesh,
    stats: {
      inner: inner.volume,
      outer: outer.volume,
      plants: planted,
      movers: actors.length,
      faces:
        geoInner.attributes.position.count / 3 +
        geoOuter.attributes.position.count / 3 +
        moverFaces,
    },
    update(t, lk, eye) {
      materials.update({
        lampA: lampHall,
        gainA:
          smooth01(T.hall.start, T.doors.start + 1.2, t) *
          (1 - smooth01(T.draw.start, T.draw.start + 1.4, t)) *
          1.1,
        lampB: lampGrove,
        gainB: smooth01(T.grove.start + 1.0, T.life.start, t) * (1 - smooth01(T.draw.start, T.draw.start + 1.6, t)),
        time: t,
        ink: lk.ink,
        colorFront: lk.colorFront,
        colorOrigin,
        dissolve: lk.dissolve,
        vortex,
        swirl: lk.swirl,
        sway: lk.sway,
        water: lk.water,
        glowGain: lk.glowGain,
        exposure: lk.exposure,
        roomDim: lk.roomDim,
        fogColor: fogColor.setHex(lk.fogHex, THREE.LinearSRGBColorSpace),
        fogNear: lk.fogNear,
        fogFar: lk.fogFar,
      });

      glass.update(t, lk.glass, eye);
      lake.update(t, lk.splash, eye, fogColor);
      arc.update(t, lk.arcPaint, lk.arcHead, lk.arcGlow, lk.arcAlpha);
      thread.update(t, lk.thread);

      // the doors swing once the hall is lit and shut again before the loop closes
      const open =
        smooth01(T.doors.start, T.doors.start + 1.7, t) * (1 - smooth01(T.lift.start + 1.8, T.draw.start, t));
      for (const d of leaves) d.holder.rotation.y = (d.side > 0 ? Math.PI : 0) + d.side * open * DOORS.swing;

      for (const a of actors) a.step(t);

      // the wider land mass is only visible once the pull-back has begun
      outerMesh.visible = lk.outerGain > 0.004;
      const outerHalf = lk.outerGain;
      matOuter.uniforms.uExposure.value = lk.exposure * 0.62;

      sky.material.uniforms.uTop.value.set(lk.sky.top);
      sky.material.uniforms.uHorizon.value.set(lk.sky.horizon);
      sky.material.uniforms.uBottom.value.set(lk.sky.bottom);
      sky.material.uniforms.uHaze.value = lk.sky.haze;
      sky.material.uniforms.uTime.value = t;
      stars.material.uniforms.uStars.value = lk.sky.stars * (1 - outerHalf * 0.35);
      stars.material.uniforms.uTime.value = t;

      spores.update(t, lk.spores * (1 - 0.7 * lk.interior));
      motes.update(t, lk.motes * (0.2 + 0.8 * lk.interior) * 0.55);
      glow.update(t, lk.glowGain);
    },
    setPixel(ratio) {
      glow.setPixel(ratio);
      stars.material.uniforms.uPixel.value = ratio;
    },
  };
}

/** Smoothstep between two loop seconds, written locally so the actors stay dependency-free. */
function smooth01(a: number, b: number, t: number): number {
  const k = Math.max(0, Math.min(1, (t - a) / Math.max(0.001, b - a)));
  return k * k * (3 - 2 * k);
}
