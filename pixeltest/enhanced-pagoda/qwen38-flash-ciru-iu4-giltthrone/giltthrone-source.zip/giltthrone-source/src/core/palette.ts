/**
 * GILTTHRONE palette: the grove is dead timber and the only light in it is *flourosh* — the
 * fungus that furs every fallen log — so the authored hues split into two families that never
 * mix: cold fluorescent green/mint on the ground, hot gold inside the doors. Everything else
 * (basalt, ironwood, iron tile) is kept nearly black so those two families stay legible at any
 * camera distance, including the frame where the camera is inside the hall.
 */

export const C = {
  // rock & ground
  inkDeep: 0x0a0b10,
  ink: 0x14161d,
  inkSoft: 0x232833,
  slate: 0x3b4252,
  stone: 0x59616f,
  stoneLite: 0x7b8391,
  gravel: 0x8d9299,
  sand: 0xa79a82,
  soil: 0x2e2620,
  soilDark: 0x211a16,

  // timber & lacquer: the grove is dead wood, the monument is ironwood
  wood: 0x4a3527,
  woodDark: 0x33231a,
  ironwood: 0x2a2019,
  ironwoodLite: 0x403024,
  bark: 0x3a2c21,
  barkLite: 0x54402f,
  vermilion: 0xa83a2c,
  vermilionDeep: 0x7c2a20,
  lacquer: 0x1d1216,
  lacquerLite: 0x33202a,

  // gold — the hall's only light family
  gold: 0xd9a441,
  goldLite: 0xf4cd78,
  goldPale: 0xfff3cf,
  goldHot: 0xffe9a8,
  goldDeep: 0x8a6320,
  bronze: 0x6f5230,
  gilt: 0xc98f2c,

  // roof
  tile: 0x1a2030,
  tileDeep: 0x121723,
  tileRim: 0x8a7440,

  // flora: dead grove, moss only where flourosh feeds it
  pine: 0x234a3c,
  pineDeep: 0x17362b,
  moss: 0x3c5a44,
  mossDeep: 0x2a4131,
  leaf: 0x46603f,
  plum: 0x9c7180,
  plumLite: 0xc09aa6,
  plumDeep: 0x8a5f74,
  maple: 0x8d4a27,

  // flourosh: the fungus, its caps, its deep shade, its drifting spores
  flourosh: 0x54f0b4,
  flouroshLite: 0xa8ffe0,
  flouroshDeep: 0x2b8f74,
  flouroshRose: 0xff6ad5,
  spore: 0x9dffd9,

  // water & light
  water: 0x14324a,
  waterLite: 0x2c6478,
  waterGlow: 0x4fb9c6,
  mist: 0x9db0bf,
  lantern: 0xffb14d,
  lanternCore: 0xffe4ab,
  ember: 0xff8a3c,
  jade: 0x2f7a68,
  ruby: 0xff3f5e,
  paper: 0xf1e6cf,
  night: 0x070810,
  moon: 0xdfe9f5,
  marble: 0x1b1a24,
  marbleLite: 0x2e2c3c,
  velvet: 0x5c1130,
} as const;

export type Key = keyof typeof C;

/** Deterministic 3D hash in 0..1 — grain, scatter and AO jitter all key off this. */
export function hash3(x: number, y: number, z: number, seed = 0): number {
  let h = (x | 0) * 374761393 + (y | 0) * 668265263 + (z | 0) * 2147483647 + seed * 1274126177;
  h = (h ^ (h >>> 13)) >>> 0;
  h = Math.imul(h, 1274126177) >>> 0;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967295;
}

/** Small deterministic PRNG for author-time scatter. */
export function rng(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

export const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const smoothstep = (e0: number, e1: number, x: number) => {
  const t = clamp((x - e0) / (e1 - e0), 0, 1);
  return t * t * (3 - 2 * t);
};
/** Blend two packed hex colours, returns hex. */
export function mixHex(a: number, b: number, t: number): number {
  const ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
  const br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
  return (Math.round(lerp(ar, br, t)) << 16) | (Math.round(lerp(ag, bg, t)) << 8) | Math.round(lerp(ab, bb, t));
}
/** Multiply a packed hex colour's brightness, clamped. */
export function shade(hex: number, k: number): number {
  const r = clamp(Math.round(((hex >> 16) & 255) * k), 0, 255);
  const g = clamp(Math.round(((hex >> 8) & 255) * k), 0, 255);
  const b = clamp(Math.round((hex & 255) * k), 0, 255);
  return (r << 16) | (g << 8) | b;
}
