import * as THREE from 'three';

/**
 * The whole piece is authored in display space: voxel colours go into the mesh attribute
 * verbatim and the composer writes the frame without a colourspace conversion. `THREE.Color`
 * would quietly sRGB-decode a hex, putting sky, fog and shell a stop under the geometry they
 * are supposed to match, so every authored colour is built through here instead.
 */
export function rawColor(hex: number): THREE.Color {
  return new THREE.Color().setHex(hex, THREE.LinearSRGBColorSpace);
}
