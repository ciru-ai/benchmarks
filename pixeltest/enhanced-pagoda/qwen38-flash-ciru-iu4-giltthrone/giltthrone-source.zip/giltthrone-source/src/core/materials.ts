import * as THREE from 'three';
import { rawColor } from './color';

/**
 * The one material language of the piece.
 *
 * A voxel owns its reveal window, so the geometry is static and the *material* does the
 * choreography: each cube scales out of its own centre, spins down from above, sways in a
 * travelling wind field, and — in the draw-back — spirals up into the brush stroke. Colour
 * is graded in the fragment stage: the world is painted in ink first, and saturation spreads
 * outward from the lanterns when they light, as if the pigment were still wet.
 *
 * One material per authored world (`uCell` differs), all driven from a single state object
 * by `VoxelMaterials.update`, so a frame is still a pure function of time.
 */

const VERT = /* glsl */ `
attribute vec3 aOrigin;
attribute vec4 aAnim;
attribute vec3 aColor;
attribute vec3 aNormal;
attribute float aKind;

uniform float uTime;
uniform float uCell;
uniform float uRise;
uniform float uSway;
uniform float uDissolve;
uniform float uDissolveMask;
uniform float uSwirl;
uniform vec3 uVortex;
uniform float uLowY;
uniform float uHighY;

varying vec3 vColor;
varying vec3 vWorld;
varying float vDepth;
varying float vGlow;
varying float vKind;
varying float vUp;

void main() {
  float seed = fract(sin(dot(aOrigin.xz + aOrigin.y * 0.37, vec2(12.9898, 78.233))) * 43758.5453);

  // ---- reveal: pop into place, easing out, arriving from above
  float prog = clamp((uTime - aAnim.x) / max(aAnim.y, 0.001), 0.0, 1.0);
  float e = 1.0 - pow(1.0 - prog, 3.0);
  float pop = sin(prog * 3.14159265) * 0.16;
  float s = clamp(e + pop * (1.0 - e), 0.0, 1.25);

  // ---- draw-back: crown first, jittered, spiralling into the vortex
  float h = clamp((aOrigin.y - uLowY) / max(uHighY - uLowY, 1.0), 0.0, 1.0);
  float key = (1.0 - h) * 0.85 + seed * 0.15;
  float d = clamp((uDissolve * uDissolveMask - key) / 0.42, 0.0, 1.0);

  vec3 local = (position - aOrigin) * s * (1.0 - d);

  float lift = 1.0 - e;
  float ang = lift * (seed - 0.5) * 5.0 + d * uSwirl * (0.7 + seed * 0.6);
  float ca = cos(ang);
  float sa = sin(ang);
  local = vec3(local.x * ca - local.z * sa, local.y, local.x * sa + local.z * ca);
  local.y += lift * lift * uRise * uCell * (0.5 + seed);

  vec3 toV = uVortex - aOrigin;
  local += toV * (d * d * 1.15);
  local.xz += vec2(-toV.z, toV.x) * (d * uSwirl * 0.02) * (seed - 0.5) * 90.0;

  vec4 world = modelMatrix * vec4(aOrigin + local, 1.0);

  // ---- wind: one travelling field so every crown breathes together
  if (aAnim.z > 0.0) {
    float w = sin(uTime * 1.05 + world.x * 0.018 + world.z * 0.014)
            + 0.45 * sin(uTime * 2.15 + world.x * 0.047 + world.z * 0.03);
    float amp = aAnim.z * uSway * uCell;
    world.x += w * amp;
    world.z += w * amp * 0.42;
  }

  vec4 mv = viewMatrix * world;
  gl_Position = projectionMatrix * mv;

  vColor = aColor;
  vWorld = world.xyz;
  vDepth = -mv.z;
  vGlow = aAnim.w;
  vKind = aKind;
  vUp = aNormal.y;
}
`;

const FRAG = /* glsl */ `
precision highp float;

uniform float uTime;
uniform float uInk;
uniform float uColorFront;
uniform vec3 uColorOrigin;
uniform vec3 uInkTint;
uniform vec3 uFogColor;
uniform float uFogNear;
uniform float uFogFar;
uniform float uWater;
uniform float uGlowGain;
uniform float uExposure;
uniform float uCell;
uniform float uInkGain;
uniform vec4 uLampA;
uniform float uGainA;
uniform vec4 uLampB;
uniform float uGainB;
uniform float uRoomDim;

varying vec3 vColor;
varying vec3 vWorld;
varying float vDepth;
varying float vGlow;
varying float vKind;
varying float vUp;

void main() {
  // ---- sumi-e grade: luminance of the baked colour, cool ink bias
  float luma = dot(vColor, vec3(0.2126, 0.7152, 0.0722));
  // the ramp climbs from pooled ink to the paper tint itself, so the ink act keeps full range
  vec3 inky = mix(vec3(0.028, 0.034, 0.048), uInkTint, pow(clamp(luma, 0.0, 1.0), 0.85));

  // ---- pigment bleeding outward from the lanterns
  float dist = distance(vWorld.xz, uColorOrigin.xz);
  float cmix = 1.0 - smoothstep(uColorFront - 18.0, uColorFront + 34.0, dist);
  float inkMix = clamp(uInk * uInkGain, 0.0, 1.0);
  vec3 col = mix(inky, vColor, cmix * (1.0 - inkMix));
  // The hall's gold is authored near-white so its roof reads in the dark. Inside, the surface
  // is dimmed and only the two lamp terms stay at full strength — otherwise every wall the
  // camera frames clips to flat white.
  col *= uRoomDim;

  // ---- water: two crossed swell trains plus a moon glint on up-facing faces
  if (vKind > 1.5 && vKind < 2.5) {
    float a = sin(vWorld.x * 0.26 + vWorld.z * 0.15 + uTime * 1.15) * 0.5 + 0.5;
    float b = sin(vWorld.x * 0.1 - vWorld.z * 0.31 - uTime * 0.62) * 0.5 + 0.5;
    float far = smoothstep(34.0, 60.0, length(vWorld.xz));
    float swell = a * b * (1.0 - 0.85 * far);
    col = mix(vec3(0.052, 0.07, 0.094), col, 0.1 + 0.14 * swell);
    float glint = pow(max(swell - 0.7, 0.0) / 0.3, 3.0);
    col += vec3(0.14, 0.23, 0.29) * glint * max(vUp, 0.0) * uWater;
  }

  // ---- lantern paper / embers / gold leaf
  if (vGlow > 0.0) {
    float flicker = 0.86 + 0.14 * sin(uTime * 7.3 + vWorld.x * 0.6 + vWorld.z * 0.4);
    col += vColor * min(vGlow, 1.0) * uGlowGain * flicker * 0.42;
  }

  // ---- the two authored lamps: gold in the hall, flourosh in the grove. Nothing is lit per
  // frame, so these are the only way an interior or a forest floor can read bright.
  float lampA = 1.0 - smoothstep(uLampA.w * 0.18, uLampA.w, distance(vWorld, uLampA.xyz));
  col += vColor * vec3(1.0, 0.72, 0.34) * uGainA * lampA * (0.34 + 0.66 * max(vUp, 0.0));
  float lampB = 1.0 - smoothstep(uLampB.w * 0.18, uLampB.w, distance(vWorld, uLampB.xyz));
  col += vColor * vec3(0.42, 1.0, 0.78) * uGainB * lampB * (0.3 + 0.7 * max(vUp, 0.0));

  float fog = smoothstep(uFogNear, uFogFar, vDepth);
  col = mix(col, uFogColor, fog);

  vec3 lit = col * uExposure;
  float hi = max(lit.r, max(lit.g, lit.b));
  if (hi > 0.92) lit *= mix(1.0, 0.92 / hi, 0.72);
  gl_FragColor = vec4(lit, 1.0);
}
`;

/** Per-frame grading state, identical for every authored world. */
export interface VoxelState {
  time: number;
  /** 1 = raw cast grey, 0 = full pigment */
  ink: number;
  /** radius (world units) the pigment has reached from `colorOrigin` */
  colorFront: number;
  colorOrigin: THREE.Vector3;
  /** 0..1 how far the gold has been drawn back up after the comet */
  dissolve: number;
  vortex: THREE.Vector3;
  swirl: number;
  sway: number;
  water: number;
  glowGain: number;
  exposure: number;
  /** multiplier on authored surfaces while the camera is inside the hall (1 = outside) */
  roomDim: number;
  /** hall lamp: world position, reach, gain */
  lampA: THREE.Vector4;
  gainA: number;
  /** grove lamp: world position, reach, gain */
  lampB: THREE.Vector4;
  gainB: number;
  fogColor: THREE.Color;
  fogNear: number;
  fogFar: number;
}

export class VoxelMaterials {
  readonly materials: THREE.ShaderMaterial[] = [];

  /**
   * One material per authored world: `cell` scales the fly-in and the wind, `dissolveMask` 0
   * keeps a world out of the draw-back, `inkGain` dials how hard the cast grade bites it.
   */
  create(cell: number, lowY: number, highY: number, dissolveMask = 1, inkGain = 1): THREE.ShaderMaterial {
    const material = new THREE.ShaderMaterial({
      vertexShader: VERT,
      fragmentShader: FRAG,
      uniforms: {
        uTime: { value: 0 },
        uCell: { value: cell },
        uRise: { value: 9 },
        uSway: { value: 0 },
        uDissolve: { value: 0 },
        uDissolveMask: { value: dissolveMask },
        uSwirl: { value: 0 },
        uVortex: { value: new THREE.Vector3(0, 260, 0) },
        uLowY: { value: lowY },
        uHighY: { value: highY },
        uInk: { value: 1 },
        uInkGain: { value: inkGain },
        uColorFront: { value: 0 },
        uColorOrigin: { value: new THREE.Vector3(0, 0, 0) },
        uInkTint: { value: rawColor(0x9fb2cc) },
        uFogColor: { value: rawColor(0x0a0c14) },
        uFogNear: { value: 200 },
        uFogFar: { value: 1200 },
        uWater: { value: 0 },
        uGlowGain: { value: 0 },
        uExposure: { value: 1 },
        uLampA: { value: new THREE.Vector4(0, 0, 0, 1) },
        uGainA: { value: 0 },
        uLampB: { value: new THREE.Vector4(0, 0, 0, 1) },
        uGainB: { value: 0 },
        uRoomDim: { value: 1 },
      },
    });
    this.materials.push(material);
    return material;
  }

  update(state: VoxelState): void {
    for (const material of this.materials) {
      const u = material.uniforms;
      u.uTime.value = state.time;
      u.uInk.value = state.ink;
      u.uColorFront.value = state.colorFront;
      u.uColorOrigin.value.copy(state.colorOrigin);
      u.uDissolve.value = state.dissolve;
      u.uVortex.value.copy(state.vortex);
      u.uSwirl.value = state.swirl;
      u.uSway.value = state.sway;
      u.uWater.value = state.water;
      u.uGlowGain.value = state.glowGain;
      u.uExposure.value = state.exposure;
      u.uLampA.value.copy(state.lampA);
      u.uGainA.value = state.gainA;
      u.uLampB.value.copy(state.lampB);
      u.uGainB.value = state.gainB;
      u.uRoomDim.value = state.roomDim;
      u.uFogColor.value.copy(state.fogColor);
      u.uFogNear.value = state.fogNear;
      u.uFogFar.value = state.fogFar;
    }
  }
}
