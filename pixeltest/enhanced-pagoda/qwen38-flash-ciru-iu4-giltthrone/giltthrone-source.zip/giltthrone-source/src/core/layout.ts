/**
 * Shared geometry of the piece: the reliquary the monument is cast inside, the two voxel grids,
 * the lake, and the hall's opening — the one rectangle three different modules have to agree on
 * (the builder that cuts the doorway, the door leaves that swing out of it, the camera that
 * flies through it).
 */

export const CELL = { inner: 1, outer: 4 };

export const INNER = { sx: 160, sy: 152, sz: 160, origin: [-80, -56, -80] } as const;
export const OUTER = { sx: 170, sy: 140, sz: 170, origin: [-340, -330, -340] } as const;

/** Grid → world for the inner grid (1 unit cells). */
export const wx = (col: number) => INNER.origin[0] + col;
export const wy = (row: number) => INNER.origin[1] + row;
export const wz = (row: number) => INNER.origin[2] + row;

/** Plan centre of the monument: the axis the hall, the doorway and the throne all share. */
export const MON = { col: 80, row: 80 } as const;

/**
 * The reliquary: r 78 centred at y 24, so it hangs from y 102 down to its tip at y -54, and the
 * island's root can sink into the plateau below without breaking the glass.
 */
export const RELIQUARY = { r: 78, centreY: 24 };
export const RELIQUARY_TOP = RELIQUARY.centreY + RELIQUARY.r;
export const RELIQUARY_TIP = RELIQUARY.centreY - RELIQUARY.r;

/** Lake surface row inside the inner grid; its radius is where the sheet meets the glass. */
export const LAKE_ROW = 60;
export const LAKE_R = Math.round(Math.sqrt(RELIQUARY.r ** 2 - (RELIQUARY.centreY - wy(LAKE_ROW)) ** 2));

/**
 * The gilt arc: the ribbon of light the gold is drawn back up along at the end of the loop.
 * It starts beside the reliquary's tip and climbs past its top.
 */
export const ARC = {
  fromY: 92,
  topY: 150,
  radius: 5.2,
  length: 620,
};

/**
 * The great hall, in inner-grid coordinates. Three modules have to agree on these numbers: the
 * builder that casts the walls and cuts the doorway, the two door leaves that swing out of it,
 * and the camera that flies through it into the throne room.
 */
export const HALL = {
  /** half-span of the hall in plan, in cells, measured from the monument axis */
  half: 15,
  /** wall thickness in cells */
  wall: 2,
  /** deck the throne stands on: the first free row above the plinth */
  floorRow: 89,
  /** slab the first storey's floor sits on, i.e. the ceiling over the hall */
  ceilingRow: 102,
  /** clear doorway spans MON.col ± doorHalf along x */
  doorHalf: 4,
  /** doorway opening runs from floorRow up to (but not including) headerRow */
  headerRow: 100,
  /** z-row of the door leaves' hinge plane: one cell in front of the outer wall face */
  doorRow: 96,
  /** z-row of the rear wall's inner face, behind the throne */
  backRow: 66,
} as const;


/** World-space centre of the doorway, and of the throne's chest, for camera and lamps. */
export const DOOR_MID = [wx(MON.col) + 0.5, wy(HALL.floorRow + 5), wz(HALL.doorRow) + 0.5] as const;
export const THRONE_MID = [wx(MON.col) + 0.5, wy(HALL.floorRow + 6), wz(HALL.backRow + 3) + 0.5] as const;
