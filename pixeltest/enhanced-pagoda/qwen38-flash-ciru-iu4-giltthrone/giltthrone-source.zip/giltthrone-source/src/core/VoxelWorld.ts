import * as THREE from 'three';
import { hash3 } from './palette';

/**
 * Dense voxel grid + face-culling mesher.
 *
 * Every voxel carries its own reveal window, so the whole garden can be authored as one
 * static grid and still stream out of the ink in a choreographed order: the mesher bakes
 * `revealStart / revealDur / sway / glow` into a per-vertex attribute and the material
 * animates each cube around its own centre. Lighting is baked into the vertex colour
 * (hemisphere term + directional sun + classic voxel AO) so no shadow maps are needed and
 * the read stays sumi-e rather than plasticky.
 */

export const Kind = {
  Solid: 0,
  Foliage: 1,
  Water: 2,
  Glow: 3,
} as const;
export type Kind = 0 | 1 | 2 | 3;

export interface Put {
  kind?: Kind;
  /** second at which this voxel starts emerging (default: already there) */
  t?: number;
  /** seconds the reveal takes (default 0.4) */
  dur?: number;
  /** sway weight; foliage defaults to 1, everything else 0 */
  sway?: number;
  /** emission 0..1 for Kind.Glow (default 1) */
  glow?: number;
}

type Triple = [number, number, number];

interface FaceDef {
  n: Triple;
  t1: Triple;
  t2: Triple;
  /** baked hemisphere light for this orientation: warm sky above, cool bounce below */
  light: Triple;
}

const FACES: FaceDef[] = [
  { n: [0, 1, 0], t1: [0, 0, 1], t2: [1, 0, 0], light: [1.0, 0.99, 0.95] },
  { n: [0, -1, 0], t1: [1, 0, 0], t2: [0, 0, 1], light: [0.44, 0.5, 0.64] },
  { n: [1, 0, 0], t1: [0, 1, 0], t2: [0, 0, 1], light: [0.8, 0.79, 0.82] },
  { n: [-1, 0, 0], t1: [0, 0, 1], t2: [0, 1, 0], light: [0.62, 0.67, 0.81] },
  { n: [0, 0, 1], t1: [1, 0, 0], t2: [0, 1, 0], light: [0.9, 0.89, 0.9] },
  { n: [0, 0, -1], t1: [0, 1, 0], t2: [1, 0, 0], light: [0.71, 0.73, 0.83] },
];

/** 4 AO levels → brightness multiplier. */
const AO_CURVE = [0.3, 0.55, 0.8, 1.0];

/** Sun direction, normalised — matches the key light of the sky shader. */
const SUN: Triple = [0.36, 0.86, 0.36];

export interface MeshOptions {
  /** size of one voxel in parent units (default 1) */
  cell?: number;
  /** where grid cell (0,0,0) sits in parent units (default origin) */
  origin?: Triple;
  /** per-voxel colour grain 0..0.25 (default 0.06) */
  grain?: number;
  /** multiplier on the baked directional term (default 1) */
  bake?: number;
  /** only mesh cells at or above this grid row */
  minY?: number;
}

export class VoxelWorld {
  readonly sx: number;
  readonly sy: number;
  readonly sz: number;
  private readonly filled: Uint8Array;
  private readonly rgb: Int32Array;
  private readonly kindArr: Uint8Array;
  private readonly tArr: Float32Array;
  private readonly durArr: Float32Array;
  private readonly swayArr: Float32Array;
  private readonly glowArr: Float32Array;

  constructor(sx: number, sy: number, sz: number) {
    this.sx = sx;
    this.sy = sy;
    this.sz = sz;
    const n = sx * sy * sz;
    this.filled = new Uint8Array(n);
    this.rgb = new Int32Array(n);
    this.kindArr = new Uint8Array(n);
    this.tArr = new Float32Array(n);
    this.durArr = new Float32Array(n);
    this.swayArr = new Float32Array(n);
    this.glowArr = new Float32Array(n);
  }

  private index(x: number, y: number, z: number): number {
    return (y * this.sz + z) * this.sx + x;
  }

  inside(x: number, y: number, z: number): boolean {
    return x >= 0 && y >= 0 && z >= 0 && x < this.sx && y < this.sy && z < this.sz;
  }

  /** Occupancy test used by the mesher/AO and by builders; out of bounds reads as air. */
  occupied(x: number, y: number, z: number): boolean {
    return this.inside(x, y, z) && this.filled[this.index(x, y, z)] === 1;
  }

  colorAt(x: number, y: number, z: number): number {
    return this.occupied(x, y, z) ? this.rgb[this.index(x, y, z)] : 0;
  }

  /** Material kind of a cell — lets the scene find every emissive voxel after authoring. */
  kindAt(x: number, y: number, z: number): Kind {
    return this.inside(x, y, z) ? (this.kindArr[this.index(x, y, z)] as Kind) : Kind.Solid;
  }

  /** Move every filled cell's reveal start by `dt` — used to drop a pre-authored model
   *  into the loop clock at an absolute second. */
  shiftReveal(dt: number): void {
    for (let i = 0; i < this.filled.length; i++) {
      if (this.filled[i] === 1) this.tArr[i] += dt;
    }
  }

  /** Highest occupied row above (x, z), i.e. the cell a builder should stack on. */
  heightAt(x: number, z: number): number {
    for (let y = this.sy - 1; y >= 0; y--) if (this.occupied(x, y, z)) return y + 1;
    return 0;
  }

  set(x: number, y: number, z: number, color: number, put: Put = {}): void {
    if (!this.inside(x, y, z)) return;
    const i = this.index(x, y, z);
    const kind = put.kind ?? Kind.Solid;
    this.filled[i] = 1;
    this.rgb[i] = color;
    this.kindArr[i] = kind;
    this.tArr[i] = put.t ?? 0;
    this.durArr[i] = put.dur ?? 0.4;
    this.swayArr[i] = put.sway ?? (kind === Kind.Foliage ? 1 : 0);
    this.glowArr[i] = kind === Kind.Glow ? (put.glow ?? 1) : 0;
  }

  erase(x: number, y: number, z: number): void {
    if (!this.inside(x, y, z)) return;
    const i = this.index(x, y, z);
    this.filled[i] = 0;
    this.rgb[i] = 0;
  }

  // ---------------------------------------------------------------- authoring helpers

  /** Inclusive axis-aligned box. */
  box(x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, color: number, put: Put = {}): void {
    for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++)
      for (let z = Math.min(z0, z1); z <= Math.max(z0, z1); z++)
        for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) this.set(x, y, z, color, put);
  }

  /** Inclusive box shell — only the six walls. */
  shell(x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, color: number, put: Put = {}): void {
    for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++)
      for (let z = Math.min(z0, z1); z <= Math.max(z0, z1); z++)
        for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) {
          const onWall =
            x === x0 || x === x1 || y === y0 || y === y1 || z === z0 || z === z1;
          if (onWall) this.set(x, y, z, color, put);
        }
  }

  /** Vertical circular column, radius in cells (inclusive disc per row). */
  cylinder(cx: number, cz: number, r: number, y0: number, y1: number, color: number, put: Put = {}): void {
    const rr = r * r;
    for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++)
      for (let dz = -Math.ceil(r); dz <= Math.ceil(r); dz++)
        for (let dx = -Math.ceil(r); dx <= Math.ceil(r); dx++)
          if (dx * dx + dz * dz <= rr) this.set(cx + dx, y, cz + dz, color, put);
  }

  /** Horizontal circular slab. */
  disc(cx: number, cz: number, r: number, y: number, color: number, put: Put = {}): void {
    const rr = r * r;
    for (let dz = -Math.ceil(r); dz <= Math.ceil(r); dz++)
      for (let dx = -Math.ceil(r); dx <= Math.ceil(r); dx++)
        if (dx * dx + dz * dz <= rr) this.set(cx + dx, y, cz + dz, color, put);
  }

  /** Ellipsoid; `noise` jitters the surface outward by up to that many cells. */
  blob(cx: number, cy: number, cz: number, rx: number, ry: number, rz: number, color: number, put: Put = {}, noise = 0): void {
    const ex = Math.ceil(rx + noise), ey = Math.ceil(ry + noise), ez = Math.ceil(rz + noise);
    for (let dy = -ey; dy <= ey; dy++)
      for (let dz = -ez; dz <= ez; dz++)
        for (let dx = -ex; dx <= ex; dx++) {
          const d = Math.sqrt((dx / rx) ** 2 + (dy / ry) ** 2 + (dz / rz) ** 2);
          const j = noise ? (hash3(cx + dx, cy + dy, cz + dz, 7) - 0.5) * 2 * noise : 0;
          if (d + j <= 1) this.set(cx + dx, cy + dy, cz + dz, color, put);
        }
  }

  /** Straight run of cells between two points (thick by `r` in a square cross-section). */
  beam(a: Triple, b: Triple, r: number, color: number, put: Put = {}): void {
    const steps = Math.max(
      1,
      Math.ceil(Math.max(Math.abs(b[0] - a[0]), Math.abs(b[1] - a[1]), Math.abs(b[2] - a[2]))),
    );
    for (let s = 0; s <= steps; s++) {
      const k = s / steps;
      const x = Math.round(a[0] + (b[0] - a[0]) * k);
      const y = Math.round(a[1] + (b[1] - a[1]) * k);
      const z = Math.round(a[2] + (b[2] - a[2]) * k);
      for (let dy = 0; dy < r; dy++)
        for (let dz = 0; dz < r; dz++)
          for (let dx = 0; dx < r; dx++) this.set(x + dx, y + dy, z + dz, color, put);
    }
  }

  /** Count of occupied cells — used for budget reporting. */
  get volume(): number {
    let n = 0;
    for (let i = 0; i < this.filled.length; i++) n += this.filled[i];
    return n;
  }

  // ------------------------------------------------------------------------- meshing

  /**
   * Emits only faces that touch air, four vertices per face with AO + light baked into the
   * colour and the reveal window baked into `aAnim`. Positions land in parent space.
   */
  mesh(opts: MeshOptions = {}): THREE.BufferGeometry {
    const cell = opts.cell ?? 1;
    const ox = opts.origin?.[0] ?? 0;
    const oy = opts.origin?.[1] ?? 0;
    const oz = opts.origin?.[2] ?? 0;
    const grain = opts.grain ?? 0.06;
    const bake = opts.bake ?? 1;
    const minY = opts.minY ?? 0;

    const pos: number[] = [];
    const nor: number[] = [];
    const col: number[] = [];
    const org: number[] = [];
    const anim: number[] = [];
    const kd: number[] = [];
    const idx: number[] = [];
    let vert = 0;

    for (let y = minY; y < this.sy; y++) {
      for (let z = 0; z < this.sz; z++) {
        for (let x = 0; x < this.sx; x++) {
          const i = this.index(x, y, z);
          if (this.filled[i] === 0) continue;
          const kind = this.kindArr[i];
          const rgb = this.rgb[i];
          const r0 = ((rgb >> 16) & 255) / 255;
          const g0 = ((rgb >> 8) & 255) / 255;
          const b0 = (rgb & 255) / 255;
          const t0 = this.tArr[i];
          const tD = this.durArr[i];
          const sway = this.swayArr[i];
          const glow = this.glowArr[i];
          const jitter = 1 + (hash3(x, y, z, 11) - 0.5) * 2 * grain;

          for (let f = 0; f < 6; f++) {
            const F = FACES[f];
            const nx = x + F.n[0], ny = y + F.n[1], nz = z + F.n[2];
            if (this.occupied(nx, ny, nz)) continue;

            // baked directional + hemisphere term
            const nd = Math.max(0, F.n[0] * SUN[0] + F.n[1] * SUN[1] + F.n[2] * SUN[2]);
            const sun = (0.84 + nd * 0.62 * bake);
            const lr = F.light[0], lg = F.light[1], lb = F.light[2];

            // tangent axes as component indices so AO sampling can walk them
            const a1 = F.t1[0] !== 0 ? 0 : F.t1[1] !== 0 ? 1 : 2;
            const a2 = F.t2[0] !== 0 ? 0 : F.t2[1] !== 0 ? 1 : 2;

            for (let c = 0; c < 4; c++) {
              const s1 = c === 0 || c === 3 ? -1 : 1;
              const s2 = c < 2 ? -1 : 1;

              // classic voxel AO: two sides + the corner, all on the air side of the face
              const d1 = [0, 0, 0]; d1[a1] = s1;
              const d2 = [0, 0, 0]; d2[a2] = s2;
              const side1 = this.occupied(nx + d1[0], ny + d1[1], nz + d1[2]);
              const side2 = this.occupied(nx + d2[0], ny + d2[1], nz + d2[2]);
              const corner = this.occupied(nx + d1[0] + d2[0], ny + d1[1] + d2[1], nz + d1[2] + d2[2]);
              const aoLevel = side1 && side2 ? 0 : 3 - (Number(side1) + Number(side2) + Number(corner));
              const ao = AO_CURVE[aoLevel];

              const k = jitter * ao * sun;
              col.push(
                Math.min(1, r0 * lr * k),
                Math.min(1, g0 * lg * k),
                Math.min(1, b0 * lb * k),
              );

              const px = x + 0.5 + F.n[0] * 0.5 + s1 * 0.5 * F.t1[0] + s2 * 0.5 * F.t2[0];
              const py = y + 0.5 + F.n[1] * 0.5 + s1 * 0.5 * F.t1[1] + s2 * 0.5 * F.t2[1];
              const pz = z + 0.5 + F.n[2] * 0.5 + s1 * 0.5 * F.t1[2] + s2 * 0.5 * F.t2[2];
              pos.push(ox + px * cell, oy + py * cell, oz + pz * cell);
              org.push(ox + (x + 0.5) * cell, oy + (y + 0.5) * cell, oz + (z + 0.5) * cell);
              nor.push(F.n[0] * 127, F.n[1] * 127, F.n[2] * 127);
              anim.push(t0, tD, sway, glow);
              kd.push(kind);
            }
            idx.push(vert, vert + 1, vert + 2, vert, vert + 2, vert + 3);
            vert += 4;
          }
        }
      }
    }

    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('aOrigin', new THREE.Float32BufferAttribute(org, 3));
    g.setAttribute('aAnim', new THREE.Float32BufferAttribute(anim, 4));
    g.setAttribute('aColor', new THREE.Uint8BufferAttribute(col.map((v) => Math.round(v * 255)), 3, true));
    g.setAttribute('aNormal', new THREE.Int8BufferAttribute(nor, 3, true));
    g.setAttribute('aKind', new THREE.Uint8BufferAttribute(kd, 1));
    g.setIndex(idx);
    // The shader displaces voxels far beyond their authored position; skip frustum culling
    // rather than recompute a bound every frame.
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(ox, oy, 0), 1e6);
    return g;
  }
}
