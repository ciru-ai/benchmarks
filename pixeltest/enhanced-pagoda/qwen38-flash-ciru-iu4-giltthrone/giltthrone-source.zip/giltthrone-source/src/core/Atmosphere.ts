import * as THREE from 'three';
import { rawColor } from './color';
import { rng } from './palette';

/**
 * Sky and stars — the only two layers that are not voxels. Both are pure functions of the
 * clock: the dome's gradient is driven by three colour uniforms the director lerps, and the
 * stars twinkle off their own seeded phase, so a seek to any second redraws the same sky.
 */

const SKY = /* glsl */ `
varying vec3 vDir;
void main() {
  vDir = normalize(position);
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;

const SKY_GROUND = /* glsl */ `
precision highp float;
uniform vec3 uTop;
uniform vec3 uHorizon;
uniform vec3 uBottom;
uniform float uHaze;
uniform float uTime;
varying vec3 vDir;

float band(vec2 p) {
  return sin(p.x * 3.1 + sin(p.y * 2.3) * 1.4) * 0.5 + 0.5;
}

void main() {
  float h = vDir.y * 0.5 + 0.5;
  // horizon band first, then the deep top; haze fattens the band and lifts it
  float low = smoothstep(0.5, 0.5 - 0.26 - uHaze * 0.18, h);
  float high = smoothstep(0.52, 0.94, h);
  vec3 col = mix(uBottom, uHorizon, low);
  col = mix(col, uTop, high);

  // slow cloud bands drifting east, strongest near the horizon
  float b = band(vec2(atan(vDir.z, vDir.x) * 0.7 + uTime * 0.012, vDir.y * 2.4));
  float veil = smoothstep(0.55, 1.0, b) * (1.0 - high) * (0.22 + uHaze * 0.5);
  col = mix(col, uHorizon * 1.35 + uTop * 0.25, veil);

  // a faint moon-glow anchoring the top of the frame
  float glow = pow(max(dot(vDir, normalize(vec3(-0.35, 0.78, 0.5))), 0.0), 26.0);
  col += uHorizon * glow * 0.5 * (1.0 - uHaze * 0.4);

  gl_FragColor = vec4(col, 1.0);
}
`;

export interface Sky {
  readonly dome: THREE.Mesh;
  readonly material: THREE.ShaderMaterial;
}

/** Inverted dome. `radius` must stay inside the camera's far plane. */
export function createSkyDome(radius: number): Sky {
  const material = new THREE.ShaderMaterial({
    vertexShader: SKY,
    fragmentShader: SKY_GROUND,
    uniforms: {
      uTop: { value: rawColor(0x05070d) },
      uHorizon: { value: rawColor(0x2a3550) },
      uBottom: { value: rawColor(0x020306) },
      uHaze: { value: 0.4 },
      uTime: { value: 0 },
    },
    side: THREE.BackSide,
    depthWrite: false,
  });
  const dome = new THREE.Mesh(new THREE.SphereGeometry(radius, 48, 28), material);
  dome.renderOrder = -10;
  dome.frustumCulled = false;
  return { dome, material };
}

const STAR = /* glsl */ `
attribute vec3 aParam; // x twinkle phase, y size, z gain
uniform float uTime;
uniform float uStars;
uniform float uPixel;
varying float vI;
void main() {
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  gl_Position = projectionMatrix * mv;
  float tw = 0.65 + 0.35 * sin(uTime * 1.7 + aParam.x * 6.2831);
  vI = uStars * aParam.z * tw;
  gl_PointSize = aParam.y * uPixel * (1.0 + 0.35 * tw);
}
`;

const STAR_GROUND = /* glsl */ `
precision highp float;
varying float vI;
void main() {
  float d = length(gl_PointCoord - 0.5) * 2.0;
  float m = exp(-d * d * 4.0) * max(1.0 - d, 0.0);
  if (m * vI <= 0.004) discard;
  gl_FragColor = vec4(vec3(0.86, 0.92, 1.0) * m * vI, m * vI);
}
`;

export interface Stars {
  readonly points: THREE.Points;
  readonly material: THREE.ShaderMaterial;
}

/** Shell of twinkling points centred on the world. */
export function createStars(count: number, radius: number, seed: number): Stars {
  const rand = rng(seed);
  const pos = new Float32Array(count * 3);
  const param = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    // even on the sphere, pushed above the horizon so the floor of the sky stays clean
    const u = rand();
    const v = rand() * 0.62 + 0.19;
    const theta = u * Math.PI * 2;
    const phi = Math.acos(1 - 2 * v);
    const r = radius * (0.9 + 0.1 * rand());
    pos[i * 3] = Math.sin(phi) * Math.cos(theta) * r;
    pos[i * 3 + 1] = Math.abs(Math.cos(phi)) * r * 0.85 + radius * 0.06;
    pos[i * 3 + 2] = Math.sin(phi) * Math.sin(theta) * r;
    param[i * 3] = rand();
    param[i * 3 + 1] = 1.1 + rand() * rand() * 3.4;
    param[i * 3 + 2] = 0.35 + rand() * 0.65;
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  geometry.setAttribute('aParam', new THREE.BufferAttribute(param, 3));
  geometry.boundingSphere = new THREE.Sphere(new THREE.Vector3(), radius * 1.05);
  const material = new THREE.ShaderMaterial({
    vertexShader: STAR,
    fragmentShader: STAR_GROUND,
    uniforms: {
      uTime: { value: 0 },
      uStars: { value: 0 },
      uPixel: { value: 1 },
    },
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const points = new THREE.Points(geometry, material);
  points.frustumCulled = false;
  return { points, material };
}
