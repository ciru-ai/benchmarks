import * as THREE from 'three';
import { rawColor } from './color';

/**
 * The three non-voxel set pieces that carry the conceit: the cast-glass reliquary the monument
 * is cast inside, the lake it stands in, and the arc of light the gold is drawn back up along.
 * Each is a single mesh with its own shader and a scalar the director drives.
 */

const FRESNEL_VERT = /* glsl */ `
varying vec3 vWorld;
varying vec3 vNormal;
void main() {
  vec4 w = modelMatrix * vec4(position, 1.0);
  vWorld = w.xyz;
  vNormal = normalize(mat3(modelMatrix) * normal);
  gl_Position = projectionMatrix * viewMatrix * w;
}
`;

/** Invisible from the inside, a rim-lit jewel from outside. */
export class Reliquary {
  readonly mesh: THREE.Mesh;
  private readonly uniforms: Record<string, THREE.IUniform>;

  constructor(radius: number, center: THREE.Vector3) {
    this.uniforms = {
      uReveal: { value: 0 },
      uEye: { value: new THREE.Vector3() },
      uLightDir: { value: new THREE.Vector3(0.42, 0.6, -0.68) },
      uTime: { value: 0 },
      uColor: { value: rawColor(0xffca8c) },
    };
    this.mesh = new THREE.Mesh(
      new THREE.SphereGeometry(radius, 64, 48),
      new THREE.ShaderMaterial({
        vertexShader: FRESNEL_VERT,
        fragmentShader: /* glsl */ `
precision highp float;
uniform float uReveal;
uniform vec3 uEye;
uniform vec3 uLightDir;
uniform float uTime;
uniform vec3 uColor;
varying vec3 vWorld;
varying vec3 vNormal;

void main() {
  vec3 n = normalize(vNormal);
  vec3 v = normalize(uEye - vWorld);
  float facing = dot(n, v);
  // grazing angle reads as glass; looking straight through it stays clear
  float fres = pow(1.0 - abs(facing), 3.2);
  vec3 l = normalize(uLightDir);
  vec3 h = normalize(l + v);
  float spec = pow(max(dot(n, h), 0.0), 300.0) * 1.5;
  float sheen = pow(max(dot(n, normalize(vec3(l.x, 0.25, l.z))), 0.0), 3.0) * 0.16;
  float wobble = 0.9 + 0.1 * sin(vWorld.x * 0.12 + vWorld.y * 0.09 + uTime * 0.8);

  // the inside of the glass never blocks the monument
  float outside = step(0.0, facing);
  vec3 col = uColor * (fres * 1.35 * wobble + sheen) + vec3(1.0, 0.92, 0.74) * spec;
  float a = clamp(fres * 0.9 + spec * 0.8 + sheen, 0.0, 1.0) * uReveal * (0.35 + 0.65 * outside);
  gl_FragColor = vec4(col, a);
}
`,
        uniforms: this.uniforms,
        transparent: true,
        depthWrite: false,
        side: THREE.DoubleSide,
      }),
    );
    this.mesh.position.copy(center);
    this.mesh.renderOrder = 20;
  }

  update(time: number, reveal: number, eye: THREE.Vector3): void {
    this.uniforms.uTime.value = time;
    this.uniforms.uReveal.value = reveal;
    (this.uniforms.uEye.value as THREE.Vector3).copy(eye);
    this.mesh.visible = reveal > 0.002;
  }
}

/** Lake: dark mirror with concentric impact rings and a slow ambient swell. */
export class Lake {
  readonly mesh: THREE.Mesh;
  private readonly uniforms: Record<string, THREE.IUniform>;

  constructor(radius: number, y: number) {
    this.uniforms = {
      uTime: { value: 0 },
      uImpact: { value: -1 },
      uImpactAt: { value: new THREE.Vector2(0, 0) },
      uLightDir: { value: new THREE.Vector3(0.42, 0.6, -0.68) },
      uEye: { value: new THREE.Vector3() },
      uDeep: { value: rawColor(0x07070d) },
      uSheen: { value: rawColor(0xc9995a) },
      uRippleGain: { value: 1 },
      uFog: { value: rawColor(0x0a0c14) },
    };
    this.mesh = new THREE.Mesh(
      new THREE.CircleGeometry(radius, 128),
      new THREE.ShaderMaterial({
        vertexShader: FRESNEL_VERT,
        fragmentShader: /* glsl */ `
precision highp float;
uniform float uTime;
uniform float uImpact;
uniform vec2 uImpactAt;
uniform vec3 uLightDir;
uniform vec3 uEye;
uniform vec3 uDeep;
uniform vec3 uSheen;
uniform float uRippleGain;
uniform vec3 uFog;
varying vec3 vWorld;
varying vec3 vNormal;

void main() {
  vec2 p = vWorld.xz - uImpactAt;
  float r = length(p);

  // ambient swell, quantised into bands so it still reads as painted water
  float swell = sin(r * 0.11 - uTime * 0.9) * 0.5 + 0.5;
  float cross2 = sin(vWorld.x * 0.07 + uTime * 0.35) * 0.5 + 0.5;

  // impact rings: a wavefront travelling outward, decaying
  float front = uImpact * 150.0;
  float band = exp(-pow((r - front) / 11.0, 2.0)) + 0.62 * exp(-pow((r - front * 0.62) / 8.0, 2.0));
  float decay = exp(-max(uImpact, 0.0) * 0.55) * step(0.0, uImpact);

  // the disc is 1200 units across: everything past the near band has to fall into the sky,
  // or the void reads as a lit floor and the swell trains moiré at distance
  float haze = smoothstep(240.0, 940.0, length(vWorld.xz));
  vec3 col = uDeep * (0.72 + 0.55 * swell * cross2 * (1.0 - haze));

  // the light's path across the water
  vec3 v = normalize(uEye - vWorld);
  float path = pow(max(dot(vec3(-v.x, 0.0, -v.z), normalize(uLightDir)), 0.0), 6.0);
  col += uSheen * path * (0.35 + 0.65 * swell) * 0.7 * (1.0 - haze * 0.82);
  col += uSheen * band * decay * uRippleGain * 1.5;

  gl_FragColor = vec4(col, 1.0);
}
`,
        uniforms: this.uniforms,
      }),
    );
    this.mesh.rotation.x = -Math.PI / 2;
    this.mesh.position.y = y;
  }

  update(time: number, impactProgress: number, eye: THREE.Vector3, fog: THREE.Color): void {
    this.uniforms.uTime.value = time;
    this.uniforms.uImpact.value = impactProgress;
    (this.uniforms.uEye.value as THREE.Vector3).copy(eye);
    (this.uniforms.uFog.value as THREE.Color).copy(fog);
  }
}

/** A stroke of gilt light arcing across the void; the gold travels along it. */
export class GiltArc {
  readonly mesh: THREE.Mesh;
  private readonly uniforms: Record<string, THREE.IUniform>;

  constructor(curve: THREE.CatmullRomCurve3, radius: number) {
    this.uniforms = {
      uTime: { value: 0 },
      /** 0 = dormant, 1 = fully painted */
      uPaint: { value: 0 },
      /** where along the stroke the hot leading edge sits */
      uHead: { value: 0 },
      uHot: { value: rawColor(0xfff0c0) },
      uCold: { value: rawColor(0x2a1d07) },
      uGlowGain: { value: 0 },
      /** the whole stroke lifting away with the gold at the end of the loop */
      uAlpha: { value: 1 },
    };
    this.mesh = new THREE.Mesh(
      new THREE.TubeGeometry(curve, 220, radius, 16, false),
      new THREE.ShaderMaterial({
        vertexShader: /* glsl */ `
varying vec2 vUv;
varying vec3 vWorld;
void main() {
  vUv = uv;
  vec4 w = modelMatrix * vec4(position, 1.0);
  vWorld = w.xyz;
  gl_Position = projectionMatrix * viewMatrix * w;
}
`,
        fragmentShader: /* glsl */ `
precision highp float;
uniform float uTime;
uniform float uPaint;
uniform float uHead;
uniform vec3 uHot;
uniform vec3 uCold;
uniform float uGlowGain;
uniform float uAlpha;
varying vec2 vUv;
varying vec3 vWorld;

void main() {
  // stroke weight tapers at both ends like a brush lifting
  float taper = smoothstep(0.0, 0.09, vUv.x) * smoothstep(1.0, 0.72, vUv.x);
  float body = smoothstep(0.0, 0.25, taper);
  // dry-brush streaks along the length
  float bristles = 0.72 + 0.28 * sin(vUv.y * 84.0 + vUv.x * 12.0);

  float painted = step(vUv.x, uPaint);
  float heat = exp(-pow((vUv.x - uHead) / 0.045, 2.0));

  vec3 col = mix(uCold, uHot, heat * 0.85) * bristles;
  col += uHot * heat * 1.7;
  float a = painted * body * (0.55 + 0.45 * bristles) * (0.35 + uGlowGain);
  a *= (0.6 + 0.4 * (0.5 + 0.5 * sin(uTime * 0.7 + vUv.x * 9.0))) * uAlpha;

  gl_FragColor = vec4(col, clamp(a, 0.0, 1.0));
}
`,
        uniforms: this.uniforms,
        transparent: true,
        depthWrite: false,
      }),
    );
    this.mesh.frustumCulled = false;
  }

  update(time: number, paint: number, head: number, glow: number, alpha: number): void {
    this.uniforms.uTime.value = time;
    this.uniforms.uPaint.value = paint;
    this.uniforms.uHead.value = head;
    this.uniforms.uGlowGain.value = glow;
    this.uniforms.uAlpha.value = alpha;
    this.mesh.visible = paint > 0.002 && alpha > 0.002;
  }
}

/** The thread of molten gold being pulled from the reliquary up into the arc. */
export class GoldThread {
  readonly mesh: THREE.Mesh;
  private readonly uniforms: Record<string, THREE.IUniform>;

  constructor(from: THREE.Vector3, to: THREE.Vector3, radius: number) {
    const dir = new THREE.Vector3().subVectors(to, from);
    const len = dir.length();
    this.uniforms = {
      uTime: { value: 0 },
      uProgress: { value: 0 },
      uLen: { value: len },
      uHot: { value: rawColor(0xffe3a4) },
      uCold: { value: rawColor(0x221606) },
    };
    this.mesh = new THREE.Mesh(
      new THREE.CylinderGeometry(radius * 0.45, radius, len, 14, 1, true),
      new THREE.ShaderMaterial({
        vertexShader: /* glsl */ `
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`,
        fragmentShader: /* glsl */ `
precision highp float;
uniform float uTime;
uniform float uProgress;
uniform float uLen;
uniform vec3 uHot;
uniform vec3 uCold;
varying vec2 vUv;

void main() {
  // ink climbing the thread: bands travel upward, density thins as it drains
  float climb = fract(vUv.y * 5.0 - uTime * 1.35);
  float beads = smoothstep(0.35, 1.0, climb);
  float neck = smoothstep(0.0, 0.14, vUv.y) * smoothstep(1.0, 0.72, vUv.y);
  float alive = smoothstep(0.0, 0.18, uProgress) * smoothstep(1.0, 0.72, uProgress);
  vec3 col = mix(uCold, uHot, beads * 0.8);
  float a = neck * alive * (0.35 + 0.65 * beads);
  gl_FragColor = vec4(col * (1.0 + beads * 1.4), a);
}
`,
        uniforms: this.uniforms,
        transparent: true,
        depthWrite: false,
        side: THREE.DoubleSide,
      }),
    );
    this.mesh.position.copy(from).add(to).multiplyScalar(0.5);
    this.mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
    this.mesh.renderOrder = 18;
  }

  update(time: number, progress: number): void {
    this.uniforms.uTime.value = time;
    this.uniforms.uProgress.value = progress;
    this.mesh.visible = progress > 0.002 && progress < 0.998;
  }
}
