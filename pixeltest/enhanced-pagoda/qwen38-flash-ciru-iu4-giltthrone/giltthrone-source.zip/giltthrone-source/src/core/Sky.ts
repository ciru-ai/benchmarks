import * as THREE from 'three';
import { rawColor } from './color';
import { clamp } from './palette';

/**
 * Sky as one inverted dome with a hand-keyed two-stop gradient plus a star field and a moon
 * that only matters once the lanterns are lit. Colours are computed by the director each
 * frame, so the sky, the fog and the voxel grade always agree.
 */

const VERT = /* glsl */ `
varying vec3 vDir;
void main() {
  vDir = normalize(position);
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;

const FRAG = /* glsl */ `
precision highp float;
uniform vec3 uTop;
uniform vec3 uHorizon;
uniform vec3 uBottom;
uniform float uStars;
uniform vec3 uMoonDir;
uniform float uMoonSize;
uniform float uHaze;

varying vec3 vDir;

float hash13(vec3 p) {
  p = fract(p * 0.3183099 + vec3(0.71, 0.113, 0.419));
  p *= 17.0;
  return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}

void main() {
  float h = vDir.y;
  vec3 col = mix(uHorizon, uTop, pow(clamp(h, 0.0, 1.0), 0.55));
  col = mix(col, uBottom, pow(clamp(-h, 0.0, 1.0), 0.42));

  // Milky band, only where the sky is dark enough for it
  if (uStars > 0.001) {
    vec3 bandAxis = normalize(vec3(0.32, 0.66, -0.68));
    float away = abs(dot(vDir, bandAxis));
    float band = exp(-away * away * 26.0);
    float grain = hash13(floor(vDir * 260.0));
    float dust = smoothstep(0.42, 1.0, grain) * band;
    float star = step(0.9975, hash13(floor(vDir * 620.0))) * smoothstep(0.02, 0.35, h);
    float twinkle = 0.6 + 0.4 * sin(uStars * 6.0 + grain * 40.0);
    col += (dust * vec3(0.34, 0.40, 0.56) * 0.5 + star * twinkle * 1.6) * uStars;
  }

  // moon: disc plus a soft halo that also seeds the water glint
  float md = dot(vDir, normalize(uMoonDir));
  float disc = smoothstep(uMoonSize, uMoonSize * 0.86, md);
  float halo = exp(-max(0.0, 1.0 - md) * 9.0) * 0.34;
  col += vec3(0.86, 0.92, 1.0) * (disc * (0.55 + uStars) + halo * (0.25 + uStars));

  // low haze so the far mountains dissolve into the sky
  col = mix(col, uHorizon, exp(-max(h, 0.0) * 7.0) * uHaze);

  gl_FragColor = vec4(col, 1.0);
}
`;

export class Sky {
  readonly mesh: THREE.Mesh;
  private readonly uniforms: Record<string, THREE.IUniform>;

  constructor(radius: number) {
    this.uniforms = {
      uTop: { value: rawColor(0x05060a) },
      uHorizon: { value: rawColor(0x0a0d16) },
      uBottom: { value: rawColor(0x04050a) },
      uStars: { value: 0 },
      uMoonDir: { value: new THREE.Vector3(0.4, 0.55, -0.7) },
      uMoonSize: { value: 0.028 },
      uHaze: { value: 0.4 },
    };
    this.mesh = new THREE.Mesh(
      new THREE.SphereGeometry(radius, 32, 24),
      new THREE.ShaderMaterial({
        vertexShader: VERT,
        fragmentShader: FRAG,
        uniforms: this.uniforms,
        side: THREE.BackSide,
        depthWrite: false,
      }),
    );
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = -10;
  }

  set(top: number, horizon: number, bottom: number, stars: number, haze: number, moonSize = 0.028): void {
    (this.uniforms.uTop.value as THREE.Color).setHex(top, THREE.LinearSRGBColorSpace);
    (this.uniforms.uHorizon.value as THREE.Color).setHex(horizon, THREE.LinearSRGBColorSpace);
    (this.uniforms.uBottom.value as THREE.Color).setHex(bottom, THREE.LinearSRGBColorSpace);
    this.uniforms.uStars.value = stars;
    this.uniforms.uHaze.value = haze;
    this.uniforms.uMoonSize.value = moonSize;
  }

  moon(direction: THREE.Vector3): void {
    (this.uniforms.uMoonDir.value as THREE.Vector3).copy(direction).normalize();
  }
}

/** Fog colour + distances paired with the sky so nothing pops at the horizon. */
export function fogFor(fogHex: number, near: number, far: number): { color: THREE.Color; near: number; far: number } {
  return { color: rawColor(fogHex), near: clamp(near, 1, 1e5), far: clamp(far, near + 1, 1e6) };
}
