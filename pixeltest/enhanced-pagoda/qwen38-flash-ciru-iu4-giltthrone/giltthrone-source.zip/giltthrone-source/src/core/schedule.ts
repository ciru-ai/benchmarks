/**
 * One clock drives everything: the voxel reveal, the sky, the camera, the UI. `T` is the
 * single source of truth so a frame can be reproduced from a number alone (render/capture.mjs
 * relies on this). Every phase is {start, dur} in seconds and the whole thing wraps at LOOP.
 *
 * The story is a smelting, not a growing: molten gold falls out of the sky, the island and the
 * great hall are cast out of the impact, the grove of dead timber catches flourosh, the doors
 * swing, the camera walks in, and the gold is drawn back up after the comet.
 */
import { clamp } from './palette';

export interface Phase {
  start: number;
  dur: number;
}

export const T = {
  /** the comet of molten gold falls through the stars */
  fall: { start: 0.0, dur: 3.4 },
  /** it lands on the crown; the light blooms out of the impact */
  impact: { start: 3.4, dur: 1.2 },
  /** lake, island, terraces and the processional stair stand up */
  ground: { start: 3.6, dur: 2.9 },
  /** the hall's walls and the storeys above them are cast, course by course */
  tiers: { start: 6.3, dur: 3.3 },
  /** roofs unfurl eave-tip first, then inward */
  roofs: { start: 9.2, dur: 3.0 },
  /** gilded columns, rails, balustrades, roof trim */
  trim: { start: 11.6, dur: 2.4 },
  /** the dead grove rises, then the flourosh furs the fallen timber */
  grove: { start: 13.6, dur: 3.0 },
  /** inside the hall: floor inlay, dais, throne, canopy, banners, treasure */
  hall: { start: 16.2, dur: 3.0 },
  /** the doors swing and the gold light pours out into the grove */
  doors: { start: 19.4, dur: 2.4 },
  /** the camera is inside with the throne */
  inside: { start: 21.8, dur: 5.2 },
  /** the grove lives: spores drift, caps breathe, the lake moves */
  life: { start: 27.0, dur: 2.6 },
  /** pull out through the doors and up to the valley */
  lift: { start: 29.6, dur: 3.4 },
  /** the gold is drawn back up after the comet and the loop closes */
  draw: { start: 33.0, dur: 2.7 },
} as const satisfies Record<string, Phase>;

export const LOOP = 36.0;

export type PhaseName = keyof typeof T;

/** Named phases with a per-phase reveal length used when a builder does not pick one. */
const DEFAULT_DUR: Partial<Record<PhaseName, number>> = {
  ground: 0.5,
  tiers: 0.45,
  roofs: 0.4,
  trim: 0.35,
  grove: 0.5,
  hall: 0.45,
  doors: 0.5,
  lift: 0.9,
};

/**
 * Builds reveal times for voxels. `step(phase, key)` spreads placements across the phase:
 * key 0 lands at the front of the window, key 1 at the back, so a builder can stream its
 * geometry in a readable order (bottom-up, eave-inward, nave-to-apse…).
 */
export interface Schedule {
  step(phase: PhaseName, key: number, dur?: number): number;
  /** progress 0..1 through a phase, clamped — for non-voxel actors */
  at(phase: PhaseName, t: number): number;
}

export function makeSchedule(): Schedule {
  return {
    step: (phase, key, dur) => {
      const p = T[phase];
      const d = dur ?? DEFAULT_DUR[phase] ?? 0.4;
      return p.start + clamp(key, 0, 1) * Math.max(p.dur - d, 0.001);
    },
    at: (phase, t) => clamp((t - T[phase].start) / T[phase].dur, 0, 1),
  };
}

/** Wrap a wall-clock time into the loop. */
export const wrap = (t: number) => {
  const m = t % LOOP;
  return m < 0 ? m + LOOP : m;
};
