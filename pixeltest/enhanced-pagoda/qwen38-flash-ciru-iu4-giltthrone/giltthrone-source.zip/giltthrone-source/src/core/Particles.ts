import * as THREE from 'three';
import { rawColor } from './color';
import { rng } from './palette';

/**
 * Deterministic particle field. A particle's position is derived from its seed and the clock
 * inside the vertex shader, never integrated on the CPU — so seeking to any second reproduces
 * exactly that frame, which is what the frame capturer needs.
 */

const VERT = /* glsl */ `
attribute vec4 aSeed;   // x angle, y radius, z height0, w speed
uniform float uTime;
uniform float uSize;
uniform float uSpan;
uniform float uSpread;
uniform float uDrift;
uniform float uSpin;
varying float vShade;
varying float vAge;
varying float vNear;

void main() {
  float ang = aSeed.x + uTime * uSpin * (0.4 + aSeed.w);
  float r = aSeed.y * (1.0 + 0.06 * sin(uTime * 0.5 + aSeed.x * 4.0));
  vec3 p;
  p.x = cos(ang) * r;
  p.z = sin(ang) * r;

  // wrap vertically: a petal that leaves the bottom re-enters at the top
  float fall = mod(aSeed.z - uTime * aSeed.w * uSpread, uSpan);
  p.y = fall - uSpan * 0.12;

  // cross-breeze, stronger the higher you are
  p.x += sin(uTime * 0.7 + aSeed.z * 0.7) * uDrift * (fall / uSpan);
  p.z += cos(uTime * 0.53 + aSeed.x * 3.1) * uDrift * 0.6;

  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  gl_Position = projectionMatrix * mv;
  gl_PointSize = min(uSize * (0.55 + aSeed.w) * (260.0 / max(-mv.z, 1.0)), 10.0);
  vNear = clamp((-mv.z - 4.0) / 10.0, 0.0, 1.0);

  vShade = 0.55 + 0.45 * sin(aSeed.x * 7.3);
  vAge = clamp(1.0 - fall / uSpan, 0.0, 1.0);
}
`;

const FRAG = /* glsl */ `
precision highp float;
uniform vec3 uColorA;
uniform vec3 uColorB;
uniform float uOpacity;
uniform float uSoft;
varying float vShade;
varying float vAge;
varying float vNear;

void main() {
  vec2 q = gl_PointCoord - 0.5;
  // leaf/petal silhouette: two overlapping arcs, soft edge
  float d = length(vec2(q.x * 1.7, q.y * 2.6));
  float m = smoothstep(0.5, 0.5 - uSoft, d);
  if (m <= 0.001) discard;
  vec3 col = mix(uColorA, uColorB, vAge);
  gl_FragColor = vec4(col * (0.65 + 0.55 * vShade), m * uOpacity * vNear);
}
`;

export interface FieldOptions {
  count: number;
  /** vertical wrap distance in world units */
  span: number;
  /** horizontal radius the field occupies */
  radius: number;
  size: number;
  colorA: number;
  colorB: number;
  /** angular speed of the orbit */
  spin: number;
  /** cross-breeze amplitude */
  drift: number;
  /** multiplier on per-particle fall speed */
  fall: number;
  soft: number;
}

export class ParticleField {
  readonly points: THREE.Points;
  private readonly uniforms: Record<string, THREE.IUniform>;

  constructor(opts: FieldOptions, seed: number) {
    const rand = rng(seed);
    const n = opts.count;
    const s = new Float32Array(n * 4);
    for (let i = 0; i < n; i++) {
      const a = rand() * Math.PI * 2;
      // sqrt keeps the disc even; a few particles hug the centre
      const r = Math.sqrt(rand()) * opts.radius;
      s[i * 4] = a;
      s[i * 4 + 1] = r;
      s[i * 4 + 2] = rand() * opts.span;
      s[i * 4 + 3] = 0.35 + rand() * 0.9;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(new Float32Array(n * 3), 3));
    g.setAttribute('aSeed', new THREE.Float32BufferAttribute(s, 4));
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e5);

    this.uniforms = {
      uTime: { value: 0 },
      uSize: { value: opts.size },
      uSpan: { value: opts.span },
      uSpread: { value: opts.fall },
      uDrift: { value: opts.drift },
      uSpin: { value: opts.spin },
      uColorA: { value: rawColor(opts.colorA) },
      uColorB: { value: rawColor(opts.colorB) },
      uOpacity: { value: 0 },
      uSoft: { value: opts.soft },
    };
    this.points = new THREE.Points(
      g,
      new THREE.ShaderMaterial({
        vertexShader: VERT,
        fragmentShader: FRAG,
        uniforms: this.uniforms,
        transparent: true,
        depthWrite: false,
        blending: THREE.NormalBlending,
      }),
    );
    this.points.frustumCulled = false;
  }

  update(time: number, opacity: number): void {
    this.uniforms.uTime.value = time;
    this.uniforms.uOpacity.value = opacity;
    this.points.visible = opacity > 0.002;
  }
}

/** Additive glow billboards — lantern halos and the ink-impact flash, drawn as soft discs. */
export class GlowSprites {
  readonly points: THREE.Points;
  private readonly uniforms: Record<string, THREE.IUniform>;

  constructor(positions: number[], sizes: number[], color: number) {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    g.setAttribute('aSize', new THREE.Float32BufferAttribute(sizes, 1));
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e5);
    this.uniforms = {
      uTime: { value: 0 },
      uColor: { value: rawColor(color) },
      uGain: { value: 0 },
      uPixel: { value: 1 },
    };
    this.points = new THREE.Points(
      g,
      new THREE.ShaderMaterial({
        vertexShader: /* glsl */ `
attribute float aSize;
uniform float uTime;
uniform float uPixel;
varying float vPulse;
varying float vAtten;
void main() {
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  gl_Position = projectionMatrix * mv;
  gl_PointSize = min(aSize * uPixel * (520.0 / max(-mv.z, 1.0)), 12.0 * uPixel);
  vAtten = clamp((-mv.z - 8.0) / 30.0, 0.0, 1.0);
  vPulse = 0.82 + 0.18 * sin(uTime * 5.7 + position.x * 0.4 + position.z * 0.3);
}
`,
        fragmentShader: /* glsl */ `
precision highp float;
uniform vec3 uColor;
uniform float uGain;
varying float vPulse;
varying float vAtten;
void main() {
  float d = length(gl_PointCoord - 0.5) * 2.0;
  float m = exp(-d * d * 4.4) * pow(max(1.0 - d, 0.0), 1.2) * vAtten;
  if (m <= 0.002) discard;
  gl_FragColor = vec4(uColor * m * uGain * vPulse * 0.42, m);
}
`,
        uniforms: this.uniforms,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      }),
    );
    this.points.frustumCulled = false;
  }

  update(time: number, gain: number): void {
    this.uniforms.uTime.value = time;
    this.uniforms.uGain.value = gain;
    this.points.visible = gain > 0.002;
  }

  /** Point sprites are sized in device pixels; the viewer and the capturer set this once. */
  setPixel(ratio: number): void {
    this.uniforms.uPixel.value = ratio;
  }
}
