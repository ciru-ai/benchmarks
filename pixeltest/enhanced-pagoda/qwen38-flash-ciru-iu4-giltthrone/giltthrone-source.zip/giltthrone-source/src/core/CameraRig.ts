import * as THREE from 'three';

/**
 * A single continuous camera for the whole piece. Two kinds of beat coexist in one list:
 *
 *  - **orbit beats** — spherical around the monument axis (`r`, `az`, `el`, `ty`), used for
 *    everything outside;
 *  - **track beats** — an explicit `pos`/`look` pair, used for the part of the tour that runs
 *    *through the doorway and into the hall*, which no orbit can describe.
 *
 * A segment is interpolated in whichever space both of its ends live in; a mixed segment falls
 * back to Cartesian, so the hand-off from orbit to track is a straight dolly rather than a jump.
 * Manual drag/wheel is layered on top of the keyframed pose as a rotation about the current
 * look target, so scrubbing never fights the tour and the pose stays a pure function of time.
 */

export interface Beat {
  /** loop second */
  t: number;
  /** orbit radius from the axis (orbit beats) */
  r?: number;
  /** azimuth, radians; keep monotonic within the orbit run so the orbit never snaps */
  az?: number;
  /** elevation, radians */
  el?: number;
  /** target height (orbit beats) */
  ty?: number;
  /** camera position, world units (track beats) */
  pos?: readonly [number, number, number];
  /** look-at point, world units (track beats) */
  look?: readonly [number, number, number];
  fov: number;
  /** segment easing out of this beat */
  ease?: 'inout' | 'linear' | 'out';
  caption?: string;
}

const easeInOut = (x: number) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);
const easeOut = (x: number) => 1 - Math.pow(1 - x, 3);

function shape(kind: Beat['ease'], x: number): number {
  if (kind === 'linear') return x;
  if (kind === 'out') return easeOut(x);
  return easeInOut(x);
}

const isTrack = (b: Beat): boolean => b.pos !== undefined && b.look !== undefined;

/** World-space camera point of an orbit beat. */
function orbitPos(b: Beat): THREE.Vector3 {
  const r = b.r ?? 0;
  const az = b.az ?? 0;
  const el = b.el ?? 0;
  const ty = b.ty ?? 0;
  return new THREE.Vector3(
    Math.sin(az) * Math.cos(el) * r,
    ty + Math.sin(el) * r,
    Math.cos(az) * Math.cos(el) * r,
  );
}

export class CameraRig {
  readonly camera: THREE.PerspectiveCamera;
  readonly target = new THREE.Vector3();
  /** operator layer */
  orbitAz = 0;
  orbitEl = 0;
  zoom = 1;

  constructor(private readonly beats: Beat[], aspect: number) {
    this.camera = new THREE.PerspectiveCamera(46, aspect, 1, 9000);
  }

  /** Nearest beat index at or before `t` — the UI highlights it. */
  beatIndex(t: number): number {
    let i = 0;
    for (let k = 0; k < this.beats.length; k++) if (this.beats[k].t <= t) i = k;
    return i;
  }

  /** Authored camera point, look target and fov at loop second `t`. */
  pose(t: number): { pos: THREE.Vector3; look: THREE.Vector3; fov: number } {
    const b = this.beats;
    let i = 0;
    while (i < b.length - 2 && t > b[i + 1].t) i++;
    const a = b[i];
    const c = b[Math.min(i + 1, b.length - 1)];
    const span = Math.max(c.t - a.t, 1e-4);
    const k = shape(a.ease, Math.max(0, Math.min(1, (t - a.t) / span)));

    const pos = new THREE.Vector3();
    const look = new THREE.Vector3();
    if (isTrack(a) && isTrack(c)) {
      pos.fromArray(a.pos!);
      pos.lerp(new THREE.Vector3().fromArray(c.pos!), k);
      look.fromArray(a.look!);
      look.lerp(new THREE.Vector3().fromArray(c.look!), k);
    } else if (isTrack(a) || isTrack(c)) {
      // mixed hand-off: put both ends in world space, then dolly between them
      const pa = isTrack(a) ? new THREE.Vector3().fromArray(a.pos!) : orbitPos(a);
      const pc = isTrack(c) ? new THREE.Vector3().fromArray(c.pos!) : orbitPos(c);
      const la = isTrack(a) ? new THREE.Vector3().fromArray(a.look!) : new THREE.Vector3(0, a.ty ?? 0, 0);
      const lc = isTrack(c) ? new THREE.Vector3().fromArray(c.look!) : new THREE.Vector3(0, c.ty ?? 0, 0);
      pos.copy(pa).lerp(pc, k);
      look.copy(la).lerp(lc, k);
    } else {
      const lerp = (x: number, y: number) => x + (y - x) * k;
      const r = lerp(a.r ?? 0, c.r ?? 0);
      const az = lerp(a.az ?? 0, c.az ?? 0);
      const el = lerp(a.el ?? 0, c.el ?? 0);
      const ty = lerp(a.ty ?? 0, c.ty ?? 0);
      pos.set(Math.sin(az) * Math.cos(el) * r, ty + Math.sin(el) * r, Math.cos(az) * Math.cos(el) * r);
      look.set(0, ty, 0);
    }
    return { pos, look, fov: a.fov + (c.fov - a.fov) * k };
  }

  look(t: number): void {
    const p = this.pose(t);
    const off = p.pos.clone().sub(p.look);
    const r = Math.max(0.001, off.length() * this.zoom);
    let el = Math.asin(Math.max(-1, Math.min(1, off.y / Math.max(0.001, off.length()))));
    const az = Math.atan2(off.x, off.z) + this.orbitAz;
    el = Math.max(-0.42, Math.min(1.35, el + this.orbitEl));

    this.target.copy(p.look);
    this.camera.position.set(
      p.look.x + Math.sin(az) * Math.cos(el) * r,
      p.look.y + Math.sin(el) * r,
      p.look.z + Math.cos(az) * Math.cos(el) * r,
    );
    this.camera.up.set(0, 1, 0);
    this.camera.lookAt(this.target);

    // Near/far retuned per pose: a 1-unit voxel and the wide valley have to share one depth
    // buffer, so the near plane tracks the distance to the target instead of staying fixed.
    const d = this.camera.position.distanceTo(this.target);
    this.camera.near = Math.max(0.35, d * 0.012);
    this.camera.far = Math.max(2600, d * 5 + 1900);
    this.camera.fov = p.fov;
    this.camera.updateProjectionMatrix();
  }

  /** Retire the operator layer slowly so a resumed tour is the authored one. */
  relax(amount: number): void {
    this.orbitAz *= 1 - amount;
    this.orbitEl *= 1 - amount;
    this.zoom += (1 - this.zoom) * amount;
  }
}
