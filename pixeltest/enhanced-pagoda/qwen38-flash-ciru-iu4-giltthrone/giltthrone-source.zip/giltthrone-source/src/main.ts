import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { CameraRig } from './core/CameraRig';
import { LOOP, wrap } from './core/schedule';
import { look } from './director';
import { BEATS } from './journey';
import { buildStage } from './stage';
import { Overlay } from './ui';

/**
 * Player. One clock drives the authored geometry, the shell, the actors and the grade; the
 * composer only adds bloom. `?capture=1` hides the overlay and `window.__seek(t)` renders an
 * exact frame, so the MP4 and the live viewer are the same code looking at the same second.
 */

const capturing = new URLSearchParams(location.search).has('capture');

const canvas = document.getElementById('view') as HTMLCanvasElement;
const renderer = new THREE.WebGLRenderer({
  canvas,
  antialias: false,
  powerPreference: 'high-performance',
  preserveDrawingBuffer: true,
});
renderer.toneMapping = THREE.NoToneMapping;

const scene = new THREE.Scene();
const rig = new CameraRig(BEATS, 16 / 9);
scene.add(rig.camera);

const stage = buildStage();
scene.add(stage.group);
const overlay = new Overlay(document.body);
if (capturing) document.body.classList.add('capturing');

const stats = document.createElement('div');
stats.id = 'stats';
if (capturing) stats.style.display = 'none';
document.body.appendChild(stats);

const composer = new EffectComposer(renderer);
composer.addPass(new RenderPass(scene, rig.camera));
const bloom = new UnrealBloomPass(new THREE.Vector2(1, 1), 0.5, 0.62, 0.86);
composer.addPass(bloom);

function resize(): void {
  const width = Math.max(320, Math.floor(window.innerWidth));
  const height = Math.max(200, Math.floor(window.innerHeight));
  renderer.setPixelRatio(Math.min(capturing ? 1 : window.devicePixelRatio, 2));
  renderer.setSize(width, height, false);
  const pr = renderer.getPixelRatio();
  composer.setPixelRatio(pr);
  composer.setSize(width, height);
  bloom.setSize(width * pr, height * pr);
  stage.setPixel(pr);
  rig.camera.aspect = width / height;
  rig.camera.updateProjectionMatrix();
}
resize();
window.addEventListener('resize', resize);

// ---------------------------------------------------------------- clock

let time = 0;
let playing = !capturing;
let last = performance.now();
let fps = 60;

function draw(t: number): void {
  const lk = look(t);
  rig.look(t);
  rig.camera.updateMatrixWorld();
  stage.update(t, lk, rig.camera.position);
  bloom.strength = lk.bloom;
  overlay.update(t);
  composer.render();
}

function frame(now: number): void {
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;
  if (dt > 0) fps += (1 / dt - fps) * 0.08;
  if (playing) {
    time = wrap(time + dt);
    rig.relax(dt * 0.3);
  }
  draw(time);
  stats.textContent =
    `${time.toFixed(2)}s / ${LOOP}s · ${Math.round(fps)} fps · ` +
    `${(stage.stats.inner + stage.stats.outer).toLocaleString()} voxels · ` +
    `${Math.round(stage.stats.faces / 1000)}k faces`;
  requestAnimationFrame(frame);
}

// ---------------------------------------------------------------- controls

let dragging = false;
let px = 0;
let py = 0;
canvas.addEventListener('pointerdown', (e) => {
  dragging = true;
  px = e.clientX;
  py = e.clientY;
  canvas.setPointerCapture(e.pointerId);
});
canvas.addEventListener('pointermove', (e) => {
  if (!dragging) return;
  rig.orbitAz -= (e.clientX - px) * 0.005;
  rig.orbitEl = Math.max(-0.5, Math.min(1.2, rig.orbitEl + (e.clientY - py) * 0.004));
  px = e.clientX;
  py = e.clientY;
});
canvas.addEventListener('pointerup', () => {
  dragging = false;
});
canvas.addEventListener(
  'wheel',
  (e) => {
    e.preventDefault();
    rig.zoom = Math.max(0.35, Math.min(3.2, rig.zoom * (1 + Math.sign(e.deltaY) * 0.08)));
  },
  { passive: false },
);

window.addEventListener('keydown', (e) => {
  if (e.code === 'Space') {
    e.preventDefault();
    playing = !playing;
  } else if (e.code === 'ArrowRight') {
    playing = false;
    time = wrap(time + (e.shiftKey ? 1 : 0.2));
  } else if (e.code === 'ArrowLeft') {
    playing = false;
    time = wrap(time - (e.shiftKey ? 1 : 0.2));
  } else if (e.key === 'o') {
    rig.orbitAz = 0;
    rig.orbitEl = 0;
    rig.zoom = 1;
  } else if (e.key === 'c') {
    overlay.setCaptions(false);
  } else if (e.key >= '1' && e.key <= '9') {
    const beat = BEATS[Number(e.key) - 1];
    if (beat) {
      playing = false;
      time = beat.t;
    }
  }
});

// ---------------------------------------------------------------- capture hook

const gl = renderer.getContext();
const probe = new Uint8Array(4);

/** Render exactly this loop second without touching the clock, then block until the frame lands. */
function seek(t: number): void {
  time = wrap(t);
  draw(time);
  gl.readPixels(0, 0, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, probe);
}

declare global {
  interface Window {
    __seek?: (t: number) => void;
    __ready?: boolean;
    __renderer?: string;
    __stats?: { inner: number; outer: number; plants: number; movers: number; faces: number };
  }
}

// warm every shader once, so a captured frame is never a compile stall
renderer.compileAsync(scene, rig.camera).then(() => {
  const ext = gl.getExtension('WEBGL_debug_renderer_info');
  window.__renderer = ext ? String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)) : 'webgl2';
  window.__stats = stage.stats;
  window.__seek = seek;
  seek(capturing ? 0 : time);
  window.__ready = true;
});

requestAnimationFrame(frame);
