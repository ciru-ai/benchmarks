import { Kind, VoxelWorld } from '../core/VoxelWorld';
import { C, hash3, mixHex, rng, shade } from '../core/palette';
import { FADE, noise2 } from './types';
import { LAKE_ROW } from '../core/layout';

/**
 * The island: a terraced volcanic stump standing in a black lake.
 *
 * Authored as radius profiles per grid row rather than as blobs, so the coastline, the
 * shelves and the cliff band stay legible at voxel resolution. Everything at or below the
 * water line is wet basalt, the shelves are soil and moss, the shoulders are eroded cliff.
 */


export interface LandPlan {
  cx: number;
  cz: number;
  /** radius of the island at the water line */
  rSea: number;
  /** row the lower garden shelf is flat on */
  shelfRow: number;
  /** row the upper pagoda terrace is flat on */
  crownRow: number;
  /** radius of the crown terrace */
  rCrown: number;
  /** bottom row of the root spike */
  rootRow: number;
  seed: number;
  /** loop second the mass starts rising from */
  t: number;
}

function coastline(plan: LandPlan, angle: number, scale: number): number {
  const w =
    0.72 * noise2(Math.cos(angle) * 2.3 + 9, Math.sin(angle) * 2.3 - 4, plan.seed) +
    0.28 * noise2(Math.cos(angle) * 5.7 - 2, Math.sin(angle) * 5.7 + 7, plan.seed + 31);
  return plan.rSea * scale * (0.82 + 0.36 * w);
}

/** Rock colour with a wet/dry split and a little mineral banding. */
function rock(row: number, x: number, z: number, topRow: number): number {
  const band = 0.5 + 0.5 * Math.sin(row * 0.9 + hash3(x, 0, z, 17) * 2.2);
  const base = mixHex(C.ink, C.slate, 0.3 + 0.4 * band);
  const dry = row > topRow - 4 ? mixHex(base, C.mossDeep, 0.32) : base;
  return shade(dry, (row < LAKE_ROW ? 0.7 : 1) * (0.9 + 0.16 * hash3(x, row, z, 5)));
}

/** Solid mass of the island, one radius profile per row. */
export function islandMass(world: VoxelWorld, plan: LandPlan): void {
  const rand = rng(plan.seed * 7919);
  const top = plan.crownRow;

  for (let row = plan.rootRow; row <= top; row++) {
    let radius: number;
    if (row < LAKE_ROW) {
      // root: a tapering spike with one bulge so the island reads as hung, not conical
      const t = (row - plan.rootRow) / (LAKE_ROW - plan.rootRow);
      radius = 5 + 34 * Math.pow(t, 0.62) + 4 * Math.sin(t * Math.PI * 1.7);
    } else if (row <= plan.shelfRow) {
      const t = (row - LAKE_ROW) / Math.max(1, plan.shelfRow - LAKE_ROW);
      radius = plan.rSea - 1 - 3 * t;
    } else {
      const t = (row - plan.shelfRow) / Math.max(1, top - plan.shelfRow);
      radius = plan.rCrown + (plan.rSea - 4 - plan.rCrown) * Math.pow(1 - t, 1.5);
    }

    const soilTop = row >= plan.shelfRow - 1 && row > LAKE_ROW;
    for (let dx = -Math.ceil(radius); dx <= Math.ceil(radius); dx++) {
      for (let dz = -Math.ceil(radius); dz <= Math.ceil(radius); dz++) {
        const rr = Math.hypot(dx, dz);
        const edge = coastline(plan, Math.atan2(dz, dx), radius / plan.rSea);
        if (rr > edge) continue;
        const skin = rr > edge - 1.4;
        const col = soilTop && skin ? mixHex(C.soilDark, C.stoneLite, 0.3 + 0.12 * hash3(dx, row, dz, 13)) : rock(row, dx, dz, top);
        world.set(plan.cx + dx, row, plan.cz + dz, col, {
          t: plan.t + (top - row) * 0.05 + rand() * 0.12,
          dur: FADE + 0.1,
        });
      }
    }
  }

  // eroded cliff band: carve vertical flutes out of the shoulder so light catches them
  for (let row = LAKE_ROW + 2; row < plan.shelfRow - 1; row++) {
    const r = plan.rSea - 1 - 3 * ((row - LAKE_ROW) / Math.max(1, plan.shelfRow - LAKE_ROW));
    for (let a = 0; a < 220; a++) {
      const ang = (a / 220) * Math.PI * 2;
      const flute = 1 - Math.pow(Math.abs(Math.sin(ang * 7.5 + plan.seed * 0.31)), 6);
      const rr = Math.round(r * (0.9 + 0.1 * flute));
      const x = plan.cx + Math.round(Math.cos(ang) * rr);
      const z = plan.cz + Math.round(Math.sin(ang) * rr);
      if (world.occupied(x, row, z) && hash3(x, row, z, 71) > 0.62) world.erase(x, row, z);
    }
  }
}

/**
 * A flat platform: stone retaining rim, packed earth and moss inside. Used for the pagoda
 * terrace and the garden plaza.
 */
export function shelf(
  world: VoxelWorld,
  o: { cx: number; cz: number; r: number; row: number; t: number; stone?: number; depth?: number },
): void {
  const depth = o.depth ?? 2;
  for (let dx = -o.r; dx <= o.r; dx++) {
    for (let dz = -o.r; dz <= o.r; dz++) {
      const rr = Math.hypot(dx, dz);
      if (rr > o.r + 0.4) continue;
      const rim = rr > o.r - 1.2;
      const col = rim
        ? shade(o.stone ?? C.stone, 0.84 + 0.22 * hash3(dx, 0, dz, 13))
        : mixHex(C.soil, C.mossDeep, 0.3 + 0.5 * hash3(dx, 1, dz, 29));
      for (let k = 0; k < depth; k++) {
        world.set(o.cx + dx, o.row - k, o.cz + dz, rim ? col : shade(col, 0.8), {
          t: o.t + (o.row - k) * 0.03 + rr * 0.012,
          dur: FADE,
        });
      }
    }
  }
}

/**
 * The lake sheet, drawn one row thick after every solid: the material's swell term does the
 * motion, and a single layer keeps the water reading flat and mirror-like.
 */
export function lakeSheet(
  world: VoxelWorld,
  o: { cx: number; cz: number; r: number; row: number; t: number },
): void {
  const deep = mixHex(C.inkDeep, C.night, 0.25);
  for (let dx = -o.r; dx <= o.r; dx++) {
    for (let dz = -o.r; dz <= o.r; dz++) {
      const rr = Math.hypot(dx, dz);
      if (rr > o.r) continue;
      const x = o.cx + dx;
      const z = o.cz + dz;
      if (world.occupied(x, o.row, z)) continue;
      const x0 = Math.abs(x - o.cx);
      const z0 = Math.abs(z - o.cz);
      // clip to a rounded square, so the shore reads as a bank rather than a perfect disc
      if (Math.hypot(Math.max(x0, z0), Math.min(x0, z0) * 0.72) > o.r) continue;
      const k = 0.7 + 0.36 * (1 - rr / o.r) + 0.08 * hash3(dx, 0, dz, 41);
      const layers = rr < o.r * 0.55 ? 2 : 1;
      for (let i = 0; i < layers; i++) {
        world.set(x, o.row - i, z, shade(deep, k - i * 0.06), {
          kind: Kind.Water,
          t: o.t + rr * 0.014 + i * 0.05,
          dur: FADE + 0.16,
        });
      }
    }
  }
}

/** Carve a basin down toward `toRow` — the pond, cut into the lower shelf. */
export function basin(
  world: VoxelWorld,
  o: { cx: number; cz: number; r: number; toRow: number; rimRow: number },
): void {
  for (let dx = -o.r - 1; dx <= o.r + 1; dx++) {
    for (let dz = -o.r - 1; dz <= o.r + 1; dz++) {
      const rr = Math.hypot(dx, dz);
      if (rr > o.r + 0.5) continue;
      const floor = o.toRow + Math.round(2.5 * Math.pow(rr / o.r, 2));
      for (let row = floor; row <= o.rimRow; row++) world.erase(o.cx + dx, row, o.cz + dz);
    }
  }
}

/**
 * Wet rice terraces, cut into whatever slope is actually there: every column keeps its own
 * surface row, so the benches hug the hillside instead of floating over it. A flat bench
 * holds water; a column whose downhill neighbour drops two rows or more gets a stone riser.
 */
export function paddies(
  world: VoxelWorld,
  o: { cx: number; cz: number; rIn: number; rOut: number; from: number; to: number; t: number },
): void {
  const surfaceAt = (x: number, z: number) => world.heightAt(x, z) - 1;
  for (let x = o.cx - o.rOut; x <= o.cx + o.rOut; x++) {
    for (let z = o.cz - o.rOut; z <= o.cz + o.rOut; z++) {
      const d = Math.hypot(x - o.cx, z - o.cz);
      if (d < o.rIn || d > o.rOut) continue;
      const bench = surfaceAt(x, z);
      if (bench < o.from || bench > o.to) continue;
      if (hash3(x, 0, z, 71) < 0.22) continue; // pockets of wild slope left unplanted
      let flat = true;
      let drop = 0;
      for (const [dx, dz] of [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1],
      ] as const) {
        const n = surfaceAt(x + dx, z + dz);
        if (n !== bench) flat = false;
        drop = Math.max(drop, bench - n);
      }
      const wet = flat && hash3(x, 1, z, 17) < 0.55;
      const green = mixHex(C.moss, C.leaf, 0.25 + 0.45 * hash3(x, 2, z, 6) + ((bench & 1) ? 0.12 : 0));
      world.set(x, bench, z, wet ? mixHex(green, C.inkDeep, 0.55) : green, {
        kind: wet ? Kind.Water : Kind.Solid,
        t: o.t + d * 0.03,
        dur: FADE,
      });
      if (!wet && hash3(x, 3, z, 27) < 0.16) {
        world.set(x, bench + 1, z, mixHex(C.pine, C.leaf, hash3(x, 4, z, 8)), {
          kind: Kind.Foliage,
          sway: 0.7,
          t: o.t + d * 0.03 + 0.2,
          dur: FADE,
        });
      }
      if (drop >= 2) {
        for (const [dx, dz] of [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1],
        ] as const) {
          if (bench - surfaceAt(x + dx, z + dz) >= 2) {
            world.set(x + dx, bench, z + dz, shade(C.stone, 0.78 + 0.2 * hash3(x, 5, z, 9)), {
              t: o.t + d * 0.03 + 0.1,
              dur: FADE,
            });
          }
        }
      }
    }
  }
}

/**
 * A ribbon of packed gravel: the approach path. Each column is laid on the terrain surface
 * that is actually there (never below `o.row`), so the walk climbs the hillside instead of
 * floating above it or being buried by it.
 */
export function path(
  world: VoxelWorld,
  pts: readonly [number, number][],
  o: { row: number; width: number; t: number; stone?: number },
): void {
  const col0 = o.stone ?? C.stoneLite;
  let walked = 0;
  for (let i = 0; i < pts.length - 1; i++) {
    const [ax, az] = pts[i];
    const [bx, bz] = pts[i + 1];
    const len = Math.max(1, Math.ceil(Math.hypot(bx - ax, bz - az)));
    for (let k = 0; k <= len; k++) {
      const u = k / len;
      const px = Math.round(ax + (bx - ax) * u);
      const pz = Math.round(az + (bz - az) * u);
      for (let dx = -o.width; dx <= o.width; dx++) {
        for (let dz = -o.width; dz <= o.width; dz++) {
          if (Math.hypot(dx, dz) > o.width + 0.3) continue;
          const x = px + dx;
          const z = pz + dz;
          if (hash3(x, 0, z, 97) < 0.18) continue;
          const row = Math.max(o.row, world.heightAt(x, z) - 1);
          world.set(x, row, z, shade(col0, 0.8 + 0.28 * hash3(x, 2, z, 11)), {
            t: o.t + walked * 0.045,
            dur: FADE,
          });
          walked += 0.02;
        }
      }
    }
  }
}

/** Stepping stones: the crossing that keeps the pond readable as water. */
export function steppingStones(
  world: VoxelWorld,
  a: [number, number],
  b: [number, number],
  o: { row: number; count: number; t: number },
): void {
  for (let i = 0; i <= o.count; i++) {
    const u = i / o.count;
    const x = Math.round(a[0] + (b[0] - a[0]) * u);
    const z = Math.round(a[1] + (b[1] - a[1]) * u);
    for (let dx = -1; dx <= 1; dx++) {
      for (let dz = -1; dz <= 1; dz++) {
        if (Math.abs(dx) + Math.abs(dz) > 2) continue;
        world.set(x + dx, o.row, z + dz, shade(C.stone, 0.9 + 0.22 * hash3(x, dx, z, 23)), {
          t: o.t + i * 0.09,
          dur: FADE,
        });
      }
    }
  }
}

/** Water pouring off a shelf: a short thick column plus the lip it falls from. */
export function cascade(
  world: VoxelWorld,
  o: { cx: number; cz: number; fromRow: number; toRow: number; r: number; t: number },
): void {
  const col = mixHex(C.inkDeep, C.mist, 0.3);
  const drop = Math.max(1, o.fromRow - o.toRow);
  for (let row = o.toRow; row <= o.fromRow; row++) {
    const u = (o.fromRow - row) / drop;
    const r = o.r * (1 + 0.5 * u);
    for (let dx = -Math.ceil(r); dx <= Math.ceil(r); dx++) {
      for (let dz = -Math.ceil(r); dz <= Math.ceil(r); dz++) {
        if (Math.hypot(dx, dz) > r) continue;
        world.set(o.cx + dx, row, o.cz + dz, shade(col, 0.78 + 0.34 * (1 - u)), {
          kind: Kind.Water,
          t: o.t + u * 0.5,
          dur: FADE,
        });
      }
    }
  }
}
