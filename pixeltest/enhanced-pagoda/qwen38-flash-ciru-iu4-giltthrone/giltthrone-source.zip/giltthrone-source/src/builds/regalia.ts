import { Kind, VoxelWorld } from '../core/VoxelWorld';
import { C, hash3, mixHex, shade } from '../core/palette';
import { BuilderArgs, FADE, opt, reveal } from './types';

/**
 * Throne-room regalia for the great hall: the dais the throne stands on, the throne itself,
 * and the hanging gold above it — canopy, banners, chandeliers — plus the sun disc mounted on
 * the back wall.
 *
 * The hall's camera never leaves the aisle running along +z toward the doors, so the standing
 * builders (`throne`, `dais`) face +z and grow upward from `a.y`, and the hanging builders
 * (`canopy`, `banner`, `chandelier`) take `a.y` as the attachment row and grow downward.
 *
 * Lighting is baked and the interior reads dark: every up-facing or door-facing gold surface is
 * authored at `C.goldPale` / `C.goldLite` / `C.goldHot`, every underside at `C.goldDeep` /
 * `C.bronze`, and each cell gets a small deterministic brightness jitter so a gilded run never
 * reads as one flat hue.
 */

// ------------------------------------------------------------------ helpers

/** Clamped integer knob. */
function knob(a: BuilderArgs, key: string, dflt: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, Math.round(opt(a, key, dflt))));
}

/**
 * Gilded cell tint. `up` names the face the cell presents: cells seen from above or from the
 * door end of the aisle are authored near white, cells seen from below are authored dark, since
 * the baked hemisphere multiplies them the other way. `k` is how far a cell may drift off its
 * base hue, so a run of gilding never reads as one flat plate.
 */
function gild(hex: number, x: number, y: number, z: number, up: number, k = 0.1): number {
  const jitter = 1 + (hash3(x, y, z, 4703) - 0.5) * 2 * k;
  const lift = up > 0 ? 1.06 : up < 0 ? 0.74 : 0.94;
  return shade(hex, jitter * lift);
}

/**
 * Concentric stepped platform of square rings, one row of rise per step. `a.y` is the tread row
 * of the outer ring: a standing builder, nothing is written below `a.y`. Each ring wears a gilded
 * riser edge on its outer band and a dark marble tread (`C.marble` / `C.marbleLite`) inboard, so
 * the stack reads as lit steps under the throne instead of one flat gold slab.
 *
 * Knobs: `half` 4..14 (default 8) half-width of the outer ring, `steps` 2..5 (default 4) rings.
 * Footprint `(2·half + 1)` × `(2·half + 1)` cells, `steps` rows tall. No glow cells.
 */
export function dais(world: VoxelWorld, a: BuilderArgs): void {
  const half = knob(a, 'half', 8, 4, 14);
  const steps = knob(a, 'steps', 4, 2, 5);
  const shrink = Math.max(1, Math.floor((half - 1) / steps));
  const put = (f: number) => ({ t: reveal(a, f), dur: FADE });

  // support first: the outer ring, then each ring inward and upward
  for (let i = 0; i < steps; i++) {
    const h = Math.max(1, half - i * shrink);
    const y = a.y + i;
    const f = 0.04 + (0.7 * i) / Math.max(1, steps - 1);
    for (let dx = -h; dx <= h; dx++) {
      for (let dz = -h; dz <= h; dz++) {
        const cheb = Math.max(Math.abs(dx), Math.abs(dz));
        const px = a.x + dx;
        const pz = a.z + dz;
        if (cheb === h) {
          // riser edge of this step: the door-facing band is authored near white
          const lip = dz === h ? C.goldPale : dz === -h ? C.goldLite : C.gold;
          world.set(px, y, pz, gild(lip, px, y, pz, dz === h ? 1 : 0, 0.08), put(f));
          continue;
        }
        // covered by the next ring up: never author voxels nobody can see
        if (i < steps - 1 && cheb <= h - shrink) continue;
        const veined = hash3(px, y, pz, 613) > 0.62;
        world.set(px, y, pz, gild(veined ? C.marbleLite : C.marble, px, y, pz, 1, 0.16), put(f + 0.05));
      }
    }
  }
}

/**
 * Monumental gilded throne on the top step, facing the doors at +z. `a.y` is the row it stands
 * on; it occupies rows `a.y … a.y + h - 1` and never writes below `a.y`. Plinth, seat slab and
 * tapering back, armrests ending in a block-gilded boss, a velvet cushion on the seat, and a
 * ruby in the crown of the back. The seat and the whole door-facing front are authored pale so
 * the throne stays the brightest object in the hall.
 *
 * Knobs: `h` 6..13 (default 10) height above `a.y`, `w` 3..6 (default 4) seat width; even `w`
 * widens to `2·⌊w/2⌋ + 1` cells to stay centred on the aisle.
 * Footprint `(2·⌊w/2⌋ + 1)` × `(2·⌊w/2⌋ + 3)` cells, `h` rows. Glow: 5 cells.
 */
export function throne(world: VoxelWorld, a: BuilderArgs): void {
  const h = knob(a, 'h', 10, 6, 13);
  const w = knob(a, 'w', 4, 3, 6);
  const hw = Math.floor(w / 2);
  const top = a.y + h - 1;
  const seat = a.y + Math.max(2, Math.round(h * 0.3));
  const backZ = a.z - hw - 1;

  const put = (f: number) => ({ t: reveal(a, f), dur: FADE });
  const under = (px: number, y: number, pz: number): number =>
    gild(mixHex(C.goldDeep, C.bronze, 0.35), px, y, pz, -1, 0.08);

  // --- plinth: a coursed gold block under the seat, hollow where nothing can see it
  for (let y = a.y; y < seat; y++) {
    const f = 0.04 + 0.12 * ((y - a.y) / Math.max(1, seat - a.y));
    for (let dx = -hw; dx <= hw; dx++)
      for (let dz = -(hw + 1); dz <= hw + 1; dz++) {
        const shell = Math.abs(dx) === hw || Math.abs(dz) === hw + 1 || y === seat - 1;
        if (!shell) continue;
        const px = a.x + dx;
        const pz = a.z + dz;
        const hex = y === seat - 1 ? C.goldLite : dz === hw + 1 ? C.goldPale : C.gold;
        world.set(px, y, pz, gild(hex, px, y, pz, y === seat - 1 ? 1 : 0), put(f));
      }
  }

  // --- seat slab: authored near white on top, dark underneath, so the seat reads bright
  for (let dx = -hw; dx <= hw; dx++)
    for (let dz = -(hw + 1); dz <= hw + 1; dz++) {
      const px = a.x + dx;
      const pz = a.z + dz;
      world.set(px, seat, pz, gild(dx === 0 || dz === hw + 1 ? C.goldPale : C.goldLite, px, seat, pz, 1), put(0.26));
      if (dz === hw + 1) world.set(px, seat - 1, pz, under(px, seat - 1, pz), put(0.22));
    }

  // --- back: tapering sides, two cells thick, the aisle-facing leaf pale
  for (let y = seat + 1; y <= top; y++) {
    const k = (y - seat) / Math.max(1, top - seat);
    const bx = Math.max(0, Math.round(hw * (1 - 0.55 * k)));
    const f = 0.4 + 0.44 * k;
    const crown = y === top;
    const rear = crown ? C.goldHot : C.goldDeep;
    const front = crown ? C.goldHot : y >= top - 1 ? C.goldPale : (y & 1) === 0 ? C.goldLite : C.gold;
    for (let dx = -bx; dx <= bx; dx++) {
      const px = a.x + dx;
      const crest = crown && (Math.abs(dx) & 1) === 0;
      world.set(px, y, backZ, gild(rear, px, y, backZ, 0, 0.06), put(f));
      world.set(
        px,
        y,
        backZ + 1,
        gild(crest ? C.goldPale : front, px, y, backZ + 1, crest ? 1 : 0, 0.08),
        put(f + 0.03),
      );
    }
    // shoulder posts stitching the back to the armrests
    if (y <= seat + 2)
      for (const s of [-1, 1])
        world.set(a.x + s * hw, y, backZ + 1, gild(C.goldLite, a.x + s * hw, y, backZ + 1, 0), put(0.42));
  }

  // --- armrests: a rail on each side ending in a block-gilded boss at the front
  const armY = seat + 1;
  for (const s of [-1, 1]) {
    for (let dz = -hw; dz <= hw + 1; dz++) {
      const pz = a.z + dz;
      const hex = dz === hw + 1 ? C.goldPale : (dz & 1) === 0 ? C.goldLite : C.gold;
      world.set(a.x + s * hw, armY, pz, gild(hex, a.x + s * hw, armY, pz, 1), put(0.5));
    }
    // the boss: a solid gilded cube crowning the front of each arm
    world.set(
      a.x + s * hw,
      armY + 1,
      a.z + hw + 1,
      gild(C.goldPale, a.x + s * hw, armY + 1, a.z + hw + 1, 1, 0.04),
      put(0.62),
    );
    world.set(a.x + s * hw, armY + 1, a.z + hw, under(a.x + s * hw, armY + 1, a.z + hw), put(0.6));
  }

  // --- cushion: velvet pad with a gilded pip along the front and outer edges
  for (let dx = -(hw - 1); dx <= hw - 1; dx++)
    for (let dz = -hw; dz <= hw; dz++) {
      const px = a.x + dx;
      const pz = a.z + dz;
      const pip = Math.abs(dx) === hw - 1 || dz === hw;
      const hex = pip
        ? gild(C.goldLite, px, armY, pz, 1, 0.06)
        : shade(C.velvet, 0.82 + 0.36 * hash3(px, armY, pz, 17));
      world.set(px, armY, pz, hex, put(0.66));
    }

  // --- glow: the ruby in the crown, then the rim of lamps at the plinth corners (5 cells)
  for (const s of [-1, 1])
    for (const t of [-1, 1])
      world.set(
        a.x + s * hw,
        a.y,
        a.z + t * (hw + 1),
        C.lanternCore,
        { kind: Kind.Glow, glow: 0.55, ...put(0.9) },
      );
  world.set(a.x, top, backZ + 1, C.ruby, { kind: Kind.Glow, glow: 1, ...put(0.96) });
}

/**
 * Cloth-of-gold canopy hung over the throne, read from below. `a.y` is the attachment row at the
 * crown of the shaft: a hanging builder, nothing is written above `a.y`. Four bronze rods drop
 * first, then the canopy plate, then the sun-ray field, then the valance that hangs below it.
 *
 * The field is authored dark (`C.goldDeep` / `C.bronze` ribs on a `C.gold` ground) and the rays
 * pale, so under a dark interior bake the plate reads as a radiating gold star from the aisle
 * instead of a flat lid.
 *
 * Knobs: `r` 3..7 (default 5) plate radius, `drop` 2..5 (default 3) rows from `a.y` to the plate.
 * Footprint `(2·r + 1)` × `(2·r + 1)` cells, `drop + 2` rows tall. Glow: 1 cell.
 */
export function canopy(world: VoxelWorld, a: BuilderArgs): void {
  const r = knob(a, 'r', 5, 3, 7);
  const drop = knob(a, 'drop', 3, 2, 5);
  const put = (f: number) => ({ t: reveal(a, f), dur: FADE });
  const plate = a.y - drop;

  // support first: the hub at the attachment row, then the four rods
  for (let dx = -1; dx <= 1; dx++)
    for (let dz = -1; dz <= 1; dz++)
      world.set(a.x + dx, a.y, a.z + dz, gild(C.bronze, a.x + dx, a.y, a.z + dz, -1, 0.07), put(0.02));
  for (const [sx, sz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]] as const)
    for (let y = a.y - 1; y > plate; y--)
      world.set(a.x + sx * (r - 1), y, a.z + sz * (r - 1), gild(C.bronze, a.x + sx * (r - 1), y, a.z + sz * (r - 1), 0, 0.05), put(0.12));

  // plate: dark ground, pale rays along the axes and diagonals
  for (let dx = -r; dx <= r; dx++)
    for (let dz = -r; dz <= r; dz++) {
      const d = Math.max(Math.abs(dx), Math.abs(dz));
      if (d > r || (d === r && Math.abs(dx) + Math.abs(dz) > 2 * r - 1)) continue;
      const px = a.x + dx;
      const pz = a.z + dz;
      const ray = dx === 0 || dz === 0 || Math.abs(dx) === Math.abs(dz);
      const hex = d === r ? C.goldPale : ray ? mixHex(C.goldLite, C.goldHot, hash3(px, plate, pz, 71)) : C.goldDeep;
      world.set(px, plate, pz, gild(hex, px, plate, pz, -1, 0.12), put(0.3 + 0.34 * (d / r)));
    }

  // valance: a scalloped hem one row below the plate, dark inside, pale tips
  for (let dx = -r; dx <= r; dx++)
    for (let dz = -r; dz <= r; dz++) {
      const d = Math.max(Math.abs(dx), Math.abs(dz));
      if (d !== r) continue;
      const px = a.x + dx;
      const pz = a.z + dz;
      const hem = (Math.abs(dx) + Math.abs(dz)) & 1 ? 1 : 2;
      for (let k = 1; k <= hem; k++)
        world.set(px, plate - k, pz, gild(k === hem ? C.goldPale : C.gold, px, plate - k, pz, -1, 0.1), put(0.62 + 0.06 * k));
    }

  // ornament last: the boss under the hub
  world.set(a.x, plate, a.z, C.lanternCore, { kind: Kind.Glow, glow: 0.7, ...put(0.92) });
}

/**
 * Suspended banner: a gilded yard-arm at `a.y` with a cloth hanging from it. `a.y` is the
 * attachment row: a hanging builder, nothing is written above `a.y`. `opts.dir` selects which
 * axis the cloth is perpendicular to — `0` faces the aisle ends (cloth spans x), `1` faces along
 * it (cloth spans z) — so pairs of banners can line the nave either way.
 *
 * Knobs: `w` 3..7 (default 5) cloth width, `len` 5..13 (default 9) rows of cloth, `dir` 0..1
 * (default 0). Footprint follows `dir`; height `len + 2` rows. Glow: 3 cells.
 */
export function banner(world: VoxelWorld, a: BuilderArgs): void {
  const w = knob(a, 'w', 5, 3, 7) | 1;
  const len = knob(a, 'len', 9, 5, 13);
  const dir = knob(a, 'dir', 0, 0, 1);
  const put = (f: number) => ({ t: reveal(a, f), dur: FADE });
  const hw = w >> 1;
  // `u` runs across the cloth, `v` is the depth the cloth faces
  const at = (u: number, y: number, v: number) => (dir === 0 ? [a.x + u, y, a.z + v] : [a.x + v, y, a.z + u]);

  // support first: the yard-arm and its two finials
  for (let u = -(hw + 1); u <= hw + 1; u++) {
    const [px, y, pz] = at(u, a.y, 0);
    const tip = Math.abs(u) === hw + 1;
    world.set(px, y, pz, gild(tip ? C.goldHot : C.goldLite, px, y, pz, tip ? 1 : -1, 0.07), put(0.05));
  }

  // cloth: velvet ground, gilded border and a vertical pale stripe down the middle
  for (let s = 1; s <= len; s++) {
    const y = a.y - s;
    const f = 0.2 + 0.56 * (s / len);
    const taper = s > len - 3 ? hw - (s - (len - 3)) + 1 : hw;
    for (let u = -hw; u <= hw; u++) {
      const [px, py, pz] = at(u, y, 0);
      if (u < -taper || u > taper) continue;
      const edge = Math.abs(u) === taper || s === 1;
      const stripe = u === 0 && (s & 1) === 0;
      const hex = stripe
        ? mixHex(C.goldPale, C.goldHot, hash3(px, py, pz, 29))
        : edge
          ? (s & 1) === 0 ? C.goldLite : C.gold
          : shade(C.velvet, 0.74 + 0.4 * hash3(px, py, pz, 53));
      world.set(px, py, pz, hex, put(f));
    }
  }

  // ornament last: three lamps set into the cloth directly under the arm
  for (const u of [-hw, 0, hw]) {
    const [px, y, pz] = at(u, a.y - 1, 0);
    world.set(px, y, pz, C.lanternCore, { kind: Kind.Glow, glow: 0.6, ...put(0.9 + 0.03 * (u + hw)) });
  }
}

/**
 * Crown chandelier hung over the nave: a stem from the ceiling, a small crown ring part-way down,
 * then the main ring with radial arms carrying cups. `a.y` is the attachment row: a hanging
 * builder, nothing is written above `a.y`. Support first (stem, crown ring, main ring), arms next,
 * lamps last.
 *
 * Knobs: `r` 2..6 (default 4) main-ring radius, `h` 4..9 (default 6) rows from `a.y` to the ring,
 * `arms` 4..12 (default 8) radial arms. Footprint `(2·r + 1)` × `(2·r + 1)` cells, `h + 1` rows.
 * Glow: `arms + 2` cells.
 */
export function chandelier(world: VoxelWorld, a: BuilderArgs): void {
  const r = knob(a, 'r', 4, 2, 6);
  const h = knob(a, 'h', 6, 4, 9);
  const arms = knob(a, 'arms', 8, 4, 12);
  const put = (f: number) => ({ t: reveal(a, f), dur: FADE });
  const ringRow = a.y - h + 1;
  const crownRow = a.y - Math.max(1, Math.round(h * 0.35));
  const rc = Math.max(1, Math.round(r * 0.5));
  const step = (Math.PI * 2) / arms;

  // support: the stem, and the crown ring it carries
  for (let y = a.y; y >= ringRow; y--)
    world.set(
      a.x,
      y,
      a.z,
      gild(y === a.y ? C.bronze : y === crownRow ? C.goldLite : C.goldDeep, a.x, y, a.z, 0, 0.05),
      put(0.04),
    );
  for (let dx = -rc; dx <= rc; dx++)
    for (let dz = -rc; dz <= rc; dz++) {
      if (Math.round(Math.hypot(dx, dz)) !== rc) continue;
      const px = a.x + dx;
      const pz = a.z + dz;
      world.set(px, crownRow, pz, gild(C.goldLite, px, crownRow, pz, 1, 0.09), put(0.18));
    }

  // main ring, arms out from the hub, and the pendants under the ring
  for (let dx = -r; dx <= r; dx++)
    for (let dz = -r; dz <= r; dz++) {
      const d = Math.hypot(dx, dz);
      if (d > r + 0.5) continue;
      const nearest = Math.round(Math.atan2(dz, dx) / step) * step;
      const onArm = Math.abs(Math.cos(nearest) * dz - Math.sin(nearest) * dx) <= 0.55;
      if (Math.round(d) !== r && !onArm) continue;
      const px = a.x + dx;
      const pz = a.z + dz;
      const hex = Math.round(d) === r ? C.gold : C.goldLite;
      world.set(px, ringRow, pz, gild(hex, px, ringRow, pz, 1, 0.1), put(0.3 + 0.22 * (d / r)));
      if (Math.round(d) === r && ((Math.abs(dx) + Math.abs(dz)) & 1) === 0) {
        for (let k = 1; k <= 2; k++)
          world.set(
            px,
            ringRow - k,
            pz,
            gild(k === 2 ? C.goldPale : C.bronze, px, ringRow - k, pz, -1, 0.08),
            put(0.6 + 0.06 * k),
          );
      }
    }

  // ornament last: one lamp per arm, plus the two crystals on the axis
  for (let k = 0; k < arms; k++) {
    const px = a.x + Math.round(r * Math.cos(k * step));
    const pz = a.z + Math.round(r * Math.sin(k * step));
    world.set(px, ringRow + 1, pz, C.lanternCore, { kind: Kind.Glow, glow: 0.8, ...put(0.78 + 0.16 * (k / arms)) });
  }
  world.set(a.x, crownRow, a.z, C.lanternCore, { kind: Kind.Glow, glow: 0.7, ...put(0.94) });
  world.set(a.x, ringRow, a.z, C.lanternCore, { kind: Kind.Glow, glow: 0.65, ...put(0.97) });
}

/**
 * Gilt sun disc mounted flat in the z plane on the rear wall, behind and above the throne. `a.y`
 * is the lowest row of the disc — a standing builder, nothing is written below `a.y` — and the
 * disc spans rows `a.y … a.y + 2r` with its heart at row `a.y + r`. A dark backing plate is cast
 * one cell behind the face first, then the rim, then the rays, then the heart, then the lamps.
 *
 * Twelve rays alternate with plain ground between a solid inner disc and the rim: the rays are
 * authored pale and the ground dark so the wheel reads as a radiating disc from the aisle rather
 * than a flat golden coin.
 *
 * Knobs: `r` 3..8 (default 6) outer radius. Footprint `(2·r + 1)` cells wide, two cells deep in z,
 * `2r + 1` rows. Glow: 5 cells.
 */
export function sunDisc(world: VoxelWorld, a: BuilderArgs): void {
  const r = knob(a, 'r', 6, 3, 8);
  const put = (f: number) => ({ t: reveal(a, f), dur: FADE });
  const cy = a.y + r;
  const rays = 12;
  const step = (Math.PI * 2) / rays;
  const core = Math.max(1, Math.round(r * 0.45));

  for (let dx = -r; dx <= r; dx++)
    for (let dz = -r; dz <= r; dz++) {
      const d = Math.round(Math.hypot(dx, dz));
      if (d > r) continue;
      const px = a.x + dx;
      const py = cy + dz;
      // backing plate first: the shadow side buried in the wall
      world.set(
        px,
        py,
        a.z - 1,
        gild(d === r ? C.bronze : C.goldDeep, px, py, a.z - 1, 0, 0.14),
        put(0.06 + 0.1 * (d / r)),
      );
      const nearest = Math.round(Math.atan2(dz, dx) / step) * step;
      const ray = d > core && Math.abs(Math.cos(nearest) * dz - Math.sin(nearest) * dx) <= 0.5 + 0.55 * (d / r);
      const hex =
        d === r
          ? mixHex(C.goldPale, C.goldHot, hash3(px, py, a.z, 97))
          : d <= core
            ? C.goldPale
            : ray
              ? C.goldLite
              : C.goldDeep;
      world.set(
        px,
        py,
        a.z,
        gild(hex, px, py, a.z, d <= core ? 1 : 0, 0.11),
        put(d === r ? 0.24 : d <= core ? 0.7 : 0.4 + 0.14 * (d / r)),
      );
    }

  // ornament last: the heart, then four lamps at the cardinal tips
  world.set(a.x, cy, a.z, C.lanternCore, { kind: Kind.Glow, glow: 1, ...put(0.9) });
  for (const [ux, uy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const)
    world.set(a.x + ux * r, cy + uy * r, a.z, C.lanternCore, { kind: Kind.Glow, glow: 0.55, ...put(0.96) });
}
