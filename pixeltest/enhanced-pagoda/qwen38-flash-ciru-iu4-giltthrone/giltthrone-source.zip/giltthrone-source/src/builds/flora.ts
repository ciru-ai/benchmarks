import { C, clamp, hash3, mixHex, shade } from '../core/palette';
import { Kind, VoxelWorld } from '../core/VoxelWorld';
import { type BuilderArgs, FADE, dice, opt, reveal, swayAt, noise2 } from './types';

/**
 * Plant and stone library. Every builder is a pure function of its arguments: all scatter
 * comes from `dice()` / `hash3()`, never from the clock or the wall. Reveal order is always
 * base-first, crown-last. Crowns are ellipsoids flattened on top, lobed by a coarse noise
 * field and eroded by a fine one, so no two are spheres and no two are alike.
 */

type Cell = [number, number, number];

interface PaintOpts {
  /** reveal order 0..1 for the bottom of this piece */
  f: number;
  /** grid row the object stands on */
  baseY: number;
  /** full object height, for sway + reveal ramping */
  totalH: number;
  /** extra reveal seconds spread across height/hash */
  span?: number;
  /** sway strength, 0 for timber and stone */
  sway?: number;
  kind?: Kind;
}

function cellKey(x: number, y: number, z: number): string {
  return x + ':' + y + ':' + z;
}

/**
 * Ellipsoid cell list. `squash` flattens the upper half, `noise` is the amplitude of a
 * coarse lobe field (bumpiness) plus a per-cell grain (ragged rim).
 */
function blobCells(
  cx: number,
  cy: number,
  cz: number,
  rx: number,
  ry: number,
  rz: number,
  noise: number,
  squash: number,
  seed: number,
): Cell[] {
  const out: Cell[] = [];
  const ex = Math.ceil(rx + noise);
  const ey = Math.ceil(ry + noise);
  const ez = Math.ceil(rz + noise);
  for (let dy = -ey; dy <= ey; dy++) {
    for (let dz = -ez; dz <= ez; dz++) {
      for (let dx = -ex; dx <= ex; dx++) {
        const up = dy > 0 ? ry * squash : ry;
        const d = Math.sqrt((dx / rx) ** 2 + (dy / up) ** 2 + (dz / rz) ** 2);
        const lobe = noise2(dx * 0.55 + cx, dz * 0.55 + cz, seed) - 0.5;
        const grain = hash3(cx + dx, cy + dy, cz + dz, seed + 31) - 0.5;
        if (d + lobe * noise - grain * noise * 0.7 <= 1) out.push([cx + dx, cy + dy, cz + dz]);
      }
    }
  }
  return out;
}

/** Drop cells whose six neighbours are all present — the interior of a crown is never seen. */
function hollow(cells: Cell[]): Cell[] {
  const s = new Set<string>();
  for (const c of cells) s.add(cellKey(c[0], c[1], c[2]));
  return cells.filter(
    ([x, y, z]) =>
      !s.has(cellKey(x + 1, y, z)) ||
      !s.has(cellKey(x - 1, y, z)) ||
      !s.has(cellKey(x, y + 1, z)) ||
      !s.has(cellKey(x, y - 1, z)) ||
      !s.has(cellKey(x, y, z + 1)) ||
      !s.has(cellKey(x, y, z - 1)),
  );
}

/** Read a knob as an integer clamped to the builder's declared range. */
function knob(a: BuilderArgs, name: string, def: number, lo: number, hi: number): number {
  return clamp(Math.round(opt(a, name, def)), lo, hi);
}

/** Stamp a cell list with a per-voxel colour and a reveal that ramps with height. */
function paint(
  world: VoxelWorld,
  a: BuilderArgs,
  cells: Cell[],
  o: PaintOpts,
  colorFor: (x: number, y: number, z: number) => number,
): void {
  const span = o.span ?? 0.22;
  const sway = o.sway ?? 0;
  const kind = o.kind ?? Kind.Solid;
  for (const [x, y, z] of cells) {
    if (y < o.baseY) continue; // never write under the surface the object stands on
    const hf = heightFrac(y, o);
    world.set(x, y, z, colorFor(x, y, z), {
      kind,
      t: reveal(a, o.f + span * (0.45 * hf + 0.55 * hash3(x, y, z, a.seed))),
      dur: FADE,
      sway: sway > 0 ? swayAt(y - o.baseY, o.totalH, sway) : 0,
    });
  }
}

/** Foliage tint: pick a palette entry by hash, then darken by height so undersides sink. */
function leafColor(cols: number[], x: number, y: number, z: number, seed: number, hf: number): number {
  const pick = cols[Math.min(cols.length - 1, Math.floor(hash3(x, y, z, seed) * cols.length))];
  return shade(pick, 0.66 + 0.2 * hf + 0.14 * hash3(x, y, z, seed + 977));
}

/**
 * Gnarled limb: walks `len` cells along (dx,dy,dz) with a quadratic `curl` added to the
 * rise, a hash wobble on the horizontal axes and a cross-section that tapers to one cell.
 * Returns the tip cell so the caller can hang a crown from it.
 */
function limb(
  world: VoxelWorld,
  a: BuilderArgs,
  ox: number,
  oy: number,
  oz: number,
  dx: number,
  dy: number,
  dz: number,
  len: number,
  r: number,
  curl: number,
  o: PaintOpts,
  colorFor: (x: number, y: number, z: number, t: number) => number,
): Cell {
  const span = o.span ?? 0.2;
  let tip: Cell = [ox, oy, oz];
  for (let s = 0; s <= len; s++) {
    const t = len > 0 ? s / len : 0;
    const wob = hash3(s + ox, oy + s * 3, oz - s, a.seed) - 0.5;
    const px = Math.round(ox + dx * t + wob * 0.8);
    const pz = Math.round(oz + dz * t - wob * 0.5);
    const py = Math.round(oy + dy * t + curl * t * t);
    const g = Math.max(1, Math.round(r * (1 - 0.6 * t)));
    const off = g >> 1;
    const f = o.f + span * t * t;
    for (let by = 0; by < g; by++)
      for (let bz = 0; bz < g; bz++)
        for (let bx = 0; bx < g; bx++) {
          const x = px + bx - off;
          const y = py + by;
          const z = pz + bz - off;
          if (y < o.baseY) continue;
          world.set(x, y, z, colorFor(x, y, z, t), {
            t: reveal(a, f),
            dur: FADE,
            sway: swayAt(y - o.baseY, o.totalH, 0.12),
          });
        }
    tip = [px, py + g - 1 - off, pz];
  }
  return tip;
}

function heightFrac(y: number, o: PaintOpts): number {
  return clamp((y - o.baseY) / Math.max(1, o.totalH), 0, 1);
}

// --------------------------------------------------------------------------- trees

/**
 * Gnarled pine: bare bent trunk, 3–5 flat tiered needle pads at staggered heights, the
 * lowest pair widest. Sway is kept low (0.5) — pines read as iron. Knobs: `h` (16).
 * Footprint x−16..x+16, z−16..z+16, y..y+h+2.
 */
export function pineTree(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const h = knob(a, 'h', 16, 10, 24);
  const o: PaintOpts = { f: 0, baseY: a.y, totalH: h };
  const needles = [C.pine, C.pineDeep, mixHex(C.pine, C.mossDeep, 0.4)];

  world.box(a.x - 1, a.y, a.z - 1, a.x + 1, a.y, a.z + 1, shade(C.soil, 0.8), { t: reveal(a, 0), dur: FADE });

  // bent trunk: three segments, each kicking further over
  const bends = 3;
  const per = Math.max(2, Math.round((h - 3) / bends));
  let px = a.x;
  let pz = a.z;
  let py = a.y;
  let dirX = rnd() < 0.5 ? 1 : -1;
  let dirZ = rnd() < 0.5 ? 1 : -1;
  const pads: Cell[] = [];
  for (let i = 0; i < bends; i++) {
    const dx = dirX * (0.5 + i * 0.9);
    const dz = dirZ * (0.4 + i * 0.5);
    const tip = limb(
      world,
      a,
      px,
      py,
      pz,
      dx * per * 0.5,
      per,
      dz * per * 0.5,
      per,
      i === 0 ? 2 : 1,
      0.9,
      { ...o, f: 0.02 * i },
      (x, y, z, t) => shade(mixHex(C.bark, C.inkSoft, 0.35), 0.6 + 0.34 * t + 0.1 * hash3(x, z, y, a.seed)),
    );
    [px, py, pz] = tip;
    pads.push([px, py, pz]);
    if (i === 1) dirX = -dirX;
  }

  // side arms off the middle of the trunk carry the low, wide tiers
  const arms = 2 + Math.floor(rnd() * 2);
  for (let i = 0; i < arms; i++) {
    const ang = (i / arms) * Math.PI * 2 + 0.7 + rnd() * 0.6;
    const startY = a.y + Math.round(h * (0.4 + 0.14 * i));
    const reach = 2 + Math.round(rnd() * 2);
    pads.push(
      limb(
        world,
        a,
        a.x,
        startY,
        a.z,
        Math.cos(ang) * reach * 1.5,
        Math.round(reach * 0.45),
        Math.sin(ang) * reach * 1.5,
        reach + 1,
        1,
        -0.8,
        { ...o, f: 0.25 + 0.1 * i },
        (x, y, z, t) => shade(C.woodDark, 0.64 + 0.3 * t + 0.08 * hash3(x, y, z, a.seed + 83)),
      ),
    );
  }

  // flat needle pads, sampled low-to-high along the arm/tip heights, lowest tier widest
  pads.sort((p, q) => p[1] - q[1] || p[0] - q[0] || p[2] - q[2]);
  const count = Math.min(pads.length, 3 + Math.floor(rnd() * 3)); // 3..5
  for (let i = 0; i < count; i++) {
    const [cx, cy, cz] = pads[Math.round((i * (pads.length - 1)) / (count - 1))];
    const spread = 1 - i / (count + 1);
    const rx = 1.8 + spread * 2.1 + hash3(cx, cz, i, a.seed) * 0.8;
    const cells = hollow(
      blobCells(cx, cy + 1, cz, rx, 1.05, rx, 0.95, 0.5, a.seed + 61 + i * 17),
    );
    paint(world, a, cells, { ...o, f: 0.45 + 0.11 * i, span: 0.26, sway: 0.5, kind: Kind.Foliage }, (x, y, z) =>
      leafColor(needles, x, y, z, a.seed + i * 11, heightFrac(y, o)),
    );
  }
}

/** Scattered single-cell blossoms inside a small sphere — used by the near-bare plum. */
function flecks(
  world: VoxelWorld,
  a: BuilderArgs,
  cx: number,
  cy: number,
  cz: number,
  radius: number,
  count: number,
  cols: number[],
  o: PaintOpts,
  f: number,
): void {
  const rnd = dice({ ...a, seed: a.seed + Math.round(cx * 31 + cz * 7 + cy) });
  let placed = 0;
  let guard = 0;
  while (placed < count && guard++ < 60) {
    const dx = Math.round((rnd() - 0.5) * 2 * radius);
    const dy = Math.round(rnd() * radius * 1.4);
    const dz = Math.round((rnd() - 0.5) * 2 * radius);
    if (world.occupied(cx + dx, cy + dy, cz + dz)) continue;
    const hf = heightFrac(cy + dy, o);
    world.set(cx + dx, cy + dy, cz + dz, shade(cols[Math.floor(rnd() * cols.length)], 0.74 + 0.26 * hf), {
      kind: Kind.Foliage,
      t: reveal(a, f + 0.25 * hf),
      dur: FADE,
      sway: swayAt(dy, o.totalH, 1),
    });
    placed++;
  }
}

/**
 * Plum: crooked, almost bare — dark zig-zag branches with sparse pale blossom flecks at the
 * tips and a few caught along the limbs. Knobs: `h` (9). Footprint x−9..x+9, z−9..z+9, y..y+h+2.
 */
export function plumTree(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const h = knob(a, 'h', 9, 6, 14);
  const o: PaintOpts = { f: 0, baseY: a.y, totalH: h };
  const barkCol = mixHex(C.woodDark, C.ink, 0.3);

  let tip: Cell = [a.x, a.y, a.z];
  const segs = 2 + Math.floor(rnd() * 2);
  const per = Math.max(1, Math.floor((h - 4) / segs));
  for (let i = 0; i < segs; i++) {
    tip = limb(
      world,
      a,
      tip[0],
      tip[1],
      tip[2],
      (i % 2 === 0 ? 1 : -2) + Math.round(rnd() * 2 - 1),
      per,
      (i % 2 === 0 ? -1 : 1) + Math.round(rnd() * 2 - 1),
      per + 1,
      i === 0 ? 2 : 1,
      0.8,
      { ...o, f: 0.04 * i },
      (x, y, z, t) => shade(barkCol, 0.6 + 0.32 * t + 0.08 * hash3(x, y, z, a.seed + 13)),
    );
  }

  const twigs = 4 + Math.floor(rnd() * 3);
  const blossom = [C.plumLite, shade(C.paper, 0.72), C.plum];
  for (let i = 0; i < twigs; i++) {
    const ang = (i / twigs) * Math.PI * 2 + rnd() * 1.1;
    const reach = Math.min(2 + Math.round(rnd() * 2), Math.max(2, Math.round(h * 0.5)));
    const rootY = a.y + Math.round(h * (0.35 + 0.5 * rnd()));
    const t = limb(
      world,
      a,
      a.x + Math.round(Math.cos(ang) * 0.5),
      rootY,
      a.z + Math.round(Math.sin(ang) * 0.5),
      Math.cos(ang) * reach * 1.5,
      Math.max(0, Math.min(Math.round(reach * 0.9), a.y + h - 3 - rootY)),
      Math.sin(ang) * reach * 1.5,
      reach + 2,
      1,
      -1.4,
      { ...o, f: 0.25 + 0.08 * i },
      (x, y, z, k) => shade(barkCol, 0.58 + 0.34 * k + 0.08 * hash3(x, y, z, a.seed + 97)),
    );
    flecks(world, a, t[0], t[1] + 1, t[2], 1 + Math.round(rnd()), 3 + Math.floor(rnd() * 4), blossom, o, 0.6);
  }
  flecks(world, a, tip[0], tip[1] + 1, tip[2], 2, 6, blossom, o, 0.75);
}

// ------------------------------------------------------------------- undergrowth

/**
 * Low ragged mound, wider than tall, with a darker soil skirt and a couple of pale tips.
 * Knobs: `r` (2), `h` (3). Footprint x−2r−1..x+2r+1, z−2r−1..z+2r+1, y..y+h+1.
 */
export function shrub(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const r = knob(a, 'r', 2, 1, 4);
  const h = knob(a, 'h', 3, 2, 7);
  const o: PaintOpts = { f: 0, baseY: a.y, totalH: h };
  const leaves = [C.mossDeep, C.moss, C.pine, C.leaf];

  const lobes = 2 + Math.floor(rnd() * 3);
  for (let i = 0; i < lobes; i++) {
    const ang = (i / lobes) * Math.PI * 2 + rnd() * 1.4;
    const off = i === 0 ? 0 : Math.round(rnd() * r);
    const cx = a.x + Math.round(Math.cos(ang) * off);
    const cz = a.z + Math.round(Math.sin(ang) * off);
    const rx = Math.max(1, r - (i === 0 ? 0 : 1)) + hash3(cx, cz, i, a.seed) * 0.6;
    const cells = blobCells(cx, a.y + Math.round(h * 0.55), cz, rx, h * 0.62, rx, 0.9, 0.62, a.seed + i * 41);
    paint(world, a, cells, { ...o, f: 0.08 * i, span: 0.3, sway: 0.7, kind: Kind.Foliage }, (x, y, z) => {
      const hf = heightFrac(y, o);
      const tip = hash3(x, y, z, a.seed + 131) > 0.86 ? C.leaf : leaves[Math.floor(hash3(x, y, z, a.seed) * leaves.length)];
      return shade(tip, 0.6 + 0.24 * hf + 0.16 * hash3(x, z, y, a.seed + 17));
    });
  }
}

/**
 * A handful of one-cell blades with an optional flower. Roughly every fifth tuft (decided by
 * hash of the column) carries a pale or plum fleck. Footprint x−2..x+2, z−2..z+2, y..y+h+1.
 */
export function grassTuft(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const h = knob(a, 'h', 3, 2, 6);
  const o: PaintOpts = { f: 0, baseY: a.y, totalH: h };
  const blades = 4 + Math.floor(rnd() * 4);
  const cols = [C.moss, C.mossDeep, C.leaf];
  const seen = new Set<string>();
  for (let i = 0; i < blades; i++) {
    const ox = Math.round((rnd() - 0.5) * 3.4);
    const oz = Math.round((rnd() - 0.5) * 3.4);
    const k = cellKey(a.x + ox, 0, a.z + oz);
    const top = a.y + Math.max(1, Math.round(h * (0.5 + 0.6 * rnd())));
    if (seen.has(k)) continue;
    seen.add(k);
    const col = cols[Math.floor(rnd() * cols.length)];
    for (let y = a.y; y <= top; y++) {
      world.set(a.x + ox, y, a.z + oz, shade(col, 0.62 + 0.34 * heightFrac(y, o)), {
        kind: Kind.Foliage,
        t: reveal(a, 0.05 * i + 0.2 * ((y - a.y) / Math.max(1, top - a.y))),
        dur: FADE,
        sway: swayAt(y - a.y, o.totalH, 1),
      });
    }
  }
  if (hash3(a.x, 0, a.z, a.seed) < 0.2) {
    const fy = a.y + h;
    world.set(a.x, fy, a.z, shade(hash3(a.x, a.z, 0, a.seed) > 0.5 ? C.plumLite : C.plumDeep, 0.92), {
      kind: Kind.Foliage,
      t: reveal(a, 0.8),
      dur: FADE,
      sway: swayAt(h, o.totalH, 1),
    });
  }
}

// ----------------------------------------------------------------------- stone

/**
 * Boulder cluster with moss only on faces that look up. Knobs: `r` (2). Footprint
 * x−2r−3..x+2r+3, z−2r−3..z+2r+3, y..y+2r+3.
 */
export function mossyRock(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const r = knob(a, 'r', 2, 1, 4);
  const totalH = 2 * r + 2;
  const o: PaintOpts = { f: 0, baseY: a.y, totalH };
  const rock = [C.stone, C.slate, C.slate, C.stoneLite];

  const rocks: Cell[] = [];
  const boulders = 2 + Math.floor(rnd() * 2);
  for (let i = 0; i < boulders; i++) {
    const ang = (i / boulders) * Math.PI * 2 + rnd() * 1.2;
    const off = i === 0 ? 0 : Math.round(rnd() * (r + 1));
    const cx = a.x + Math.round(Math.cos(ang) * off);
    const cz = a.z + Math.round(Math.sin(ang) * off);
    const rx = r - (i === 0 ? 0 : 1) + 0.6 + hash3(cx, cz, i, a.seed) * 0.7;
    for (const c of blobCells(cx, a.y + Math.round(rx * 0.7), cz, rx, rx * 0.8, rx, 0.85, 0.72, a.seed + i * 37)) {
      rocks.push(c);
    }
  }
  const filled = new Set<string>();
  for (const c of rocks) filled.add(cellKey(c[0], c[1], c[2]));

  paint(world, a, rocks, { ...o, span: 0.34 }, (x, y, z) => {
    const hf = heightFrac(y, o);
    const under = !filled.has(cellKey(x, y - 1, z)) && !world.occupied(x, y - 1, z);
    const base = rock[Math.floor(hash3(x, y, z, a.seed) * rock.length)];
    return shade(base, (under ? 0.52 : 0.66) + 0.2 * hf + 0.14 * hash3(x, z, y, a.seed + 53));
  });

  // moss caps: only rows whose top face is open, patchy along it
  const caps: Cell[] = [];
  for (const [x, y, z] of rocks) {
    if (filled.has(cellKey(x, y + 1, z)) || world.occupied(x, y + 1, z)) continue;
    if (hash3(x, y, z, a.seed + 733) > 0.62) caps.push([x, y + 1, z]);
  }
  paint(world, a, caps, { ...o, f: 0.6, span: 0.3, sway: 0.18, kind: Kind.Foliage }, (x, y, z) =>
    shade(hash3(x, y, z, a.seed + 91) > 0.45 ? C.moss : C.mossDeep, 0.68 + 0.3 * hash3(x, z, y, a.seed + 7)),
  );
}

/**
 * Cliff-ish vertical stack of 2–4 jagged ink-grey blobs, undersides shaded hard, with a few
 * moss tufts caught on ledges. Knobs: `h` (12). Footprint x−6..x+6, z−6..z+6, y..y+h+3.
 */
export function rockStack(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const h = knob(a, 'h', 12, 5, 18);
  const o: PaintOpts = { f: 0, baseY: a.y, totalH: h };
  const rock = [C.slate, C.inkSoft, C.slate, mixHex(C.inkSoft, C.stone, 0.3)];

  const tiers = 2 + Math.floor(rnd() * 3); // 2..4
  const cells: Cell[] = [];
  const filled = new Set<string>();
  let cy = a.y;
  for (let i = 0; i < tiers; i++) {
    const frac = i / tiers;
    const rx = Math.min(3.4, Math.max(1, Math.round((3.2 - 1.8 * frac) * (0.7 + 0.5 * hash3(i, a.x, a.z, a.seed)))));
    const ry = Math.min(4, Math.max(1, Math.round((h / tiers) * (0.65 + 0.35 * hash3(i, a.z, a.x, a.seed + 3)))));
    const cx = a.x + Math.round((hash3(i, 5, 11, a.seed) - 0.5) * 2.4 * frac);
    const cz = a.z + Math.round((hash3(i, 13, 7, a.seed + 9) - 0.5) * 2.4 * frac);
    cy = a.y + Math.round(frac * h) + 1;
    for (const c of blobCells(cx, cy, cz, rx, ry, rx, 0.9, 0.85, a.seed + i * 53)) {
      if (!filled.has(cellKey(c[0], c[1], c[2]))) {
        filled.add(cellKey(c[0], c[1], c[2]));
        cells.push(c);
      }
    }
  }
  paint(world, a, cells, { ...o, span: 0.4 }, (x, y, z) => {
    const hf = heightFrac(y, o);
    const under = !filled.has(cellKey(x, y - 1, z));
    const base = rock[Math.floor(hash3(x, z, y, a.seed) * rock.length)];
    return shade(base, (under ? 0.44 : 0.64) + 0.24 * hf + 0.12 * hash3(x, y, z, a.seed + 29));
  });

  const ledges: Cell[] = [];
  for (const [x, y, z] of cells) {
    if (filled.has(cellKey(x, y + 1, z)) || world.occupied(x, y + 1, z)) continue;
    if (hash3(x, y, z, a.seed + 419) > 0.8) ledges.push([x, y + 1, z]);
  }
  paint(world, a, ledges, { ...o, f: 0.65, span: 0.3, sway: 0.3, kind: Kind.Foliage }, (x, y, z) =>
    shade(hash3(x, y, z, a.seed) > 0.5 ? C.mossDeep : C.moss, 0.66 + 0.3 * heightFrac(y, o)),
  );
}

/**
 * Lotus: flat one-cell pads floating on the water row `a.y`, each notched where the stem
 * would cut in, plus 1–3 raised blossoms. Knobs: `n` (5 pads), `h` (6, stem reach).
 * Footprint: radius max(3, h−2)+2 in x/z around (x,z), rows y..y+h+2.
 */
export function lotus(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const n = knob(a, 'n', 5, 1, 12);
  const reach = knob(a, 'h', 6, 2, 9);
  const o: PaintOpts = { f: 0, baseY: a.y, totalH: reach };

  const pads: Cell[] = [];
  const taken = new Set<string>();
  for (let i = 0; i < n * 4 && pads.length < n; i++) {
    const ang = rnd() * Math.PI * 2;
    const rad = rnd() * 3.4;
    const cx = a.x + Math.round(Math.cos(ang) * rad);
    const cz = a.z + Math.round(Math.sin(ang) * rad);
    const k = cellKey(cx, a.y, cz);
    if (taken.has(k)) continue;
    taken.add(k);
    pads.push([cx, a.y, cz]);
  }

  const flowers = 1 + Math.floor(rnd() * 3); // 1..3
  for (let i = 0; i < pads.length; i++) {
    const [cx, py, cz] = pads[i];
    const r = 1 + hash3(cx, cz, i, a.seed) * 0.8;
    const disc = blobCells(cx, py, cz, r, 0.34, r, 0.35, 0.5, a.seed + i * 19);
    const keep = disc.filter(([x, y, z]) => !(x === cx && z === cz && i % 2 === 0 && y === py));
    paint(world, a, keep.length ? keep : disc, { ...o, f: 0.1 * i, span: 0.3 }, (x, y, z) => {
      const rim = hash3(x, z, y, a.seed + 17) > 0.72 ? C.moss : C.mossDeep;
      return shade(rim, 0.62 + 0.3 * hash3(x, y, z, a.seed + 3));
    });
    // the notch: a punched cell on the near rim
    const nx = cx + (hash3(cx, 1, cz, a.seed) > 0.5 ? 1 : -1);
    world.erase(nx, py, cz);

    if (i >= pads.length - flowers) {
      const stemH = Math.max(1, Math.round(reach * (0.4 + 0.5 * hash3(cx, cz, 3, a.seed))));
      for (let s = 1; s <= stemH; s++) {
        world.set(cx, py + s, cz, shade(C.mossDeep, 0.7 + 0.25 * (s / stemH)), {
          t: reveal(a, 0.35 + 0.25 * (s / stemH)),
          dur: FADE,
          sway: swayAt(s, o.totalH, 0.6),
        });
      }
      const fy = py + stemH + 1;
      const petals = [C.plumLite, C.plum, shade(C.paper, 0.72)];
      const bloom: Cell[] = [[cx, fy, cz], [cx + 1, fy, cz], [cx - 1, fy, cz], [cx, fy, cz + 1], [cx, fy, cz - 1]];
      if (hash3(cx, cz, 9, a.seed) > 0.45) bloom.push([cx, fy + 1, cz]);
      paint(world, a, bloom, { ...o, f: 0.7, span: 0.28, sway: 0.8, kind: Kind.Foliage }, (x, y, z) =>
        shade(petals[Math.floor(hash3(x, y, z, a.seed + 71) * petals.length)], 0.74 + 0.26 * heightFrac(y, o)),
      );
      world.set(cx, fy, cz, shade(C.goldLite, 0.95), { kind: Kind.Glow, glow: 0.35, t: reveal(a, 0.85), dur: FADE });
    }
  }
}

// ---- flourosh grove

/** Compass headings, unit steps: 0 = +z, then quarter-turns through +x. Diagonals take both
 * axes so a run stays block-readable instead of turning into diagonal spaghetti. */
const HEADING: ReadonlyArray<readonly [number, number]> = [
  [0, 1],
  [1, 1],
  [1, 0],
  [1, -1],
  [0, -1],
  [-1, -1],
  [-1, 0],
  [-1, 1],
];

/** Spend-down handle for a builder's Kind.Glow cells; every cap draw checks it before writing. */
interface GlowBudget {
  left: number;
}

/** Cells a fan of radius `w` and `hgt` rows will spend, so a caller can refuse a clipped cap. */
function capCells(w: number, hgt: number): number {
  let n = 0;
  for (let dx = -w; dx <= w; dx++)
    for (let dz = -w; dz <= w; dz++) if (dx * dx + dz * dz <= w * w + w * 0.6) n++;
  return n * Math.max(1, hgt);
}

/**
 * One fan-shaped cap: a round plate `w` cells in radius, `hgt` rows thick, centred on the
 * column above `x,z` and rooted by a single pale stipe at `sy`. Glow tracks cap volume, so a
 * three-cell button reads dim and a wide open cap reads hot. One cell in eight is rose.
 */
function shroomFan(
  world: VoxelWorld,
  a: BuilderArgs,
  x: number,
  y: number,
  z: number,
  w: number,
  hgt: number,
  sy: number,
  f: number,
  bud: GlowBudget,
): void {
  const glow = clamp(0.45 + 0.04 * (2 * w + 1) * hgt, 0.45, 1);
  if (sy >= a.y && sy < y && bud.left > 0 && !world.occupied(x, sy, z)) {
    bud.left--;
    world.set(x, sy, z, shade(C.paper, 0.88), {
      kind: Kind.Glow,
      glow: 0.45,
      t: reveal(a, f - 0.04),
      dur: FADE,
    });
  }
  for (let dy = 0; dy < hgt; dy++) {
    const cy = y + dy;
    if (cy < a.y) continue;
    for (let dx = -w; dx <= w; dx++) {
      for (let dz = -w; dz <= w; dz++) {
        if (dx * dx + dz * dz > w * w + w * 0.6) continue;
        if (bud.left <= 0) return;
        const mint = [C.flourosh, C.flouroshLite, C.flouroshDeep];
        const cap = hash3(x + dx, cy, z + dz, a.seed + 401) > 0.875;
        const base = cap ? C.flouroshRose : mint[Math.floor(hash3(x + dx, cy, z + dz, a.seed + 53) * mint.length)];
        bud.left--;
        world.set(x + dx, cy, z + dz, shade(base, 0.88 + 0.18 * hash3(x + dx, cy, z + dz, a.seed + 7)), {
          kind: Kind.Glow,
          glow,
          t: reveal(a, f),
          dur: FADE,
        });
      }
    }
  }
}

/**
 * Dead tree lying on the ground: round cross-sections stamped one cell at a time along an
 * eight-way heading, the far end snapped open to pale heartwood, a raised root plate at the
 * near end, 2–3 broken stubs. Bark is ironwood / bark with hash banding; moss collars the
 * ground contact; flourosh shelves the upper side of the log and one flank, never as a cloud.
 * Knobs: `len` (5..16, 10) axis cells, `r` (1..3, 2) trunk radius, `dir` (0..7, 0) heading,
 * `fur` (0..100, 70) cap density. Footprint `len+r+2` cells along the heading, 2r+5 wide at
 * the plate, y..y+2r+5. Glow ceiling 22 cells.
 */
export function fallenLog(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const len = knob(a, 'len', 10, 5, 16);
  const r = knob(a, 'r', 2, 1, 3);
  const dir = knob(a, 'dir', 0, 0, 7);
  const fur = knob(a, 'fur', 70, 0, 100) / 100;
  const o: PaintOpts = { f: 0, baseY: a.y, totalH: 2 * r + 5 };
  const bud: GlowBudget = { left: 22 };
  const [ux, uz] = HEADING[dir];
  const [qx, qz] = HEADING[(dir + 2) % 8];
  const cy = a.y + r; // log axis, so the underside rests on a.y
  const axis = (s: number): [number, number] => [a.x + ux * s, a.z + uz * s];

  // trunk: one round disc per cell of the heading; the k=0 column keeps the run connected
  const trunk: Cell[] = [];
  for (let s = 0; s < len; s++) {
    const [bx, bz] = axis(s);
    for (let k = -r; k <= r; k++)
      for (let dy = -r; dy <= r; dy++) {
        if (dy * dy + k * k > r * r + 0.5) continue;
        trunk.push([bx + qx * k, cy + dy, bz + qz * k]);
      }
  }
  paint(world, a, trunk, { ...o, span: 0.1 }, (x, y, z) => {
    const band = hash3((x - a.x) * ux + (z - a.z) * uz, 0, 0, a.seed + 29);
    const ring = clamp((y - a.y) / (2 * r), 0, 1);
    return shade(hash3(x, y, z, a.seed + 13) > 0.52 ? C.ironwood : C.bark, 0.5 + 0.28 * ring + 0.22 * band);
  });

  // snapped end: last disc exposed, a couple of splinters past it
  const [hx, hz] = axis(len - 1);
  const heart: Cell[] = [];
  for (let k = -r; k <= r; k++)
    for (let dy = -r; dy <= r; dy++) {
      if (dy * dy + k * k <= r * r + 0.5) heart.push([hx + qx * k, cy + dy, hz + qz * k]);
    }
  heart.push([hx + ux, cy, hz + uz]);
  if (r > 1 && hash3(hx, 5, hz, a.seed + 61) > 0.35) heart.push([hx + ux + qx, cy + 1, hz + uz + qz]);
  paint(
    world,
    a,
    heart,
    { ...o, f: 0.2, span: 0.16 },
    (x, y, z) =>
      shade(
        mixHex(C.barkLite, C.paper, clamp(0.42 + 0.5 * (1 - Math.abs(y - cy) / r), 0, 1)),
        0.82 + 0.22 * hash3(x, y, z, a.seed + 3),
      ),
  );

  // raised root plate: the near end sits on a flared collar of root-bound wood
  const R = r + 2;
  const plate: Cell[] = [];
  for (let dz = -R; dz <= R; dz++)
    for (let dx = -R; dx <= R; dx++) {
      const d = Math.sqrt(dx * dx + dz * dz);
      if (d <= R + 0.3) plate.push([a.x + dx, a.y, a.z + dz]);
      if (d <= R - 1.4 + hash3(a.x + dx, 1, a.z + dz, a.seed + 17)) plate.push([a.x + dx, a.y + 1, a.z + dz]);
    }
  paint(world, a, plate, { ...o, span: 0.05 }, (x, y, z) => {
    const g = hash3(x, y, z, a.seed + 5);
    return shade(mixHex(C.ironwood, C.soilDark, 0.3 + 0.35 * g), 0.72 + 0.3 * (y - a.y) + 0.18 * g);
  });

  // broken stubs: short tapered runs off the top of two or three discs, snapped to one cell
  const stubs = 2 + (hash3(a.x, len, a.z, a.seed + 73) > 0.45 ? 1 : 0);
  for (let i = 0; i < stubs; i++) {
    const [bx, bz] = axis(1 + Math.floor(((i + 1) / (stubs + 1)) * (len - 2) + hash3(a.x, i, a.z, a.seed + 41)));
    const side = hash3(bx, 7, bz, a.seed + 11) > 0.5 ? 1 : -1;
    const reach = 2 + Math.floor(hash3(bx, 3, bz, a.seed + 19) * 3); // 2..4
    const stub: Cell[] = [];
    for (let t = 0; t <= reach; t++)
      for (let b = 0; b <= (t <= 1 ? 1 : 0); b++) stub.push([bx + qx * side * t, cy + b, bz + qz * side * t]);
    paint(world, a, stub, { ...o, f: 0.14, span: 0.14 }, (x, y, z) =>
      Math.max(Math.abs(x - bx), Math.abs(z - bz)) >= reach
        ? mixHex(C.barkLite, C.paper, 0.55)
        : shade(C.ironwood, 0.66 + 0.3 * hash3(x, y, z, a.seed + 23)),
    );
  }

  // moss collar where the bark meets the ground
  const collar: Cell[] = [];
  for (let s = 0; s < Math.max(2, Math.round(len * 0.55)); s++) {
    const [bx, bz] = axis(s);
    for (let k = -r - 1; k <= r + 1; k++) {
      if (Math.abs(k) < r - 0.4) continue;
      collar.push([bx + qx * k, a.y, bz + qz * k]);
    }
  }
  paint(world, a, collar, { ...o, f: 0.45, span: 0.16, sway: 0.1, kind: Kind.Foliage }, (x, y, z) =>
    leafColor([C.moss, C.mossDeep], x, y, z, a.seed, 0.25),
  );

  // fungus last: shelves on the crown of the log, then a row down one flank
  const caps = 2 + Math.round((2 + len * 0.35) * (0.3 + 0.7 * fur));
  for (let i = 0; i < caps; i++) {
    const s = 1 + Math.floor(rnd() * Math.max(1, len - 2));
    const [bx, bz] = axis(s);
    const w = r >= 2 && rnd() > 0.6 ? 2 : 1;
    const hgt = rnd() > 0.72 ? 2 : 1;
    if (bud.left < capCells(w, hgt)) break;
    shroomFan(world, a, bx, cy + r + 1, bz, w, hgt, cy + r + 1, 0.7 + 0.16 * (s / len), bud);
  }
  const flank = hash3(a.x, cy, a.z, a.seed + 83) > 0.5 ? 1 : -1;
  for (let i = 0; i < 3 && bud.left >= capCells(1, 1); i++) {
    const s = 2 + Math.floor(rnd() * Math.max(1, len - 3));
    const [bx, bz] = axis(s);
    const fy = cy + (i === 1 ? 1 : 0);
    shroomFan(world, a, bx + qx * flank * (r + 1), fy, bz + qz * flank * (r + 1), 1, 1, fy, 0.84 + 0.08 * i, bud);
  }
}

/**
 * Standing dead stump, hollowed out: bark wall, jagged broken rim, a cup whose floor and inner
 * faces are authored near-white so they read in the dark, then flourosh lining the inside of
 * the cup and a row running down one flank of the bark. Zero foliage.
 * Knobs: `h` (3..8, 5) rows of timber, `r` (1..3, 2) trunk radius, `fur` (0..100, 80) cap
 * density. Footprint x−r−2..x+r+2, z−r−2..z+r+2, y..y+h+2. Glow ceiling 16 cells.
 */
export function flouroshStump(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const h = knob(a, 'h', 5, 3, 8);
  const r = knob(a, 'r', 2, 1, 3);
  const fur = knob(a, 'fur', 80, 0, 100) / 100;
  const o: PaintOpts = { f: 0, baseY: a.y, totalH: h + 2 };
  const bud: GlowBudget = { left: 16 };
  const top = a.y + h - 1;
  const floor = a.y + Math.max(1, Math.round(h * 0.4)); // plug of solid wood left under the cup
  const ri = Math.max(0, r - 1); // inner radius of the chamber

  // wall, hollowed above the floor and notched where the rim broke away
  const wall: Cell[] = [];
  for (let y = a.y; y <= top; y++)
    for (let dz = -r; dz <= r; dz++)
      for (let dx = -r; dx <= r; dx++) {
        const d2 = dx * dx + dz * dz;
        if (d2 > r * r + 0.6) continue;
        if (y > floor && d2 <= ri * ri + 0.3) continue;
        if (y === top && hash3(a.x + dx, 2, a.z + dz, a.seed + 67) < 0.2) continue;
        wall.push([a.x + dx, y, a.z + dz]);
      }
  paint(world, a, wall, { ...o, span: 0.2 }, (x, y, z) =>
    shade(
      hash3(x, y, z, a.seed + 13) > 0.5 ? C.ironwood : C.bark,
      0.5 + 0.3 * clamp((y - a.y) / Math.max(1, h - 1), 0, 1) + 0.22 * hash3(x, z, y, a.seed + 29),
    ),
  );

  // chamber floor and rim read pale against the charred bark
  const hearth: Cell[] = [];
  const rim: Cell[] = [];
  for (let dz = -r; dz <= r; dz++)
    for (let dx = -r; dx <= r; dx++) {
      const d2 = dx * dx + dz * dz;
      if (d2 <= ri * ri + 0.3) hearth.push([a.x + dx, floor, a.z + dz]);
      if (d2 > ri * ri + 0.3 && d2 <= r * r + 0.6 && hash3(a.x + dx, 2, a.z + dz, a.seed + 67) >= 0.2)
        rim.push([a.x + dx, top, a.z + dz]);
    }
  paint(world, a, hearth, { ...o, f: 0.2, span: 0.14 }, (x, y, z) =>
    shade(mixHex(C.paper, C.flouroshLite, 0.3 + 0.4 * hash3(x, y, z, a.seed + 47)), 0.9 + 0.14 * hash3(x, z, y, a.seed)),
  );
  paint(world, a, rim, { ...o, f: 0.28, span: 0.14 }, (x, y, z) =>
    shade(mixHex(C.barkLite, C.paper, 0.25 * hash3(x, y, z, a.seed + 11)), 0.84 + 0.24 * hash3(x, y, z, a.seed + 3)),
  );

  // moss at the ground contact only
  const collar: Cell[] = [];
  for (let dz = -r - 1; dz <= r + 1; dz++)
    for (let dx = -r - 1; dx <= r + 1; dx++) {
      const d2 = dx * dx + dz * dz;
      if (d2 <= (r + 1.2) * (r + 1.2) && d2 > r * r + 0.6 && hash3(a.x + dx, 0, a.z + dz, a.seed + 91) > 0.45)
        collar.push([a.x + dx, a.y, a.z + dz]);
    }
  paint(world, a, collar, { ...o, f: 0.42, span: 0.14, sway: 0.1, kind: Kind.Foliage }, (x, y, z) =>
    leafColor([C.moss, C.mossDeep], x, y, z, a.seed, 0.25),
  );

  // fungus last: one open cap on the cup floor, buttons ringing it, then a row down the bark
  const side = HEADING[Math.floor(rnd() * 8)];
  const open = ri >= 2 ? 2 : 1;
  if (bud.left >= capCells(open, 1)) shroomFan(world, a, a.x, floor + 1, a.z, open, 1, floor + 1, 0.62, bud);
  const ring = ri > 0 ? 1 + (fur > 0.5 ? 1 : 0) : 1;
  const ry = ri > 0 ? floor + 1 : floor + 2; // with a 1-wide shaft the button stacks on the cap
  for (let i = 0; i < ring && bud.left >= capCells(0, 1); i++) {
    const ang = ((i + 1) / (ring + 1)) * Math.PI * 2 + rnd();
    shroomFan(
      world,
      a,
      a.x + Math.round(Math.cos(ang) * ri),
      ry,
      a.z + Math.round(Math.sin(ang) * ri),
      0,
      1,
      ry,
      0.68 + 0.1 * i,
      bud,
    );
  }
  for (let i = 0; i < 3 && fur > 0.4 && bud.left >= capCells(0, 1); i++) {
    const y = top - 1 - i;
    if (y <= floor) continue;
    shroomFan(world, a, a.x + side[0] * (r + 1), y, a.z + side[1] * (r + 1), 0, 1, y, 0.8 + 0.07 * i, bud);
  }
}

/**
 * Grove floor: no timber. A moss pad with sparse spore dust, two or three fern fronds that
 * arc and droop, then clusters of button caps rooted in the pad — the caps hold still, only
 * the fronds sway. Clusters stop the moment the glow budget is spent, so `n` reads as a
 * density ask, not a promise.
 * Knobs: `r` (2..4, 3) pad radius, `n` (5..18, 11) cap clusters. Footprint
 * x−r−1..x+r+1, z−r−1..z+r+1, y..y+5. Glow ceiling 12 cells.
 */
export function flouroshPatch(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const r = knob(a, 'r', 3, 2, 4);
  const n = knob(a, 'n', 11, 5, 18);
  const o: PaintOpts = { f: 0, baseY: a.y, totalH: 5 };
  const bud: GlowBudget = { left: 12 };

  // pad: moss over litter, holed by hash so it reads as ground cover rather than a disc
  const pad: Cell[] = [];
  for (let dz = -r - 1; dz <= r + 1; dz++)
    for (let dx = -r - 1; dx <= r + 1; dx++) {
      const d2 = dx * dx + dz * dz;
      if (d2 > (r + 0.6) * (r + 0.6)) continue;
      if (d2 > (r - 1) * (r - 1) && hash3(a.x + dx, 0, a.z + dz, a.seed + 17) < 0.34) continue;
      pad.push([a.x + dx, a.y, a.z + dz]);
    }
  paint(world, a, pad, { ...o, span: 0.1, sway: 0.1, kind: Kind.Foliage }, (x, y, z) =>
    leafColor([C.moss, C.mossDeep, C.pine], x, y, z, a.seed, 0.4),
  );

  // fern fronds: one cell wide, rising a third of their length then falling back over
  const fronds = r >= 3 ? 3 : 2;
  for (let i = 0; i < fronds; i++) {
    const ang = (i / fronds) * Math.PI * 2 + rnd() * 1.1;
    const ox = Math.round(Math.cos(ang) * (r - 1));
    const oz = Math.round(Math.sin(ang) * (r - 1));
    const vx = Math.round(Math.cos(ang));
    const vz = Math.round(Math.sin(ang));
    const L = 3 + Math.floor(rnd() * 3); // 3..5
    const stem: Cell[] = [];
    for (let t = 0; t <= L; t++) {
      const rise = t <= L - 1 ? t : L - 2;
      const px = a.x + ox + Math.round(vx * t * 0.6);
      const pz = a.z + oz + Math.round(vz * t * 0.6);
      stem.push([px, a.y + rise, pz]);
      if (t > 0 && hash3(px, rise, pz, a.seed + 37) > 0.35) stem.push([px + vz, a.y + rise, pz - vx]);
    }
    paint(world, a, stem, { ...o, f: 0.2, span: 0.22, sway: 0.62, kind: Kind.Foliage }, (x, y, z) =>
      leafColor([C.mossDeep, C.moss, C.leaf], x, y, z, a.seed + 5, heightFrac(y, o)),
    );
  }

  // caps last, rooted in the pad: tight clusters of buttons, a few open ones at the rim
  for (let i = 0; i < n && bud.left > 0; i++) {
    const ang = rnd() * Math.PI * 2;
    const rad = Math.round(rnd() * r);
    const cx = a.x + Math.round(Math.cos(ang) * rad);
    const cz = a.z + Math.round(Math.sin(ang) * rad);
    const group = 1 + (hash3(cx, cz, i, a.seed + 71) > 0.55 ? 1 : 0);
    for (let g = 0; g < group && bud.left > 0; g++) {
      const w = rad >= r - 1 && g === 0 && r >= 3 && rnd() > 0.55 ? 1 : 0;
      if (bud.left < capCells(w, 1)) break;
      shroomFan(world, a, cx + (g ? 1 : 0), a.y + w, cz, w, 1, a.y + w, 0.66 + 0.2 * (i / n), bud);
    }
  }
}

/**
 * Grove silhouette: tall standing dead tree. Root flare, a trunk that drifts with `lean` and
 * tapers to one column near the fork, 2–3 bare limbs twisting out and away and tapering to a
 * single cell, one broken snag partway up, and a three-row scar carved out of the +z face so
 * the hollow reads as a cavity with fungus shelves growing out of it. Zero foliage.
 * Knobs: `h` (12..24, 17) crown height above the base, `lean` (0..2, 1) drift toward +x.
 * Footprint x−9..x+9, z−9..z+9, y..y+h+2. Glow ceiling 10 cells.
 */
export function deadTree(world: VoxelWorld, a: BuilderArgs): void {
  const rnd = dice(a);
  const h = knob(a, 'h', 17, 12, 24);
  const lean = knob(a, 'lean', 1, 0, 2);
  const o: PaintOpts = { f: 0, baseY: a.y, totalH: h + 2 };
  const bud: GlowBudget = { left: 10 };
  const wood = [C.ironwood, C.bark, C.woodDark];
  const riseRows = Math.max(5, Math.round(h * 0.55));
  const forkY = a.y + riseRows;
  const drift = (y: number): number => Math.round(lean * ((y - a.y) / riseRows));

  const flare: Cell[] = [];
  for (let dz = -3; dz <= 3; dz++)
    for (let dx = -3; dx <= 3; dx++) {
      const d2 = dx * dx + dz * dz;
      if (d2 > 9) continue;
      if (d2 > 4 && hash3(a.x + dx, 0, a.z + dz, a.seed + 5) < 0.3) continue;
      flare.push([a.x + dx, a.y, a.z + dz]);
    }
  paint(world, a, flare, { ...o, span: 0.06 }, (x, y, z) =>
    shade(mixHex(C.ironwood, C.soilDark, 0.3 + 0.35 * hash3(x, y, z, a.seed + 9)), 0.64 + 0.22 * hash3(x, z, y, a.seed)),
  );

  const scarY = a.y + Math.max(2, Math.round(h * 0.2));
  const trunk: Cell[] = [];
  for (let y = a.y; y <= forkY; y++) {
    const t = (y - a.y) / riseRows;
    const ox = drift(y);
    const g = t > 0.8 ? 1 : 2;
    for (let dz = -g; dz <= g; dz++)
      for (let dx = -g; dx <= g; dx++) {
        if (dx * dx + dz * dz > g * g + 0.5) continue;
        if (g > 1 && y >= scarY && y <= scarY + 2 && dz >= 0 && Math.abs(dx) <= 1) continue;
        trunk.push([a.x + ox + dx, y, a.z + dz]);
      }
  }
  paint(world, a, trunk, { ...o, span: 0.3 }, (x, y, z) =>
    shade(
      wood[Math.min(wood.length - 1, Math.floor(hash3(x, y, z, a.seed + 13) * wood.length))],
      0.5 + 0.3 * heightFrac(y, o) + 0.2 * hash3(x, z, y, a.seed + 29),
    ),
  );

  // cavity floor and side walls, authored near-white so the hollow reads
  const pit: Cell[] = [];
  for (let dz = 0; dz <= 2; dz++)
    for (let dx = -1; dx <= 1; dx++) {
      if (dx * dx + dz * dz <= 4.5) pit.push([a.x + drift(scarY) + dx, scarY - 1, a.z + dz]);
    }
  for (let y = scarY; y <= scarY + 2; y++) pit.push([a.x + drift(y) + 2, y, a.z], [a.x + drift(y) - 2, y, a.z]);
  paint(world, a, pit, { ...o, f: 0.24, span: 0.14 }, (x, y, z) =>
    shade(mixHex(C.paper, C.flouroshLite, 0.35 + 0.35 * hash3(x, y, z, a.seed + 47)), 0.9 + 0.18 * hash3(x, z, y, a.seed)),
  );

  // bare limbs: the fork twists out and tapers to one cell, each arm snapping to a twig
  const rem = Math.max(3, h - riseRows);
  const arms = 2 + (hash3(a.x, forkY, a.z, a.seed + 71) > 0.45 ? 1 : 0);
  for (let i = 0; i < arms; i++) {
    const ang = (i / arms) * Math.PI * 2 + rnd() * 0.8;
    const spread = 3 + Math.round(lean) + Math.round(rnd() * 2);
    const tip = limb(
      world,
      a,
      a.x + lean,
      forkY,
      a.z,
      Math.round(Math.cos(ang) * spread),
      rem + 1,
      Math.round(Math.sin(ang) * spread),
      rem + 1,
      2,
      -0.8 - rnd(),
      { ...o, f: 0.34 },
      (x, y, z, t) => shade(wood[Math.min(2, Math.floor(hash3(x, y, z, a.seed + 19) * 3))], 0.56 + 0.36 * t),
    );
    limb(
      world,
      a,
      tip[0],
      tip[1],
      tip[2],
      Math.round(Math.cos(ang) * 2),
      1,
      Math.round(Math.sin(ang) * 2),
      2 + Math.floor(rnd() * 2),
      1,
      -1.1,
      { ...o, f: 0.56 },
      (x, y, z, t) => shade(C.barkLite, 0.5 + 0.34 * t + 0.18 * hash3(x, y, z, a.seed + 31)),
    );
  }

  // one broken arm partway up the trunk
  const sang = rnd() * Math.PI * 2;
  const snagY = a.y + Math.round(riseRows * 0.62);
  limb(
    world,
    a,
    a.x + drift(snagY) + Math.round(Math.cos(sang)),
    snagY,
    a.z + Math.round(Math.sin(sang)),
    Math.round(Math.cos(sang) * 3),
    1,
    Math.round(Math.sin(sang) * 3),
    3,
    1,
    -1.4,
    { ...o, f: 0.26 },
    (x, y, z, t) => shade(C.bark, 0.48 + 0.34 * t + 0.2 * hash3(x, y, z, a.seed + 43)),
  );

  // fungus last: two shelves growing out of the hollow, the upper one the brightest
  for (let i = 0; i < 2 && bud.left >= capCells(1, 1); i++)
    shroomFan(world, a, a.x + drift(scarY), scarY + i, a.z + 1, 1, 1, scarY + i, 0.6 + 0.14 * i, bud);
}
