import { Kind, VoxelWorld } from '../core/VoxelWorld';
import { C, hash3, mixHex, rng, shade } from '../core/palette';
import { BuilderArgs, FADE, opt, reveal } from './types';

/**
 * Hall furniture and treasure for GILTTHRONE 金殿 — everything that stands inside the ground
 * storey of the padoga.
 *
 * The hall is lit only by what burns inside it, so every piece here is authored against baked
 * lighting: everything that has to read in the dark interior is authored near-white (`C.goldPale`,
 * `C.goldHot`), every downward- or inward-facing surface is authored dark (`C.goldDeep`, `C.bronze`,
 * `C.lacquer`). Glow cells cost one sprite each downstream, so each builder that emits light keeps
 * a counter and hard-stops at the cap named in its own doc comment.
 */

// ------------------------------------------------------------------ helpers

/** Integer knob, clamped to the range documented on the builder. */
function int(a: BuilderArgs, key: string, dflt: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, Math.round(opt(a, key, dflt))));
}

/** Per-cell gilding so a run of identical gold never reads as one flat plate. */
function giltTint(hex: number, x: number, y: number, z: number, amount = 0.08): number {
  return shade(hex, 1 + (hash3(x, y, z, 33) - 0.5) * 2 * amount);
}

/**
 * Axis step for the two axis-picking builders: `axis` 0 runs along z, 1 along x; `sgn` flips it.
 * Returns the world cell for a forward offset `u` and a lateral offset `v`.
 */
function place(axis: number, sgn: number, a: BuilderArgs, u: number, v: number): [number, number] {
  const uu = Math.round(u);
  const vv = Math.round(v);
  return axis === 1 ? [a.x + sgn * uu, a.z + vv] : [a.x + vv, a.z + sgn * uu];
}

// ------------------------------------------------------------------ gilded column

/**
 * Fluted gilded column standing on row `a.y`: a stepped plinth (two courses, the lower one
 * chamfered), a shaft whose vertical flutes are a per-cell rib pattern keyed to the angle around
 * the axis, a capital that enlarges over two rows, and a square abacus slab on top.
 *
 * Knobs: `h` shaft rows 7..18 (default 12), `r` shaft radius 1..3 (default 2), `flutes` rib
 * count 4..8 (default 6). Footprint `(2r + 5)²` cells centred on `a.x/a.z`, height `h + 5` rows
 * above `a.y`. Glow budget: **2 cells** — one hot cell in the capital, one on the abacus — counted
 * in code, never written past the cap.
 */
export function goldColumn(world: VoxelWorld, a: BuilderArgs): void {
  const h = int(a, 'h', 12, 7, 18);
  const r = int(a, 'r', 2, 1, 3);
  const flutes = int(a, 'flutes', 6, 4, 8);
  let glow = 0;
  const lit = (x: number, y: number, z: number, hex: number, power: number, f: number): void => {
    if (glow >= 2) return;
    glow += 1;
    world.set(x, y, z, hex, { kind: Kind.Glow, glow: power, t: reveal(a, f), dur: FADE });
  };

  // --- plinth: two courses, the lower one a full cell wider than the upper
  for (let dy = 0; dy < 2; dy++) {
    const half = r + 2 - dy;
    const stone = dy === 0 ? shade(C.marble, 1.25) : C.marbleLite;
    for (let dx = -half; dx <= half; dx++) {
      for (let dz = -half; dz <= half; dz++) {
        const corner = Math.abs(dx) === half && Math.abs(dz) === half;
        world.set(a.x + dx, a.y + dy, a.z + dz, giltTint(corner ? C.goldDeep : stone, a.x + dx, a.y + dy, a.z + dz, 0.06), {
          t: reveal(a, 0.02 + 0.06 * dy),
          dur: FADE,
        });
      }
    }
  }

  // --- shaft: one disc per row, ribs read as flutes, top-lit rows brighter
  const y0 = a.y + 2;
  for (let dy = 0; dy < h; dy++) {
    const y = y0 + dy;
    const k = 0.74 + 0.3 * (dy / Math.max(1, h - 1));
    for (let dx = -r; dx <= r; dx++) {
      for (let dz = -r; dz <= r; dz++) {
        if (dx * dx + dz * dz > r * r + r * 0.35) continue;
        const angle = Math.atan2(dz, dx);
        const rib = Math.floor(((angle / (Math.PI * 2) + 0.5) * flutes + 16 * flutes) % flutes);
        const flute = (rib & 1) === 0;
        const hex = flute ? shade(mixHex(C.gold, C.goldLite, 0.45), k) : shade(C.goldDeep, k + 0.16);
        world.set(a.x + dx, y, a.z + dz, giltTint(hex, a.x + dx, y, a.z + dz, 0.07), {
          t: reveal(a, 0.12 + 0.44 * (dy / Math.max(1, h - 1))),
          dur: FADE,
        });
      }
    }
  }

  // --- capital: two enlarging crowns, then the abacus slab
  const y1 = y0 + h;
  for (let dy = 0; dy < 2; dy++) {
    const y = y1 + dy;
    const rad = r + 0.6 + dy * 0.9;
    for (let dx = -r - 2; dx <= r + 2; dx++) {
      for (let dz = -r - 2; dz <= r + 2; dz++) {
        if (dx * dx + dz * dz > rad * rad) continue;
        const hex = shade(mixHex(C.goldLite, C.goldPale, 0.25 + 0.25 * dy), 0.9 + 0.12 * dy);
        world.set(a.x + dx, y, a.z + dz, giltTint(hex, a.x + dx, y, a.z + dz), {
          t: reveal(a, 0.62 + 0.12 * dy),
          dur: FADE,
        });
      }
    }
    if (dy === 1) lit(a.x, y, a.z, mixHex(C.goldHot, C.goldPale, 0.5), 0.4, 0.86);
  }
  const half = r + 2;
  for (let dx = -half; dx <= half; dx++) {
    for (let dz = -half; dz <= half; dz++) {
      const edge = Math.abs(dx) === half || Math.abs(dz) === half;
      world.set(a.x + dx, y1 + 2, a.z + dz, edge ? shade(C.bronze, 0.92) : giltTint(C.goldPale, a.x + dx, y1 + 2, a.z + dz, 0.05), {
        t: reveal(a, 0.9),
        dur: FADE,
      });
    }
  }
  lit(a.x, y1 + 2, a.z, C.goldHot, 0.5, 0.96);
}

// ------------------------------------------------------------------ treasure pile

/**
 * Heap of coin and plate standing on row `a.y`: stacked shrinking discs in graded gold (bronze-gold at
 * the skirt, near-white at the crown) form the mound; `chests` ironwood chests with bronze bands and a
 * gilt lid line are drawn afterwards so they read as half-buried; single coin cells spill from the skirt
 * outward across the floor; one tall standing urn — foot, bellied body, neck, flared rim — stands off
 * the back of the heap.
 *
 * Knobs: `r` mound radius 2..6 (default 4), `h` mound rows 2..6 (default 4), `chests` 1..4 (default 2).
 * Footprint `2r + 9` cells across centred on `a.x/a.z`, `h + 5` rows tall. The mound is disc-built and
 * the chests are box-built so the silhouette stays a mass — no single-cell noise on the outline. Glow
 * budget: **0 cells**; the pile is lit by the braziers, it does not light itself.
 */
export function treasurePile(world: VoxelWorld, a: BuilderArgs): void {
  const r = int(a, 'r', 4, 2, 6);
  const h = int(a, 'h', 4, 2, 6);
  const chests = int(a, 'chests', 2, 1, 4);
  const d = rng(a.seed * 90217);

  // --- mound: shrinking discs graded dark at the skirt, pale at the crown
  for (let dy = 0; dy < h; dy++) {
    const k = dy / Math.max(1, h - 1);
    const rad = r * (1 - 0.72 * k * k);
    const hex = dy === h - 1 ? C.goldPale : mixHex(mixHex(C.goldDeep, C.gold, k), C.goldLite, k * 0.55);
    for (let dx = -r; dx <= r; dx++) {
      for (let dz = -r; dz <= r; dz++) {
        if (dx * dx + dz * dz > rad * rad) continue;
        world.set(a.x + dx, a.y + dy, a.z + dz, giltTint(hex, a.x + dx, a.y + dy, a.z + dz, 0.1), {
          t: reveal(a, 0.04 + 0.5 * k),
          dur: FADE,
        });
      }
    }
  }
  // crown dish so the top reads as a lit mass rather than a fringe
  for (let dx = -1; dx <= 1; dx++) {
    for (let dz = -1; dz <= 1; dz++) {
      world.set(a.x + dx, a.y + h, a.z + dz, giltTint(C.goldPale, a.x + dx, a.y + h, a.z + dz, 0.05), {
        t: reveal(a, 0.58),
        dur: FADE,
      });
    }
  }

  // --- chests, drawn over the mound so their lower course disappears into it
  for (let i = 0; i < chests; i++) {
    const along = d() < 0.5 ? 1 : -1;
    const axis = i % 2;
    const len = 3 + (i % 2);
    const bx = a.x + Math.round((r + 1) * (axis === 1 ? along : 0.7 * along));
    const bz = a.z + Math.round((r + 1) * (axis === 1 ? 0.7 * along : along));
    const f = 0.5 + 0.1 * i;
    for (let dy = 0; dy < 3; dy++) {
      for (let u = 0; u < len; u++) {
        for (let v = 0; v < 2; v++) {
          const wx = axis === 1 ? bx + u : bx + v;
          const wz = axis === 1 ? bz + v : bz + u;
          const banded = dy === 1 || u === 0 || u === len - 1;
          world.set(wx, a.y + dy, wz, giltTint(banded ? C.bronze : C.ironwood, wx, a.y + dy, wz, 0.09), {
            t: reveal(a, f),
            dur: FADE,
          });
        }
      }
    }
    for (let u = 0; u < len; u++) {
      const wx = axis === 1 ? bx + u : bx;
      const wz = axis === 1 ? bz : bz + u;
      world.set(wx, a.y + 3, wz, C.gilt, { t: reveal(a, f + 0.08), dur: FADE });
    }
  }

  // --- coins spilling onto the floor: short radial runs of single cells
  const spills = 3 + chests;
  for (let i = 0; i < spills; i++) {
    const ang = (i / spills) * Math.PI * 2 + d() * 0.5;
    const ux = Math.round(Math.cos(ang));
    const uz = Math.round(Math.sin(ang));
    const run = 2 + Math.floor(d() * 3);
    for (let s = 0; s < run; s++) {
      const x = a.x + ux * (r + 1 + s);
      const z = a.z + uz * (r + 1 + s);
      if (world.occupied(x, a.y, z)) continue;
      const hex = s === 0 ? C.goldLite : (x + z) % 2 === 0 ? C.gold : C.gilt;
      world.set(x, a.y, z, hex, { t: reveal(a, 0.64 + 0.04 * s), dur: FADE });
    }
  }

  // --- standing urn off the back: foot, bellied body, flared rim with a dark interior
  const cx = a.x - r - 2;
  const cz = a.z;
  const body = shade(C.bronze, 1.12);
  for (let dx = -1; dx <= 1; dx++) {
    for (let dz = -1; dz <= 1; dz++) {
      world.set(cx + dx, a.y, cz + dz, shade(C.goldDeep, 1.15), { t: reveal(a, 0.7), dur: FADE });
    }
  }
  for (let dy = 1; dy <= 3; dy++) {
    const rad = dy === 2 ? 1.9 : 1.4;
    for (let dx = -2; dx <= 2; dx++) {
      for (let dz = -2; dz <= 2; dz++) {
        if (dx * dx + dz * dz > rad * rad) continue;
        world.set(cx + dx, a.y + dy, cz + dz, giltTint(dy === 3 ? mixHex(body, C.goldLite, 0.4) : body, cx + dx, a.y + dy, cz + dz, 0.08), {
          t: reveal(a, 0.72 + 0.05 * dy),
          dur: FADE,
        });
      }
    }
  }
  for (let dx = -2; dx <= 2; dx++) {
    for (let dz = -2; dz <= 2; dz++) {
      if (dx * dx + dz * dz > 6.5) continue;
      world.set(cx + dx, a.y + 4, cz + dz, shade(C.goldHot, 0.95), { t: reveal(a, 0.92), dur: FADE });
    }
  }
  world.set(cx, a.y + 4, cz, C.lacquer, { t: reveal(a, 0.96), dur: FADE });
}

// ------------------------------------------------------------------ brazier

/**
 * Gilded tripod fire bowl on a stem, standing on row `a.y`: three legs splayed out to their feet and
 * gathered at the stem, a two-row bowl whose outer course is dark bronze and whose top course is bright
 * gilding, a ring of coals across the mouth, and a thin flame column over it. Extra height past the
 * minimum is spent on the legs first, then on the flame.
 *
 * Knobs: `h` total rows 3..8 (default 5). Footprint 7×7 cells centred on `a.x/a.z`, `h + 1` rows tall
 * with the defaults. Glow budget: **7 cells** — coals claim them first, the flame takes what is left —
 * counted in code and clamped there.
 */
export function brazier(world: VoxelWorld, a: BuilderArgs): void {
  const h = int(a, 'h', 5, 3, 8);
  const legH = Math.max(2, h - 4);
  const flames = Math.max(1, h - legH - 1);
  const yBowl = a.y + legH;
  let glow = 0;
  const burn = (x: number, y: number, z: number, hex: number, power: number, f: number): void => {
    if (glow >= 7) return;
    glow += 1;
    world.set(x, y, z, hex, { kind: Kind.Glow, glow: power, t: reveal(a, f), dur: FADE });
  };

  // --- legs: three splayed struts from a wide foot up to the stem, plus a cross foot
  const yTop = yBowl - 1;
  for (const [fx, fz] of [[0, 2], [-2, -1], [2, -1]] as const) {
    world.beam([a.x + fx, a.y, a.z + fz], [a.x, yTop, a.z], 1, giltTint(C.bronze, a.x + fx, a.y, a.z + fz, 0.08), {
      t: reveal(a, 0.06),
      dur: FADE,
    });
    world.set(a.x + fx, a.y, a.z + fz, shade(C.goldDeep, 1.15), { t: reveal(a, 0.02), dur: FADE });
  }
  world.set(a.x, yTop, a.z, mixHex(C.gold, C.goldLite, 0.4), { t: reveal(a, 0.3), dur: FADE });

  // --- bowl: dark outer course below, bright gilding on the upper course and rim
  for (let dy = 0; dy < 2; dy++) {
    const y = yBowl + dy;
    const rad = 1.6 + dy * 0.9;
    for (let dx = -3; dx <= 3; dx++) {
      for (let dz = -3; dz <= 3; dz++) {
        const dd = dx * dx + dz * dz;
        if (dd > rad * rad) continue;
        const hex =
          dy === 0
            ? shade(C.bronze, 0.86 + 0.1 * (dx === 0 && dz === 0 ? 1 : 0))
            : mixHex(C.gold, C.goldLite, 0.5);
        world.set(a.x + dx, y, a.z + dz, giltTint(hex, a.x + dx, y, a.z + dz, 0.07), {
          t: reveal(a, 0.34 + 0.14 * dy),
          dur: FADE,
        });
      }
    }
  }

  // --- coals: a solid charcoal bed, four cells of it picked out as burning
  const yCoals = yBowl + 1;
  for (let dx = -1; dx <= 1; dx++) {
    for (let dz = -1; dz <= 1; dz++) {
      world.set(a.x + dx, yCoals, a.z + dz, giltTint(C.lacquer, a.x + dx, yCoals, a.z + dz, 0.12), {
        t: reveal(a, 0.6),
        dur: FADE,
      });
    }
  }
  for (const [ox, oz] of [[1, 1], [-1, -1], [1, -1], [-1, 1]] as const) {
    const hex = ox < 0 ? C.ember : C.goldHot;
    burn(a.x + ox, yCoals, a.z + oz, hex, 0.55 + 0.15 * Math.abs(ox), 0.64);
  }

  // --- flame column: one cell wide, tapering, the hall's point source
  for (let dy = 0; dy < flames; dy++) {
    const k = dy / Math.max(1, flames - 1);
    burn(
      a.x,
      yCoals + 1 + dy,
      a.z,
      dy === 0 ? C.lanternCore : mixHex(C.goldHot, C.ember, k),
      1 - 0.4 * k,
      0.76 + 0.08 * dy,
    );
  }
}

// ------------------------------------------------------------------ guardian lions

/**
 * A seated pair of guardian lions in dark gilded bronze, mirrored across the aisle at
 * `a.x - off` (hind paw on a ball) and `a.x + off` (hind paw on a cub), both facing `dir`. Each lion
 * is built from chunky masses only — a marble plinth, a haunch block, a taller chest block, a head
 * with a wider mane ring, a blunt three-cell muzzle, one leg dropped straight down and one raised onto
 * its object — so the pair still reads as silhouettes from the far end of the hall.
 *
 * Knobs: `off` aisle half-width 3..10 (default 5), `h` lion rows above the plinth 3..6 (default 4),
 * `dir` 0 = facing -z, 1 = facing +z (default 1). Footprint `2*off + 5` cells across x by 6 cells along
 * z, `h + 1` rows tall. Glow budget: **2 cells** — one eye per lion — enforced by the counter.
 */
export function lionPair(world: VoxelWorld, a: BuilderArgs): void {
  const off = int(a, 'off', 5, 3, 10);
  const h = int(a, 'h', 4, 3, 6);
  const fz = int(a, 'dir', 1, 0, 1) === 0 ? -1 : 1;
  let glow = 0;
  const hide = shade(C.bronze, 0.78);
  const body = mixHex(C.bronze, C.goldDeep, 0.3);
  const mane = mixHex(C.bronze, C.goldLite, 0.45);
  for (const side of [-1, 1] as const) {
    const lx = a.x + side * off;
    // local forward `u` runs along the facing direction, local lateral `v` across it
    const put = (u: number, v: number, dy: number, hex: number, f: number): void => {
      world.set(lx + v, a.y + dy, a.z + fz * u, hex, { t: reveal(a, f), dur: FADE });
    };
    for (let u = -1; u <= 1; u++) {
      for (let v = -1; v <= 1; v++) {
        put(u, v, 0, v === 0 || u === -1 ? C.marble : shade(C.marbleLite, 1.15), 0.04);
      }
    }
    // haunch and chest: two solid blocks, the chest a row taller so the seat reads
    for (let dy = 1; dy <= Math.min(2, h); dy++) {
      for (let u = -2; u <= -1; u++) {
        for (let v = -1; v <= 1; v++) put(u, v, dy, giltTint(hide, lx + v, a.y + dy, u, 0.09), 0.12);
      }
      for (let u = 0; u <= 1; u++) {
        for (let v = -1; v <= 1; v++) {
          put(u, v, dy, giltTint(dy === Math.min(2, h) ? body : shade(body, 0.86), lx + v, a.y + dy, u, 0.08), 0.24);
        }
      }
    }
    for (let u = 0; u <= 1; u++) {
      for (let v = -1; v <= 1; v++) {
        for (let dy = 3; dy <= h - 1; dy++) put(u, v, dy, giltTint(body, lx + v, a.y + dy, u, 0.08), 0.34);
      }
    }
    // mane ring and head
    for (let dy = h - 1; dy <= h; dy++) {
      for (let u = 1; u <= 3; u++) {
        for (let v = -2; v <= 2; v++) {
          if (Math.max(Math.abs(u - 2), Math.abs(v)) !== 2) continue;
          put(u, v, dy, giltTint(dy === h ? mane : shade(mane, 0.82), lx + v, a.y + dy, u, 0.1), 0.56);
        }
      }
    }
    for (let u = 1; u <= 2; u++) {
      for (let v = -1; v <= 1; v++) {
        for (let dy = h - 1; dy <= h; dy++) put(u, v, dy, giltTint(shade(body, 1.06), lx + v, a.y + dy, u, 0.06), 0.5);
      }
    }
    // blunt muzzle: three cells flat across the front, dark
    for (let v = -1; v <= 1; v++) put(3, v, h - 1, shade(C.lacquer, 1.1 + 0.2 * (v === 0 ? 1 : 0)), 0.74);
    // legs: the free side drops straight, the guarded side climbs onto its object
    for (let dy = 1; dy <= 2; dy++) put(2, -side, dy, shade(hide, 1.05), 0.44);
    for (let u = 2; u <= 3; u++) {
      for (let dy = 1; dy <= 2; dy++) {
        if (u === 3 && dy === 2) continue;
        const hex = side < 0 ? mixHex(C.goldDeep, C.bronze, 0.4) : shade(C.bronze, 0.95);
        put(u, side, dy, hex, 0.62);
      }
    }
    put(3, side, 2, side < 0 ? C.marbleLite : shade(C.bronze, 1.15), 0.7);
    put(1, side, 3, mixHex(body, C.goldLite, 0.3), 0.68);
    put(2, side, 3, mixHex(body, C.goldLite, 0.3), 0.7);
    if (glow < 2) {
      glow += 1;
      world.set(lx, a.y + h - 1, a.z + fz * 2, C.goldHot, {
        kind: Kind.Glow,
        glow: 0.7,
        t: reveal(a, 0.94),
        dur: FADE,
      });
    }
  }
}

// ------------------------------------------------------------------ floor inlay

/**
 * Floor inlay band written exactly on the single row `a.y` — nothing above it, nothing below. A one-cell
 * border of `C.goldDeep` frames a field of `C.marbleLite`, and every `every` cells along the length a
 * gilt motif repeats: a lozenge when the band is wide enough to carry one, otherwise a double stripe.
 * Motif centres step by two rows of cells so the pattern reads as inlaid stone rather than paint.
 *
 * Knobs: `len` cells along the band 8..40 (default 24), `wide` cells across 3..9 (default 5),
 * `dir` 0 = along z, 1 = along x (default 1), `every` motif pitch 3..7 (default 4). Footprint `len × wide`
 * cells centred on `a.x/a.z`, exactly one row thick at `a.y`. Glow budget: **0 cells**.
 */
export function goldInlay(world: VoxelWorld, a: BuilderArgs): void {
  const len = int(a, 'len', 24, 8, 40);
  const wide = int(a, 'wide', 5, 3, 9);
  const axis = int(a, 'dir', 1, 0, 1);
  const every = int(a, 'every', 4, 3, 7);
  const half = Math.floor(len / 2);
  const halfW = Math.floor(wide / 2);
  const lozenge = wide >= 5;
  for (let i = 0; i < len; i++) {
    for (let j = -halfW; j <= halfW; j++) {
      const [wx, wz] = place(axis, 1, a, i - half, j);
      const edge = i === 0 || i === len - 1 || j === -halfW || j === halfW;
      if (edge) {
        world.set(wx, a.y, wz, giltTint(C.goldDeep, wx, a.y, wz, 0.06), {
          t: reveal(a, 0.05 + 0.3 * (i / Math.max(1, len - 1))),
          dur: FADE,
        });
        continue;
      }
      const k = i % every;
      const r = Math.abs(j);
      const motif = lozenge
        ? (k === 0 && r <= 1) || (k === 1 && r === 1) || (every - 1 && k === every - 1 && r === 1)
        : k === 0 || k === 1;
      const hex = motif ? (r === 0 ? C.goldPale : C.gilt) : giltTint(C.marbleLite, wx, a.y, wz, 0.05);
      world.set(wx, a.y, wz, hex, {
        t: reveal(a, 0.12 + 0.3 * (i / Math.max(1, len - 1))),
        dur: FADE,
      });
    }
  }
}

// ------------------------------------------------------------------ gilded stair

/**
 * Short processional stair of marble treads with gilded nosing, climbing `rise` rows across `run` cells
 * and `width` cells wide along `dir` (0 = +z, 1 = -z, 2 = +x, 3 = -x). Each tread is filled solid from
 * row `a.y` up to its own top so the flight reads as a cut block, the leading column of every tread is
 * gilded, and the two outer files carry a darker marble cheek.
 *
 * Knobs: `run` cells of travel 4..16 (default 8), `rise` rows climbed 2..8 (default 4), `width` cells
 * across 3..9 (default 5), `dir` 0..3 (default 0). Footprint `run` × `width` cells with the flight
 * starting at `a.x/a.z`; top row `a.y + rise - 1`. Glow budget: **0 cells**.
 */
export function gildedStair(world: VoxelWorld, a: BuilderArgs): void {
  const run = int(a, 'run', 8, 4, 16);
  const rise = int(a, 'rise', 4, 2, 8);
  const width = int(a, 'width', 5, 3, 9);
  const dir = Math.max(0, Math.min(3, Math.floor(opt(a, 'dir', 0))));
  const axis = dir === 2 || dir === 3 ? 1 : 0;
  const sgn = dir === 0 || dir === 2 ? 1 : -1;
  const w0 = -Math.floor(width / 2);
  for (let i = 0; i < run; i++) {
    const top = Math.floor(((i + 1) * rise) / run) - 1;
    if (top < 0) continue;
    const f = 0.04 + 0.8 * (i / Math.max(1, run - 1));
    for (let w = 0; w < width; w++) {
      const cheek = w === 0 || w === width - 1;
      for (let dy = 0; dy <= top; dy++) {
        const [wx, wz] = place(axis, sgn, a, i, w0 + w);
        const lit = dy === top ? 1 : 0.86;
        world.set(wx, a.y + dy, wz, giltTint(shade(cheek ? C.marble : C.marbleLite, lit), wx, a.y + dy, wz, 0.05), {
          t: reveal(a, f),
          dur: FADE,
        });
      }
      // gilded nosing on the exposed front of the tread
      const [nx, nz] = place(axis, sgn, a, i + sgn * 0, w0 + w);
      world.set(nx, a.y + top, nz, cheek ? C.gold : giltTint(C.goldLite, nx, a.y + top, nz, 0.05), {
        t: reveal(a, f + 0.06),
        dur: FADE,
      });
    }
  }
}

