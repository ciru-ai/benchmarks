import { Kind, VoxelWorld } from '../core/VoxelWorld';
import { C, hash3, mixHex, shade } from '../core/palette';
import { FADE, BuilderArgs, opt, reveal } from './types';

/**
 * Architecture library for GILTTHRONE 金殿.
 *
 * Everything here is authored as a heightfield-first exercise: the signature curved roof
 * is one function (`curvedRoof`) reused by the pagoda, the pavilion and the gate, so the
 * whole garden shares a single roof geometry language — a concave (ogee) slope that is
 * steep under the ridge and nearly flat at the eave, with the four corners lifting clear
 * of the mid-eave line.
 */

// ------------------------------------------------------------------ shared helpers


export interface RoofSpec {
  /** roof centre in plan */
  cx: number;
  cz: number;
  /** half-span in cells along each axis */
  hx: number;
  hz: number;
  /** row of the mid-eave line */
  y0: number;
  /** rows gained from the eave line up to the ridge */
  rise: number;
  /** how far the corner tips climb above the mid-eave line (3..5 for big roofs) */
  lift: number;
  /** reveal window: f0 for the eave tips, f1 for the ridge */
  f0: number;
  f1: number;
  /** deterministic jitter seed */
  seed: number;
}

/**
 * Column height of the shared curved roof at plan offset `(dx, dz)`: an ogee curve of the
 * normalised Chebyshev radius — steep under the ridge, almost flat at the eave — plus a
 * corner uplift keyed to how close the cell is to a diagonal, so the four tips climb clear
 * of the mid-eave line. Slope never exceeds one row per cell, so the sheet is a watertight
 * heightfield with no hollow interior to hide.
 */
function roofHeight(s: RoofSpec, dx: number, dz: number): number {
  const hx = Math.max(1, Math.round(s.hx));
  const hz = Math.max(1, Math.round(s.hz));
  const u = Math.max(Math.abs(dx) / hx, Math.abs(dz) / hz);
  const c = Math.min(Math.abs(dx) / hx, Math.abs(dz) / hz);
  return (
    s.y0 +
    Math.round(s.rise * (1 - Math.pow(u, 0.62)) + s.lift * Math.pow(u, 2.2) * Math.pow(c, 1.1))
  );
}

/**
 * THE curved roof, reused by the pagoda, the pavilion and the gate. One column of tiles per
 * plan cell of the footprint; outer columns get a second, darker voxel so the soffit reads
 * as a thick bracketed slab. Tile ribs alternate `C.tile` / `C.tileRim` every other rib of
 * the nearer face, the rim row is picked out in slate, and the ridge is capped with
 * gable-end boards. Reveal runs eave-tip first, ridge last. Returns the top row used.
 */
export function curvedRoof(world: VoxelWorld, a: BuilderArgs, s: RoofSpec): number {
  const hx = Math.max(1, Math.round(s.hx));
  const hz = Math.max(1, Math.round(s.hz));
  for (let dz = -hz; dz <= hz; dz++) {
    for (let dx = -hx; dx <= hx; dx++) {
      const u = Math.max(Math.abs(dx) / hx, Math.abs(dz) / hz);
      // Tile ribs run down the slope, so alternate across the nearer face.
      const rib = Math.abs(dx) >= Math.abs(dz) ? dz : dx;
      let color: number = ((rib + 100) & 1) === 0 ? C.tile : C.tileRim;
      if (u > 0.93) color = mixHex(C.tileRim, C.slate, 0.35);
      // Ink-wash variation so a big sheet never reads as one flat hue.
      if (hash3(dx + s.cx, 0, dz + s.cz, s.seed + 11) > 0.86) color = mixHex(color, C.mist, 0.16);
      const f = s.f0 + (s.f1 - s.f0) * (1 - u);
      const y = roofHeight(s, dx, dz);
      world.set(s.cx + dx, y, s.cz + dz, color, { t: reveal(a, f), dur: FADE });
      if (u > 0.42) {
        world.set(s.cx + dx, y - 1, s.cz + dz, shade(C.tileDeep, 0.7), { t: reveal(a, f), dur: FADE });
      }
    }
  }
  const ridge = s.y0 + s.rise;
  const cap = shade(C.tileDeep, 0.8);
  const ridgeHalf = Math.max(1, Math.round(Math.min(hx, hz) * 0.34));
  for (let dx = -ridgeHalf; dx <= ridgeHalf; dx++) {
    world.set(s.cx + dx, ridge + 1, s.cz, cap, { t: reveal(a, s.f1), dur: FADE });
    if (Math.abs(dx) === ridgeHalf) {
      // Gable-end boards (shanmian) capping the hip ends.
      world.set(s.cx + dx, ridge + 2, s.cz, C.woodDark, { t: reveal(a, s.f1), dur: FADE });
      world.set(s.cx + dx, ridge + 2, s.cz + 1, shade(C.vermilionDeep, 0.92), { t: reveal(a, s.f1), dur: FADE });
      world.set(s.cx + dx, ridge + 2, s.cz - 1, shade(C.vermilionDeep, 0.92), { t: reveal(a, s.f1), dur: FADE });
    }
  }
  // Upturned eave tips: one claw per corner, flicking above the rim.
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      world.set(
        s.cx + sx * hx,
        roofHeight(s, sx * hx, sz * hz) + 1,
        s.cz + sz * hz,
        C.tileRim,
        { t: reveal(a, s.f0), dur: FADE },
      );
    }
  }
  return ridge + 2;
}

/** Stepped stone terrace / platform: `steps` rings, one row tall each, widest first. */
export function stoneSteps(
  world: VoxelWorld,
  a: BuilderArgs,
  cx: number,
  cz: number,
  half: number,
  y: number,
  steps: number,
  f0: number,
  f1: number,
): void {
  for (let s = 0; s < steps; s++) {
    const h = half + (steps - 1 - s);
    const t = f0 + ((f1 - f0) * s) / Math.max(1, steps - 1);
    const k = 1 - 0.16 * (steps - 1 - s);
    world.box(cx - h, y + s, cz - h, cx + h, y + s, cz + h, shade(C.stone, k), {
      t: reveal(a, t),
      dur: FADE,
    });
    // Top step gets a full slab so the deck is solid.
    if (s === steps - 1) world.box(cx - h, y + s, cz - h, cx + h, y + s, cz + h, shade(C.stoneLite, 0.96), { t: reveal(a, t), dur: FADE });
  }
}

/** A stair of dressed blocks climbing `rise` rows across `run` cells on one side. */
export function stoneStair(
  world: VoxelWorld,
  a: BuilderArgs,
  x: number,
  y: number,
  z: number,
  dir: number,
  run: number,
  width: number,
  rise: number,
  f: number,
): void {
  const ax = dir === 2 || dir === 3 ? 1 : 0; // axis of travel: 0 = z, 1 = x
  const sgn = dir === 0 || dir === 2 ? 1 : -1;
  const treads = Math.max(1, run);
  for (let i = 0; i < treads; i++) {
    const stepRow = Math.floor(((i + 1) * rise) / treads) - 1;
    if (stepRow < 0) continue;
    const d = i * sgn;
    const w0 = -Math.floor(width / 2);
    const w1 = w0 + width - 1;
    const t = f + (i / Math.max(1, treads - 1)) * 0.04;
    if (ax === 1) {
      world.box(x + d, y + stepRow, z + w0, x + d, y + Math.max(stepRow, 0), z + w1, shade(C.stoneLite, 0.9 - 0.02 * (treads - i)), { t: reveal(a, t), dur: FADE });
    } else {
      world.box(x + w0, y + stepRow, z + d, x + w1, y + Math.max(stepRow, 0), z + d, shade(C.stoneLite, 0.9 - 0.02 * (treads - i)), { t: reveal(a, t), dur: FADE });
    }
  }
}

/** Stone courses: a block of masonry with visible horizontal joints and corner quoins. */
export function masonry(
  world: VoxelWorld,
  a: BuilderArgs,
  x0: number,
  y0: number,
  z0: number,
  x1: number,
  y1: number,
  z1: number,
  f: number,
  base: number,
): void {
  for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) {
    const course = Math.floor((y - Math.min(y0, y1)) / 2);
    const k = 0.82 + 0.06 * (((y - Math.min(y0, y1)) % 2) === 0 ? 1 : 0) + 0.04 * (course % 2);
    for (let z = Math.min(z0, z1); z <= Math.max(z0, z1); z++) {
      for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) {
        const onShell = x === x0 || x === x1 || z === z0 || z === z1 || y === y0 || y === y1;
        if (!onShell && x > x0 && x < x1 && z > z0 && z < z1 && y > y0 && y < y1) continue;
        const q = (x === x0 || x === x1) && (z === z0 || z === z1);
        const grain = hash3(x, y, z, 5);
        const col = q ? shade(base, k + 0.1) : shade(base, k - 0.06 + grain * 0.1);
        world.set(x, y, z, col, { t: reveal(a, f), dur: FADE });
      }
    }
  }
}

/** Balustrade ring: sill, chamfered rail, and a post every `every` cells. */
export function balustrade(
  world: VoxelWorld,
  a: BuilderArgs,
  cx: number,
  cz: number,
  half: number,
  y: number,
  f: number,
  every: number,
): void {
  const h = Math.round(half);
  const col = shade(C.stoneLite, 0.92);
  for (let d = -h; d <= h; d++) {
    for (const [x, z] of [
      [cx + d, cz - h],
      [cx + d, cz + h],
      [cx - h, cz + d],
      [cx + h, cz + d],
    ] as const) {
      world.set(x, y, z, col, { t: reveal(a, f), dur: FADE });
      const isPost = d % every === 0 || Math.abs(d) === h;
      world.set(x, y + 1, z, isPost ? C.stone : col, { t: reveal(a, f), dur: FADE });
      if (isPost) world.set(x, y + 2, z, shade(C.vermilionDeep, 0.85), { t: reveal(a, f), dur: FADE });
    }
  }
}

/** Bracket sets (tokyo): stepped timber blocks with arms reaching out under an eave. */
export function brackets(
  world: VoxelWorld,
  a: BuilderArgs,
  cx: number,
  cz: number,
  half: number,
  y: number,
  reach: number,
  f: number,
): void {
  const h = Math.round(half);
  for (let d = -h; d <= h; d += 2) {
    for (const [px, pz, ox, oz] of [
      [cx + d, cz - h, 0, -1],
      [cx + d, cz + h, 0, 1],
      [cx - h, cz + d, -1, 0],
      [cx + h, cz + d, 1, 0],
    ] as const) {
      world.set(px, y, pz, C.woodDark, { t: reveal(a, f), dur: FADE });
      world.set(px, y + 1, pz, C.vermilionDeep, { t: reveal(a, f), dur: FADE });
      for (let r = 1; r <= reach; r++) {
        const w = r === reach ? 1 : 0;
        world.set(px + ox * r, y + 1 + w, pz + oz * r, w ? C.wood : C.woodDark, {
          t: reveal(a, f),
          dur: FADE,
        });
      }
    }
  }
}

/**
 * A timber storey: lacquered corner posts, plaster panels with framed window openings, a
 * sill course and a double lintel band. Only the perimeter is built — above the great hall the
 * interior is never seen and stays hollow.
 */
function storey(
  world: VoxelWorld,
  a: BuilderArgs,
  cx: number,
  cz: number,
  half: number,
  y0: number,
  height: number,
  f: number,
  seed: number,
): void {
  const h = Math.round(half);
  const y1 = y0 + Math.max(3, height) - 1;
  const holeW = h >= 6 ? 1 : 0;
  const hb0 = y0 + 2;
  const hb1 = y1 - 2 > hb0 ? y1 - 2 : hb0;
  for (let d = -h; d <= h; d++) {
    for (const [px, pz, ox, oz] of [
      [cx + d, cz - h, 0, -1],
      [cx + d, cz + h, 0, 1],
      [cx - h, cz + d, -1, 0],
      [cx + h, cz + d, 1, 0],
    ] as const) {
      const isCorner = Math.abs(d) === h;
      const inHole = Math.abs(d) <= holeW;
      for (let y = y0; y <= y1; y++) {
        if (isCorner) {
          world.set(px, y, pz, y === y1 ? C.woodDark : C.vermilionDeep, { t: reveal(a, f), dur: FADE });
          continue;
        }
        if (y === y0) {
          world.set(px, y, pz, shade(C.stone, 0.85), { t: reveal(a, f), dur: FADE });
          continue;
        }
        if (y >= y1 - 1) {
          world.set(px, y, pz, y === y1 ? C.wood : C.woodDark, { t: reveal(a, f), dur: FADE });
          continue;
        }
        // Vertical timber mullion every third cell.
        if ((d + 100) % 3 === 0) {
          world.set(px, y, pz, C.woodDark, { t: reveal(a, f), dur: FADE });
          continue;
        }
        if (inHole && y >= hb0 && y <= hb1) {
          // Glazed opening: leave the cell empty, frame it in dark timber.
          if (y === hb0) world.set(px + ox, y, pz + oz, C.woodDark, { t: reveal(a, f), dur: FADE });
          continue;
        }
        const wash = 0.86 + 0.14 * hash3(px, y, pz, seed + 3);
        world.set(px, y, pz, shade(mixHex(C.paper, C.mist, 0.3), wash * (0.82 + 0.18 * ((y - y0) / Math.max(1, y1 - y0)))), {
          t: reveal(a, f),
          dur: FADE,
        });
      }
      if (inHole) {
        world.set(px, hb1 + 1, pz, C.wood, { t: reveal(a, f), dur: FADE });
        world.set(px, hb0 - 1, pz, shade(C.stoneLite, 0.95), { t: reveal(a, f), dur: FADE });
      }
    }
  }
}

// ------------------------------------------------------------------ monuments

function int(a: BuilderArgs, key: string, dflt: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, Math.round(opt(a, key, dflt))));
}

/**
 * The finial: a gilded spire of stacked rings, capped by a jewel that lights with the
 * lanterns. `h` rows tall above `a.y`.
 */
export function finial(world: VoxelWorld, a: BuilderArgs): void {
  const h = int(a, 'h', 9, 5, 14);
  const f = 0.86;
  for (let k = 0; k < 3; k++) {
    const r = 2 - k * 0.5;
    const y = a.y + 1 + k * 2;
    for (let dx = -2; dx <= 2; dx++) {
      for (let dz = -2; dz <= 2; dz++) {
        if (Math.hypot(dx, dz) > r) continue;
        world.set(a.x + dx, y, a.z + dz, shade(C.gold, 0.8 + 0.14 * k), { t: reveal(a, f), dur: FADE });
      }
    }
  }
  for (let y = a.y; y < a.y + h; y++) {
    world.set(a.x, y, a.z, y > a.y + h - 3 ? C.goldLite : C.gold, { t: reveal(a, f + 0.02), dur: FADE });
  }
  world.set(a.x, a.y + h, a.z, C.lanternCore, { kind: Kind.Glow, glow: 0.9, t: reveal(a, 0.98), dur: FADE });
  world.set(a.x, a.y + h - 1, a.z, C.goldLite, { kind: Kind.Glow, glow: 0.45, t: reveal(a, 0.98), dur: FADE });
}

/**
 * THE five-storey pagoda. Plinth, then per tier: timber storey → bracket course → curved
 * roof, each tier half a span narrower and the roofs overlapping the one below, so the
 * silhouette steps in as it climbs. Reveal is bottom tier first; the finial is the last
 * voxel in the whole inner act.
 *
 * Footprint: x ± (half+3), z ± (half+3). Height with the defaults: 57 rows above `a.y`.
 */
export function pagoda(world: VoxelWorld, a: BuilderArgs): void {
  const tiers = int(a, 'tiers', 5, 3, 6);
  const half = int(a, 'half', 11, 6, 14);
  const tierH = int(a, 'tierH', 3, 3, 6);

  // stepped plinth
  stoneSteps(world, a, a.x, a.z, half + 1, a.y, 3, 0.0, 0.08);
  let y = a.y + 3;
  let h = half;

  for (let t = 0; t < tiers; t++) {
    const f = 0.06 + (t / tiers) * 0.62;
    // a narrow cloister band under each storey ties the tiers to the roofs
    if (t > 0) balustrade(world, a, a.x, a.z, h + 2, y - 2, f - 0.02, 3);
    storey(world, a, a.x, a.z, h, y, tierH + 1, f, a.seed + t * 13);
    // lamp inside the ground-floor hall, visible through the framed opening
    if (t === 0) {
      world.set(a.x, y + 2, a.z, C.lanternCore, { kind: Kind.Glow, glow: 0.85, t: reveal(a, 0.95), dur: 0.6 });
      world.set(a.x, y + 1, a.z, C.lantern, { kind: Kind.Glow, glow: 0.6, t: reveal(a, 0.95), dur: 0.6 });
    }
    brackets(world, a, a.x, a.z, h, y + tierH + 1, 2, f + 0.03);
    const top = curvedRoof(world, a, {
      cx: a.x,
      cz: a.z,
      hx: h + 3,
      hz: h + 3,
      y0: y + tierH + 2,
      rise: Math.max(3, Math.round(h * 0.42)),
      lift: t === 0 ? 3 : 2,
      f0: f + 0.04,
      f1: f + 0.12,
      seed: a.seed + t * 29,
    });
    y = top + 2;
    h = Math.max(2, h - 2);
  }

  finial(world, { ...a, y, t: a.t + a.dt * 0.62, dt: a.dt * 0.3 });
}


/**
 * Mountain gate (sanmon): two battered piers, a double lintel, plaques and one wide curved
 * roof. The path walks through it. Footprint x ± (span+3), height 15 rows.
 */
export function gate(world: VoxelWorld, a: BuilderArgs): void {
  const span = int(a, 'half', 6, 3, 10);
  const pier = Math.round(span * 0.34) + 1;
  for (const s of [-1, 1]) {
    masonry(
      world, a,
      a.x + s * span - pier, a.y, a.z - pier,
      a.x + s * span + pier, a.y + 9, a.z + pier,
      0.02, C.stone,
    );
    // capped pier head
    world.box(
      a.x + s * span - pier - 1, a.y + 10, a.z - pier - 1,
      a.x + s * span + pier + 1, a.y + 10, a.z + pier + 1,
      C.stoneLite, { t: reveal(a, 0.06), dur: FADE },
    );
  }
  // lintels: a heavy beam and a thinner one above it, plus the centre plaque
  for (let d = -span; d <= span; d++) {
    world.box(a.x + d, a.y + 9, a.z - 1, a.x + d, a.y + 9, a.z + 1, C.vermilion, { t: reveal(a, 0.05), dur: FADE });
    world.box(a.x + d, a.y + 11, a.z, a.x + d, a.y + 11, a.z, C.woodDark, { t: reveal(a, 0.08), dur: FADE });
  }
  for (let y = a.y + 7; y <= a.y + 8; y++) {
    world.set(a.x, y, a.z, C.paper, { kind: Kind.Glow, glow: 0.32, t: reveal(a, 0.1), dur: FADE });
  }
  curvedRoof(world, a, {
    cx: a.x,
    cz: a.z,
    hx: span + 3,
    hz: Math.round(span * 0.55) + 2,
    y0: a.y + 12,
    rise: 4,
    lift: 3,
    f0: 0.09,
    f1: 0.16,
    seed: a.seed + 7,
  });
}

/**
 * Open pavilion: stepped stone deck, four lacquered posts, a rail, a table and a hip roof.
 * Sits where the camera stops to look back at the pagoda. Footprint x ± (half+2).
 */
export function pavilion(world: VoxelWorld, a: BuilderArgs): void {
  const half = int(a, 'half', 6, 4, 9);
  stoneSteps(world, a, a.x, a.z, half, a.y, 2, 0.0, 0.05);
  const y0 = a.y + 2;
  balustrade(world, a, a.x, a.z, half, y0, 0.06, 2);
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      for (let y = y0; y <= y0 + 5; y++) {
        world.set(a.x + sx * (half - 1), y, a.z + sz * (half - 1), C.vermilion, { t: reveal(a, 0.08), dur: FADE });
      }
    }
  }
  world.box(a.x - 1, y0 + 1, a.z - 1, a.x + 1, y0 + 1, a.z + 1, C.wood, { t: reveal(a, 0.1), dur: FADE });
  world.set(a.x, y0 + 2, a.z, C.lantern, { kind: Kind.Glow, glow: 0.7, t: reveal(a, 0.96), dur: 0.6 });
  brackets(world, a, a.x, a.z, half - 1, y0 + 6, 2, 0.12);
  curvedRoof(world, a, {
    cx: a.x,
    cz: a.z,
    hx: half + 2,
    hz: half + 2,
    y0: y0 + 7,
    rise: 4,
    lift: 3,
    f0: 0.13,
    f1: 0.2,
    seed: a.seed + 19,
  });
}

/** Dressed stone stair climbing from the path up to a terrace. */
export function stair(world: VoxelWorld, a: BuilderArgs): void {
  const run = int(a, 'run', 12, 4, 26);
  const rise = int(a, 'rise', 10, 2, 16);
  stoneStair(world, a, a.x, a.y, a.z, int(a, 'dir', 1, 0, 3), run, int(a, 'width', 5, 2, 9), rise, 0.14);
}

/** Railing ring, exposed so a terrace can be fenced without a full platform. */
export function railing(world: VoxelWorld, a: BuilderArgs): void {
  balustrade(world, a, a.x, a.z, int(a, 'half', 10, 3, 24), a.y, 0.2, int(a, 'every', 3, 2, 6));
}
