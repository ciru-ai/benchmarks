import { VoxelWorld } from '../core/VoxelWorld';
import { hash3, rng } from '../core/palette';

/**
 * Builder contract. A builder writes solid voxels into a `VoxelWorld`; it never creates
 * geometry, never touches the scene graph, and never reads wall-clock time — a frame is a
 * pure function of the clock, so authors stay deterministic.
 *
 * Static builders (`(world, args) => void`) place one object on the island.
 * Movable builders (`makeX(...)`) fill a *small private* world whose pivot is returned, so
 * the scene can mesh it once and drive the Object3D (koi, wheel, pilgrims).
 */

export interface BuilderArgs {
  /** grid column of the object's centre */
  x: number;
  z: number;
  /** first grid row the object may occupy (the surface it stands on) */
  y: number;
  /** reveal start of the object's first voxel, in loop seconds */
  t: number;
  /** seconds the object takes to appear — spread parts across this */
  dt: number;
  seed: number;
  /** optional numeric knobs, read with `opt()` */
  opts?: Record<string, number>;
}

export interface MovableModel {
  world: VoxelWorld;
  /** pivot in cell units (fractional allowed); the mesh is centred on it */
  center: [number, number, number];
  /** total seconds the model takes to appear */
  dt: number;
}

/** Read an optional knob with a default. */
export function opt(a: BuilderArgs, name: string, fallback: number): number {
  const v = a.opts?.[name];
  return v === undefined ? fallback : v;
}

/** Per-object deterministic stream, independent of every other object's draws. */
export function dice(a: BuilderArgs): () => number {
  return rng(a.seed * 2654435761);
}

/**
 * Reveal time for a piece of an object: `f` is 0 for the piece that should appear first
 * (the base of a trunk, the eave tip of a roof) and 1 for the last (the crown, the finial).
 */
export function reveal(a: BuilderArgs, f: number): number {
  return a.t + Math.max(0, Math.min(1, f)) * a.dt * 0.72;
}

/** Short per-voxel fade so a piece arrives crisply but not instantly. */
export const FADE = 0.34;

/** Sway weight that ramps with height above an object's base — crowns breathe, roots do not. */
export function swayAt(heightAboveBase: number, total: number, strength = 1): number {
  const f = Math.max(0, Math.min(1, heightAboveBase / Math.max(1, total)));
  return strength * (0.15 + 0.85 * f * f);
}

/** Cheap deterministic value noise on a lattice, for coastlines and canopy edges. */
export function noise2(x: number, z: number, seed = 0): number {
  return hash3(Math.round(x), 0, Math.round(z), seed);
}

export { VoxelWorld };
