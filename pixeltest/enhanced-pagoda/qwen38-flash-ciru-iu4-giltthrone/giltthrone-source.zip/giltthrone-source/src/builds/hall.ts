import { Kind, VoxelWorld } from '../core/VoxelWorld';
import { C, hash3, mixHex, rng, shade } from '../core/palette';
import { HALL } from '../core/layout';
import { FADE, BuilderArgs, MovableModel, opt, reveal } from './types';
import { brackets, curvedRoof, finial, stoneSteps, stoneStair } from './pagoda';

/**
 * The monument of GILTTHRONE 金殿: a hall first, a pagoda on top of it.
 *
 * INKFALL's pagoda was sealed — its storey helper builds a perimeter and leaves the inside
 * empty because the camera never goes there. Here the ground storey *is* the room: the walls are
 * two cells thick, the doorway is cut clear from the deck to the header course, the underside of
 * the ceiling slab is dressed, and the door leaves are separate movable models so they can swing.
 * Everything above the ceiling slab goes back to being scenery.
 *
 * Rows are given absolutely through `HALL` (core/layout) because the doorway has three readers:
 * this builder, the two door leaves, and the camera that flies between them.
 */

/** Clamped integer knob — `types.opt` has no range of its own. */
function num(a: BuilderArgs, name: string, dflt: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, Math.round(opt(a, name, dflt))));
}

/** Gilded masonry course: dark core, bright face, hash-worn so a big wall never goes flat. */
function gild(world: VoxelWorld, x: number, y: number, z: number, f: number, a: BuilderArgs, bright = 0): void {
  const k = 0.8 + 0.2 * hash3(x, y, z, a.seed + 17) + bright * 0.18;
  world.set(x, y, z, shade(bright > 0 ? C.goldLite : C.goldDeep, k), { t: reveal(a, f), dur: FADE });
}

/** A lacquered post with a gilded base and collar, `y0..y1` inclusive. */
function post(
  world: VoxelWorld,
  a: BuilderArgs,
  x: number,
  z: number,
  y0: number,
  y1: number,
  f: number,
  hex: number,
): void {
  for (let y = y0; y <= y1; y++) {
    const k = 0.78 + 0.1 * hash3(x, y, z, a.seed) + 0.12 * ((y - y0) % 3 === 0 ? 1 : 0);
    world.set(x, y, z, shade(hex, k), { t: reveal(a, f), dur: FADE });
  }
  gild(world, x, y0, z, f, a, 1);
  gild(world, x, y1, z, f, a, 1);
}

/** A gilded band course ringing the walls at `y`. */
function band(world: VoxelWorld, a: BuilderArgs, half: number, y: number, f: number): void {
  for (let d = -half; d <= half; d++) {
    for (const [x, z] of [
      [a.x + d, a.z - half],
      [a.x + d, a.z + half],
      [a.x - half, a.z + d],
      [a.x + half, a.z + d],
    ] as const) {
      gild(world, x, y, z, f, a, Math.abs(d) === half ? 1 : 0);
    }
  }
}

/**
 * Stepped plinth under the hall: two rings of dressed masonry and a bright deck, so the deck's
 * top surface is the floor the throne stands on. Footprint x ± (half+1), 2 rows above `a.y`.
 */
export function plinth(world: VoxelWorld, a: BuilderArgs): void {
  const half = Math.max(4, Math.round(num(a, 'half', HALL.half, 6, 20)));
  stoneSteps(world, a, a.x, a.z, half + 1, a.y, 2, 0.0, 0.06);
  // the front approach is dressed and gilded at the nosing
  stoneStair(world, a, a.x, a.y, a.z + half + 2, 1, 6, 2 * HALL.doorHalf + 3, 2, 0.05);
}

/**
 * The envelope: two-cell walls from the deck to the ceiling slab, the doorway cut clear, side
 * windows framed in gild, a coffered ceiling, and the arched niche behind the throne.
 *
 * `a.y` is `HALL.floorRow` — the deck the hall stands on. Interior air runs
 * `floorRow .. ceilingRow-1`; the slab itself is two rows thick. Footprint x ± half.
 */
export function hallShell(world: VoxelWorld, a: BuilderArgs): void {
  const half = Math.max(6, Math.round(num(a, 'half', HALL.half, 6, 20)));
  const y0 = Math.round(num(a, 'floorRow', HALL.floorRow, 2, 150));
  const slab = Math.round(num(a, 'ceilingRow', HALL.ceilingRow, 4, 151));
  const header = Math.round(num(a, 'headerRow', HALL.headerRow, 3, 150));
  const doorHalf = Math.max(1, Math.round(num(a, 'doorHalf', HALL.doorHalf, 1, 8)));
  const stone = mixHex(C.marble, C.goldDeep, 0.42);

  // two concentric square rings = a wall of thickness 2
  for (const t of [0, 1]) {
    const h = half - t;
    for (let d = -h; d <= h; d++) {
      const faces: readonly [number, number, number, number][] = [
        [a.x + d, a.z + h, 0, 1],
        [a.x + d, a.z - h, 0, -1],
        [a.x - h, a.z + d, -1, 0],
        [a.x + h, a.z + d, 1, 0],
      ];
      for (const [x, z, ox, oz] of faces) {
        const isCorner = Math.abs(d) === h;
        const inDoor = oz === 1 && Math.abs(d) <= doorHalf;
        const windowed = ox !== 0 && !isCorner && (d + 100) % 4 === 0 && h !== half;
        for (let y = y0; y <= slab - 1; y++) {
          if (inDoor && y < header) continue;
          if (windowed && y >= y0 + 3 && y <= header - 2) continue;
          if (isCorner) {
            gild(world, x, y, z, 0.1 + t * 0.02, a, y % 4 === 0 ? 1 : 0);
            continue;
          }
          const course = 0.82 + 0.1 * hash3(x, y, z, a.seed + 5) + 0.05 * (((y - y0) % 3) === 0 ? 1 : 0);
          world.set(x, y, z, shade(stone, course - t * 0.05), { t: reveal(a, 0.1 + t * 0.03), dur: FADE });
        }
        // window jambs, lintel and a lamp cell that reads through the opening
        if (windowed) {
          for (let y = y0 + 2; y <= header - 1; y++) {
            gild(world, x, y, z, 0.34, a, 1);
            world.set(x + ox, y, z + oz, C.lacquerLite, { t: reveal(a, 0.36), dur: FADE });
          }
          world.set(
            x,
            y0 + Math.round((header - 2 - y0) / 2),
            z,
            C.lanternCore,
            { kind: Kind.Glow, glow: 0.85, t: reveal(a, 0.95), dur: 0.5 },
          );
        }
        // the doorway is framed by a gilded jamb and a heavy header course
        if (inDoor && Math.abs(d) === doorHalf) {
          for (let y = y0; y < header; y++) gild(world, x, y, z, 0.3, a, Math.abs(d) === doorHalf ? 1 : 0);
        }
      }
    }
  }
  for (let d = -doorHalf - 1; d <= doorHalf + 1; d++) {
    for (let t = 0; t < 2; t++) {
      gild(world, a.x + d, header, a.z + half - t, 0.36, a, 1);
      gild(world, a.x + d, header + 1, a.z + half - t, 0.38, a, Math.abs(d) === doorHalf + 1 ? 1 : 0);
    }
  }

  // string courses tie the walls together and give the camera something to read inside
  band(world, a, half, y0, 0.12);
  band(world, a, half, y0 + 5, 0.24);
  band(world, a, half, header + 1, 0.4);

  // ceiling: a dark slab with a coffered, gilded underside
  world.box(a.x - half + 1, slab - 1, a.z - half + 1, a.x + half - 1, slab - 1, a.z + half - 1, C.lacquer, {
    t: reveal(a, 0.5),
    dur: FADE,
  });
  for (let x = a.x - half + 2; x <= a.x + half - 2; x += 4) {
    for (let z = a.z - half + 2; z <= a.z + half - 2; z += 4) {
      gild(world, x, slab - 1, z, 0.54, a, 1);
    }
  }
  world.box(a.x - half, slab, a.z - half, a.x + half, slab, a.z + half, shade(C.ironwood, 0.9), {
    t: reveal(a, 0.56),
    dur: FADE,
  });
}

/**
 * The apse behind the throne: a gilded screen with an arched niche, a stepped gold plinth for
 * the dais to sit against, and a lamp row that reads as a halo from the nave.
 *
 * `a.y` is the deck row; `a.z` is the inner face of the rear wall. Footprint x ± half.
 */
export function throneNiche(world: VoxelWorld, a: BuilderArgs): void {
  const half = Math.max(4, Math.round(num(a, 'half', 9, 4, 14)));
  const y0 = Math.round(num(a, 'floorRow', HALL.floorRow, 2, 150));
  const top = Math.round(num(a, 'topRow', y0 + 11, 4, 151));
  for (let d = -half; d <= half; d++) {
    for (let t = 0; t < 2; t++) {
      const z = a.z - t;
      const arch = Math.round(Math.max(0, Math.abs(d) - 2) * 0.55);
      for (let y = y0; y <= top - arch; y++) {
        const bright = Math.abs(d) <= 3 || y === y0 || y === top - arch;
        if (bright) gild(world, a.x + d, y, z, 0.44 + t * 0.02, a, 1);
        else world.set(a.x + d, y, z, shade(C.lacquerLite, 0.8 + 0.14 * hash3(a.x + d, y, z, a.seed)), {
          t: reveal(a, 0.46),
          dur: FADE,
        });
      }
    }
  }
  for (let d = -3; d <= 3; d++) {
    world.set(a.x + d, y0 + 2, a.z - 2, C.lantern, { kind: Kind.Glow, glow: 0.7, t: reveal(a, 0.96), dur: 0.5 });
  }
}

/**
 * A porch over the doorway: four gilded columns on the deck, a lintel band and one small
 * curved roof, so the camera passes under a roofline on its way in. Columns stand at
 * x ± (doorHalf+1) and x ± (doorHalf+6), one row in front of the wall face.
 */
export function portico(world: VoxelWorld, a: BuilderArgs): void {
  const y0 = num(a, 'floorRow', HALL.floorRow, 2, 140);
  const top = num(a, 'porchRow', HALL.headerRow + 3, 4, 150);
  const z0 = num(a, 'porchRow0', HALL.doorRow + 1, 2, 150);
  for (const dz of [0, 4]) {
    for (const s of [-1, 1]) {
      for (const d of [HALL.doorHalf + 1, HALL.doorHalf + 6]) {
        post(world, a, a.x + s * d, z0 + dz, y0, top, 0.2 + dz * 0.02, C.lacquer);
      }
    }
  }
  for (const s of [-1, 1]) {
    for (let d = HALL.doorHalf + 1; d <= HALL.doorHalf + 6; d++) {
      gild(world, a.x + s * d, top + 1, z0, 0.5, a, 1);
      gild(world, a.x + s * d, top + 1, z0 + 4, 0.5, a, 1);
    }
  }
  for (let x = a.x - HALL.doorHalf - 6; x <= a.x + HALL.doorHalf + 6; x++) {
    for (let z = z0; z <= z0 + 4; z++) gild(world, x, top + 2, z, 0.56, a, (x + z) % 2 === 0 ? 1 : 0);
  }
  curvedRoof(world, a, {
    cx: a.x,
    cz: z0 + 2,
    hx: HALL.doorHalf + 7,
    hz: 4,
    y0: top + 3,
    rise: 4,
    lift: 2,
    f0: 0.62,
    f1: 0.8,
    seed: a.seed + 31,
  });
}

/**
 * The stack above the hall: two lacquered tiers, each bracketed and roofed, and the finial.
 * `a.y` is the row directly above the ceiling slab. The tiers are hollow shells — the room
 * below is the only interior the camera ever sees. Footprint x ± (half+3).
 */
export function upperTiers(world: VoxelWorld, a: BuilderArgs): void {
  const tiers: ReadonlyArray<[number, number, number, number, number, number]> = [
    // [half, height, eave rise, corner lift, f0, f1]
    [12, 10, 7, 4, 0.1, 0.34],
    [9, 7, 5, 3, 0.4, 0.62],
  ];
  let y = a.y;
  for (const [half, h, rise, lift, f0, f1] of tiers) {
    for (let t = 0; t < h; t++) {
      const row = y + t;
      const fr = f0 + (f1 - f0) * (t / Math.max(1, h - 1));
      for (let d = -half; d <= half; d++) {
        for (const [x, z] of [
          [a.x + d, a.z - half],
          [a.x + d, a.z + half],
          [a.x - half, a.z + d],
          [a.x + half, a.z + d],
        ] as const) {
          const corner = Math.abs(d) === half;
          if (corner) {
            post(world, a, x, z, y, y + h - 1, fr, C.lacquer);
            continue;
          }
          const window = (d + 100) % 4 === 0 && t > 1 && t < h - 2;
          if (window) {
            if (t % 2 === 0) gild(world, x, row, z, fr, a, 1);
            else
              world.set(x, row, z, C.lanternCore, { kind: Kind.Glow, glow: 0.55, t: reveal(a, fr), dur: FADE });
            continue;
          }
          world.set(
            x,
            row,
            z,
            shade(t % 3 === 0 ? C.lacquerLite : C.lacquer, 0.82 + 0.1 * hash3(x, row, z, a.seed)),
            { t: reveal(a, fr), dur: FADE },
          );
        }
      }
    }
    band(world, a, half, y + h, f1 + 0.02);
    brackets(world, a, a.x, a.z, half, y + h + 1, 3, f1 + 0.04);
    y =
      curvedRoof(world, a, {
        cx: a.x,
        cz: a.z,
        hx: half + 3,
        hz: half + 3,
        y0: y + h + 2,
        rise,
        lift,
        f0: f1 + 0.06,
        f1: f1 + 0.2,
        seed: a.seed + half,
      }) + 2;
  }
  finial(world, { ...a, y: y - 1, t: a.t + a.dt * 0.86, dt: a.dt * 0.14 });
}

/**
 * One door leaf as a movable model, so the pair can swing open on camera.
 *
 * Authored hinge-side: column 0 is the hinge strap, the leaf body runs along +x, and the face
 * plane is local z 2 with straps and the ring handle at z 3. `center` puts the pivot on the
 * hinge column, so the stage rotates the holder about the hinge and the leaf's bottom row sits
 * on the deck when the holder is at `wy(HALL.floorRow) + 0.5`.
 *
 * Boarding is `C.ironwood` / `C.ironwoodLite`; two iron bands, a gilded lattice in the upper
 * third, a field of studs and a ring handle at the meeting edge. `w` cells wide (default 5),
 * `h` rows tall (default 11 = the clear opening).
 */
export function makeDoorLeaf(seed: number, o: { w?: number; h?: number } = {}): MovableModel {
  const w = Math.max(3, Math.min(8, Math.round(o.w ?? 5)));
  const h = Math.max(6, Math.min(14, Math.round(o.h ?? 11)));
  const world = new VoxelWorld(w + 2, h, 4);
  const d = rng(seed * 2246822519);
  const put = (x: number, y: number, z: number, hex: number, f: number): void => {
    world.set(x, y, z, hex, { t: f, dur: FADE });
  };
  // hinge strap first, then the boards, then iron, then gild
  for (let y = 0; y < h; y++) put(0, y, 2, shade(C.bronze, 0.9 + 0.1 * (y % 2)), 0.04 + 0.1 * (y / h));
  for (let x = 1; x <= w; x++) {
    for (let y = 0; y < h; y++) {
      const board = (x + (seed % 3)) % 2 === 0;
      put(
        x,
        y,
        2,
        shade(board ? C.ironwoodLite : C.ironwood, 0.76 + 0.16 * d()),
        0.1 + 0.35 * ((x - 1) / (w - 1)),
      );
    }
  }
  for (const iron of [1, Math.round(h * 0.45), h - 2]) {
    for (let x = 1; x <= w; x++) put(x, iron, 3, shade(C.bronze, 0.86 + 0.1 * hash3(x, iron, 3, seed)), 0.5);
  }
  for (let x = 1; x <= w; x++) {
    for (let y = Math.round(h * 0.6); y <= h - 3; y++) {
      if ((x + y) % 2 === 0) put(x, y, 3, C.goldDeep, 0.62);
    }
  }
  for (let x = 1; x <= w; x++) {
    for (let y = 2; y <= h - 3; y += 3) put(x, y, 3, C.goldLite, 0.72);
  }
  // ring handle at the meeting edge
  const hy = Math.round(h * 0.42);
  for (const [x, y] of [
    [w, hy - 1],
    [w, hy],
    [w, hy + 1],
    [w - 1, hy + 1],
  ] as const) {
    put(x, y, 3, C.gold, 0.9);
  }
  put(w, hy, 3, C.goldLite, 0.96);
  return { world, center: [0.5, 0, 2.5], dt: 0.9 };
}
