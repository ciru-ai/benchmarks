import { Kind, VoxelWorld } from '../core/VoxelWorld';
import { C, hash3, mixHex, rng, shade } from '../core/palette';
import { BuilderArgs, FADE, MovableModel, opt, reveal } from './types';

/**
 * Garden furniture and living models.
 *
 * Static builders dress the apron and the shore: stone lanterns and a moored punt.
 * Movable builders fill a small private world around a declared pivot so the scene can
 * mesh once and drive the Object3D (koi, pilgrim, crane).
 */

// ------------------------------------------------------------------ helpers

/**
 * Local frame for every directional static builder: `u` runs along the object's long axis,
 * `v` across it. `dir` 0 = +x, 1 = +z, 2 = -x, 3 = -z.
 */
function orient(dir: number, a: BuilderArgs, u: number, v: number): [number, number] {
  // Grid writes must land on whole cells, so a half-cell-centred run is snapped here.
  const uu = Math.round(u);
  const vv = Math.round(v);
  switch (((Math.round(dir) % 4) + 4) % 4) {
    case 0:
      return [a.x + uu, a.z + vv];
    case 1:
      return [a.x + vv, a.z + uu];
    case 2:
      return [a.x - uu, a.z - vv];
    default:
      return [a.x - vv, a.z + uu];
  }
}

/** Deterministic per-cell tint so a run of identical timber never reads as plastic. */
function tint(hex: number, x: number, y: number, z: number, amount = 0.09): number {
  return shade(hex, 1 + (hash3(x, y, z, 21) - 0.5) * 2 * amount);
}

// ------------------------------------------------------------------ stone lantern

/**
 * Hexagonal snow-view lantern, exactly `h` rows tall: footing, shaft, flared platform, a
 * light box of four posts around a lit core, and a cap whose eave tips curl up to a gold
 * finial. Extra height past the minimum goes to the shaft first, then to the light box.
 */
export function stoneLantern(world: VoxelWorld, a: BuilderArgs): void {
  const h = Math.max(6, Math.round(opt(a, 'h', 6)));
  const { x, y, z } = a;
  const extra = h - 6;
  const shaftGrow = Math.ceil(extra * 0.55);
  const boxGrow = extra - shaftGrow;
  const put = (f: number) => ({ t: reveal(a, f), dur: FADE });

  // footing: low disc, the darkest stone in the piece
  world.disc(x, z, 2.4, y, shade(C.stone, 0.6), put(0));
  world.disc(x, z, 1.6, y, C.stone, put(0.02));

  // shaft: rounded column (plus-section) with a darker collar at the top
  const shaftTop = y + 1 + shaftGrow;
  for (let r = y + 1; r <= shaftTop; r++) {
    world.set(x, r, z, C.stoneLite, put(0.1 + 0.05 * (r - y)));
    for (const [dx, dz] of ARMS)
      world.set(x + dx, r, z + dz, shade(C.stoneLite, 0.92), put(0.12));
  }
  world.set(x, shaftTop, z, shade(C.stone, 0.86), put(0.3));

  // platform: overhanging slab, corners knocked back a shade
  const py = shaftTop + 1;
  world.box(x - 1, py, z - 1, x + 1, py, z + 1, C.stoneLite, put(0.4));
  for (const [dx, dz] of CORNERS) world.set(x + dx, py, z + dz, shade(C.stoneLite, 0.8), put(0.4));

  // light box: four corner posts, lit paper on the four faces, a bright core behind it
  const ly = py + 1;
  const lTop = ly + boxGrow;
  for (let r = ly; r <= lTop; r++) {
    for (const [dx, dz] of CORNERS) world.set(x + dx, r, z + dz, shade(C.stone, 0.84), put(0.55));
    for (const [dx, dz] of ARMS)
      world.set(x + dx, r, z + dz, C.lantern, { kind: Kind.Glow, glow: 0.7, ...put(0.86) });
  }
  world.set(x, ly, z, C.lanternCore, { kind: Kind.Glow, glow: 1, ...put(0.95) });

  // cap: hipped slab at `cy`, eave tips curling one row higher into the gold finial
  const cy = lTop + 1;
  world.box(x - 1, cy, z - 1, x + 1, cy, z + 1, C.tileDeep, put(0.7));
  for (const [dx, dz] of ARMS) world.set(x + dx, cy, z + dz, shade(C.tile, 0.72), put(0.74));
  for (const [dx, dz] of ARMS) world.set(x + dx, cy + 1, z + dz, C.tileRim, put(0.82));
  world.set(x, cy + 1, z, C.gold, put(1));
}

const ARMS: ReadonlyArray<readonly [number, number]> = [
  [-1, 0],
  [1, 0],
  [0, -1],
  [0, 1],
];

const CORNERS: ReadonlyArray<readonly [number, number]> = [
  [-1, -1],
  [-1, 1],
  [1, -1],
  [1, 1],
];

// ------------------------------------------------------------------ boat

/** Flat-bottomed punt: sheer line lifting at both ends, a woven canopy, a resting pole. */
export function boat(world: VoxelWorld, a: BuilderArgs): void {
  const dir = Math.floor(opt(a, 'dir', 0));
  const len = Math.min(14, Math.max(6, Math.round(opt(a, 'len', 9))));
  const put = (f: number) => ({ t: reveal(a, f), dur: FADE });
  const half = Math.floor((len - 1) / 2);

  // hull: floor planking with an open interior, gunwale at the waterline
  for (let u = 0; u < len; u++) {
    const k = len > 1 ? u / (len - 1) : 0.5;
    const tip = u === 0 || u === len - 1;
    const hw = tip ? 0 : 1;
    const fy = a.y + (tip ? 1 : 0); // sheer rises at the ends
    const f = 0.05 + 0.5 * Math.abs(k - 0.5) * 2;
    for (let v = -hw; v <= hw; v++) {
      const [wx, wz] = orient(dir, a, u - half, v);
      world.set(wx, fy, wz, tint(shade(C.woodDark, tip ? 1.1 : 1), wx, fy, wz), put(f));
      if (!tip && Math.abs(v) === 1)
        world.set(wx, a.y + 1, wz, tint(C.wood, wx, a.y + 1, wz), put(f + 0.08));
    }
    // thwarts across the open hull
    if (!tip && (u === half - 1 || u === half + 1)) {
      const [wx, wz] = orient(dir, a, u - half, 0);
      world.set(wx, a.y + 1, wz, shade(C.wood, 1.12), put(f + 0.12));
    }
  }

  // canopy: three arched ribs over the middle seat, thatched in faded straw
  for (const du of [-1, 0, 1]) {
    for (const s of [-1, 1]) {
      const [wx, wz] = orient(dir, a, du, s);
      world.set(wx, a.y + 2, wz, tint(shade(C.sand, 0.82), wx, a.y + 2, wz), put(0.55));
    }
  }
  for (let u = -1; u <= 1; u++) {
    const [wx, wz] = orient(dir, a, u, -1);
    world.set(wx, a.y + 3, wz, tint(C.sand, wx, a.y + 3, wz), put(0.68));
    const [wx2, wz2] = orient(dir, a, u, 1);
    world.set(wx2, a.y + 3, wz2, tint(C.sand, wx2, a.y + 3, wz2), put(0.68));
  }
  for (let u = -1; u <= 1; u++) {
    const [wx, wz] = orient(dir, a, u, 0);
    world.set(wx, a.y + 4, wz, tint(shade(C.sand, 1.1), wx, a.y + 4, wz), put(0.74));
  }

  // pole: laid along the stern, one end lifted onto the gunwale
  const [p0x, p0z] = orient(dir, a, half - 1, 1);
  const [p1x, p1z] = orient(dir, a, -half + 2, 1);
  world.beam([p0x, a.y + 2, p0z], [p1x, a.y + 5, p1z], 1, C.bark, put(0.88));
}

// --------------------------------------------------------------- movable models

/** Seconds a movable model needs to arrive; the scene offsets its whole reveal clock. */
const M_DT = 1.15;

/** Local reveal window for a part of a movable model — `f` 0 = first, 1 = last. */
function mput(f: number): { t: number; dur: number } {
  return { t: Math.max(0, Math.min(1, f)) * M_DT * 0.72, dur: FADE };
}

/**
 * A koi swimming along +x in its own 14×4×5 world, pivot at the body centre. Vermilion
 * blankets are drawn from `seed`, so no two koi match, and the belly row is shaded down so
 * the fish reads correctly when the camera passes below it.
 */
export function makeKoi(seed: number): MovableModel {
  const world = new VoxelWorld(14, 4, 5);
  const d = rng(seed * 40503);
  const patches: Array<[number, number]> = [];
  for (let i = 0; i < 3; i++) {
    patches.push([5 + Math.floor(d() * 7), 1 + Math.floor(d() * 2)]);
  }
  const painted = (x: number, y: number): boolean =>
    patches.some((p) => Math.abs(x - p[0]) <= 1 && y === p[1]);
  const fin = mixHex(C.paper, C.mist, 0.4);
  for (let x = 2; x <= 13; x++) {
    const hw = x >= 13 ? 1 : x === 12 || x <= 4 ? 0 : 1;
    const f = 0.06 + 0.6 * ((13 - x) / 13);
    for (let y = 1; y <= 2; y++) {
      const base = painted(x, y) ? C.vermilion : C.paper;
      const hex = y === 1 ? shade(base, 0.72) : base;
      for (let z = 2 - hw; z <= 2 + hw; z++) world.set(x, y, z, hex, mput(f));
    }
  }
  // dorsal fin: a thin plate along the spine
  for (let x = 7; x <= 10; x++) {
    world.set(x, 3, 2, painted(x, 2) ? shade(C.vermilion, 0.86) : fin, mput(0.74));
  }
  // pectoral and pelvic fins, symmetric about the mid-plane
  for (const px of [11, 7]) {
    for (const pz of [0, 4]) world.set(px, 1, pz, fin, mput(0.8));
  }
  // forked caudal fin — the lobes mirror about the body's centre height
  world.set(1, 1, 2, shade(C.paper, 0.9), mput(0.4));
  world.set(1, 2, 2, C.paper, mput(0.4));
  world.set(0, 0, 2, mixHex(C.paper, C.ink, 0.34), mput(0.52));
  world.set(0, 3, 2, mixHex(C.paper, C.ink, 0.34), mput(0.52));
  // eyes
  world.set(13, 2, 1, C.ink, mput(0.92));
  world.set(13, 2, 3, C.ink, mput(0.92));
  return { world, center: [8, 2, 2.5], dt: M_DT };
}

/**
 * A robed pilgrim walking along +x in a 4×9×4 world, pivot at the feet. The body is
 * symmetric about both centre planes; the carrying pole runs across the shoulders with a
 * cloth bindle on each end, so the figure stays balanced when the scene turns it.
 */
export function makePilgrim(seed: number): MovableModel {
  const world = new VoxelWorld(4, 9, 4);
  const d = rng(seed * 2654435761);
  const robe = d() < 0.5 ? C.tile : shade(C.slate, 0.92);
  const sash = d() < 0.5 ? C.vermilionDeep : C.lacquer;
  const skin = mixHex(C.paper, C.sand, 0.4);
  for (let x = 1; x <= 2; x++) {
    for (let z = 1; z <= 2; z++) world.set(x, 0, z, shade(C.bark, 0.86), mput(0.02));
  }
  for (let y = 1; y <= 4; y++) {
    const hex = y === 4 ? sash : y <= 2 ? shade(robe, 0.76) : robe;
    for (let x = 1; x <= 2; x++) {
      for (let z = 1; z <= 2; z++) world.set(x, y, z, tint(hex, x, y, z, 0.05), mput(0.12));
    }
  }
  // sleeves hang at the sides, one column out
  for (let y = 3; y <= 4; y++) {
    for (const sx of [0, 3]) {
      for (let z = 1; z <= 2; z++) world.set(sx, y, z, shade(robe, 0.88), mput(0.5));
    }
  }
  world.box(1, 5, 1, 2, 5, 2, tint(C.slate, 1, 5, 1, 0.05), mput(0.56));
  world.box(1, 6, 1, 2, 6, 2, skin, mput(0.66));
  // conical straw hat: wide brim ring, then the crown
  for (let x = 0; x <= 3; x++) {
    for (let z = 0; z <= 3; z++) {
      if ((x === 0 || x === 3) && (z === 0 || z === 3)) continue;
      world.set(x, 7, z, tint(shade(C.paper, 0.58), x, 7, z, 0.06), mput(0.8));
    }
  }
  world.box(1, 8, 1, 2, 8, 2, shade(C.paper, 0.52), mput(0.9));
  // carrying pole across the shoulders with a bindle at each end
  for (let z = 0; z <= 3; z++) world.set(3, 5, z, shade(C.bark, 0.94), mput(0.96));
    world.set(3, 4, 0, shade(C.paper, 0.5), mput(1));
    world.set(3, 4, 3, shade(C.paper, 0.5), mput(1));
  return { world, center: [2, 0, 2], dt: M_DT };
}

/**
 * A white crane flying along +x in a 20×6×17 world, pivot at the body centre. The wings are
 * level plates at the shoulder row, swept back, with ink flight feathers at the tips; the
 * legs trail tucked under the tail. Left and right wings mirror about the mid-plane so the
 * scene's wing bob reads evenly from either side.
 */
export function makeCrane(seed: number): MovableModel {
  const world = new VoxelWorld(20, 6, 17);
  const flight = rng(seed * 2246822519)() < 0.5 ? C.ink : mixHex(C.ink, C.tileDeep, 0.45);
  // the birds read as paper cut-outs, so the feather colour is held under the bake that
  // would otherwise blow them out to white against a night sky
  const plume = shade(C.paper, 0.42);
  const mid = 8;
  for (let x = 5; x <= 14; x++) {
    const hw = x === 5 || x === 14 ? 0 : 1;
    const f = 0.04 + 0.3 * ((14 - x) / 12);
    for (let y = 2; y <= 3; y++) {
      const hex = y === 2 ? shade(plume, 0.78) : plume;
      for (let z = mid - hw; z <= mid + hw; z++) world.set(x, y, z, hex, mput(f));
    }
  }
  // shoulders blend the wing plates into the body
  for (const sz of [mid - 2, mid + 2]) {
    for (let x = 10; x <= 11; x++) world.set(x, 3, sz, shade(plume, 0.92), mput(0.42));
  }
  for (let j = 1; j <= 8; j++) {
    const chord = j <= 2 ? 3 : j <= 4 ? 2 : 1;
    const hex = j >= 6 ? flight : j >= 3 ? shade(plume, 0.96) : plume;
    const f = 0.46 + 0.42 * (j / 8);
    for (let x = 12 - chord; x <= 11; x++) {
      for (const sz of [mid + j, mid - j]) {
        world.set(x, 4, sz, tint(hex, x, 4, sz, 0.05), mput(f));
      }
    }
  }
  // ink tail coverts
  for (const sz of [mid - 1, mid, mid + 1]) world.set(4, 3, sz, C.ink, mput(0.78));
  for (const sz of [mid - 1, mid + 1]) world.set(3, 3, sz, shade(flight, 1.35), mput(0.8));
  // neck rises to the head, red crown, pale beak
  world.set(15, 3, mid, plume, mput(0.6));
  world.set(16, 3, mid, plume, mput(0.66));
  world.set(17, 4, mid, plume, mput(0.72));
  world.set(18, 4, mid, shade(plume, 0.98), mput(0.84));
  world.set(18, 5, mid, C.vermilion, mput(0.92));
  world.set(19, 4, mid, shade(C.gravel, 0.92), mput(0.9));
  // legs tucked straight back
  for (const sz of [mid - 1, mid + 1]) {
    for (let x = 4; x <= 8; x++) world.set(x, 1, sz, shade(C.slate, 0.82), mput(0.86));
    world.set(3, 1, sz, C.ink, mput(0.94));
  }
  return { world, center: [10, 3, 8.5], dt: M_DT };
}
