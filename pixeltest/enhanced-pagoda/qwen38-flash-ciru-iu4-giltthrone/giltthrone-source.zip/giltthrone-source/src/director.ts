import { T, LOOP } from './core/schedule';
import { clamp, lerp, smoothstep } from './core/palette';

/**
 * The director: one pure function from loop-seconds to every look value — sky, fog, grade,
 * reveal/draw-back, reliquary, arc, particles, bloom. Nothing animates anywhere else, so the
 * film and the interactive tour are the same piece of timing.
 */

interface SkyKey {
  t: number;
  top: number;
  horizon: number;
  bottom: number;
  stars: number;
  haze: number;
}

/** Keyfranked because the moods are authored, not interpolated blindly: void → the fall's flare
 *  → cast gold → the hall's own light → clear night with the grove burning green → void. */
const SKY: SkyKey[] = [
  { t: 0.0, top: 0x04050a, horizon: 0x0a0b13, bottom: 0x020306, stars: 0.88, haze: 0.1 },
  { t: 3.4, top: 0x0a0a12, horizon: 0x3a2a17, bottom: 0x040408, stars: 0.5, haze: 0.3 },
  { t: 6.3, top: 0x0d0c14, horizon: 0x5c3d1d, bottom: 0x05050a, stars: 0.34, haze: 0.34 },
  { t: 11.6, top: 0x141119, horizon: 0x8a6229, bottom: 0x07070c, stars: 0.14, haze: 0.4 },
  { t: 16.2, top: 0x121019, horizon: 0x6b4c28, bottom: 0x06060b, stars: 0.18, haze: 0.38 },
  { t: 21.8, top: 0x101018, horizon: 0x53402c, bottom: 0x060609, stars: 0.3, haze: 0.42 },
  { t: 27.0, top: 0x080c17, horizon: 0x2a3a3f, bottom: 0x04060a, stars: 0.8, haze: 0.36 },
  { t: 31.0, top: 0x050810, horizon: 0x16202c, bottom: 0x030408, stars: 1.0, haze: 0.26 },
  { t: 34.4, top: 0x04050c, horizon: 0x0d1119, bottom: 0x020307, stars: 0.94, haze: 0.14 },
  { t: LOOP, top: 0x04050a, horizon: 0x0a0b13, bottom: 0x020306, stars: 0.88, haze: 0.1 },
];

interface NumKey {
  t: number;
  v: number;
}

function keysAt(keys: NumKey[], t: number): number {
  let i = 0;
  while (i < keys.length - 2 && t > keys[i + 1].t) i++;
  const a = keys[i];
  const b = keys[i + 1];
  const k = smoothstep(a.t, b.t, t);
  return lerp(a.v, b.v, k);
}

function channel(hex: number, shift: number): number {
  return (hex >> shift) & 255;
}

function skyAt(t: number): { top: number; horizon: number; bottom: number; stars: number; haze: number } {
  let i = 0;
  while (i < SKY.length - 2 && t > SKY[i + 1].t) i++;
  const a = SKY[i];
  const b = SKY[i + 1];
  const k = smoothstep(a.t, b.t, t);
  const blend = (x: number, y: number) => Math.round(lerp(x, y, k));
  const mix = (x: number, y: number) =>
    (blend(channel(x, 16), channel(y, 16)) << 16) |
    (blend(channel(x, 8), channel(y, 8)) << 8) |
    blend(channel(x, 0), channel(y, 0));
  return {
    top: mix(a.top, b.top),
    horizon: mix(a.horizon, b.horizon),
    bottom: mix(a.bottom, b.bottom),
    stars: lerp(a.stars, b.stars, k),
    haze: lerp(a.haze, b.haze, k),
  };
}

/** Exposure rides the amount of sky in frame: the valley reads brightest, a closed room the
 *  dimmest. The hall is authored near-white so its roof reads in the dark, so pushing exposure
 *  up inside only clips the frame — the lamps, not the exposure, are what light the nave. */
const EXPOSURE: NumKey[] = [
  { t: 0, v: 0.74 },
  { t: 3.4, v: 0.92 },
  { t: 11.6, v: 1.04 },
  { t: 19.4, v: 1.0 },
  { t: 22.4, v: 0.98 },
  { t: 26.6, v: 1.0 },
  { t: 30.6, v: 0.98 },
  { t: 33.0, v: 0.94 },
  { t: 35.7, v: 0.74 },
];

/** 1 = monochrome cast, 0 = full pigment. The pigment bleeds out from the impact. */
const GRADE: NumKey[] = [
  { t: 0, v: 1 },
  { t: T.impact.start, v: 1 },
  { t: 16.2, v: 0.34 },
  { t: T.life.start, v: 0.04 },
  { t: 33.0, v: 0.04 },
  { t: 35.2, v: 1 },
  { t: LOOP, v: 1 },
];

const FOG_NEAR: NumKey[] = [
  { t: 0, v: 240 },
  { t: 6.3, v: 300 },
  { t: 19.4, v: 380 },
  { t: 22.4, v: 46 },
  { t: 26.6, v: 52 },
  { t: 30.6, v: 360 },
  { t: 33.0, v: 520 },
  { t: 35.2, v: 240 },
  { t: LOOP, v: 240 },
];

const FOG_FAR: NumKey[] = [
  { t: 0, v: 1050 },
  { t: 6.3, v: 1450 },
  { t: 19.4, v: 2000 },
  { t: 22.4, v: 420 },
  { t: 26.6, v: 480 },
  { t: 30.6, v: 1900 },
  { t: 33.0, v: 2700 },
  { t: 35.2, v: 1050 },
  { t: LOOP, v: 1050 },
];

/** The wider land mass, hidden until the pull-back leaves the reliquary. */
const OUTER: NumKey[] = [
  { t: 0, v: 0 },
  { t: 29.6, v: 0 },
  { t: 32.2, v: 1 },
  { t: 34.6, v: 1 },
  { t: 35.6, v: 0 },
  { t: LOOP, v: 0 },
];

export interface Look {
  /** 1 = monochrome cast, 0 = full pigment */
  ink: number;
  /** radius the pigment has bled to */
  colorFront: number;
  /** 0..1 draw-back */
  dissolve: number;
  swirl: number;
  sway: number;
  water: number;
  glowGain: number;
  exposure: number;
  /** multiplier on authored surfaces while the camera is inside the hall (1 = outside) */
  roomDim: number;
  /** the wider land mass, hidden until the pull-back */
  outerGain: number;
  sky: { top: number; horizon: number; bottom: number; stars: number; haze: number };
  fogHex: number;
  fogNear: number;
  fogFar: number;
  /** how much of the cast-glass reliquary is still standing */
  glass: number;
  /** how far inside the doors the camera is, 0 outside → 1 at the throne */
  interior: number;
  /** the arc of light the gold is drawn back along */
  arcPaint: number;
  arcHead: number;
  arcGlow: number;
  arcAlpha: number;
  /** the thread of gold falling into the reliquary at the start */
  thread: number;
  /** the lake's wake from the landing */
  splash: number;
  /** fluorescent spores off the caps */
  spores: number;
  motes: number;
  bloom: number;
}

export function look(t: number): Look {
  const impact = T.impact;
  const bleed = smoothstep(impact.start, impact.start + impact.dur + 3.4, t);
  const sky = skyAt(t);
  const inDoors = smoothstep(T.doors.start - 1.4, T.inside.start + 1.2, t);
  const outAgain = smoothstep(T.lift.start, T.lift.start + 2.2, t);

  return {
    ink: keysAt(GRADE, t),
    colorFront: 60 + bleed * 1080,
    sky,
    fogHex: sky.horizon,
    fogNear: keysAt(FOG_NEAR, t),
    fogFar: keysAt(FOG_FAR, t),
    dissolve: smoothstep(T.draw.start + 0.15, T.draw.start + T.draw.dur - 0.1, t) * 1.4,
    swirl: smoothstep(T.draw.start, T.draw.start + 1.3, t) * (1 - smoothstep(35.2, 35.9, t)),
    sway:
      smoothstep(T.grove.start + 1.2, T.life.start, t) *
      (0.62 + 0.38 * Math.sin(t * 0.42)) *
      (1 - smoothstep(T.lift.start + 1.0, T.lift.start + 2.6, t)),
    water: smoothstep(impact.start, impact.start + 1.8, t),
    glowGain: clamp(
      smoothstep(impact.start, impact.start + impact.dur, t) * (0.86 + 0.14 * inDoors * (1 - outAgain)),
      0,
      1.0,
    ),
    exposure: keysAt(EXPOSURE, t),
    roomDim: 1 - 0.8 * inDoors * (1 - outAgain),
    outerGain: keysAt(OUTER, t),
    glass: 1 - smoothstep(T.draw.start + 0.4, LOOP - 0.3, t),
    interior: inDoors * (1 - outAgain),
    arcPaint: smoothstep(T.lift.start + 0.4, T.draw.start, t),
    arcHead: smoothstep(T.lift.start, T.draw.start + T.draw.dur * 0.6, t),
    arcGlow: smoothstep(T.lift.start + 0.6, T.lift.start + 2.4, t) * (1 - smoothstep(35.0, 35.8, t)),
    arcAlpha: 1 - smoothstep(35.2, LOOP - 0.2, t),
    thread: smoothstep(0.2, 1.4, t) * (1 - smoothstep(impact.start - 0.2, impact.start + 0.5, t)),
    splash: smoothstep(impact.start, impact.start + 0.7, t) * (1 - smoothstep(impact.start + 1.6, impact.start + 4.2, t)),
    spores: smoothstep(T.grove.start + 1.6, T.life.start, t) * (1 - smoothstep(T.draw.start, LOOP - 0.4, t)),
    motes: 0.2 + 0.8 * inDoors * (1 - outAgain),
    bloom:
      (0.5 + 0.45 * smoothstep(impact.start, impact.start + 1.0, t) * (1 - smoothstep(33.0, 35.4, t))) *
      (1 - 0.72 * inDoors * (1 - outAgain)),
  };
}
