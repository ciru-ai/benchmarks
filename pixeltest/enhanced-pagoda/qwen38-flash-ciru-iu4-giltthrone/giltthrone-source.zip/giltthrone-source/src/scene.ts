import { VoxelWorld } from './core/VoxelWorld';
import { C, rng } from './core/palette';
import { LAKE_ROW, LAKE_R, HALL, MON } from './core/layout';
import { makeSchedule } from './core/schedule';
import { BuilderArgs } from './builds/types';
import * as land from './builds/land';
import * as flora from './builds/flora';
import * as arch from './builds/pagoda';
import * as props from './builds/props';
import * as hall from './builds/hall';
import * as treasure from './builds/treasure';
import * as regalia from './builds/regalia';

/**
 * The whole piece in one authored pair of worlds.
 *
 * Nothing here animates by hand: geometry is authored once into `VoxelWorld`s with a reveal
 * second per voxel, and every actor (koi, pilgrim, crane, lanterns, shell) is a pure function of
 * the loop clock, so `seek(t)` reproduces any frame exactly.
 *
 * Composition: a dead grove on a terraced island, a gold hall cast dead centre with its doorway
 * facing the processional stair, and the fungus — hundreds of cells of it — on every fallen log.
 */

// grid anchors inside the drop (1 cell = 1 world unit, origin at INNER.origin)
const CX = MON.col; // island centre column — the axis the monument stands on
const CZ = MON.row; // island centre row-in-plan
const WATER = LAKE_ROW; // 60 — the lake sheet inside the drop
const SHELF = 68; // lower garden surface, eight rows of cliff above the water
const CROWN = 86; // monument terrace surface

const sched = makeSchedule();

const PLAZA = { x: 80, z: 126, r: 9 }; // arrival plaza on the shore, foot of the stair
const APRON = { x: 80, z: 112, r: 7 }; // mid landing between the plaza and the terrace
const GATE = { x: 80, z: 134 }; // mountain gate at the water the barge lands at
const POND = { x: 104, z: 100, r: 9 }; // kettle pond carved into the shelf
const CHUTE = { x: 100, z: 92 }; // where the overflow falls toward the lake
const GROVE = { x: 56, z: 62, r: 12 }; // the old log grove below the terrace
const JETTY = { x: 92, z: 140 }; // where the barge lies off the gate

/** The approach walk, in grid columns: barge landing, plaza, then the foot of the stair. */
export const PATH: [number, number][] = [
  [GATE.x, GATE.z - 2],
  [GATE.x - 6, 131],
  [PLAZA.x - 2, PLAZA.z + 2],
  [PLAZA.x, PLAZA.z - 5],
];

/** Build the argument object every builder expects. */
function args(
  x: number,
  z: number,
  y: number,
  t: number,
  dt: number,
  seed: number,
  opts?: Record<string, number>,
): BuilderArgs {
  return { x, z, y, dt, t, seed, opts };
}

/** First free row above the terrain at a column — where an object should stand. */
function groundOn(world: VoxelWorld, x: number, z: number): number {
  return world.heightAt(x, z);
}

/**
 * Walk `count` deterministic sites in an annulus about the island axis and keep only the ones
 * that are dry (above the water), off the monument terrace and off the processional corridor.
 */
function scatter(
  world: VoxelWorld,
  seed: number,
  count: number,
  rIn: number,
  rOut: number,
  place: (x: number, z: number, r: number) => void,
): void {
  const rand = rng(seed);
  let placed = 0;
  for (let guard = 0; guard < count * 40 && placed < count; guard++) {
    const a = rand() * Math.PI * 2;
    const r = rIn + (rOut - rIn) * Math.sqrt(rand());
    const x = Math.round(CX + Math.sin(a) * r);
    const z = Math.round(CZ + Math.cos(a) * r);
    if (x < 8 || z < 8 || x > 151 || z > 151) continue;
    if (world.heightAt(x, z) <= WATER + 1) continue; // dry ground only
    if (Math.abs(x - MON.col) < 21 && Math.abs(z - MON.row) < 21) continue; // the terrace
    if (Math.abs(x - MON.col) < 6 && z > MON.row + 18) continue; // the stair corridor
    if (Math.hypot(x - POND.x, z - POND.z) < POND.r + 2) continue;
    if (Math.hypot(x - PLAZA.x, z - PLAZA.z) < PLAZA.r - 2) continue;
    placed++;
    place(x, z, rand());
  }
}

// ------------------------------------------------------------------ terrain

export function authorLand(world: VoxelWorld): void {
  const t0 = sched.step('ground', 0, 0.6);

  land.islandMass(world, {
    cx: CX,
    cz: CZ,
    rSea: 52,
    shelfRow: SHELF,
    crownRow: CROWN,
    rCrown: 24,
    rootRow: 20,
    seed: 3,
    t: t0,
  });

  // wet terraces over the shoulder, before the stone platforms cut into them
  land.paddies(world, {
    cx: CX,
    cz: CZ,
    rIn: 26,
    rOut: 33,
    from: SHELF + 1,
    to: CROWN - 2,
    t: sched.step('ground', 0.45, 0.6),
  });

  // the monument's terrace and the arrival plaza, each a flat cap on the slope
  land.shelf(world, {
    cx: MON.col,
    cz: MON.row,
    r: 20,
    row: CROWN,
    t: sched.step('ground', 0.3, 0.5),
    depth: 4,
  });
  land.shelf(world, {
    cx: PLAZA.x,
    cz: PLAZA.z,
    r: PLAZA.r,
    row: 72,
    t: sched.step('ground', 0.38, 0.5),
    depth: 6,
    stone: C.marble,
  });
  land.shelf(world, {
    cx: APRON.x,
    cz: APRON.z,
    r: APRON.r,
    row: 79,
    t: sched.step('ground', 0.42, 0.5),
    depth: 7,
    stone: C.marble,
  });

  // pond, then the chute the pond is fed from, then the lake itself
  land.basin(world, { cx: POND.x, cz: POND.z, r: POND.r, toRow: 54, rimRow: SHELF });
  land.basin(world, { cx: CHUTE.x, cz: CHUTE.z, r: 3, toRow: WATER, rimRow: CROWN - 4 });
  land.cascade(world, {
    cx: CHUTE.x,
    cz: CHUTE.z,
    fromRow: CROWN - 4,
    toRow: WATER,
    r: 2,
    t: sched.step('ground', 0.72, 0.4),
  });
  land.lakeSheet(world, {
    cx: CX,
    cz: CZ,
    r: LAKE_R,
    row: WATER,
    t: sched.step('ground', 0.18, 0.5),
  });

  // the walk: gate → shelf switchbacks → the foot of the processional stair
  land.path(world, PATH, { row: 72, width: 2, t: sched.step('trim', 0.1, 0.5) });
  land.path(world, [[MON.col, 104], [MON.col, 100], [MON.col, HALL.doorRow + 1]], {
    row: CROWN,
    width: 5,
    t: sched.step('trim', 0.2, 0.5),
  });
  land.steppingStones(world, [JETTY.x, JETTY.z - 4], [POND.x + 4, POND.z + 6], {
    row: WATER,
    count: 6,
    t: sched.step('trim', 0.3, 0.4),
  });
}

// ------------------------------------------------------------------ architecture

export function authorMonuments(world: VoxelWorld, seed: number): void {
  // the processional stair: plaza → apron → terrace, two flights on the shared axis
  arch.stair(
    world,
    args(MON.col, 121, groundOn(world, MON.col, 121), sched.step('ground', 0.55, 0.5), 1.3, seed + 11, {
      run: 7,
      rise: 7,
      width: 7,
      dir: 1,
    }),
  );
  arch.stair(
    world,
    args(MON.col, 111, groundOn(world, MON.col, 111), sched.step('ground', 0.62, 0.5), 1.3, seed + 12, {
      run: 8,
      rise: 7,
      width: 7,
      dir: 1,
    }),
  );

  // the gate the barge lands under, and the pavilion the stair pauses beside
  arch.gate(
    world,
    args(GATE.x, GATE.z, groundOn(world, GATE.x, GATE.z), sched.step('trim', 0.0, 0.5), 1.5, seed + 13, {
      half: 5,
    }),
  );
  arch.pavilion(
    world,
    args(APRON.x - 10, APRON.z + 1, groundOn(world, APRON.x - 10, APRON.z + 1), sched.step('trim', 0.3, 0.5), 1.4, seed + 14, {
      half: 5,
    }),
  );

  // lanterns down the processional line, one every few cells of walk
  const rand = rng(seed + 91);
  for (let i = 0; i < PATH.length - 1; i++) {
    const [ax, az] = PATH[i];
    const [bx, bz] = PATH[i + 1];
    for (let s = 0; s < 3; s++) {
      const k = (s + 1) / 4;
      const x = Math.round(ax + (bx - ax) * k);
      const z = Math.round(az + (bz - az) * k);
      const side = s % 2 === 0 ? -1 : 1;
      props.stoneLantern(
        world,
        args(x + side * 3, z, groundOn(world, x + side * 3, z), sched.step('trim', 0.4 + 0.05 * i + 0.02 * s, 0.4), 0.9, seed + 200 + i * 4 + s, {
          h: 6 + Math.floor(rand() * 2),
        }),
      );
    }
  }

  // the barge at the gate, and the rail that fences the terrace's front rim
  props.boat(world, args(JETTY.x, JETTY.z, WATER + 1, sched.step('trim', 0.55, 0.5), 1.2, seed + 15, { dir: 2, len: 11 }));
  arch.railing(
    world,
    args(MON.col, MON.row, CROWN + 1, sched.step('trim', 0.25, 0.4), 1.4, seed + 16, { half: 20, every: 3 }),
  );

  // the hall itself: plinth, envelope, apse, porch, and the stack above
  const cast = sched.step('tiers', 0, 0.55);
  hall.plinth(world, args(MON.col, MON.row, CROWN, cast, 1.6, seed + 30, { half: HALL.half }));
  hall.hallShell(world, args(MON.col, MON.row, HALL.floorRow, sched.step('tiers', 0.25, 0.55), 2.2, seed + 31, { half: HALL.half }));
  hall.throneNiche(world, args(MON.col, HALL.backRow + 1, HALL.floorRow, sched.step('tiers', 0.5, 0.4), 1.4, seed + 32, { half: 9, topRow: HALL.ceilingRow - 1 }));
  hall.portico(world, args(MON.col, MON.row, HALL.floorRow, sched.step('roofs', 0.1, 0.5), 1.5, seed + 33, {}));
  hall.upperTiers(world, args(MON.col, MON.row, HALL.ceilingRow + 2, sched.step('tiers', 0.6, 0.4), 3.0, seed + 34, { half: HALL.half }));
}

// ------------------------------------------------------------------ the treasury

/** Everything the camera only sees from inside, laid out on the hall's own grid. */
export function authorTreasury(world: VoxelWorld, seed: number): void {
  const inlay = sched.step('hall', 0, 0.4);

  // the aisle inlay runs from the doorway to the dais, one row into the deck
  treasure.goldInlay(
    world,
    args(MON.col, Math.round((HALL.backRow + HALL.doorRow) / 2), HALL.floorRow - 1, inlay, 1.2, seed + 40, {
      len: HALL.doorRow - HALL.backRow - 6,
      wide: 5,
      dir: 0,
      every: 4,
    }),
  );

  // four gilded columns carry the ceiling; their shafts stop one row under the slab
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      treasure.goldColumn(
        world,
        args(
          MON.col + sx * 10,
          MON.row + sz * 7,
          HALL.floorRow,
          sched.step('hall', 0.06 + (sz + 1) * 0.04 + (sx + 1) * 0.02, 0.45),
          1.4,
          seed + 41 + (sx + 1) * 2 + (sz + 1),
          { h: 8, r: 2 },
        ),
      );
    }
  }

  // braziers at the foot of the dais, guardian lions outside at the porch
  for (const sx of [-1, 1]) {
    treasure.brazier(
      world,
      args(MON.col + sx * 8, MON.row + 1, HALL.floorRow, sched.step('hall', 0.42, 0.4), 1.1, seed + 50 + (sx + 1), { h: 3 }),
    );
  }
  treasure.lionPair(
    world,
    args(MON.col, HALL.doorRow + 1, HALL.floorRow, sched.step('hall', 0.5, 0.4), 1.3, seed + 52, { off: 7, h: 4, dir: 1 }),
  );

  // coin heaped in the corners of the nave and on the porch deck
  const piles: [number, number, number, number][] = [
    [MON.col - 12, MON.row + 11, 2, 2],
    [MON.col + 12, MON.row + 11, 2, 2],
    [MON.col - 12, MON.row + 4, 2, 1],
    [MON.col + 12, MON.row + 4, 2, 1],
  ];
  piles.forEach(([x, z, r, chests], i) => {
    treasure.treasurePile(
      world,
      args(x, z, HALL.floorRow, sched.step('hall', 0.6 + i * 0.06, 0.45), 1.2, seed + 60 + i, { r, h: 2, chests }),
    );
  });

  // the regalia, in the order the camera meets them
  regalia.dais(
    world,
    args(MON.col, 72, HALL.floorRow, sched.step('hall', 0.16, 0.4), 1.2, seed + 70, { half: 5, steps: 3 }),
  );
  regalia.throne(
    world,
    args(MON.col, 72, HALL.floorRow + 3, sched.step('hall', 0.26, 0.45), 1.4, seed + 71, { h: 6, w: 4 }),
  );
  regalia.sunDisc(
    world,
    args(MON.col, HALL.backRow, 94, sched.step('hall', 0.34, 0.4), 1.2, seed + 72, { r: 3 }),
  );
  regalia.canopy(
    world,
    args(MON.col, 72, HALL.ceilingRow - 1, sched.step('hall', 0.62, 0.4), 1.2, seed + 73, { r: 4, drop: 2 }),
  );
  for (const sx of [-1, 1]) {
    regalia.banner(
      world,
      args(MON.col + sx * 6, 68, HALL.ceilingRow - 1, sched.step('hall', 0.68 + (sx + 1) * 0.03, 0.4), 1.1, seed + 74 + (sx + 1), {
        w: 5,
        len: 8,
        dir: 0,
      }),
    );
  }
  regalia.chandelier(
    world,
    args(MON.col, 84, HALL.ceilingRow - 1, sched.step('hall', 0.76, 0.4), 1.3, seed + 76, { r: 2, h: 3, arms: 8 }),
  );
}

// ------------------------------------------------------------------ the grove

export function authorGrove(world: VoxelWorld, seed: number): number {
  let planted = 0;
  const timber = sched.step('grove', 0, 0.55);
  const fur = sched.step('grove', 0.5, 0.5);

  // standing dead timber on the shoulder, ringed by the flourosh it drops
  scatter(world, seed + 3, 9, 34, 46, (x, z, r) => {
    const h = 9 + Math.floor(r * 7);
    flora.deadTree(world, args(x, z, groundOn(world, x, z), timber + r * 0.5, 1.1, seed + 300 + planted, { h, lean: Math.floor(r * 3) }));
    planted++;
  });

  // the log grove itself: timber felled where it fell, then furred over
  scatter(world, seed + 5, 20, 25, 48, (x, z, r) => {
    flora.fallenLog(
      world,
      args(x, z, groundOn(world, x, z) - 1, fur + r * 0.45, 1.3, seed + 400 + planted, {
        len: 6 + Math.floor(r * 8),
        r: 1 + Math.floor(r * 2),
        dir: Math.floor(r * 8),
        fur: 45 + Math.floor(r * 50),
      }),
    );
    planted++;
  });

  scatter(world, seed + 7, 10, 26, 47, (x, z, r) => {
    flora.flouroshStump(
      world,
      args(x, z, groundOn(world, x, z), fur + 0.2 + r * 0.4, 1.2, seed + 500 + planted, {
        h: 3 + Math.floor(r * 4),
        r: 1 + Math.floor(r * 2),
        fur: 60 + Math.floor(r * 40),
      }),
    );
    planted++;
  });

  scatter(world, seed + 11, 18, 23, 49, (x, z, r) => {
    flora.flouroshPatch(
      world,
      args(x, z, groundOn(world, x, z), fur + 0.35 + r * 0.4, 1.0, seed + 600 + planted, {
        r: 2 + Math.floor(r * 2),
        n: 6 + Math.floor(r * 9),
      }),
    );
    planted++;
  });

  // the living remainder: evergreens on the terrace shoulder, plums by the plaza
  scatter(world, seed + 13, 7, 34, 45, (x, z, r) => {
    flora.pineTree(world, args(x, z, groundOn(world, x, z), timber + r * 0.4, 1.2, seed + 700 + planted, { h: 13 + Math.floor(r * 5) }));
    planted++;
  });
  scatter(world, seed + 17, 4, 34, 43, (x, z, r) => {
    flora.plumTree(world, args(x, z, groundOn(world, x, z), timber + 0.2 + r * 0.4, 1.2, seed + 800 + planted, { h: 8 + Math.floor(r * 3) }));
    planted++;
  });
  scatter(world, seed + 19, 12, 22, 50, (x, z, r) => {
    flora.shrub(world, args(x, z, groundOn(world, x, z), fur + r * 0.3, 0.9, seed + 900 + planted, { r: 2, h: 2 + Math.floor(r * 2) }));
    planted++;
  });
  scatter(world, seed + 23, 16, 21, 50, (x, z, r) => {
    flora.grassTuft(world, args(x, z, groundOn(world, x, z), fur + r * 0.3, 0.8, seed + 1000 + planted));
    planted++;
  });
  scatter(world, seed + 29, 12, 25, 48, (x, z, r) => {
    flora.mossyRock(world, args(x, z, groundOn(world, x, z), timber + r * 0.3, 0.9, seed + 1100 + planted, { r: 1 + Math.floor(r * 2) }));
    planted++;
  });

  // lotus on the pond, and a rock stack at the grove's heart
  flora.lotus(world, args(POND.x, POND.z, WATER + 1, sched.step('life', 0.1, 0.5), 1.2, seed + 1200, { n: 6, h: 5 }));
  flora.rockStack(
    world,
    args(GROVE.x, GROVE.z, groundOn(world, GROVE.x, GROVE.z), timber + 0.1, 1.4, seed + 1201, { h: 11 }),
  );
  planted += 2;
  return planted;
}
