#!/usr/bin/env node
// Deterministic frame capture. Drives window.__seek(t) over CDP and writes one PNG
// per stamp — no dependency on wall-clock animation, so a re-run reproduces frames.
// Usage: capture.mjs --url file://…/index.html --out frames [--fps 30 --duration 32]
//        [--width 1920 --height 1080] [--at 1.5,4.2] [--gl angle|egl|swift] [--scale 1]
import { spawn } from 'node:child_process';
import { mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const arg = (name, fallback) => {
  const i = process.argv.indexOf('--' + name);
  return i > -1 ? process.argv[i + 1] : fallback;
};

const url = arg('url', null);
const out = arg('out', null);
const fps = Number(arg('fps', 30));
const duration = Number(arg('duration', 10));
const width = Number(arg('width', 1920));
const height = Number(arg('height', 1080));
const chromeBin = arg('chrome', '/usr/bin/chromium');
const scale = Number(arg('scale', 1));
const at = arg('at', null);
const only = arg('only', null);
const gl = arg('gl', 'angle');
if (!url || !out) {
  console.error('usage: capture.mjs --url <file://…> --out <dir> [--fps 30 --duration 32]');
  process.exit(2);
}
mkdirSync(out, { recursive: true });

const glFlags =
  gl === 'swift'
    ? ['--use-gl=swiftshader', '--enable-unsafe-swiftshader']
    : gl === 'egl'
      ? ['--use-gl=egl']
      : ['--use-gl=angle', '--use-angle=vulkan'];

const profile = mkdtempSync(join(tmpdir(), 'giltthrone-chrome-'));
const port = 9333 + Math.floor(Math.random() * 400);
const chrome = spawn(
  chromeBin,
  [
    '--headless=new',
    '--no-sandbox',
    '--hide-scrollbars',
    '--disable-dev-shm-usage',
    '--disable-gpu-vsync',
    '--disable-frame-rate-limit',
    '--force-device-scale-factor=' + scale,
    '--window-size=' + width + ',' + height,
    '--remote-debugging-port=' + port,
    '--user-data-dir=' + profile,
    '--allow-file-access-from-files',
    '--disable-features=Translate',
    '--js-flags=--max-old-space-size=4096',
    ...glFlags,
    url,
  ],
  { stdio: ['ignore', 'ignore', 'inherit'] },
);

const stop = () => {
  try {
    chrome.kill('SIGKILL');
  } catch {}
  try {
    rmSync(profile, { recursive: true, force: true });
  } catch {}
};
process.on('exit', stop);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function target() {
  for (let i = 0; i < 160; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${port}/json/list`);
      const list = await res.json();
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl);
      if (page) return page.webSocketDebuggerUrl;
    } catch {}
    await sleep(250);
  }
  throw new Error('Chrome devtools endpoint never appeared');
}

let nextId = 1;
const pending = new Map();
let socket;

function send(method, params = {}) {
  const id = nextId++;
  socket.send(JSON.stringify({ id, method, params }));
  return new Promise((resolve, reject) => pending.set(id, { resolve, reject }));
}

async function evaluate(expression) {
  const answer = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true });
  if (answer.exceptionDetails)
    throw new Error('page error: ' + JSON.stringify(answer.exceptionDetails.text || answer.exceptionDetails.exception));
  return answer.result.value;
}

const wsUrl = await target();
socket = new WebSocket(wsUrl);
await new Promise((resolve, reject) => {
  socket.onopen = resolve;
  socket.onerror = reject;
});
socket.onmessage = (event) => {
  const message = JSON.parse(event.data);
  if (message.id && pending.has(message.id)) {
    const { resolve, reject } = pending.get(message.id);
    pending.delete(message.id);
    message.error ? reject(new Error(message.error.message)) : resolve(message.result);
  }
};

await send('Runtime.enable');
await send('Page.enable');
await send('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: scale, mobile: false });

// The page sets __ready once every buffer is uploaded and shaders are compiled.
for (let i = 0; i < 400; i++) {
  if (await evaluate('Boolean(window.__ready)')) break;
  await sleep(250);
  if (i === 399) throw new Error('page never set window.__ready');
}
if (process.env.DUMP_RENDERER) console.log('renderer: ' + (await evaluate('window.__renderer || "?"')));

const stamps = at
  ? at.split(',').map(Number)
  : Array.from({ length: Math.round(duration * fps) }, (_, i) => i / fps);
const total = stamps.length;
const started = Date.now();
for (let i = 0; i < total; i++) {
  const t = stamps[i];
  if (only && !only.split(',').map(Number).includes(i)) continue;
  await evaluate(`window.__seek(${t.toFixed(6)})`);
  const shot = await send('Page.captureScreenshot', { format: 'png' });
  writeFileSync(join(out, 'frame-' + String(Math.round(t * fps)).padStart(5, '0') + '.png'), Buffer.from(shot.data, 'base64'));
  if (i % 30 === 0 || i === total - 1) {
    const rate = ((i + 1) / ((Date.now() - started) / 1000)).toFixed(1);
    process.stdout.write('frame ' + (i + 1) + '/' + total + ' (' + rate + ' fps)\n');
  }
}
console.log(JSON.stringify({ frames: total, fps, out, elapsed_s: (Date.now() - started) / 1000 }));
stop();
process.exit(0);
