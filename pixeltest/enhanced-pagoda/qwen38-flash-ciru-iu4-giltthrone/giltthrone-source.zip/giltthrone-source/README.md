# GILTTHRONE 金殿 — a padoga cast in gold

A 36-second seamless loop, rendered in the browser from one deterministic clock. A comet of
molten gold falls out of the sky; the impact casts a lake, an island and a processional stair;
the great hall is cast course by course, the roofs unfurl, gilt lands on every course. A dead
grove of fallen timber rises around it and flourosh furs every log — cold green fluorescence on
the ground, hot gold behind the doors. The treasury fills (inlay, dais, throne, canopy, banners,
coin), the doors swing, the gold light pours out into the grove, and the camera walks in through
the doorway to the throne. Then the gold is drawn back up the arc after the comet and the loop
closes on the frame it opened with.

Successor to `padogas/inkfall-20261106`, built on the same engine with the one question INKFALL
never asked: what happens if the camera goes *inside*? That answer is `src/builds/hall.ts`,
`src/builds/treasure.ts`, `src/builds/regalia.ts` and the `roomDim` term in `core/materials.ts`.

Deliverables: `giltthrone.mp4` (1920×1080, 24 fps, 864 frames, 36.000 s) and
`giltthrone-poster.jpg`, plus `dist/index.html`, one self-contained 656 kB file with no network
requests — open it from disk and it plays.

## Run it

```sh
npm install
npm run dev            # vite dev server
npm run check          # tsc --noEmit
npm run build          # dist/index.html — one self-contained file
npm run preview -- --port 5199 --strictPort   # the capturer below points at this port
```

Drag to orbit, wheel to zoom, space to pause, `←`/`→` to scrub (`shift` for whole seconds),
`1`–`9` to jump to a beat, `o` to drop the operator layer, `c` to hide captions. The operator
layer is added on top of the keyframed pose and relaxes back to the authored camera, so scrubbing
never fights the tour.

## It is a pure function of time

Nothing animates by accumulation. `core/schedule.ts` (`T`, `LOOP = 36`) is the only clock;
`director.ts` maps loop-seconds to every look value (sky, fog, ink grade, pigment front,
`roomDim`, glow, particles, arc, bloom). Builders place voxels with a reveal time and duration,
so a frame is reproducible from a number alone.

| hook | meaning |
| --- | --- |
| `window.__ready` | buffers uploaded, shaders compiled |
| `window.__seek(t)` | render exactly second `t` of the loop |
| `window.__stats` | `{ inner, outer, plants, movers, faces }` |
| `window.__renderer` | GL renderer string |

`?capture=1` hides the overlay and the live loop.

## The tour

Sixteen beats: ten orbits around the monument axis and six explicit `pos`/`look` track beats for
the part that flies through the doorway, which no orbit can describe.

| phase | start | dur | what lands |
| --- | --- | --- | --- |
| `fall` | 0.0 | 3.4 | the comet of molten gold falls through the stars |
| `impact` | 3.4 | 1.2 | it lands on the crown, light blooms out of the impact |
| `ground` | 3.6 | 2.9 | lake, island, terraces, processional stair |
| `tiers` | 6.3 | 3.3 | the hall's walls and the storeys above them, course by course |
| `roofs` | 9.2 | 3.0 | roofs unfurl eave-tip first, then inward |
| `trim` | 11.6 | 2.4 | gilded columns, rails, balustrades, roof trim |
| `grove` | 13.6 | 3.0 | the dead grove rises, then flourosh furs the fallen timber |
| `hall` | 16.2 | 3.0 | inside: floor inlay, dais, throne, canopy, banners, treasure |
| `doors` | 19.4 | 2.4 | the doors swing, gold light pours out into the grove |
| `inside` | 21.8 | 5.2 | the camera is inside with the throne |
| `life` | 27.0 | 2.6 | spores drift, caps breathe, the lake moves |
| `lift` | 29.6 | 3.4 | back out through the doors and up to the valley |
| `draw` | 33.0 | 2.7 | the gold is drawn back up the arc, the loop closes |

World numbers the interior beats are written against (`core/layout.ts`): lake row 60 (`y 4`),
hall deck row 89 (`y 33`), ceiling slab row 102 (`y 46`), doorway opening rows 89…99 on row 96,
throne at `THRONE_MID` — the aisle runs straight down `-z` onto it.

## Capture a film

```sh
npx vite build
node render/capture.mjs \
  --url "http://127.0.0.1:5199/?capture=1" \
  --out qa/frames-hd --fps 24 --duration 36 --width 1920 --height 1080

ffmpeg -framerate 24 -i qa/frames-hd/frame-%05d.png \
  -c:v libx264 -preset slow -crf 18 -pix_fmt yuv420p -movflags +faststart giltthrone.mp4
```

`--at 24.4,26.6` grabs single stamps; `--gl angle|egl|swift` picks the GL backend
(`angle --use-angle=vulkan` is the default). ~4.2 frames/s at 1080p on this machine, so the
864-frame pass is about 3½ minutes. The frame directory is a build intermediate — delete it once
the encode is verified.

## Check a frame, don't admire a thumbnail

A bright gold room reads as *fine* at 1000 px wide while 90 % of its pixels are clipped. Measure:

```sh
magick frame.png -colorspace gray -format "%[fx:mean]\n" info:                    # mean luma
magick frame.png -colorspace gray -threshold 96% -format "%[fx:mean]" info:       # clipped share
```

Working targets: mean 0.35–0.65, clipped share ≤ 0.15 outside and ≤ 0.20 in the interior beats
where lamps are in frame. Before this pass the interior sat at mean 0.91 / 96 % clipped; it now
sits at 0.34–0.65 / 0–21 %.

## Structure

```
src/
  core/
    schedule.ts    T: phase start/dur for the whole loop, plus per-phase reveal lengths
    director.ts    t -> every look value; the only place moods are authored
    layout.ts      the reliquary, the two voxel grids, the lake, HALL, the two lamp anchors
    palette.ts     gold / flourosh palette, hash3, rng, mixHex/shade
    color.ts       rawColor(): authored colours stay in display space (no OutputPass)
    VoxelWorld.ts  grid + mesher: air-facing faces only, AO and directional light baked
                   into vertex colour, per-voxel reveal/sway/swirl attributes
    materials.ts   one ShaderMaterial language for both worlds: ink grade, pigment front,
                   water, glow, roomDim, fog, dissolve, tonal shoulder
    CameraRig.ts   keyframed beats — orbit or pos/look — plus operator layer, near/far retuned
    Sky.ts Atmosphere.ts Shell.ts Particles.ts   dome, haze, glass, stars, spores, glow
  builds/          land.ts flora.ts pagoda.ts props.ts hall.ts treasure.ts regalia.ts
                   — pure grid writers
  scene.ts         composes the inner world: island plan, terraces, treasury, grove
  outer.ts         the wider valley: night mesa basin, dead tree belt, stair, lakeside village
  stage.ts         assembles meshes, movers, particles; per-frame uniform updates
  journey.ts       the camera beats and their captions
  ui.ts            title, captions with the Japanese line, progress rail
  main.ts          renderer, bloom composer, loop, capture hooks
qa/engine-contract.md  the builder contract (rules, API, how the interior stays readable)
```

## Look notes

- **Two light families, opposite colour temperature.** Flourosh is cold mint and lives on the
  grove floor; the hall is hot gold. They fight unless their reaches are bounded, so `stage.ts`
  sets `lampHall` r 34 (inside the walls) and `lampGrove` r 66 (outside them). Nothing is lit per
  frame — these two authored lamps are the only light an interior or a forest floor can get.
- **`roomDim`.** The hall's gold is authored near-white so its roof reads in the dark, which
  clips the whole frame the moment the camera is inside. The material therefore multiplies
  *surface* colour by `1 - 0.8 · interior` before the lamp terms, `director.ts` dips bloom by
  72 % on the same signal, and `EXPOSURE` stays flat (~1.0) inside: the lamps, not the exposure,
  light the nave.
- **Display-space colour.** The composer has no OutputPass, so every authored hex goes through
  `rawColor()` and is used verbatim — mixing `new THREE.Color(hex)` (sRGB-decoded) with raw
  vertex colours puts sky and geometry a stop apart.
- **Baked lighting.** Faces get a hemisphere term, a sun term and classic voxel AO at author
  time; nothing is lit per frame, which is what lets 268 k faces run.
- **Scale.** Inner grid 160×152×160 at 1 unit per voxel, outer 170×140×170 at 4 units. Camera
  near/far tracks the distance to the target so a 1-unit voxel and the outer mountain share one
  depth buffer.
- **Interior framing.** The nave is 30 × 30 × 13 cells: every interior beat needs ≥ 4 cells of
  clearance from the column footprints, the treasure piles, the chandelier and the dais, and the
  chandelier hangs high (`h 3`) so it never crosses the sightline to the throne.

Last measured build: `inner 246 557 · outer 512 583 · plants 110 · movers 10 · faces 268 856`.
