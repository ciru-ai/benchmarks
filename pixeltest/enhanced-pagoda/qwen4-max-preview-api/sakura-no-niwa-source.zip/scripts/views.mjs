/** Camera composition survey: every preset plus candidate vista angles. */
export default async function run(page, { outDir, tag }) {
  const ids = ['vista', 'pagoda', 'bridge', 'pond', 'zen', 'gate', 'tea', 'aerial', 'roots'];
  for (const id of ids) {
    await page.evaluate((v) => window.__garden.setView(v), id);
    await page.waitForTimeout(1500);
    await page.screenshot({ path: `${outDir}/${tag}-${id}.png` });
    console.log('view', id, 'ok');
  }
  const candidates = [
    { name: 'sw-a', pos: [-150, 96, 168], target: [-8, 26, 4] },
    { name: 'sw-b', pos: [-118, 78, 178], target: [-14, 22, 8] },
    { name: 's-c', pos: [-40, 88, 215], target: [-10, 24, 4] },
  ];
  for (const c of candidates) {
    await page.evaluate((cfg) => {
      window.__garden.rig.cancelTween();
      window.__garden.rig.camera.position.set(...cfg.pos);
      window.__garden.rig.controls.target.set(...cfg.target);
      window.__garden.rig.controls.update();
    }, c);
    await page.waitForTimeout(1400);
    await page.screenshot({ path: `${outDir}/${tag}-${c.name}.png` });
    console.log('candidate', c.name, 'ok');
  }
}
