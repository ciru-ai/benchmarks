/** Interaction sweep used by scripts/verify.mjs --script */
export default async function run(page, { logs, outDir, tag }) {
  const shot = async (name) => {
    await page.screenshot({ path: `${outDir}/${tag}-${name}.png` });
  };
  const step = async (name, fn, wait = 1400) => {
    const before = logs.length;
    await fn();
    await page.waitForTimeout(wait);
    const errs = logs.slice(before).filter((l) => l.startsWith('[error]') || l.startsWith('[pageerror]'));
    console.log(`STEP ${name}: ${errs.length ? 'ERRORS ' + errs.join(' | ') : 'ok'}`);
    await shot(name);
  };

  // 1. orbit drag
  await step('01-orbit', async () => {
    const box = await page.locator('canvas').boundingBox();
    await page.mouse.move(box.x + box.width * 0.4, box.y + box.height * 0.5);
    await page.mouse.down();
    for (let i = 1; i <= 12; i++) {
      await page.mouse.move(box.x + box.width * 0.4 + i * 14, box.y + box.height * 0.5 - i * 3);
      await page.waitForTimeout(30);
    }
    await page.mouse.up();
  });

  const camAfterDrag = await page.evaluate(() => window.__garden.debug().camera);
  console.log('camera after drag:', JSON.stringify(camAfterDrag));

  // 2. wheel zoom
  await step('02-zoom', async () => {
    await page.mouse.wheel(0, -420);
  });

  // 3. live dials
  await step('03-autumn-dusk', async () => {
    await page.evaluate(() => {
      window.__garden.settings.set('season', 'autumn');
      window.__garden.settings.set('hour', 17.4);
      window.__garden.settings.set('sunShafts', 1.1);
      window.__garden.settings.set('bloom', 0.9);
    });
  }, 2200);

  // 4. summer + wireframe + grid
  await step('04-summer-grid', async () => {
    await page.evaluate(() => {
      window.__garden.settings.set('season', 'summer');
      window.__garden.settings.set('hour', 12.5);
      window.__garden.settings.set('showGrid', true);
      window.__garden.settings.set('sunShafts', 0.5);
      window.__garden.settings.set('bloom', 0.62);
    });
  }, 2200);

  await step('05-wireframe', async () => {
    await page.evaluate(() => {
      window.__garden.settings.set('wireframe', true);
      window.__garden.settings.set('showGrid', false);
    });
  }, 900);

  await step('06-solid-again', async () => {
    await page.evaluate(() => window.__garden.settings.set('wireframe', false));
  }, 900);

  // 5. bell + gust + ripple through the real API the UI uses
  await step('07-bell-gust', async () => {
    await page.evaluate(() => {
      window.__garden.interaction.ringBell();
      window.__garden.life.gust(1.6);
      window.__garden.materials.addRipple(-28, 20, 1);
      window.__garden.life.koi.startle(-28, 20);
    });
  }, 700);

  const bellState = await page.evaluate(() => {
    const b = window.__garden.world.bell;
    return { rotation: b.object.rotation.z, name: b.object.name };
  });
  console.log('bell:', JSON.stringify(bellState));

  // 6. rebuild with 7 tiers + new seed through the panel controls
  await step('08-rebuild-seven', async () => {
    await page.evaluate(() => {
      window.__garden.settings.set('season', 'spring');
      window.__garden.settings.set('hour', 8.2);
      window.__garden.settings.set('pagodaTiers', 7);
      window.__garden.settings.set('seed', 'momiji-tera-777');
    });
  }, 6500);

  const rebuilt = await page.evaluate(() => window.__garden.debug());
  console.log('after rebuild:', JSON.stringify(rebuilt));

  // 7. pause / resume
  await step('09-pause', async () => {
    await page.evaluate(() => window.__garden.settings.set('paused', true));
  }, 800);
  const pausedTime = await page.evaluate(() => window.__garden.engine.elapsed);
  await page.waitForTimeout(700);
  const pausedTime2 = await page.evaluate(() => window.__garden.engine.elapsed);
  console.log('pause holds clock:', pausedTime === pausedTime2, pausedTime, pausedTime2);
  await step('10-resume', async () => {
    await page.evaluate(() => window.__garden.settings.set('paused', false));
  }, 800);

  // 8. quality switch + reset
  await step('11-quality-reset', async () => {
    await page.evaluate(() => {
      window.__garden.settings.set('quality', 'medium');
    });
  }, 1600);
  await step('12-reset', async () => {
    await page.evaluate(() => window.__garden.resetAll());
  }, 6000);

  // 9. click a real landmark on screen (bell tower proxy) via projected coords
  await step('13-click-pond', async () => {
    const pt = await page.evaluate(() => {
      const g = window.__garden;
      const THREE = g.engine.scene;
      void THREE;
      const item = g.world.interactives.find((i) => i.id === 'pond');
      const v = item.position.clone().project(g.rig.camera);
      const rect = g.engine.renderer.domElement.getBoundingClientRect();
      return { x: rect.left + (v.x * 0.5 + 0.5) * rect.width, y: rect.top + (-v.y * 0.5 + 0.5) * rect.height };
    });
    await page.mouse.move(pt.x, pt.y);
    await page.waitForTimeout(400);
    await page.mouse.down();
    await page.waitForTimeout(60);
    await page.mouse.up();
  }, 900);

  const hover = await page.evaluate(() => document.getElementById('tooltip')?.className ?? 'none');
  console.log('tooltip class after hover:', hover);

  // 10. hide / show UI
  await step('14-hide-ui', async () => {
    await page.keyboard.press('h');
  }, 900);
  await step('15-show-ui', async () => {
    await page.keyboard.press('h');
  }, 900);

  // 11. resize
  await step('16-resize', async () => {
    await page.setViewportSize({ width: 1100, height: 720 });
  }, 1600);
  await step('17-resize-back', async () => {
    await page.setViewportSize({ width: 1600, height: 950 });
  }, 1600);

  const final = await page.evaluate(() => window.__garden.debug());
  console.log('final:', JSON.stringify(final));
}
