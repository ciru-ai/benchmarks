/**
 * Browser verification harness.
 * Usage: node scripts/verify.mjs [--url http://127.0.0.1:5288] [--tag step1] [--wait 9000]
 *                                [--script path/to/interaction.mjs] [--mobile]
 * Captures console output, page errors, WebGL stats and screenshots.
 */
import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';

const args = Object.fromEntries(
  process.argv.slice(2).reduce((acc, cur, i, arr) => {
    if (cur.startsWith('--')) acc.push([cur.slice(2), arr[i + 1]?.startsWith('--') ? true : arr[i + 1]]);
    return acc;
  }, []),
);

const url = args.url || 'http://127.0.0.1:5288/';
const tag = args.tag || 'shot';
const extraWait = Number(args.wait || 6000);
const outDir = path.resolve('shots');
fs.mkdirSync(outDir, { recursive: true });

const browser = await chromium.launch({
  executablePath: '/usr/bin/google-chrome-stable',
  headless: true,
  args: [
    '--no-sandbox',
    '--use-gl=angle',
    '--use-angle=swiftshader',
    '--enable-unsafe-swiftshader',
    '--disable-dev-shm-usage',
    '--hide-scrollbars',
    '--force-device-scale-factor=1',
  ],
});

const context = await browser.newContext({
  viewport: args.mobile ? { width: 414, height: 896 } : { width: 1600, height: 950 },
  deviceScaleFactor: 1,
  isMobile: Boolean(args.mobile),
  hasTouch: Boolean(args.mobile),
});
const page = await context.newPage();

const logs = [];
page.on('console', (msg) => logs.push(`[${msg.type()}] ${msg.text()}`));
page.on('pageerror', (err) => logs.push(`[pageerror] ${err.message}\n${err.stack ?? ''}`));
page.on('requestfailed', (req) => logs.push(`[requestfailed] ${req.url()} ${req.failure()?.errorText}`));

await page.goto(url, { waitUntil: 'load', timeout: 60000 });

// Wait for the loader to disappear (world built + intro started).
try {
  await page.waitForFunction(() => document.getElementById('loader')?.classList.contains('is-hidden'), null, {
    timeout: 120000,
  });
} catch {
  logs.push('[warn] loader never hid within 120s');
}

await page.waitForTimeout(extraWait);

if (args.script) {
  const mod = await import(path.resolve(args.script));
  await mod.default(page, { logs, outDir, tag });
}

const info = await page.evaluate(() => {
  const canvas = document.querySelector('canvas');
  const gl = canvas?.getContext('webgl2');
  const stats = window.__garden?.debug?.() ?? null;
  return {
    canvas: canvas ? { w: canvas.width, h: canvas.height, cw: canvas.clientWidth, ch: canvas.clientHeight } : null,
    glLost: gl ? gl.isContextLost() : 'no-webgl2',
    stats,
    loaderHidden: document.getElementById('loader')?.classList.contains('is-hidden'),
    bodyScroll: { sw: document.body.scrollWidth, cw: document.body.clientWidth, sh: document.body.scrollHeight, ch: document.body.clientHeight },
  };
});

const file = path.join(outDir, `${tag}.png`);
await page.screenshot({ path: file });
fs.writeFileSync(path.join(outDir, `${tag}.log.txt`), logs.join('\n'));
fs.writeFileSync(path.join(outDir, `${tag}.json`), JSON.stringify(info, null, 2));

console.log('--- console ---');
console.log(logs.slice(-60).join('\n') || '(clean)');
console.log('--- info ---');
console.log(JSON.stringify(info, null, 2));
console.log('screenshot:', file);

await browser.close();
