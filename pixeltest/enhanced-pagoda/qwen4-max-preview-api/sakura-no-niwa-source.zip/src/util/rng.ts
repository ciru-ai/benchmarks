/** Deterministic, seedable pseudo random generator (mulberry32). */
export class Rng {
  private state: number;

  constructor(seed: number | string = 1) {
    this.state = typeof seed === 'string' ? hashString(seed) : seed >>> 0;
    if (this.state === 0) this.state = 0x9e3779b9;
  }

  /** float in [0,1) */
  next(): number {
    this.state = (this.state + 0x6d2b79f5) >>> 0;
    let t = this.state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  range(min: number, max: number): number {
    return min + this.next() * (max - min);
  }

  int(min: number, max: number): number {
    return Math.floor(this.range(min, max + 1));
  }

  chance(p: number): boolean {
    return this.next() < p;
  }

  pick<T>(items: readonly T[]): T {
    return items[Math.min(items.length - 1, Math.floor(this.next() * items.length))];
  }

  /** Weighted pick: entries of [value, weight]. */
  weighted<T>(entries: readonly (readonly [T, number])[]): T {
    let total = 0;
    for (const e of entries) total += e[1];
    let r = this.next() * total;
    for (const e of entries) {
      r -= e[1];
      if (r <= 0) return e[0];
    }
    return entries[entries.length - 1][0];
  }

  shuffle<T>(items: T[]): T[] {
    for (let i = items.length - 1; i > 0; i--) {
      const j = Math.floor(this.next() * (i + 1));
      [items[i], items[j]] = [items[j], items[i]];
    }
    return items;
  }

  /** Approximately normal distributed value. */
  gauss(mean = 0, dev = 1): number {
    const u = Math.max(1e-6, this.next());
    const v = this.next();
    return mean + dev * Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }

  fork(salt: number): Rng {
    return new Rng((this.state ^ Math.imul(salt + 1, 0x85ebca6b)) >>> 0);
  }
}

export function hashString(str: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

const SEED_WORDS_A = ['sakura', 'momiji', 'tsuki', 'kaze', 'yuki', 'hana', 'koi', 'take', 'matsu', 'kumo'];
const SEED_WORDS_B = ['niwa', 'tera', 'hashi', 'ike', 'yama', 'michi', 'ishi', 'akari', 'shizuku', 'hotaru'];

export function randomSeedWord(rand: () => number = Math.random): string {
  const a = SEED_WORDS_A[Math.floor(rand() * SEED_WORDS_A.length)];
  const b = SEED_WORDS_B[Math.floor(rand() * SEED_WORDS_B.length)];
  return `${a}-${b}-${Math.floor(rand() * 900 + 100)}`;
}
