/**
 * Garden ambience, synthesised entirely in WebAudio (no asset downloads).
 * Every layer is tied to something visible: wind to the blossom drift,
 * water to the waterfall, crickets to nightfall, chimes to gusts, the bonshō
 * to the bell swing, and the deer-scarer's knock to its tipping tube.
 */
export class Ambience {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private windGain: GainNode | null = null;
  private windFilter: BiquadFilterNode | null = null;
  private waterGain: GainNode | null = null;
  private cricketGain: GainNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private started = false;
  private gestureSeen = false;
  private enabled = true;
  private volume = 0.55;
  private wind = 0.5;
  private night = 0;
  private lastDroplet = 0;
  private pentatonic = [0, 2, 4, 7, 9, 12, 14, 16];

  get running(): boolean {
    return this.started && this.ctx?.state === 'running';
  }

  /** Must be called from a user gesture the first time. */
  async unlock(): Promise<void> {
    this.gestureSeen = true;
    if (!this.enabled) return;
    if (!this.ctx) this.create();
    if (this.ctx?.state === 'suspended') await this.ctx.resume();
  }

  private create(): void {
    const Ctor = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return;
    const ctx = new Ctor();
    this.ctx = ctx;

    const master = ctx.createGain();
    master.gain.value = this.enabled ? this.volume : 0;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -18;
    comp.ratio.value = 4;
    master.connect(comp).connect(ctx.destination);
    this.master = master;

    // shared noise source
    const len = ctx.sampleRate * 3;
    const buffer = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0;
    for (let i = 0; i < len; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99765 * b0 + white * 0.099046;
      b1 = 0.963 * b1 + white * 0.2965164;
      b2 = 0.57 * b2 + white * 1.0526913;
      data[i] = (b0 + b1 + b2 + white * 0.1848) * 0.16;
    }
    this.noiseBuffer = buffer;

    // --- wind bed ---
    const windSrc = ctx.createBufferSource();
    windSrc.buffer = buffer;
    windSrc.loop = true;
    const windFilter = ctx.createBiquadFilter();
    windFilter.type = 'lowpass';
    windFilter.frequency.value = 420;
    windFilter.Q.value = 0.6;
    const windGain = ctx.createGain();
    windGain.gain.value = 0.16;
    windSrc.connect(windFilter).connect(windGain).connect(master);
    windSrc.start();
    this.windFilter = windFilter;
    this.windGain = windGain;

    // --- waterfall / stream bed ---
    const waterSrc = ctx.createBufferSource();
    waterSrc.buffer = buffer;
    waterSrc.loop = true;
    const waterFilter = ctx.createBiquadFilter();
    waterFilter.type = 'bandpass';
    waterFilter.frequency.value = 1100;
    waterFilter.Q.value = 0.5;
    const waterHp = ctx.createBiquadFilter();
    waterHp.type = 'highpass';
    waterHp.frequency.value = 400;
    const waterGain = ctx.createGain();
    waterGain.gain.value = 0.1;
    waterSrc.connect(waterFilter).connect(waterHp).connect(waterGain).connect(master);
    waterSrc.start();
    this.waterGain = waterGain;

    // --- cricket bed (night) ---
    const cricketSrc = ctx.createBufferSource();
    cricketSrc.buffer = buffer;
    cricketSrc.loop = true;
    const cricketBp = ctx.createBiquadFilter();
    cricketBp.type = 'bandpass';
    cricketBp.frequency.value = 4600;
    cricketBp.Q.value = 14;
    const cricketGain = ctx.createGain();
    cricketGain.gain.value = 0;
    const trem = ctx.createOscillator();
    trem.type = 'square';
    trem.frequency.value = 11;
    const tremGain = ctx.createGain();
    tremGain.gain.value = 0.5;
    trem.connect(tremGain).connect(cricketGain.gain);
    trem.start();
    cricketSrc.connect(cricketBp).connect(cricketGain).connect(master);
    cricketSrc.start();
    this.cricketGain = cricketGain;

    this.started = true;
  }

  setEnabled(on: boolean): void {
    this.enabled = on;
    if (on && this.gestureSeen) void this.unlock();
    if (this.master && this.ctx) {
      this.master.gain.cancelScheduledValues(this.ctx.currentTime);
      this.master.gain.setTargetAtTime(on ? this.volume : 0, this.ctx.currentTime, 0.15);
    }
  }

  setVolume(v: number): void {
    this.volume = v;
    if (this.master && this.ctx && this.enabled) {
      this.master.gain.setTargetAtTime(v, this.ctx.currentTime, 0.1);
    }
  }

  setWind(w: number): void {
    this.wind = w;
  }

  setNight(n: number): void {
    this.night = n;
  }

  update(dt: number, time: number): void {
    if (!this.ctx || !this.started || !this.enabled) return;
    const t = this.ctx.currentTime;
    if (this.windGain && this.windFilter) {
      const swell = 0.5 + 0.5 * Math.sin(time * 0.23) * Math.sin(time * 0.11 + 1.3);
      this.windGain.gain.setTargetAtTime(0.05 + this.wind * 0.2 * (0.55 + swell * 0.7), t, 0.4);
      this.windFilter.frequency.setTargetAtTime(300 + this.wind * 700 * (0.5 + swell), t, 0.5);
    }
    if (this.waterGain) this.waterGain.gain.setTargetAtTime(0.075 + 0.02 * Math.sin(time * 0.4), t, 0.5);
    if (this.cricketGain) this.cricketGain.gain.setTargetAtTime(this.night * 0.05, t, 0.8);
    void dt;
  }

  private env(node: AudioNode, gain: number, attack: number, decay: number, when = 0): GainNode | null {
    if (!this.ctx || !this.master) return null;
    const ctx = this.ctx;
    const t = ctx.currentTime + when;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, gain), t + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t + attack + decay);
    node.connect(g).connect(this.master);
    return g;
  }

  private tone(freq: number, gain: number, decay: number, type: OscillatorType = 'sine', when = 0, detune = 0): void {
    if (!this.ctx || !this.enabled) return;
    const ctx = this.ctx;
    const osc = ctx.createOscillator();
    osc.type = type;
    osc.frequency.value = freq;
    osc.detune.value = detune;
    this.env(osc, gain, 0.006, decay, when);
    const t = ctx.currentTime + when;
    osc.start(t);
    osc.stop(t + decay + 0.12);
  }

  private noiseBurst(gain: number, decay: number, freq: number, q: number, type: BiquadFilterType = 'bandpass', when = 0): void {
    if (!this.ctx || !this.noiseBuffer || !this.enabled) return;
    const ctx = this.ctx;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.playbackRate.value = 1 + Math.random() * 0.3;
    const filter = ctx.createBiquadFilter();
    filter.type = type;
    filter.frequency.value = freq;
    filter.Q.value = q;
    src.connect(filter);
    this.env(filter, gain, 0.004, decay, when);
    const t = ctx.currentTime + when;
    src.start(t, Math.random() * 2);
    src.stop(t + decay + 0.1);
  }

  /** Furin wind chime, triggered by a visible gust. */
  chime(strength = 1): void {
    if (!this.ctx || !this.enabled) return;
    const base = 880 * Math.pow(2, this.pentatonic[Math.floor(Math.random() * 5)] / 12);
    const n = 2 + Math.floor(Math.random() * 3);
    for (let i = 0; i < n; i++) {
      const f = base * Math.pow(2, this.pentatonic[Math.floor(Math.random() * this.pentatonic.length)] / 12);
      const when = i * (0.07 + Math.random() * 0.12);
      this.tone(f, 0.055 * strength, 1.6 + Math.random(), 'sine', when);
      this.tone(f * 2.76, 0.018 * strength, 0.9, 'sine', when);
    }
  }

  /** Bonshō temple bell: inharmonic partials with a long tail. */
  bell(strength = 1): void {
    if (!this.ctx || !this.enabled) return;
    const f0 = 108;
    const partials: [number, number, number][] = [
      [1, 0.32, 7.5],
      [2.02, 0.16, 5.5],
      [2.98, 0.1, 4.2],
      [4.12, 0.07, 3.0],
      [5.43, 0.045, 2.2],
      [6.8, 0.03, 1.6],
    ];
    for (const [mult, gain, decay] of partials) {
      this.tone(f0 * mult, gain * strength, decay, 'sine', 0, (Math.random() - 0.5) * 6);
    }
    this.noiseBurst(0.12 * strength, 0.35, 320, 1.2);
    // slow beating shimmer
    this.tone(f0 * 1.005, 0.14 * strength, 7.0, 'sine', 0.02);
  }

  /** Small water plink for petals landing on the pond. */
  droplet(strength = 1): void {
    if (!this.ctx || !this.enabled) return;
    const now = this.ctx.currentTime;
    if (now - this.lastDroplet < 0.22) return;
    this.lastDroplet = now;
    const f = 620 + Math.random() * 900;
    if (!this.master) return;
    const ctx = this.ctx;
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    const t = ctx.currentTime;
    osc.frequency.setValueAtTime(f * 1.8, t);
    osc.frequency.exponentialRampToValueAtTime(f * 0.6, t + 0.11);
    this.env(osc, 0.05 * strength, 0.004, 0.16);
    osc.start(t);
    osc.stop(t + 0.3);
  }

  /** Shishi-odoshi bamboo knock. */
  clack(): void {
    if (!this.ctx || !this.enabled) return;
    this.noiseBurst(0.16, 0.09, 1500, 2.5);
    this.tone(196, 0.1, 0.28, 'triangle');
    this.tone(392, 0.04, 0.16, 'sine', 0.005);
  }

  /** Koi splash / pond tap. */
  splash(strength = 1): void {
    if (!this.ctx || !this.enabled) return;
    this.noiseBurst(0.13 * strength, 0.32, 900, 0.8);
    this.noiseBurst(0.07 * strength, 0.5, 2400, 0.6, 'highpass', 0.03);
    this.droplet(0.8 * strength);
  }

  /** Soft wooden tick for lantern flares. */
  flare(): void {
    if (!this.ctx || !this.enabled) return;
    this.tone(1320, 0.05, 0.5, 'sine');
    this.tone(1980, 0.025, 0.35, 'sine', 0.02);
    this.noiseBurst(0.04, 0.25, 3200, 1.5, 'bandpass');
  }

  dispose(): void {
    void this.ctx?.close();
    this.ctx = null;
    this.started = false;
  }
}
