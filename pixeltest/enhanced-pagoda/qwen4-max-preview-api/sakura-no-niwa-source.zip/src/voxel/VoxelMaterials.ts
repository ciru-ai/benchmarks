import * as THREE from 'three';
import { PALETTE_SIZE, makePaletteTexture, updatePaletteTexture, type SeasonId } from './Palette';

export const MAX_RIPPLES = 8;

export interface SharedUniforms {
  uPalette: { value: THREE.DataTexture };
  uPaletteSize: { value: number };
  uAO: { value: number };
  uEdge: { value: number };
  uTime: { value: number };
  uWind: { value: number };
  uGlow: { value: number };
  uSway: { value: number };
}

const VERT_HEAD = /* glsl */ `
attribute float aPaletteId;
attribute float aAO;
attribute vec2 aFaceUv;
attribute float aSway;
uniform sampler2D uPalette;
uniform float uPaletteSize;
uniform float uTime;
uniform float uWind;
uniform float uSway;
varying vec3 vPalColor;
varying float vAO;
varying vec2 vFaceUv;
varying vec3 vWorldPos;
`;

const FRAG_HEAD = /* glsl */ `
uniform float uAO;
uniform float uEdge;
uniform float uGlow;
varying vec3 vPalColor;
varying float vAO;
varying vec2 vFaceUv;
varying vec3 vWorldPos;
`;

const PALETTE_SAMPLE = /* glsl */ `
vPalColor = texture2D(uPalette, vec2((aPaletteId + 0.5) / uPaletteSize, 0.5)).rgb;
vAO = aAO;
vFaceUv = aFaceUv;
vWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;
`;

const SURFACE_TINT = /* glsl */ `
float aoTerm = mix(1.0, vAO, uAO);
vec2 edgeDist = min(vFaceUv, 1.0 - vFaceUv);
float edgeMask = smoothstep(0.0, 0.075, min(edgeDist.x, edgeDist.y));
float edgeTerm = mix(1.0, 0.62 + 0.38 * edgeMask, uEdge);
diffuseColor.rgb *= vPalColor * aoTerm * edgeTerm;
`;

/** Owns the palette lookup texture and the three voxel surface materials. */
export class VoxelMaterials {
  readonly uniforms: SharedUniforms;
  readonly solid: THREE.MeshStandardMaterial;
  readonly glow: THREE.MeshStandardMaterial;
  readonly water: THREE.MeshStandardMaterial;
  readonly ripples: THREE.Vector4[] = [];
  private rippleCursor = 0;
  private waterUniforms = {
    uRipples: { value: [] as THREE.Vector4[] },
    uWaveHeight: { value: 0.16 },
    uWaterTime: { value: 0 },
    uOpacity: { value: 0.82 },
  };

  constructor(season: SeasonId) {
    const palette = makePaletteTexture(season);
    for (let i = 0; i < MAX_RIPPLES; i++) this.ripples.push(new THREE.Vector4(0, 0, -99, 0));
    this.waterUniforms.uRipples.value = this.ripples;

    this.uniforms = {
      uPalette: { value: palette },
      uPaletteSize: { value: PALETTE_SIZE },
      uAO: { value: 1 },
      uEdge: { value: 0.55 },
      uTime: { value: 0 },
      uWind: { value: 0.45 },
      uGlow: { value: 1 },
      uSway: { value: 1 },
    };

    this.solid = new THREE.MeshStandardMaterial({
      roughness: 0.88,
      metalness: 0.04,
      envMapIntensity: 0.35,
      dithering: true,
    });
    this.injectSurface(this.solid, false);

    this.glow = new THREE.MeshStandardMaterial({
      roughness: 0.5,
      metalness: 0,
      emissive: new THREE.Color(0xffffff),
      emissiveIntensity: 1,
      toneMapped: true,
    });
    this.injectSurface(this.glow, true);

    this.water = new THREE.MeshStandardMaterial({
      roughness: 0.22,
      metalness: 0.16,
      transparent: true,
      opacity: 0.82,
      envMapIntensity: 0.55,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    this.injectWater(this.water);
  }

  private shared(): Record<string, THREE.IUniform> {
    return this.uniforms as unknown as Record<string, THREE.IUniform>;
  }

  private injectSurface(mat: THREE.MeshStandardMaterial, emissive: boolean): void {
    const shared = this.shared();
    mat.onBeforeCompile = (shader) => {
      Object.assign(shader.uniforms, shared);
      shader.vertexShader = shader.vertexShader
        .replace('#include <common>', `#include <common>\n${VERT_HEAD}`)
        .replace(
          '#include <begin_vertex>',
          `#include <begin_vertex>
           float swayPhase = uTime * 1.15 + position.x * 0.21 + position.z * 0.17;
           float swayAmt = aSway * uWind * uSway;
           transformed.x += sin(swayPhase) * swayAmt * 0.55;
           transformed.z += cos(swayPhase * 0.83 + 1.7) * swayAmt * 0.45;
           transformed.y += sin(swayPhase * 1.4) * swayAmt * 0.12;
           ${PALETTE_SAMPLE}`,
        );
      shader.fragmentShader = shader.fragmentShader
        .replace('#include <common>', `#include <common>\n${FRAG_HEAD}`)
        .replace('#include <color_fragment>', `#include <color_fragment>\n${SURFACE_TINT}`);
      if (emissive) {
        shader.fragmentShader = shader.fragmentShader.replace(
          '#include <emissivemap_fragment>',
          '#include <emissivemap_fragment>\n totalEmissiveRadiance *= vPalColor * uGlow;',
        );
      }
    };
    mat.customProgramCacheKey = () => (emissive ? 'voxel-glow-v1' : 'voxel-solid-v1');
  }

  private injectWater(mat: THREE.MeshStandardMaterial): void {
    const shared = this.shared();
    const wu = this.waterUniforms;
    mat.onBeforeCompile = (shader) => {
      Object.assign(shader.uniforms, shared, wu);
      shader.vertexShader = shader.vertexShader
        .replace(
          '#include <common>',
          `#include <common>
${VERT_HEAD}
uniform vec4 uRipples[${MAX_RIPPLES}];
uniform float uWaveHeight;
uniform float uWaterTime;
varying float vFoam;
varying float vWave;`,
        )
        .replace(
          '#include <begin_vertex>',
          `#include <begin_vertex>
           ${PALETTE_SAMPLE}
           float wave = 0.0;
           float foam = 0.0;
           if (normal.y > 0.5) {
             float t = uWaterTime;
             wave += sin(position.x * 0.42 + t * 1.1) * 0.5;
             wave += sin(position.z * 0.37 - t * 0.85) * 0.5;
             wave += sin((position.x + position.z) * 0.23 + t * 1.6) * 0.35;
             wave *= uWaveHeight;
             for (int i = 0; i < ${MAX_RIPPLES}; i++) {
               vec4 r = uRipples[i];
               float age = t - r.z;
               if (r.w > 0.001 && age > 0.0 && age < 4.0) {
                 float d = distance(position.xz, r.xy);
                 float front = age * 6.5;
                 float ring = exp(-pow(d - front, 2.0) * 0.35) * exp(-age * 1.05) * r.w;
                 wave += ring * 0.85;
                 foam += ring * 1.4;
               }
             }
             transformed.y += wave;
           }
           vWave = wave;
           vFoam = clamp(foam, 0.0, 1.0);
           vWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;`,
        );
      shader.fragmentShader = shader.fragmentShader
        .replace(
          '#include <common>',
          `#include <common>
${FRAG_HEAD}
uniform float uOpacity;
uniform float uWaterTime;
varying float vFoam;
varying float vWave;`,
        )
        .replace(
          '#include <color_fragment>',
          `#include <color_fragment>
           float shimmer = 0.5 + 0.5 * sin(vWorldPos.x * 0.7 + vWorldPos.z * 0.55 + uWaterTime * 2.1);
           vec3 waterCol = vPalColor * (0.82 + 0.20 * shimmer) + vec3(0.03, 0.08, 0.11) * max(vWave, 0.0) * 2.2;
           waterCol = mix(waterCol, vec3(0.88, 0.95, 1.0), vFoam * 0.6);
           diffuseColor.rgb *= waterCol * mix(1.0, vAO, uAO * 0.5);
           diffuseColor.a *= uOpacity;`,
        );
    };
    mat.customProgramCacheKey = () => 'voxel-water-v1';
  }

  setSeason(season: SeasonId): void {
    updatePaletteTexture(this.uniforms.uPalette.value, season);
  }

  setEnvironment(env: THREE.Texture | null): void {
    this.solid.envMap = env;
    this.glow.envMap = env;
    this.water.envMap = env;
    this.solid.needsUpdate = true;
    this.glow.needsUpdate = true;
    this.water.needsUpdate = true;
  }

  addRipple(x: number, z: number, strength = 1): void {
    const r = this.ripples[this.rippleCursor];
    r.set(x, z, this.waterUniforms.uWaterTime.value, strength);
    this.rippleCursor = (this.rippleCursor + 1) % MAX_RIPPLES;
  }

  update(time: number): void {
    this.uniforms.uTime.value = time;
    this.waterUniforms.uWaterTime.value = time;
  }

  setWaveHeight(v: number): void {
    this.waterUniforms.uWaveHeight.value = v;
  }

  setWaterOpacity(v: number): void {
    this.waterUniforms.uOpacity.value = v;
    this.water.opacity = v;
  }

  dispose(): void {
    this.solid.dispose();
    this.glow.dispose();
    this.water.dispose();
    this.uniforms.uPalette.value.dispose();
  }
}
