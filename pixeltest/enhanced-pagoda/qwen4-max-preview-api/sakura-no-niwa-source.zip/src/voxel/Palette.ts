import * as THREE from 'three';

/**
 * The diorama's colour library.
 *
 * Every voxel stores a *palette id*, not a colour. The id is looked up in a
 * 256x1 float texture inside the shader, which means a whole season can be
 * repainted live (spring -> winter) without rebuilding a single triangle.
 */

export const enum Kind {
  Solid = 0,
  Glow = 1,
  Water = 2,
  Leaf = 3,
}

export interface PaletteEntry {
  name: string;
  hex: string;
  kind: Kind;
}

type Spec = [name: string, hex: string, kind?: Kind];

/** Master (spring) palette — warm sumi neutrals, vermilion, jade, sakura, gold. */
const SPEC: Spec[] = [
  // --- earth & stone -------------------------------------------------
  ['SOIL_D', '#4a3324'],
  ['SOIL_M', '#61432e'],
  ['SOIL_L', '#7d573a'],
  ['ROOT', '#3a281c'],
  ['ROCK_D', '#3b4049'],
  ['ROCK_M', '#565d69'],
  ['ROCK_L', '#78808d'],
  ['ROCK_XL', '#9aa3b0'],
  ['GRANITE_D', '#5a5f68'],
  ['GRANITE_M', '#7b818b'],
  ['GRANITE_L', '#9ba2ac'],
  ['GRANITE_XL', '#bcc3cb'],
  ['MOSS_STONE', '#6c7a55'],
  ['SLATE', '#414753'],
  // --- ground cover --------------------------------------------------
  ['GRASS_D', '#2f7038'],
  ['GRASS_M', '#43913f'],
  ['GRASS_L', '#5cb04b'],
  ['GRASS_XL', '#7ec95a'],
  ['MOSS_D', '#2c6440'],
  ['MOSS_L', '#4f8f52'],
  ['CLOVER', '#8fc861'],
  ['SAND_D', '#c9b998'],
  ['SAND_M', '#ded1b2'],
  ['SAND_L', '#efe6cd'],
  ['GRAVEL_D', '#9a9382'],
  ['GRAVEL_M', '#b5ad99'],
  ['GRAVEL_L', '#cdc6b2'],
  ['PETAL_CARPET', '#ffc3d8'],
  ['PETAL_CARPET_D', '#f79bbd'],
  ['PETAL_A', '#ffc0d4'],
  ['PETAL_B', '#ff9ec2'],
  ['PETAL_C', '#ffdce9'],
  ['PETAL_D', '#f2739f'],
  ['PETAL_E', '#fff2f7'],
  // --- wood & architecture -------------------------------------------
  ['WOOD_D', '#3f2b20'],
  ['WOOD_M', '#6b4630'],
  ['WOOD_L', '#8d6242'],
  ['WOOD_XL', '#a97c53'],
  ['VERMILION_D', '#a82c1e'],
  ['VERMILION', '#d6402a'],
  ['VERMILION_L', '#ef6a45'],
  ['LACQUER', '#20242e'],
  ['PLASTER', '#f3ece0'],
  ['PLASTER_D', '#ddd2c0'],
  ['TATAMI', '#c8a86a'],
  ['THATCH_D', '#8d6f45'],
  ['THATCH_M', '#b08f52'],
  ['THATCH_L', '#cbab6d'],
  ['ROOF_D', '#1d2b42'],
  ['ROOF_M', '#2b3f5c'],
  ['ROOF_L', '#3c5878'],
  ['ROOF_XL', '#547597'],
  ['RIDGE', '#6d90b4'],
  ['GOLD_D', '#b8862a'],
  ['GOLD', '#e0a83c'],
  ['GOLD_L', '#f7d16a'],
  ['BRONZE', '#7d7a4e'],
  ['PAPER', '#f7f0dd'],
  // --- foliage -------------------------------------------------------
  ['SAKURA_D', '#f2739f', Kind.Leaf],
  ['SAKURA_M', '#ff9ec2', Kind.Leaf],
  ['SAKURA_L', '#ffbdd6', Kind.Leaf],
  ['SAKURA_XL', '#ffdce9', Kind.Leaf],
  ['SAKURA_W', '#fff2f7', Kind.Leaf],
  ['SAKURA_BUD', '#e0568c', Kind.Leaf],
  ['MAPLE_D', '#b32a1f', Kind.Leaf],
  ['MAPLE_M', '#e0452a', Kind.Leaf],
  ['MAPLE_L', '#f2703a', Kind.Leaf],
  ['MAPLE_XL', '#ffa63d', Kind.Leaf],
  ['PINE_D', '#17422c', Kind.Leaf],
  ['PINE_M', '#245c3a', Kind.Leaf],
  ['PINE_L', '#347a48', Kind.Leaf],
  ['WILLOW_D', '#7fa544', Kind.Leaf],
  ['WILLOW_L', '#a9cd66', Kind.Leaf],
  ['BAMBOO_D', '#5f8a2e', Kind.Leaf],
  ['BAMBOO_M', '#7fa83c', Kind.Leaf],
  ['BAMBOO_L', '#9dc653', Kind.Leaf],
  ['BAMBOO_LEAF', '#b7d96a', Kind.Leaf],
  ['HEDGE', '#2d6b3c', Kind.Leaf],
  // --- flowers -------------------------------------------------------
  ['AZALEA_D', '#c2317c', Kind.Leaf],
  ['AZALEA_M', '#e0479b', Kind.Leaf],
  ['AZALEA_L', '#ff77bb', Kind.Leaf],
  ['IRIS_D', '#4b3aa8', Kind.Leaf],
  ['IRIS_M', '#6f5ad6', Kind.Leaf],
  ['IRIS_L', '#9b87f0', Kind.Leaf],
  ['LOTUS', '#ff9ec9', Kind.Leaf],
  ['LOTUS_L', '#ffe3f0', Kind.Leaf],
  ['LILY_PAD', '#3f8a4a', Kind.Leaf],
  ['LILY_PAD_L', '#5aa85c', Kind.Leaf],
  ['MARIGOLD', '#ffb02e', Kind.Leaf],
  ['MARIGOLD_L', '#ffd45e', Kind.Leaf],
  ['STEM', '#3d7a3a', Kind.Leaf],
  // --- water & life --------------------------------------------------
  ['WATER', '#2f8fb8', Kind.Water],
  ['WATER_D', '#1b5f86', Kind.Water],
  ['WATER_L', '#54b6d6', Kind.Water],
  ['FOAM', '#d6f2fa', Kind.Water],
  ['KOI_ORANGE', '#ff7a2f'],
  ['KOI_WHITE', '#fdf6ee'],
  ['KOI_RED', '#e33b2e'],
  ['KOI_INK', '#2b2b33'],
  ['KOI_GOLD', '#ffc457'],
  ['CRANE_W', '#f6f4ef'],
  ['CRANE_K', '#26262e'],
  ['CRANE_R', '#e0453a'],
  ['CLOUD', '#f7f4ff'],
  ['CLOUD_D', '#dcd8f0'],
  ['SNOW', '#f2f7ff'],
  ['SNOW_D', '#d8e4f4'],
  ['ICE', '#a9dced', Kind.Water],
  // --- emissive ------------------------------------------------------
  ['LANTERN_FIRE', '#ffc766', Kind.Glow],
  ['LANTERN_CORE', '#fff0c2', Kind.Glow],
  ['SHOJI_GLOW', '#ffd79a', Kind.Glow],
  ['FOX_FIRE', '#7fe3d4', Kind.Glow],
  ['SPIRIT_ORB', '#ffa8e0', Kind.Glow],
  ['EMBER', '#ff8a3c', Kind.Glow],
];

export const PALETTE_SIZE = 256;

export const P: Record<string, number> = {};
export const PALETTE: PaletteEntry[] = [{ name: 'AIR', hex: '#000000', kind: Kind.Solid }];

SPEC.forEach(([name, hex, kind], i) => {
  const id = i + 1;
  P[name] = id;
  PALETTE.push({ name, hex, kind: kind ?? Kind.Solid });
});

export const KIND_OF = new Uint8Array(PALETTE_SIZE);
PALETTE.forEach((e, i) => (KIND_OF[i] = e.kind));

export type SeasonId = 'spring' | 'summer' | 'autumn' | 'winter';

export interface SeasonTheme {
  id: SeasonId;
  label: string;
  jp: string;
  blurb: string;
  swatch: [string, string, string];
  overrides: Record<string, string>;
  petalColors: string[];
  petalRate: number;
  waterHex: string;
  skyTint: string;
  ambientTint: string;
  defaultHour: number;
}

export const SEASONS: Record<SeasonId, SeasonTheme> = {
  spring: {
    id: 'spring',
    label: 'Sakura Spring',
    jp: '春',
    blurb: 'Blossom fall over the koi pond',
    swatch: ['#ff9ec2', '#5cb04b', '#d6402a'],
    overrides: {},
    petalColors: ['#ffc0d4', '#ff9ec2', '#ffdce9', '#f2739f', '#fff2f7'],
    petalRate: 1,
    waterHex: '#2f8fb8',
    skyTint: '#ffd9e6',
    ambientTint: '#ffe8f0',
    defaultHour: 8.2,
  },
  summer: {
    id: 'summer',
    label: 'Verdant Summer',
    jp: '夏',
    blurb: 'Deep green shade, cicada heat',
    swatch: ['#347a48', '#9dc653', '#54b6d6'],
    overrides: {
      GRASS_D: '#276b2f',
      GRASS_M: '#35843a',
      GRASS_L: '#4aa044',
      GRASS_XL: '#6dbf52',
      MOSS_D: '#245c39',
      MOSS_L: '#3f8347',
      SAKURA_D: '#2f7a42',
      SAKURA_M: '#43954d',
      SAKURA_L: '#5cb058',
      SAKURA_XL: '#83c766',
      SAKURA_W: '#e9f6d8',
      SAKURA_BUD: '#f6f2e2',
      MAPLE_D: '#25603a',
      MAPLE_M: '#347a48',
      MAPLE_L: '#4f9a52',
      MAPLE_XL: '#79bb5c',
      WILLOW_D: '#6f9c3c',
      WILLOW_L: '#9ec95c',
      PETAL_CARPET: '#8dc464',
      PETAL_CARPET_D: '#6aa94c',
      PETAL_A: '#b7d96a',
      PETAL_B: '#e9f6d8',
      PETAL_C: '#9dc653',
      PETAL_D: '#d8ecb0',
      PETAL_E: '#ffffff',
      WATER: '#2aa2c4',
      WATER_L: '#5fd0e4',
      AZALEA_D: '#b8339c',
      AZALEA_M: '#d94bb0',
    },
    petalColors: ['#b7d96a', '#e9f6d8', '#9dc653', '#ffffff'],
    petalRate: 0.32,
    waterHex: '#2aa2c4',
    skyTint: '#cfeaff',
    ambientTint: '#e6f6ff',
    defaultHour: 13,
  },
  autumn: {
    id: 'autumn',
    label: 'Momiji Autumn',
    jp: '秋',
    blurb: 'Fire maples and gold leaf rain',
    swatch: ['#e0452a', '#ffa63d', '#c8a86a'],
    overrides: {
      GRASS_D: '#5d6a2c',
      GRASS_M: '#77813a',
      GRASS_L: '#95974a',
      GRASS_XL: '#b3ab5c',
      MOSS_D: '#4d6231',
      MOSS_L: '#77843f',
      CLOVER: '#c0b45f',
      SAKURA_D: '#c9762c',
      SAKURA_M: '#e79a3a',
      SAKURA_L: '#f7bb5c',
      SAKURA_XL: '#ffd88a',
      SAKURA_W: '#ffeec4',
      SAKURA_BUD: '#b85c22',
      MAPLE_D: '#8f1d16',
      MAPLE_M: '#d1301f',
      MAPLE_L: '#f2622a',
      MAPLE_XL: '#ffab35',
      WILLOW_D: '#b08a30',
      WILLOW_L: '#d8b44c',
      BAMBOO_D: '#6c8a2c',
      BAMBOO_M: '#8fa53a',
      BAMBOO_L: '#adb84e',
      PETAL_CARPET: '#e8a44a',
      PETAL_CARPET_D: '#c9762c',
      PETAL_A: '#e0452a',
      PETAL_B: '#f2703a',
      PETAL_C: '#ffa63d',
      PETAL_D: '#ffd88a',
      PETAL_E: '#b32a1f',
      HEDGE: '#4a6a30',
      WATER: '#2b7fa8',
      LILY_PAD: '#7d7a35',
      LILY_PAD_L: '#9a9645',
    },
    petalColors: ['#e0452a', '#f2703a', '#ffa63d', '#ffd88a', '#b32a1f'],
    petalRate: 0.85,
    waterHex: '#2b7fa8',
    skyTint: '#ffcf9a',
    ambientTint: '#ffe0bb',
    defaultHour: 17.1,
  },
  winter: {
    id: 'winter',
    label: 'Yuki Winter',
    jp: '冬',
    blurb: 'Snow silence, lanterns burning',
    swatch: ['#f2f7ff', '#a9dced', '#2b3f5c'],
    overrides: {
      GRASS_D: '#c3d2e4',
      GRASS_M: '#dbe6f3',
      GRASS_L: '#eef4fb',
      GRASS_XL: '#ffffff',
      MOSS_D: '#b9c9d8',
      MOSS_L: '#dae5f0',
      CLOVER: '#f0f6ff',
      SAKURA_D: '#b9a6ae',
      SAKURA_M: '#dcc9d2',
      SAKURA_L: '#f0e2e8',
      SAKURA_XL: '#fbf3f7',
      SAKURA_W: '#ffffff',
      SAKURA_BUD: '#a08e97',
      MAPLE_D: '#7c5a52',
      MAPLE_M: '#9c7a6c',
      MAPLE_L: '#cbb2a4',
      MAPLE_XL: '#efe3d8',
      PINE_D: '#1c4433',
      PINE_M: '#2c5c43',
      PINE_L: '#e8f1fa',
      WILLOW_D: '#a08c62',
      WILLOW_L: '#e4ecf6',
      BAMBOO_D: '#5c7a44',
      BAMBOO_M: '#7d9a56',
      BAMBOO_L: '#e9f2fb',
      BAMBOO_LEAF: '#dbe8f4',
      HEDGE: '#c9d8e4',
      ROOF_D: '#2a3a52',
      ROOF_M: '#43597a',
      ROOF_L: '#c9d9ea',
      ROOF_XL: '#e9f2fb',
      RIDGE: '#f4f9ff',
      THATCH_D: '#9c8a6c',
      THATCH_M: '#d8cbb2',
      THATCH_L: '#f2ece0',
      PETAL_CARPET: '#eef4fb',
      PETAL_CARPET_D: '#d3e0ee',
      PETAL_A: '#ffffff',
      PETAL_B: '#eef4fb',
      PETAL_C: '#d8e4f4',
      PETAL_D: '#ffffff',
      PETAL_E: '#f8fbff',
      SAND_D: '#d5dfe9',
      SAND_M: '#e8eff7',
      SAND_L: '#f8fbff',
      GRAVEL_D: '#b3bfc9',
      GRAVEL_L: '#e6edf4',
      WATER: '#3f88a8',
      WATER_D: '#2a6180',
      WATER_L: '#8fc6dd',
      FOAM: '#eef8ff',
      LILY_PAD: '#8aa896',
      LILY_PAD_L: '#cfe0e4',
      AZALEA_D: '#8c6480',
      AZALEA_M: '#b48ca6',
      AZALEA_L: '#e8dce4',
      IRIS_D: '#5a5590',
      IRIS_M: '#8f89c0',
      IRIS_L: '#e2e6f6',
      LOTUS: '#e6d8e0',
      LOTUS_L: '#fbf6fa',
      MARIGOLD: '#c9a86a',
      MARIGOLD_L: '#f0e4c8',
    },
    petalColors: ['#ffffff', '#eef4fb', '#d8e4f4', '#ffffff'],
    petalRate: 0.7,
    waterHex: '#3f88a8',
    skyTint: '#cfe0f5',
    ambientTint: '#dceaf8',
    defaultHour: 19.4,
  },
};

export const SEASON_ORDER: SeasonId[] = ['spring', 'summer', 'autumn', 'winter'];

/** sRGB hex -> linear float triplet (three's colour management does the transfer). */
function linear(hex: string, out: Float32Array, offset: number, boost = 1): void {
  const c = new THREE.Color(hex);
  out[offset] = c.r * boost;
  out[offset + 1] = c.g * boost;
  out[offset + 2] = c.b * boost;
  out[offset + 3] = 1;
}

/** Build the linear RGBA lookup table used by the voxel shader. */
export function buildPaletteData(season: SeasonId): Float32Array {
  const theme = SEASONS[season];
  const data = new Float32Array(PALETTE_SIZE * 4);
  for (let i = 1; i < PALETTE.length; i++) {
    const entry = PALETTE[i];
    const hex = theme.overrides[entry.name] ?? entry.hex;
    linear(hex, data, i * 4, entry.kind === Kind.Glow ? 1.35 : 1);
  }
  return data;
}

export function makePaletteTexture(season: SeasonId): THREE.DataTexture {
  const tex = new THREE.DataTexture(buildPaletteData(season), PALETTE_SIZE, 1, THREE.RGBAFormat, THREE.FloatType);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.generateMipmaps = false;
  tex.needsUpdate = true;
  return tex;
}

export function updatePaletteTexture(tex: THREE.DataTexture, season: SeasonId): void {
  const data = buildPaletteData(season);
  (tex.image.data as Float32Array).set(data);
  tex.needsUpdate = true;
}

/** Hex of a palette slot for a given season (used by petals / UI accents). */
export function seasonHex(name: string, season: SeasonId): string {
  return SEASONS[season].overrides[name] ?? PALETTE[P[name]].hex;
}
