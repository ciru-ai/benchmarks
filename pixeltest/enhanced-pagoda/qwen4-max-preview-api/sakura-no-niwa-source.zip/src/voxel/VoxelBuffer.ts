import { KIND_OF, Kind } from './Palette';

export interface Bounds {
  sx: number;
  sy: number;
  sz: number;
  ox: number;
  oy: number;
  oz: number;
}

export const WORLD_BOUNDS: Bounds = { sx: 148, sy: 152, sz: 148, ox: -74, oy: -46, oz: -74 };

/**
 * Dense sparse-ish voxel volume. Ids are palette indices (0 = air).
 * Authoring happens in world coordinates; the buffer handles the offset.
 */
export class VoxelBuffer {
  readonly sx: number;
  readonly sy: number;
  readonly sz: number;
  readonly ox: number;
  readonly oy: number;
  readonly oz: number;
  readonly data: Uint16Array;
  count = 0;

  constructor(bounds: Bounds = WORLD_BOUNDS) {
    this.sx = bounds.sx;
    this.sy = bounds.sy;
    this.sz = bounds.sz;
    this.ox = bounds.ox;
    this.oy = bounds.oy;
    this.oz = bounds.oz;
    this.data = new Uint16Array(this.sx * this.sy * this.sz);
  }

  index(x: number, y: number, z: number): number {
    return (x - this.ox) + (y - this.oy) * this.sx + (z - this.oz) * this.sx * this.sy;
  }

  inside(x: number, y: number, z: number): boolean {
    return (
      x >= this.ox && x < this.ox + this.sx &&
      y >= this.oy && y < this.oy + this.sy &&
      z >= this.oz && z < this.oz + this.sz
    );
  }

  get(x: number, y: number, z: number): number {
    if (!this.inside(x, y, z)) return 0;
    return this.data[this.index(x, y, z)];
  }

  solid(x: number, y: number, z: number): boolean {
    const v = this.get(x, y, z);
    return v !== 0 && KIND_OF[v] !== Kind.Water;
  }

  set(x: number, y: number, z: number, id: number): void {
    if (!this.inside(x, y, z)) return;
    const i = this.index(x, y, z);
    const prev = this.data[i];
    if (prev === id) return;
    if (prev === 0 && id !== 0) this.count++;
    else if (prev !== 0 && id === 0) this.count--;
    this.data[i] = id;
  }

  /** Only paint into empty space — handy for moss, petals, decorations. */
  setIfAir(x: number, y: number, z: number, id: number): void {
    if (this.get(x, y, z) === 0) this.set(x, y, z, id);
  }

  /** Replace only voxels of a specific id. */
  replace(x: number, y: number, z: number, from: number, to: number): void {
    if (this.get(x, y, z) === from) this.set(x, y, z, to);
  }

  clear(): void {
    this.data.fill(0);
    this.count = 0;
  }

  /** Inclusive axis-aligned box fill. */
  box(x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, id: number): void {
    const xa = Math.min(x0, x1), xb = Math.max(x0, x1);
    const ya = Math.min(y0, y1), yb = Math.max(y0, y1);
    const za = Math.min(z0, z1), zb = Math.max(z0, z1);
    for (let y = ya; y <= yb; y++)
      for (let z = za; z <= zb; z++)
        for (let x = xa; x <= xb; x++) this.set(x, y, z, id);
  }

  /** Hollow box (walls only), floor optional. */
  shell(x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, id: number, floor = false): void {
    for (let y = y0; y <= y1; y++) {
      for (let z = z0; z <= z1; z++) {
        for (let x = x0; x <= x1; x++) {
          const edge = x === x0 || x === x1 || z === z0 || z === z1;
          if (edge || (floor && y === y0)) this.set(x, y, z, id);
        }
      }
    }
  }

  /** Flat filled disc on the XZ plane. */
  disc(cx: number, y: number, cz: number, r: number, id: number, ringOnly = false): void {
    const rr = r * r;
    const inner = (r - 1.05) * (r - 1.05);
    for (let z = Math.floor(cz - r); z <= Math.ceil(cz + r); z++) {
      for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) {
        const d = (x - cx) * (x - cx) + (z - cz) * (z - cz);
        if (d <= rr && (!ringOnly || d >= inner)) this.set(x, y, z, id);
      }
    }
  }

  /** Ellipsoid; `paint` may return 0 to skip a cell (noise erosion). */
  ellipsoid(
    cx: number,
    cy: number,
    cz: number,
    rx: number,
    ry: number,
    rz: number,
    paint: number | ((x: number, y: number, z: number, d: number) => number),
  ): void {
    for (let y = Math.floor(cy - ry); y <= Math.ceil(cy + ry); y++) {
      for (let z = Math.floor(cz - rz); z <= Math.ceil(cz + rz); z++) {
        for (let x = Math.floor(cx - rx); x <= Math.ceil(cx + rx); x++) {
          const dx = (x - cx) / rx;
          const dy = (y - cy) / ry;
          const dz = (z - cz) / rz;
          const d = dx * dx + dy * dy + dz * dz;
          if (d > 1) continue;
          const id = typeof paint === 'function' ? paint(x, y, z, d) : paint;
          if (id) this.set(x, y, z, id);
        }
      }
    }
  }

  sphere(cx: number, cy: number, cz: number, r: number, paint: number | ((x: number, y: number, z: number, d: number) => number)): void {
    this.ellipsoid(cx, cy, cz, r, r, r, paint);
  }

  /** Vertical column. */
  column(x: number, y0: number, y1: number, z: number, id: number): void {
    for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) this.set(x, y, z, id);
  }

  /** Voxel line (3D DDA) with optional square thickness. */
  line(x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, id: number, thickness = 1): void {
    const steps = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0), Math.abs(z1 - z0));
    const half = (thickness - 1) / 2;
    for (let i = 0; i <= steps; i++) {
      const t = steps === 0 ? 0 : i / steps;
      const x = Math.round(x0 + (x1 - x0) * t);
      const y = Math.round(y0 + (y1 - y0) * t);
      const z = Math.round(z0 + (z1 - z0) * t);
      if (thickness <= 1) this.set(x, y, z, id);
      else {
        for (let dx = -Math.floor(half); dx <= Math.ceil(half); dx++)
          for (let dz = -Math.floor(half); dz <= Math.ceil(half); dz++)
            this.set(x + dx, y, z + dz, id);
      }
    }
  }

  /** Highest non-air voxel at a column, or `fallback`. */
  topAt(x: number, z: number, fromY = this.oy + this.sy - 1, fallback = -999): number {
    for (let y = fromY; y >= this.oy; y--) {
      if (this.get(x, y, z) !== 0) return y;
    }
    return fallback;
  }

  /** Highest *solid* (non-water) voxel at a column. */
  groundAt(x: number, z: number, fromY = this.oy + this.sy - 1, fallback = -999): number {
    for (let y = fromY; y >= this.oy; y--) {
      const v = this.get(x, y, z);
      if (v !== 0 && KIND_OF[v] !== Kind.Water) return y;
    }
    return fallback;
  }

  /** Iterate every occupied cell. */
  forEach(fn: (x: number, y: number, z: number, id: number) => void): void {
    const { sx, sy, sz, ox, oy, oz, data } = this;
    let i = 0;
    for (let y = 0; y < sy; y++)
      for (let z = 0; z < sz; z++)
        for (let x = 0; x < sx; x++, i++) {
          const id = data[i];
          if (id !== 0) fn(x + ox, y + oy, z + oz, id);
        }
  }
}
