import * as THREE from 'three';
import { KIND_OF, Kind } from './Palette';
import type { VoxelBuffer } from './VoxelBuffer';

/**
 * Culled-face voxel mesher with baked per-vertex ambient occlusion.
 *
 * Only faces touching air (or a different transparency class) are emitted, so
 * a 400k voxel island becomes ~100k quads in three draw calls. AO is baked into
 * an attribute so its strength stays a live uniform, and every vertex carries
 * its palette id + face-local UV (used for the mortar/edge shader).
 */

interface FaceDef {
  n: [number, number, number];
  axis: number;
  corners: [number, number, number][];
}

const FACES: FaceDef[] = [
  { n: [1, 0, 0], axis: 0, corners: [[1, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]] },
  { n: [-1, 0, 0], axis: 0, corners: [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]] },
  { n: [0, 1, 0], axis: 1, corners: [[0, 1, 1], [1, 1, 1], [1, 1, 0], [0, 1, 0]] },
  { n: [0, -1, 0], axis: 1, corners: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]] },
  { n: [0, 0, 1], axis: 2, corners: [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]] },
  { n: [0, 0, -1], axis: 2, corners: [[1, 0, 0], [0, 0, 0], [0, 1, 0], [1, 1, 0]] },
];

const FACE_UV: [number, number][] = [[0, 0], [1, 0], [1, 1], [0, 1]];
const AO_LEVELS = [0.40, 0.62, 0.82, 1.0];

class FloatList {
  arr: Float32Array;
  len = 0;
  constructor(cap = 4096) {
    this.arr = new Float32Array(cap);
  }
  private grow(need: number): void {
    if (this.len + need <= this.arr.length) return;
    let cap = this.arr.length * 2;
    while (cap < this.len + need) cap *= 2;
    const next = new Float32Array(cap);
    next.set(this.arr.subarray(0, this.len));
    this.arr = next;
  }
  push1(a: number): void {
    this.grow(1);
    this.arr[this.len++] = a;
  }
  push2(a: number, b: number): void {
    this.grow(2);
    this.arr[this.len++] = a;
    this.arr[this.len++] = b;
  }
  push3(a: number, b: number, c: number): void {
    this.grow(3);
    this.arr[this.len++] = a;
    this.arr[this.len++] = b;
    this.arr[this.len++] = c;
  }
  view(): Float32Array {
    return this.arr.subarray(0, this.len);
  }
}

class IndexList {
  arr: Uint32Array;
  len = 0;
  constructor(cap = 8192) {
    this.arr = new Uint32Array(cap);
  }
  push6(a: number, b: number, c: number, d: number, e: number, f: number): void {
    if (this.len + 6 > this.arr.length) {
      let cap = this.arr.length * 2;
      while (cap < this.len + 6) cap *= 2;
      const next = new Uint32Array(cap);
      next.set(this.arr.subarray(0, this.len));
      this.arr = next;
    }
    const arr = this.arr;
    let i = this.len;
    arr[i++] = a; arr[i++] = b; arr[i++] = c;
    arr[i++] = d; arr[i++] = e; arr[i++] = f;
    this.len = i;
  }
  view(): Uint32Array {
    return this.arr.subarray(0, this.len);
  }
}

class GeometryBuilder {
  pos = new FloatList(1 << 16);
  nrm = new FloatList(1 << 16);
  pal = new FloatList(1 << 14);
  ao = new FloatList(1 << 14);
  uv = new FloatList(1 << 15);
  sway = new FloatList(1 << 14);
  idx = new IndexList(1 << 15);
  verts = 0;
  faces = 0;

  quad(
    corners: [number, number, number][],
    x: number, y: number, z: number,
    n: [number, number, number],
    id: number,
    aos: number[],
    sway: number,
    flip: boolean,
  ): void {
    const base = this.verts;
    for (let i = 0; i < 4; i++) {
      const c = corners[i];
      this.pos.push3(x + c[0], y + c[1], z + c[2]);
      this.nrm.push3(n[0], n[1], n[2]);
      this.pal.push1(id);
      this.ao.push1(aos[i]);
      this.uv.push2(FACE_UV[i][0], FACE_UV[i][1]);
      this.sway.push1(sway);
    }
    this.verts += 4;
    this.faces++;
    if (flip) this.idx.push6(base + 1, base + 2, base + 3, base + 1, base + 3, base);
    else this.idx.push6(base, base + 1, base + 2, base, base + 2, base + 3);
  }

  build(name: string): THREE.BufferGeometry | null {
    if (this.verts === 0) return null;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pos.view(), 3));
    g.setAttribute('normal', new THREE.BufferAttribute(this.nrm.view(), 3));
    g.setAttribute('aPaletteId', new THREE.BufferAttribute(this.pal.view(), 1));
    g.setAttribute('aAO', new THREE.BufferAttribute(this.ao.view(), 1));
    g.setAttribute('aFaceUv', new THREE.BufferAttribute(this.uv.view(), 2));
    g.setAttribute('aSway', new THREE.BufferAttribute(this.sway.view(), 1));
    g.setIndex(new THREE.BufferAttribute(this.idx.view(), 1));
    g.computeBoundingSphere();
    g.computeBoundingBox();
    g.name = name;
    return g;
  }
}

export interface MeshResult {
  solid: THREE.BufferGeometry | null;
  glow: THREE.BufferGeometry | null;
  water: THREE.BufferGeometry | null;
  stats: { voxels: number; faces: number; vertices: number; ms: number };
}

export function meshVolume(volume: VoxelBuffer): MeshResult {
  const t0 = performance.now();
  const { sx, sy, sz, data } = volume;
  const strideY = sx;
  const strideZ = sx * sy;
  const builders = [new GeometryBuilder(), new GeometryBuilder(), new GeometryBuilder()]; // solid / glow / water
  const aos = [1, 1, 1, 1];
  const off: [number, number, number] = [0, 0, 0];

  // Occlusion sampler working directly on the dense array.
  const occludes = (ix: number, iy: number, iz: number): number => {
    if (ix < 0 || iy < 0 || iz < 0 || ix >= sx || iy >= sy || iz >= sz) return 0;
    const v = data[ix + iy * strideY + iz * strideZ];
    return v !== 0 && KIND_OF[v] !== Kind.Water ? 1 : 0;
  };

  let i = 0;
  for (let iz = 0; iz < sz; iz++) {
    for (let iy = 0; iy < sy; iy++) {
      for (let ix = 0; ix < sx; ix++, i++) {
        const id = data[i];
        if (id === 0) continue;
        const kind = KIND_OF[id];
        const isWater = kind === Kind.Water;
        const builder = builders[isWater ? 2 : kind === Kind.Glow ? 1 : 0];
        const sway = kind === Kind.Leaf ? 0.35 + 0.65 * Math.min(1, Math.max(0, (iy + volume.oy - 4) / 34)) : 0;

        for (let f = 0; f < 6; f++) {
          const face = FACES[f];
          const nx = ix + face.n[0];
          const ny = iy + face.n[1];
          const nz = iz + face.n[2];
          let neighbour = 0;
          if (nx >= 0 && ny >= 0 && nz >= 0 && nx < sx && ny < sy && nz < sz) {
            neighbour = data[nx + ny * strideY + nz * strideZ];
          }
          if (neighbour !== 0) {
            const nk = KIND_OF[neighbour];
            if (!isWater && nk !== Kind.Water) continue; // opaque hides opaque
            if (isWater && nk === Kind.Water) continue; // water hides water
            if (isWater && nk !== Kind.Water) continue; // water against solid: hidden
          }
          if (isWater && face.n[1] < 0) continue; // no pond floor faces

          // --- ambient occlusion for the four corners ---
          let flip = false;
          if (!isWater) {
            for (let c = 0; c < 4; c++) {
              const corner = face.corners[c];
              off[0] = face.n[0];
              off[1] = face.n[1];
              off[2] = face.n[2];
              for (let a = 0; a < 3; a++) {
                if (a === face.axis) continue;
                off[a] = corner[a] === 1 ? 1 : -1;
              }
              const t1: [number, number, number] = [off[0], off[1], off[2]];
              const t2: [number, number, number] = [off[0], off[1], off[2]];
              // isolate each tangent
              let first = true;
              for (let a = 0; a < 3; a++) {
                if (a === face.axis) continue;
                if (first) {
                  t2[a] = 0;
                  first = false;
                } else {
                  t1[a] = 0;
                }
              }
              const s1 = occludes(nx + t1[0], ny + t1[1], nz + t1[2]);
              const s2 = occludes(nx + t2[0], ny + t2[1], nz + t2[2]);
              const cor = occludes(nx + off[0], ny + off[1], nz + off[2]);
              const level = s1 && s2 ? 0 : 3 - (s1 + s2 + cor);
              aos[c] = AO_LEVELS[level];
            }
            flip = aos[0] + aos[2] <= aos[1] + aos[3];
          } else {
            aos[0] = aos[1] = aos[2] = aos[3] = 1;
          }

          builder.quad(
            face.corners,
            ix + volume.ox,
            iy + volume.oy,
            iz + volume.oz,
            face.n,
            id,
            aos,
            sway,
            flip,
          );
        }
      }
    }
  }

  const solid = builders[0].build('voxel-solid');
  const glow = builders[1].build('voxel-glow');
  const water = builders[2].build('voxel-water');
  const faces = builders.reduce((s, b) => s + b.faces, 0);
  const vertices = builders.reduce((s, b) => s + b.verts, 0);

  return {
    solid,
    glow,
    water,
    stats: { voxels: volume.count, faces, vertices, ms: performance.now() - t0 },
  };
}

/** Mesh a tiny standalone volume (koi, cranes, clouds, props) into one geometry. */
export function meshProp(volume: VoxelBuffer, center = true): THREE.BufferGeometry {
  const result = meshVolume(volume);
  const geo = result.solid ?? result.glow ?? new THREE.BufferGeometry();
  if (center && geo.boundingBox) {
    const c = new THREE.Vector3();
    geo.boundingBox.getCenter(c);
    geo.translate(-c.x, -c.y, -c.z);
    geo.computeBoundingSphere();
  }
  return geo;
}
