import * as THREE from 'three';
import { VoxelBuffer } from './VoxelBuffer';
import { meshProp } from './Mesher';

export type Cell = [x: number, y: number, z: number, id: number];

/** Build a small merged geometry from explicit voxel cells (props, fish, birds). */
export function propGeometry(cells: Cell[], center = true): THREE.BufferGeometry {
  let minX = Infinity, minY = Infinity, minZ = Infinity;
  let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
  for (const [x, y, z] of cells) {
    minX = Math.min(minX, x); maxX = Math.max(maxX, x);
    minY = Math.min(minY, y); maxY = Math.max(maxY, y);
    minZ = Math.min(minZ, z); maxZ = Math.max(maxZ, z);
  }
  if (!cells.length) return new THREE.BufferGeometry();
  const pad = 2;
  const vol = new VoxelBuffer({
    sx: maxX - minX + 1 + pad * 2,
    sy: maxY - minY + 1 + pad * 2,
    sz: maxZ - minZ + 1 + pad * 2,
    ox: minX - pad,
    oy: minY - pad,
    oz: minZ - pad,
  });
  for (const [x, y, z, id] of cells) vol.set(x, y, z, id);
  return meshProp(vol, center);
}

/** A single unit cube carrying the voxel shader attributes. */
export function cubeGeometry(id: number): THREE.BufferGeometry {
  return propGeometry([[0, 0, 0, id]], true);
}
