import './styles/main.css';
import * as THREE from 'three';
import { Engine } from './core/Engine';
import { CameraRig, CAMERA_PRESETS } from './core/CameraRig';
import { Lighting } from './core/Lighting';
import { Sky } from './core/Sky';
import { QUALITY_PRESETS, SettingsStore, REBUILD_KEYS, DEFAULTS, type Settings } from './core/Settings';
import { VoxelMaterials } from './voxel/VoxelMaterials';
import { SEASONS, SEASON_ORDER, type SeasonId } from './voxel/Palette';
import { WorldBuilder, type World } from './world/WorldBuilder';
import { LAYOUT } from './world/Layout';
import { LifeSystem } from './anim/LifeSystem';
import { Ambience } from './audio/Ambience';
import { Loading } from './ui/Loading';
import { Toasts } from './ui/Toast';
import { Hud } from './ui/Hud';
import { Views } from './ui/Views';
import { TopBar } from './ui/TopBar';
import { ControlPanel } from './ui/ControlPanel';
import { Interaction } from './ui/Interaction';
import { randomSeedWord } from './util/rng';

const app = document.getElementById('app')!;
const stage = document.getElementById('stage')!;

const settings = new SettingsStore();

// Shareable state via URL (?seed=…&season=autumn&hour=19&quality=low&view=pond)
const params = new URLSearchParams(location.search);
if (params.get('seed')) settings.set('seed', params.get('seed')!, true);
if (params.get('season') && SEASON_ORDER.includes(params.get('season') as SeasonId)) {
  settings.set('season', params.get('season') as SeasonId, true);
}
if (params.get('hour')) settings.set('hour', Number(params.get('hour')), true);
if (params.get('quality')) settings.set('quality', params.get('quality') as Settings['quality'], true);
if (params.get('view')) settings.set('autoRotate', false, true);

/** Software rasterisers (CI / headless) get the lean preset so the scene stays responsive. */
function detectSoftwareRenderer(): boolean {
  try {
    const probe = document.createElement('canvas');
    const gl = probe.getContext('webgl2');
    if (!gl) return false;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const name = ext ? String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)) : '';
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /swiftshader|llvmpipe|software|basic render/i.test(name);
  } catch {
    return false;
  }
}
if (!params.get('quality') && detectSoftwareRenderer()) settings.set('quality', 'low', true);

const loading = new Loading(app);
const toasts = new Toasts(app);

try {
  const rig = new CameraRig(stage, stage.clientWidth / Math.max(1, stage.clientHeight), settings.get('fov'));
  const engine = new Engine(stage, rig.camera, settings);
  boot(rig, engine).catch((err) => {
    console.error(err);
    loading.fail(`The garden could not open: ${(err as Error).message}`);
  });
} catch (err) {
  console.error(err);
  loading.fail('WebGL2 is unavailable in this browser.');
}

async function boot(rig: CameraRig, engine: Engine): Promise<void> {
  const scene = engine.scene;
  const sky = new Sky();
  scene.add(sky.mesh);

  const lighting = new Lighting(QUALITY_PRESETS[settings.get('quality')].shadowMap);
  scene.add(lighting.group);

  const fog = new THREE.FogExp2(0xcfe9f7, settings.get('fogDensity'));
  scene.fog = fog;

  const materials = new VoxelMaterials(settings.get('season'));
  const builder = new WorldBuilder(materials);
  const audio = new Ambience();
  audio.setVolume(settings.get('audioVolume'));

  const unlockAudio = (): void => {
    void audio.unlock();
    window.removeEventListener('pointerdown', unlockAudio);
    window.removeEventListener('keydown', unlockAudio);
  };
  window.addEventListener('pointerdown', unlockAudio);
  window.addEventListener('keydown', unlockAudio);

  // voxel construction grid
  const grid = new THREE.GridHelper(148, 74, new THREE.Color('#edb54a'), new THREE.Color('#4d7cc4'));
  grid.position.set(0, LAYOUT.waterLevel + 1.02, 0);
  const gridMat = grid.material as THREE.Material;
  gridMat.transparent = true;
  gridMat.opacity = 0.22;
  grid.visible = settings.get('showGrid');
  grid.name = 'voxel-grid';
  scene.add(grid);

  // ---------------------------------------------------------------- interface
  const hud = new Hud(app);
  const views = new Views(app, (id) => {
    rig.applyPreset(id, 1.7);
    const preset = CAMERA_PRESETS.find((p) => p.id === id);
    toasts.show(`${preset?.jp ?? ''} ${preset?.label ?? id}`, 'sakura', 1600);
  });

  let uiVisible = true;
  const toggleUi = (): void => {
    uiVisible = !uiVisible;
    hud.setVisible(uiVisible);
    views.setVisible(uiVisible);
    panel.setVisible(uiVisible);
    topbar.setVisible(uiVisible);
    interaction.setEnabled(uiVisible);
    const size = engine.size;
    updateBias(size.width, size.height);
    if (!uiVisible) toasts.show('Interface hidden · press H to bring it back', 'gold', 2200);
  };

  const topbar = new TopBar(app, {
    onToggleAudio: () => settings.set('audio', !settings.get('audio')),
    onTogglePause: () => settings.set('paused', !settings.get('paused')),
    onSnapshot: () => snapshot(),
    onToggleUi: () => toggleUi(),
    onFullscreen: () => {
      if (document.fullscreenElement) void document.exitFullscreen();
      else void app.requestFullscreen?.();
    },
  });

  const interaction = new Interaction(app, engine.renderer.domElement, rig, materials, audio, toasts, scene);

  const panel = new ControlPanel(app, settings, {
    onRandomize: () => randomize(),
    onReset: () => resetAll(),
    onSnapshot: () => snapshot(),
    onExportRecipe: () => exportRecipe(),
    onImportRecipe: (file) => void importRecipe(file),
    onShare: () => void shareLink(),
    onGust: () => {
      life?.gust(1.4);
      toasts.show('A gust crosses the garden', 'sakura', 1800);
    },
    onRingBell: () => interaction.ringBell(),
  });

  const sunUv = new THREE.Vector2(0.5, 0.9);
  const updateBias = (w: number, h: number): void => {
    rig.resize(w / Math.max(1, h));
    if (!uiVisible) {
      rig.setViewBias(0, 0, w, h);
      return;
    }
    if (w > 900) {
      const rail = panel.root.getBoundingClientRect().width + 28;
      rig.setViewBias(rail * 0.5, 0, w, h);
      rig.setFramingScale(1);
    } else {
      const dock = panel.root.getBoundingClientRect().height + 96;
      rig.setViewBias(0, dock * 0.4, w, h);
      rig.setFramingScale(Math.max(1, Math.min(1.9, h / Math.max(160, (h - dock) * 1.35))));
    }
  };
  engine.onResize(updateBias);

  // -------------------------------------------------------------------- world
  let world: World | null = null;
  let life: LifeSystem | null = null;
  let building = false;
  let envDirty = true;
  let envTimer = 0;

  const applyLighting = (): void => {
    lighting.setTime(settings.get('hour'), settings.get('sunAzimuth'));
    sky.uniforms.uSunDir.value.copy(lighting.sunDir);
    sky.uniforms.uZenith.value.copy(lighting.zenithColor);
    sky.uniforms.uHorizon.value.copy(lighting.horizonColor);
    sky.uniforms.uGround.value.copy(lighting.zenithColor).multiplyScalar(0.72).lerp(lighting.horizonColor, 0.1);
    sky.uniforms.uSunColor.value.copy(lighting.sunColor);
    sky.uniforms.uNight.value = lighting.nightFactor;
    sky.uniforms.uSeasonTint.value.set(SEASONS[settings.get('season')].skyTint);
    fog.color.copy(lighting.horizonColor).lerp(lighting.zenithColor, 0.25);
    fog.density = settings.get('fogDensity');
    materials.uniforms.uGlow.value = lighting.glowLevel;
    hud.setClock(Lighting.hourLabel(settings.get('hour')), Lighting.phaseLabel(settings.get('hour')));
    envDirty = true;
  };

  const rebuild = async (showVeil: boolean): Promise<void> => {
    if (building) return;
    building = true;
    if (showVeil) loading.showVeil();
    try {
      const next = await builder.build(settings.values, (p) => loading.progress(p));
      if (life) {
        scene.remove(life.group);
        life.dispose();
        life = null;
      }
      if (world) {
        scene.remove(world.group);
        world.dispose();
      }
      world = next;
      scene.add(world.group);
      life = new LifeSystem(world, materials, settings);
      life.setPixelRatio(engine.renderer.getPixelRatio());
      life.onGust = (strength) => audio.chime(strength);
      life.onPetalLand = () => audio.droplet(0.22);
      scene.add(life.group);
      world.bell.onRing = (s) => {
        audio.bell(s);
        rig.kick(0.45 * s);
      };
      world.odoshi.onClack = () => audio.clack();
      interaction.setWorld(world, life);
      lighting.setLanternAnchors(world.lanterns);
      hud.setWorldStats(world.stats);
      lighting.markShadowDirty();
      engine.renderer.shadowMap.needsUpdate = true;
      envDirty = true;
    } finally {
      building = false;
      loading.hideVeil();
    }
  };

  // ----------------------------------------------------------- settings wiring
  const liveApply = (key: keyof Settings): void => {
    switch (key) {
      case 'hour':
      case 'sunAzimuth':
      case 'fogDensity':
        applyLighting();
        break;
      case 'season':
        materials.setSeason(settings.get('season'));
        applyLighting();
        break;
      case 'exposure':
        engine.setExposure(settings.get('exposure'));
        break;
      case 'aoStrength':
        materials.uniforms.uAO.value = settings.get('aoStrength');
        break;
      case 'edgeLines':
        materials.uniforms.uEdge.value = settings.get('edgeLines');
        break;
      case 'windSpeed':
        materials.uniforms.uWind.value = settings.get('windSpeed');
        break;
      case 'waveHeight':
        materials.setWaveHeight(settings.get('waveHeight'));
        break;
      case 'waterOpacity':
        materials.setWaterOpacity(settings.get('waterOpacity'));
        break;
      case 'glowStrength':
        lighting.glowStrength = settings.get('glowStrength');
        applyLighting();
        break;
      case 'lanternsLit':
        lighting.lanternsLit = settings.get('lanternsLit');
        applyLighting();
        break;
      case 'bloom':
        engine.post.bloom.strength = settings.get('bloom');
        break;
      case 'sunShafts':
        engine.post.grade.uniforms.uShafts.value = settings.get('sunShafts');
        break;
      case 'tiltShift':
        engine.post.grade.uniforms.uTiltShift.value = settings.get('tiltShift');
        break;
      case 'grain':
        engine.post.grade.uniforms.uGrain.value = settings.get('grain');
        break;
      case 'vignette':
        engine.post.grade.uniforms.uVignette.value = settings.get('vignette');
        break;
      case 'autoRotate':
      case 'rotateSpeed':
        rig.setAutoRotate(settings.get('autoRotate'), settings.get('rotateSpeed'));
        break;
      case 'fov':
        rig.setFov(settings.get('fov'));
        break;
      case 'quality':
        engine.setQuality(settings.get('quality'));
        lighting.setShadowMapSize(QUALITY_PRESETS[settings.get('quality')].shadowMap);
        engine.renderer.shadowMap.needsUpdate = true;
        life?.setPixelRatio(engine.renderer.getPixelRatio());
        envDirty = true;
        break;
      case 'wireframe':
        materials.solid.wireframe = settings.get('wireframe');
        materials.glow.wireframe = settings.get('wireframe');
        break;
      case 'showGrid':
        grid.visible = settings.get('showGrid');
        break;
      case 'paused':
        engine.setPaused(settings.get('paused'));
        topbar.setPaused(settings.get('paused'));
        break;
      case 'audio':
        topbar.setAudio(settings.get('audio'));
        audio.setEnabled(settings.get('audio'));
        break;
      case 'audioVolume':
        audio.setVolume(settings.get('audioVolume'));
        break;
      default:
        break;
    }
  };

  let rebuildTimer = 0;
  settings.onAny((key) => {
    liveApply(key);
    life?.applySetting(key);
    if (REBUILD_KEYS.includes(key)) {
      window.clearTimeout(rebuildTimer);
      rebuildTimer = window.setTimeout(() => void rebuild(true), 260);
    }
  });

  // ------------------------------------------------------------------ actions
  function snapshot(): void {
    engine.renderOnce();
    engine.renderer.domElement.toBlob((blob) => {
      if (!blob) {
        toasts.show('Snapshot failed — try again', 'gold');
        return;
      }
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `sakura-niwa-${settings.get('seed')}-${settings.get('season')}.png`;
      a.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 4000);
      toasts.show('Snapshot saved to your downloads', 'jade');
    }, 'image/png');
  }

  function exportRecipe(): void {
    const recipe = { kind: 'sakura-niwa-recipe', version: 1, created: new Date().toISOString(), settings: settings.values };
    const blob = new Blob([JSON.stringify(recipe, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sakura-niwa-${settings.get('seed')}.json`;
    a.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 4000);
    toasts.show('Garden recipe saved', 'jade');
  }

  async function importRecipe(file: File): Promise<void> {
    try {
      const text = await file.text();
      const data = JSON.parse(text) as { kind?: string; settings?: Partial<Settings> };
      if (data.kind !== 'sakura-niwa-recipe' || !data.settings) throw new Error('Not a garden recipe');
      const clean: Partial<Settings> = {};
      for (const [k, v] of Object.entries(data.settings)) {
        if (k in DEFAULTS && typeof v === typeof DEFAULTS[k as keyof Settings]) {
          (clean as Record<string, unknown>)[k] = v;
        }
      }
      settings.patch(clean);
      panel.syncAll();
      toasts.show(`Recipe loaded · ${settings.get('seed')}`, 'jade');
    } catch (err) {
      toasts.show(`Could not read that recipe: ${(err as Error).message}`, 'gold', 3600);
    }
  }

  async function shareLink(): Promise<void> {
    const url = new URL(location.href);
    url.search = new URLSearchParams({
      seed: settings.get('seed'),
      season: settings.get('season'),
      hour: settings.get('hour').toFixed(1),
      quality: settings.get('quality'),
    }).toString();
    try {
      await navigator.clipboard.writeText(url.toString());
      toasts.show('Share link copied to the clipboard', 'jade');
    } catch {
      window.history.replaceState(null, '', url.toString());
      toasts.show('Share link is now in the address bar', 'gold');
    }
  }

  function randomize(): void {
    const seed = randomSeedWord();
    settings.set('seed', seed);
    settings.set('treeDensity', Number((0.75 + Math.random() * 0.8).toFixed(2)));
    settings.set('blossomDensity', Number((0.7 + Math.random() * 0.7).toFixed(2)));
    settings.set('gardenDetail', Number((0.7 + Math.random() * 0.8).toFixed(2)));
    panel.syncAll();
    toasts.show(`New island · ${seed}`, 'sakura', 2600);
  }

  function resetAll(): void {
    settings.reset();
    panel.syncAll();
    rig.applyPreset('vista', 1.4);
    views.setActive('vista');
    toasts.show('Every dial back to its opening position', 'gold');
  }

  // ----------------------------------------------------------------- keyboard
  window.addEventListener('keydown', (e) => {
    const tag = (e.target as HTMLElement)?.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') return;
    switch (e.key.toLowerCase()) {
      case ' ':
        e.preventDefault();
        settings.set('paused', !settings.get('paused'));
        break;
      case 'r':
        rig.applyPreset('vista', 1.4);
        views.setActive('vista');
        break;
      case 'h':
        toggleUi();
        break;
      case 'm':
        settings.set('audio', !settings.get('audio'));
        break;
      case 'p':
        snapshot();
        break;
      case 'b':
        interaction.ringBell();
        break;
      case 'g':
        life?.gust(1.4);
        break;
      case 'f':
        if (document.fullscreenElement) void document.exitFullscreen();
        else void app.requestFullscreen?.();
        break;
      default:
        if (/^[1-9]$/.test(e.key)) {
          const preset = CAMERA_PRESETS[Number(e.key) - 1];
          if (preset) {
            rig.applyPreset(preset.id, 1.5);
            views.setActive(preset.id);
          }
        }
        break;
    }
  });

  stage.addEventListener('scene-context-lost', () => {
    loading.showVeil('Graphics context lost — restoring');
  });
  stage.addEventListener('scene-context-restored', () => {
    loading.hideVeil();
    toasts.show('Graphics context restored', 'jade');
  });

  // ------------------------------------------------------------ initial state
  for (const key of Object.keys(settings.values) as (keyof Settings)[]) liveApply(key);
  applyLighting();
  topbar.setAudio(settings.get('audio'));
  topbar.setPaused(settings.get('paused'));
  engine.start();

  await rebuild(false);
  loading.finish();
  hud.ready();
  views.ready();
  panel.ready();

  const startView = params.get('view');
  if (startView && CAMERA_PRESETS.some((p) => p.id === startView)) {
    rig.applyPreset(startView, 0.01);
    views.setActive(startView);
  } else {
    rig.intro(() => toasts.show('Drag to orbit · click the pagoda to ring its bell', 'sakura', 4600));
  }

  // -------------------------------------------------------------------- frame

  engine.onFrame((dt, time) => {
    rig.update(dt, time);
    lighting.update(time);
    sky.update(time);
    materials.update(time);
    if (world) for (const prop of world.props) prop.update(dt, time);
    life?.update(dt, time, lighting.nightFactor);
    interaction.update(dt, time);
    audio.setWind(settings.get('windSpeed'));
    audio.setNight(lighting.nightFactor);
    audio.update(dt, time);

    if (lighting.consumeShadowDirty()) engine.renderer.shadowMap.needsUpdate = true;

    if (envDirty) {
      envTimer += dt;
      if (envTimer > 0.3) {
        envTimer = 0;
        envDirty = false;
        materials.setEnvironment(sky.bakeEnvironment(engine.renderer));
      }
    }

    const visibility = lighting.sunScreenPosition(rig.camera, sunUv);
    const grade = engine.post.grade.uniforms;
    grade.uSunPos.value.copy(sunUv);
    grade.uTime.value = time;
    grade.uShafts.value = settings.get('sunShafts') * visibility * (0.2 + 0.8 * lighting.dayFactor);

    hud.update(dt, engine.stats);
  });

  // Debug + automation surface (used by the browser verification harness).
  (window as unknown as Record<string, unknown>).__garden = {
    settings,
    engine,
    rig,
    lighting,
    materials,
    sky,
    audio,
    panel,
    interaction,
    get world() {
      return world;
    },
    get life() {
      return life;
    },
    rebuild,
    snapshot,
    randomize,
    resetAll,
    setView: (id: string) => {
      rig.applyPreset(id, 0.01);
      views.setActive(id);
    },
    debug: () => ({
      fps: Number(engine.stats.fps.toFixed(1)),
      drawCalls: engine.stats.drawCalls,
      triangles: engine.stats.triangles,
      voxels: world?.stats.voxels ?? 0,
      quads: world?.stats.faces ?? 0,
      buildMs: Math.round(world?.stats.buildMs ?? 0),
      meshMs: Math.round(world?.stats.meshMs ?? 0),
      hour: settings.get('hour'),
      season: settings.get('season'),
      quality: settings.get('quality'),
      camera: rig.camera.position.toArray().map((n) => Number(n.toFixed(1))),
      lanterns: world?.lanterns.length ?? 0,
      interactives: world?.interactives.length ?? 0,
      petals: settings.get('petalAmount'),
      audioRunning: audio.running,
    }),
  };
}
