import * as THREE from 'three';
import { el } from './dom';
import { P } from '../voxel/Palette';
import { cubeGeometry } from '../voxel/PropKit';
import type { VoxelMaterials } from '../voxel/VoxelMaterials';
import type { CameraRig } from '../core/CameraRig';
import type { World, Interactive } from '../world/WorldBuilder';
import type { LifeSystem } from '../anim/LifeSystem';
import type { Ambience } from '../audio/Ambience';
import type { Toasts } from './Toast';
import { LAYOUT } from '../world/Layout';

interface Flare {
  light: THREE.PointLight;
  mesh: THREE.Mesh;
  life: number;
}

/**
 * Pointer picking: hover labels for the landmarks, and clicks that ring the
 * bell, flare a lantern, or send a ripple across the koi pond.
 */
export class Interaction {
  private camera: THREE.Camera;
  private dom: HTMLElement;
  private raycaster = new THREE.Raycaster();
  private pointer = new THREE.Vector2(-2, -2);
  private proxies: THREE.Mesh[] = [];
  private proxyGroup = new THREE.Group();
  private tooltip: HTMLElement;
  private hovered: Interactive | null = null;
  private world: World | null = null;
  private life: LifeSystem | null = null;
  private materials: VoxelMaterials;
  private rig: CameraRig;
  private audio: Ambience;
  private toasts: Toasts;
  private flares: Flare[] = [];
  private flareGeo: THREE.BufferGeometry;
  private downAt = { x: 0, y: 0 };
  private pressActive = false;
  private hoverAccum = 0;
  private needsHover = false;
  private waterPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -(LAYOUT.waterLevel + 1));
  private hitPoint = new THREE.Vector3();
  private enabled = true;

  constructor(
    app: HTMLElement,
    dom: HTMLElement,
    rig: CameraRig,
    materials: VoxelMaterials,
    audio: Ambience,
    toasts: Toasts,
    scene: THREE.Scene,
  ) {
    this.dom = dom;
    this.camera = rig.camera;
    this.rig = rig;
    this.materials = materials;
    this.audio = audio;
    this.toasts = toasts;
    this.tooltip = el('div', { class: 'tooltip', id: 'tooltip' });
    app.appendChild(this.tooltip);

    this.proxyGroup.visible = false;
    this.proxyGroup.name = 'pick-proxies';
    scene.add(this.proxyGroup);

    this.flareGeo = cubeGeometry(P.LANTERN_CORE);
    for (let i = 0; i < 4; i++) {
      const light = new THREE.PointLight(0xffc478, 0, 34, 2);
      light.visible = false;
      const mesh = new THREE.Mesh(this.flareGeo, materials.glow);
      mesh.visible = false;
      scene.add(light, mesh);
      this.flares.push({ light, mesh, life: 0 });
    }

    dom.addEventListener('pointermove', this.onPointerMove);
    dom.addEventListener('pointerdown', this.onPointerDown);
    // OrbitControls captures the pointer on its own element, so pointerup can
    // arrive somewhere else in the tree — listen at the window to be sure.
    window.addEventListener('pointerup', this.onPointerUp, true);
    window.addEventListener('pointercancel', this.onPointerCancel, true);
    dom.addEventListener('pointerleave', this.onPointerLeave);
  }

  setWorld(world: World, life: LifeSystem): void {
    this.world = world;
    this.life = life;
    this.proxyGroup.clear();
    this.proxies = [];
    for (const item of world.interactives) {
      const geo = new THREE.SphereGeometry(item.radius, 10, 8);
      const mesh = new THREE.Mesh(geo, undefined);
      mesh.position.copy(item.position);
      mesh.userData.item = item;
      this.proxyGroup.add(mesh);
      this.proxies.push(mesh);
    }
    this.proxyGroup.updateMatrixWorld(true);
  }

  setEnabled(on: boolean): void {
    this.enabled = on;
    if (!on) this.clearHover();
  }

  private onPointerMove = (e: PointerEvent): void => {
    const rect = this.dom.getBoundingClientRect();
    this.pointer.set(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1);
    this.tooltip.style.left = `${e.clientX - rect.left}px`;
    this.tooltip.style.top = `${e.clientY - rect.top}px`;
    this.needsHover = true;
  };

  private onPointerLeave = (): void => {
    this.pointer.set(-2, -2);
    this.clearHover();
  };

  private onPointerDown = (e: PointerEvent): void => {
    this.downAt = { x: e.clientX, y: e.clientY };
    this.pressActive = true;
  };

  private onPointerCancel = (): void => {
    this.pressActive = false;
  };

  private onPointerUp = (e: PointerEvent): void => {
    if (!this.pressActive) return;
    this.pressActive = false;
    const dx = e.clientX - this.downAt.x;
    const dy = e.clientY - this.downAt.y;
    // A stationary press is a tap, however long the frame took to arrive.
    if (Math.hypot(dx, dy) > 8 || !this.enabled) return;
    const rect = this.dom.getBoundingClientRect();
    if (e.clientX < rect.left || e.clientX > rect.right || e.clientY < rect.top || e.clientY > rect.bottom) return;
    this.pointer.set(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1);
    this.pick();
    this.activate();
  };

  private clearHover(): void {
    this.hovered = null;
    this.tooltip.classList.remove('is-visible');
    this.dom.classList.remove('is-pointing');
  }

  private pick(): void {
    if (!this.world || this.pointer.x < -1.5) {
      this.clearHover();
      return;
    }
    this.raycaster.setFromCamera(this.pointer, this.camera);
    const hits = this.raycaster.intersectObjects(this.proxies, false);
    const item = hits.length ? (hits[0].object.userData.item as Interactive) : null;
    if (item === this.hovered) return;
    this.hovered = item;
    if (item) {
      this.tooltip.innerHTML = '';
      this.tooltip.append(el('span', { text: item.label }), el('small', { text: item.hint }));
      this.tooltip.classList.add('is-visible');
      this.dom.classList.add('is-pointing');
    } else {
      this.clearHover();
    }
  }

  private activate(): void {
    const item = this.hovered;
    if (!item || !this.world) {
      // bare water tap anywhere on the pond
      this.raycaster.setFromCamera(this.pointer, this.camera);
      if (this.raycaster.ray.intersectPlane(this.waterPlane, this.hitPoint)) {
        const t = this.world?.terrain;
        if (t && (t.pondAt(this.hitPoint.x, this.hitPoint.z) > 0.3 || t.streamAt(this.hitPoint.x, this.hitPoint.z) > 0.3)) {
          this.ripple(this.hitPoint.x, this.hitPoint.z);
        }
      }
      return;
    }
    switch (item.kind) {
      case 'bell':
        this.world.bell?.ring(1);
        this.life?.petals.burst(item.position, 70);
        this.toasts.show('The bonshō rolls out across the valley', 'gold', 3200);
        break;
      case 'lantern':
        this.flare(item.position);
        this.audio.flare();
        break;
      case 'water': {
        this.raycaster.setFromCamera(this.pointer, this.camera);
        if (this.raycaster.ray.intersectPlane(this.waterPlane, this.hitPoint)) {
          this.ripple(this.hitPoint.x, this.hitPoint.z);
        } else {
          this.ripple(item.position.x, item.position.z);
        }
        break;
      }
      default:
        this.rig.focus(item.position, Math.max(30, item.radius * 2.6), 1.4);
        this.toasts.show(`${item.label} — ${item.hint}`, 'sakura', 3000);
        break;
    }
  }

  private ripple(x: number, z: number): void {
    this.materials.addRipple(x, z, 1);
    this.life?.koi.startle(x, z);
    this.audio.splash(1);
  }

  private flare(position: THREE.Vector3): void {
    const slot = this.flares.reduce((best, f) => (f.life < best.life ? f : best), this.flares[0]);
    slot.life = 1;
    slot.light.position.copy(position);
    slot.light.visible = true;
    slot.mesh.position.copy(position);
    slot.mesh.visible = true;
  }

  ringBell(): void {
    this.world?.bell?.ring(1);
    const pagoda = this.world?.interactives.find((i) => i.id === 'pagoda');
    if (pagoda) this.life?.petals.burst(pagoda.position, 80);
    this.toasts.show('The bonshō rolls out across the valley', 'gold', 3200);
  }

  update(dt: number, time: number): void {
    this.hoverAccum += dt;
    if (this.needsHover && this.hoverAccum > 0.07) {
      this.hoverAccum = 0;
      this.needsHover = false;
      this.pick();
    }
    for (const f of this.flares) {
      if (f.life <= 0) continue;
      f.life = Math.max(0, f.life - dt * 0.85);
      const k = f.life;
      const pulse = Math.sin((1 - k) * Math.PI);
      f.light.intensity = pulse * 90;
      f.mesh.scale.setScalar(0.6 + pulse * 2.6);
      f.mesh.rotation.set(time * 1.2, time * 0.9, 0);
      if (f.life <= 0) {
        f.light.visible = false;
        f.mesh.visible = false;
      }
    }
  }

  dispose(): void {
    this.dom.removeEventListener('pointermove', this.onPointerMove);
    this.dom.removeEventListener('pointerdown', this.onPointerDown);
    window.removeEventListener('pointerup', this.onPointerUp, true);
    window.removeEventListener('pointercancel', this.onPointerCancel, true);
    this.dom.removeEventListener('pointerleave', this.onPointerLeave);
    for (const p of this.proxies) p.geometry.dispose();
    this.flareGeo.dispose();
    this.tooltip.remove();
  }
}
