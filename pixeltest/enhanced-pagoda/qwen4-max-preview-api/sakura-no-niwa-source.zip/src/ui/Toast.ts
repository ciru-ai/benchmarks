import { el } from './dom';

export type ToastTone = 'gold' | 'sakura' | 'jade';

/** Small transient notices, stacked under the top bar. */
export class Toasts {
  private root: HTMLElement;
  private active: HTMLElement[] = [];

  constructor(app: HTMLElement) {
    this.root = el('div', { class: 'toasts', id: 'toasts', role: 'status', 'aria-live': 'polite' });
    app.appendChild(this.root);
  }

  show(message: string, tone: ToastTone = 'gold', ms = 2600): void {
    const node = el('div', { class: `toast toast--${tone}` }, [el('i'), el('span', { text: message })]);
    this.root.appendChild(node);
    this.active.push(node);
    while (this.active.length > 3) {
      const old = this.active.shift();
      old?.remove();
    }
    window.setTimeout(() => {
      node.classList.add('is-out');
      window.setTimeout(() => {
        node.remove();
        const i = this.active.indexOf(node);
        if (i >= 0) this.active.splice(i, 1);
      }, 420);
    }, ms);
  }
}
