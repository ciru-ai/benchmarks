import { el } from './dom';
import type { BuildProgress } from '../world/WorldBuilder';

/** Full-screen ink loader plus the lightweight "rebuilding" veil. */
export class Loading {
  private root: HTMLElement;
  private fill: HTMLElement;
  private stage: HTMLElement;
  private kanji: HTMLElement;
  private veil: HTMLElement;
  private veilText: HTMLElement;

  constructor(app: HTMLElement) {
    this.root = document.getElementById('loader')!;
    this.fill = document.getElementById('loader-fill')!;
    this.stage = document.getElementById('loader-stage')!;
    this.kanji = document.getElementById('loader-kanji')!;

    this.veilText = el('span', { text: 'Rebuilding the garden' });
    this.veil = el('div', { class: 'veil', id: 'veil' }, [
      el('div', { class: 'veil__box' }, [el('div', { class: 'spinner' }), this.veilText]),
    ]);
    app.appendChild(this.veil);
  }

  progress(p: BuildProgress): void {
    const pct = Math.round(((p.step + 0.35) / p.steps) * 100);
    this.fill.style.width = `${Math.min(100, pct)}%`;
    this.stage.textContent = p.label;
    this.kanji.textContent = p.jp;
  }

  message(text: string): void {
    this.stage.textContent = text;
  }

  finish(): void {
    this.fill.style.width = '100%';
    this.stage.textContent = 'The garden is open';
    window.setTimeout(() => this.root.classList.add('is-hidden'), 260);
  }

  showVeil(text = 'Rebuilding the garden'): void {
    this.veilText.textContent = text;
    this.veil.classList.add('is-visible');
  }

  hideVeil(): void {
    this.veil.classList.remove('is-visible');
  }

  fail(message: string): void {
    this.stage.textContent = message;
    this.kanji.textContent = '×';
    this.fill.style.width = '100%';
    this.fill.style.background = 'linear-gradient(90deg,#ff5c4d,#ffb02e)';
  }
}
