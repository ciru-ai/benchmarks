import { el, svgIcon, ICONS } from './dom';
import { Lighting } from '../core/Lighting';
import type { Settings, SettingsStore, QualityLevel } from '../core/Settings';
import { SEASONS, SEASON_ORDER, type SeasonId } from '../voxel/Palette';
import { clamp01 } from '../util/math';

export interface PanelActions {
  onRandomize(): void;
  onReset(): void;
  onSnapshot(): void;
  onExportRecipe(): void;
  onImportRecipe(file: File): void;
  onShare(): void;
  onGust(): void;
  onRingBell(): void;
}

type Syncer = () => void;

/**
 * The permanent instrument rail: every parameter that changes how the diorama
 * looks or behaves, applied the instant it moves.
 */
export class ControlPanel {
  readonly root: HTMLElement;
  private settings: SettingsStore;
  private syncers = new Map<keyof Settings, Syncer[]>();
  private fileInput: HTMLInputElement;

  constructor(app: HTMLElement, settings: SettingsStore, actions: PanelActions) {
    this.settings = settings;

    const body = el('div', { class: 'panel__body scroll-y' });
    this.root = el('aside', { class: 'panel', id: 'panel', 'aria-label': 'Garden controls' }, [
      el('div', { class: 'panel__head' }, [
        el('h2', { text: '作庭 · Garden Instruments' }),
        el('p', { text: 'Every dial repaints the island live' }),
      ]),
      body,
    ]);
    app.appendChild(this.root);

    // ---------------------------------------------------------- season & sky
    const sky = this.group(body, 'Season & sky', '空');
    this.seasonCards(sky);
    this.slider(sky, 'hour', 'Hour of day', 0, 24, 0.1, (v) => `${Lighting.hourLabel(v)} · ${Lighting.phaseLabel(v)}`, 'Sun, moon, lantern fires and sky colour follow this dial.');
    this.segmented(sky, 'hour', 'Jump to', [
      { label: 'Dawn', value: 6.4 },
      { label: 'Noon', value: 12.5 },
      { label: 'Dusk', value: 18.2 },
      { label: 'Night', value: 21.5 },
    ]);
    this.slider(sky, 'sunAzimuth', 'Sun bearing', -180, 180, 1, (v) => `${v.toFixed(0)}°`);
    this.slider(sky, 'fogDensity', 'Atmosphere', 0, 0.004, 0.0001, (v) => `${(v * 1000).toFixed(2)}‰`);
    this.slider(sky, 'exposure', 'Exposure', 0.5, 1.8, 0.01, (v) => `${v.toFixed(2)}×`);

    // ------------------------------------------------------------- the world
    const world = this.group(body, 'Island & pagoda', '庭');
    this.seedRow(world, actions);
    this.segmented(world, 'pagodaTiers', 'Pagoda tiers', [
      { label: 'Three', value: 3 },
      { label: 'Five', value: 5 },
      { label: 'Seven', value: 7 },
    ]);
    this.slider(world, 'treeDensity', 'Tree count', 0.3, 1.8, 0.1, (v) => `${Math.round(v * 100)}%`, 'Rebuilds the planting plan.');
    this.slider(world, 'blossomDensity', 'Canopy fullness', 0.4, 1.6, 0.05, (v) => `${Math.round(v * 100)}%`);
    this.slider(world, 'gardenDetail', 'Undergrowth', 0.2, 1.8, 0.1, (v) => `${Math.round(v * 100)}%`, 'Shrubs, iris, boulders, lily pads and flower beds.');

    // -------------------------------------------------------------- the life
    const life = this.group(body, 'Living things', '命');
    this.slider(life, 'petalAmount', 'Blossom fall', 0, 2300, 25, (v) => `${v.toFixed(0)} petals`);
    this.slider(life, 'windSpeed', 'Wind', 0, 2, 0.02, (v) => `${(v * 18).toFixed(0)} km/h`, 'Drives petals, canopy sway, smoke and the chimes.');
    this.slider(life, 'koiCount', 'Koi in the pond', 0, 30, 1, (v) => `${v.toFixed(0)} fish`);
    this.slider(life, 'waveHeight', 'Water swell', 0, 0.5, 0.01, (v) => v.toFixed(2));
    this.slider(life, 'waterOpacity', 'Water clarity', 0.35, 1, 0.01, (v) => `${Math.round(v * 100)}%`);
    this.toggle(life, 'lanternsLit', 'Lanterns lit');
    this.toggle(life, 'clouds', 'Drifting clouds');
    this.toggle(life, 'cranes', 'Cranes overhead');
    this.toggle(life, 'fireflies', 'Fireflies at night');
    const lifeBtns = el('div', { class: 'btn-grid' });
    lifeBtns.append(
      this.button('Send a gust', ICONS.leaf, () => actions.onGust()),
      this.button('Ring the bell', ICONS.bell, () => actions.onRingBell(), true),
    );
    life.appendChild(lifeBtns);

    // -------------------------------------------------------------- the look
    const look = this.group(body, 'Light & lens', '光');
    this.slider(look, 'bloom', 'Bloom', 0, 1.6, 0.02, (v) => v.toFixed(2));
    this.slider(look, 'sunShafts', 'Sun shafts', 0, 1.5, 0.02, (v) => v.toFixed(2));
    this.slider(look, 'glowStrength', 'Lantern glow', 0, 2.5, 0.05, (v) => `${v.toFixed(2)}×`);
    this.slider(look, 'aoStrength', 'Voxel occlusion', 0, 1.4, 0.02, (v) => v.toFixed(2));
    this.slider(look, 'edgeLines', 'Voxel edges', 0, 1, 0.02, (v) => `${Math.round(v * 100)}%`, 'Darkens the seam between neighbouring cubes.');
    this.slider(look, 'tiltShift', 'Miniature blur', 0, 1.2, 0.02, (v) => v.toFixed(2));
    this.slider(look, 'vignette', 'Vignette', 0, 1, 0.02, (v) => v.toFixed(2));
    this.slider(look, 'grain', 'Film grain', 0, 1, 0.02, (v) => v.toFixed(2));

    // ------------------------------------------------------------ the camera
    const cam = this.group(body, 'Camera & display', '視');
    this.toggle(cam, 'autoRotate', 'Slow orbit');
    this.slider(cam, 'rotateSpeed', 'Orbit speed', -1.5, 1.5, 0.02, (v) => v.toFixed(2));
    this.slider(cam, 'fov', 'Field of view', 24, 70, 1, (v) => `${v.toFixed(0)}°`);
    this.toggle(cam, 'wireframe', 'Wireframe');
    this.toggle(cam, 'showGrid', 'Voxel grid');

    // ------------------------------------------------------------- the system
    const sys = this.group(body, 'Quality & keepsakes', '系');
    this.segmented(sys, 'quality', 'Render quality', [
      { label: 'Low', value: 'low' },
      { label: 'Med', value: 'medium' },
      { label: 'High', value: 'high' },
      { label: 'Ultra', value: 'ultra' },
    ]);
    this.slider(sys, 'audioVolume', 'Ambience volume', 0, 1, 0.01, (v) => `${Math.round(v * 100)}%`);
    this.toggle(sys, 'paused', 'Freeze time');

    const grid = el('div', { class: 'btn-grid' });
    grid.append(
      this.button('Snapshot', ICONS.camera, () => actions.onSnapshot(), true),
      this.button('Share link', ICONS.info, () => actions.onShare()),
      this.button('Save recipe', ICONS.download, () => actions.onExportRecipe()),
      this.button('Load recipe', ICONS.sliders, () => this.fileInput.click()),
      this.button('Randomize', ICONS.dice, () => actions.onRandomize()),
      this.button('Reset all', ICONS.reset, () => actions.onReset()),
    );
    sys.appendChild(grid);
    sys.appendChild(
      el('p', { class: 'ctl__hint', text: 'A recipe is a small JSON file with every dial position — load it back to restore this exact garden.' }),
    );

    this.fileInput = el('input', { type: 'file', accept: 'application/json,.json', style: 'display:none' });
    this.fileInput.addEventListener('change', () => {
      const file = this.fileInput.files?.[0];
      if (file) actions.onImportRecipe(file);
      this.fileInput.value = '';
    });
    sys.appendChild(this.fileInput);

    settings.onAny((key) => this.syncKey(key));
    this.syncAll();
  }

  // ------------------------------------------------------------------ helpers
  private group(parent: HTMLElement, title: string, jp: string): HTMLElement {
    const node = el('section', { class: 'group' }, [
      el('h3', { class: 'group__title' }, [title, el('span', { class: 'jp', text: jp })]),
    ]);
    parent.appendChild(node);
    return node;
  }

  private register(key: keyof Settings, fn: Syncer): void {
    const list = this.syncers.get(key) ?? [];
    list.push(fn);
    this.syncers.set(key, list);
  }

  private syncKey(key: keyof Settings): void {
    for (const fn of this.syncers.get(key) ?? []) fn();
  }

  syncAll(): void {
    for (const key of this.syncers.keys()) this.syncKey(key);
  }

  private slider(
    parent: HTMLElement,
    key: keyof Settings,
    label: string,
    min: number,
    max: number,
    step: number,
    format: (v: number) => string,
    hint?: string,
  ): void {
    const value = el('span', { class: 'ctl__value' });
    const input = el('input', {
      type: 'range',
      min,
      max,
      step,
      'aria-label': label,
    }) as HTMLInputElement;
    const row = el('div', { class: 'ctl' }, [
      el('div', { class: 'ctl__label' }, [el('span', { text: label }), value]),
      input,
      hint ? el('p', { class: 'ctl__hint', text: hint }) : null,
    ]);
    parent.appendChild(row);

    const sync = (): void => {
      const v = Number(this.settings.get(key));
      input.value = String(v);
      value.textContent = format(v);
      input.style.setProperty('--fill', `${clamp01((v - min) / (max - min)) * 100}%`);
    };
    input.addEventListener('input', () => {
      this.settings.set(key, Number(input.value) as never);
    });
    this.register(key, sync);
    sync();
  }

  private toggle(parent: HTMLElement, key: keyof Settings, label: string): void {
    const btn = el('button', { class: 'toggle', type: 'button', 'aria-pressed': 'false' }, [
      el('span', { text: label }),
      el('span', { class: 'toggle__switch' }),
    ]);
    parent.appendChild(btn);
    const sync = (): void => {
      const on = Boolean(this.settings.get(key));
      btn.classList.toggle('is-on', on);
      btn.setAttribute('aria-pressed', String(on));
    };
    btn.addEventListener('click', () => this.settings.set(key, !this.settings.get(key) as never));
    this.register(key, sync);
    sync();
  }

  private segmented<T extends string | number>(
    parent: HTMLElement,
    key: keyof Settings,
    label: string,
    options: { label: string; value: T }[],
  ): void {
    const wrap = el('div', { class: 'segmented', role: 'group', 'aria-label': label });
    const buttons: HTMLButtonElement[] = [];
    for (const opt of options) {
      const btn = el('button', { type: 'button', text: opt.label });
      btn.addEventListener('click', () => this.settings.set(key, opt.value as never));
      buttons.push(btn);
      wrap.appendChild(btn);
    }
    parent.appendChild(el('div', { class: 'ctl' }, [el('div', { class: 'ctl__label' }, [el('span', { text: label })]), wrap]));
    const sync = (): void => {
      const cur = this.settings.get(key);
      options.forEach((opt, i) => buttons[i].classList.toggle('is-active', opt.value === cur));
    };
    this.register(key, sync);
    sync();
  }

  private seasonCards(parent: HTMLElement): void {
    const wrap = el('div', { class: 'seasons' });
    const cards: HTMLButtonElement[] = [];
    for (const id of SEASON_ORDER) {
      const theme = SEASONS[id];
      const card = el('button', {
        class: 'season',
        type: 'button',
        title: theme.blurb,
        style: `--s1:${theme.swatch[0]};--s2:${theme.swatch[1]};--s3:${theme.swatch[2]}`,
      }, [
        el('span', { class: 'season__jp', text: theme.jp }),
        el('span', { class: 'season__name', text: theme.label }),
      ]);
      card.addEventListener('click', () => {
        this.settings.set('season', id as SeasonId);
        this.settings.set('hour', theme.defaultHour);
      });
      cards.push(card);
      wrap.appendChild(card);
    }
    parent.appendChild(el('div', { class: 'ctl' }, [wrap]));
    const sync = (): void => {
      const cur = this.settings.get('season');
      SEASON_ORDER.forEach((id, i) => cards[i].classList.toggle('is-active', id === cur));
    };
    this.register('season', sync);
    sync();
  }

  private seedRow(parent: HTMLElement, actions: PanelActions): void {
    const input = el('input', { type: 'text', 'aria-label': 'World seed', spellcheck: 'false' }) as HTMLInputElement;
    const dice = el('button', { class: 'btn btn--icon', type: 'button', title: 'Roll a new seed' }, [svgIcon(ICONS.dice)]);
    const row = el('div', { class: 'seedrow' }, [input, dice]);
    parent.appendChild(
      el('div', { class: 'ctl' }, [
        el('div', { class: 'ctl__label' }, [el('span', { text: 'World seed' })]),
        row,
        el('p', { class: 'ctl__hint', text: 'Same seed, same island — terrain, trees and stone all follow it.' }),
      ]),
    );
    input.addEventListener('change', () => {
      const v = input.value.trim();
      if (v) this.settings.set('seed', v);
      else input.value = this.settings.get('seed');
    });
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') input.blur();
    });
    dice.addEventListener('click', () => actions.onRandomize());
    const sync = (): void => {
      if (document.activeElement !== input) input.value = this.settings.get('seed');
    };
    this.register('seed', sync);
    sync();
  }

  private button(label: string, icon: string, onClick: () => void, primary = false): HTMLButtonElement {
    const btn = el('button', { class: `btn${primary ? ' btn--primary' : ''}`, type: 'button' }, [
      svgIcon(icon),
      el('span', { text: label }),
    ]);
    btn.addEventListener('click', onClick);
    return btn;
  }

  ready(): void {
    this.root.classList.add('is-ready');
  }

  setVisible(visible: boolean): void {
    this.root.style.display = visible ? '' : 'none';
  }

  get quality(): QualityLevel {
    return this.settings.get('quality');
  }
}
