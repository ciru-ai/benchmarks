import { el } from './dom';
import { formatCount } from '../util/math';
import type { EngineStats } from '../core/Engine';
import type { WorldStats } from '../world/WorldBuilder';

/** Bottom-left legend + live telemetry. */
export class Hud {
  private root: HTMLElement;
  private fps: HTMLElement;
  private draws: HTMLElement;
  private tris: HTMLElement;
  private voxels: HTMLElement;
  private faces: HTMLElement;
  private clock: HTMLElement;
  private accum = 0;

  constructor(app: HTMLElement) {
    this.fps = el('b', { text: '—' });
    this.draws = el('b', { text: '—' });
    this.tris = el('b', { text: '—' });
    this.voxels = el('b', { text: '—' });
    this.faces = el('b', { text: '—' });
    this.clock = el('b', { text: '—' });

    const hints = el('div', { class: 'hud__card hud__card--hints' }, [
      el('h3', { class: 'hud__title' }, ['庭の歩き方', el('b', { text: '· how to wander' })]),
      el('ul', { class: 'hud__hints' }, [
        el('li', {}, [el('kbd', { text: 'drag' }), el('span', { text: 'orbit the island · scroll to zoom · right-drag to pan' })]),
        el('li', {}, [el('kbd', { text: 'click' }), el('span', { text: 'ring the pagoda bell, light lanterns, ripple the pond' })]),
        el('li', {}, [el('kbd', { text: 'space' }), el('span', { text: 'freeze time · R resets the view · H hides the interface' })]),
      ]),
    ]);

    const stats = el('div', { class: 'hud__card' }, [
      el('div', { class: 'stats' }, [
        el('span', {}, ['FPS ', this.fps]),
        el('span', { class: 'sep', text: '│' }),
        el('span', {}, ['draws ', this.draws]),
        el('span', { class: 'sep', text: '│' }),
        el('span', {}, ['tris ', this.tris]),
        el('span', { class: 'sep', text: '│' }),
        el('span', {}, ['voxels ', this.voxels]),
        el('span', { class: 'sep', text: '│' }),
        el('span', {}, ['quads ', this.faces]),
        el('span', { class: 'sep', text: '│' }),
        el('span', {}, ['hour ', this.clock]),
      ]),
    ]);

    this.root = el('div', { class: 'hud', id: 'hud' }, [hints, stats]);
    app.appendChild(this.root);
  }

  ready(): void {
    this.root.classList.add('is-ready');
  }

  setWorldStats(stats: WorldStats): void {
    this.voxels.textContent = formatCount(stats.voxels);
    this.faces.textContent = formatCount(stats.faces);
    this.root.title = `Built in ${Math.round(stats.buildMs)} ms · meshed in ${Math.round(stats.meshMs)} ms`;
  }

  setClock(label: string, phase: string): void {
    this.clock.textContent = `${label} ${phase}`;
  }

  update(dt: number, stats: EngineStats): void {
    this.accum += dt;
    if (this.accum < 0.35) return;
    this.accum = 0;
    this.fps.textContent = stats.fps.toFixed(0);
    this.draws.textContent = String(stats.drawCalls);
    this.tris.textContent = formatCount(stats.triangles);
    this.fps.style.color = stats.fps >= 50 ? 'var(--jade)' : stats.fps >= 28 ? 'var(--gold)' : 'var(--danger)';
  }

  setVisible(visible: boolean): void {
    this.root.style.display = visible ? '' : 'none';
  }
}
