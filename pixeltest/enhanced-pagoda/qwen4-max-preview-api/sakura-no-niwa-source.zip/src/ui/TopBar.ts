import { el, svgIcon, ICONS } from './dom';

export interface TopBarHandlers {
  onToggleAudio(): void;
  onTogglePause(): void;
  onSnapshot(): void;
  onToggleUi(): void;
  onFullscreen(): void;
}

/** Title seal, sound state, time freeze, snapshot and interface controls. */
export class TopBar {
  private root: HTMLElement;
  private audioBtn: HTMLButtonElement;
  private audioLabel: HTMLElement;
  private pauseBtn: HTMLButtonElement;
  private pauseLabel: HTMLElement;

  constructor(app: HTMLElement, handlers: TopBarHandlers) {
    this.audioLabel = el('span', { text: 'Sound on' });
    this.audioBtn = el('button', {
      class: 'chip is-on',
      type: 'button',
      id: 'audio-toggle',
      title: 'Mute / unmute every sound (M)',
      'aria-pressed': 'true',
    }, [svgIcon(ICONS.sound), this.audioLabel]);
    this.audioBtn.addEventListener('click', handlers.onToggleAudio);

    this.pauseLabel = el('span', { text: 'Freeze' });
    this.pauseBtn = el('button', { class: 'chip', type: 'button', id: 'pause-toggle', title: 'Freeze time (Space)' }, [
      svgIcon(ICONS.pause),
      this.pauseLabel,
    ]);
    this.pauseBtn.addEventListener('click', handlers.onTogglePause);

    const shot = el('button', { class: 'chip', type: 'button', title: 'Save a PNG of the current view (P)' }, [
      svgIcon(ICONS.camera),
      el('span', { text: 'Snapshot' }),
    ]);
    shot.addEventListener('click', handlers.onSnapshot);

    const hide = el('button', { class: 'chip chip--icon', type: 'button', title: 'Hide the interface (H)' }, [svgIcon(ICONS.sliders)]);
    hide.addEventListener('click', handlers.onToggleUi);

    const full = el('button', { class: 'chip chip--icon', type: 'button', title: 'Fullscreen (F)' }, [svgIcon(ICONS.expand)]);
    full.addEventListener('click', handlers.onFullscreen);

    this.root = el('header', { class: 'topbar', id: 'topbar' }, [
      el('div', { class: 'brand' }, [
        el('div', { class: 'brand__seal', text: '桜' }),
        el('div', { class: 'brand__text' }, [
          el('h1', { text: '桜の庭 · Sakura-no-Niwa' }),
          el('p', { text: 'Voxel pagoda garden · diorama no. 05' }),
        ]),
      ]),
      el('div', { class: 'topbar__spacer' }),
      el('div', { class: 'topbar__tools' }, [this.audioBtn, this.pauseBtn, shot, hide, full]),
    ]);
    app.appendChild(this.root);
  }

  setAudio(on: boolean): void {
    this.audioBtn.classList.toggle('is-on', on);
    this.audioBtn.setAttribute('aria-pressed', String(on));
    this.audioLabel.textContent = on ? 'Sound on' : 'Muted';
    const icon = svgIcon(on ? ICONS.sound : ICONS.mute);
    this.audioBtn.replaceChild(icon, this.audioBtn.firstElementChild!);
  }

  setPaused(paused: boolean): void {
    this.pauseBtn.classList.toggle('is-on', paused);
    this.pauseLabel.textContent = paused ? 'Frozen' : 'Freeze';
    const icon = svgIcon(paused ? ICONS.play : ICONS.pause);
    this.pauseBtn.replaceChild(icon, this.pauseBtn.firstElementChild!);
  }

  setVisible(visible: boolean): void {
    this.root.style.display = visible ? '' : 'none';
  }
}
