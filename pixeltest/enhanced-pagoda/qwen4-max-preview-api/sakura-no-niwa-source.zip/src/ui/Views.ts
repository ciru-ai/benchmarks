import { el } from './dom';
import { CAMERA_PRESETS } from '../core/CameraRig';

/** Viewpoint rail — always-visible named camera presets. */
export class Views {
  private root: HTMLElement;
  private buttons = new Map<string, HTMLButtonElement>();

  constructor(app: HTMLElement, onSelect: (id: string) => void) {
    this.root = el('div', { class: 'views scroll-x', id: 'views', role: 'group', 'aria-label': 'Camera viewpoints' });
    for (const preset of CAMERA_PRESETS) {
      const btn = el('button', { type: 'button', title: preset.label, 'data-id': preset.id }, [
        el('span', { class: 'jp', text: preset.jp }),
        el('span', { class: 'en', text: preset.label }),
      ]);
      btn.addEventListener('click', () => {
        this.setActive(preset.id);
        onSelect(preset.id);
      });
      this.buttons.set(preset.id, btn);
      this.root.appendChild(btn);
    }
    app.appendChild(this.root);
    this.setActive('vista');
  }

  ready(): void {
    this.root.classList.add('is-ready');
  }

  setActive(id: string): void {
    for (const [key, btn] of this.buttons) btn.classList.toggle('is-active', key === id);
  }

  setVisible(visible: boolean): void {
    this.root.style.display = visible ? '' : 'none';
  }
}
