import { P } from '../voxel/Palette';
import type { VoxelBuffer } from '../voxel/VoxelBuffer';

export interface RoofOptions {
  /** Half extents of the eave rectangle. */
  halfX: number;
  halfZ: number;
  /** Rise from eave to ridge. */
  height: number;
  /** Concavity of the slope: >1 flares the eaves, steepens the ridge. */
  curve?: number;
  /** Extra lift at the four corners (Japanese sorizori). */
  upturn?: number;
  tileA?: number;
  tileB?: number;
  tileShadow?: number;
  ridge?: number;
  trim?: number;
  cornerTip?: number;
  /** Tile stripe period along X (0 = no stripes). */
  stripe?: number;
  thickness?: number;
  /** Fill the outer roof down to this absolute Y (eave soffit / bracket line). */
  soffit?: number;
  /** Hang small bells at the eave corners. */
  bells?: boolean;
}

/**
 * Voxel interpretation of a Japanese hip roof (yosemune-zukuri):
 * concave slope, flared and upturned corners, tile striping, gilded
 * eave trim and hanging corner bells.
 */
export function hipRoof(volume: VoxelBuffer, cx: number, baseY: number, cz: number, o: RoofOptions): number {
  const curve = o.curve ?? 1.75;
  const upturn = o.upturn ?? 2.2;
  const tileA = o.tileA ?? P.ROOF_M;
  const tileB = o.tileB ?? P.ROOF_D;
  const tileShadow = o.tileShadow ?? P.ROOF_D;
  const ridge = o.ridge ?? P.RIDGE;
  const trim = o.trim ?? P.ROOF_XL;
  const cornerTip = o.cornerTip ?? P.GOLD;
  const stripe = o.stripe ?? 3;
  const thickness = o.thickness ?? 2;
  const hx = o.halfX;
  const hz = o.halfZ;
  let apex = baseY;

  for (let dz = -hz; dz <= hz; dz++) {
    for (let dx = -hx; dx <= hx; dx++) {
      const nx = Math.abs(dx) / hx;
      const nz = Math.abs(dz) / hz;
      const m = Math.max(nx, nz);
      const slope = o.height * (1 - Math.pow(m, 1 / curve));
      const corner = Math.pow(Math.min(nx, nz), 2.1) * Math.pow(m, 1.4) * upturn;
      const y = baseY + Math.round(slope + corner);
      apex = Math.max(apex, y);

      const isEdge = m > 0.999;
      const isHip = Math.abs(nx - nz) < 0.06 && m > 0.12;
      const isRidge = slope >= o.height - 0.75;
      const isCorner = nx > 0.82 && nz > 0.82;

      let id: number;
      if (isRidge) id = ridge;
      else if (isHip) id = trim;
      else if (isEdge) id = trim;
      else if (stripe > 0 && ((dx + 200) % stripe === 0)) id = tileA === P.ROOF_M ? P.ROOF_L : tileA;
      else id = (dx + dz) % 2 === 0 ? tileA : tileB;

      if (isCorner && isEdge) id = cornerTip;
      if (y <= baseY) id = tileShadow === tileB ? tileB : id;

      const depth = isEdge ? thickness + 1 : thickness;
      const lowest = o.soffit !== undefined && m > 0.45 ? Math.min(y - depth + 1, o.soffit) : y - depth + 1;
      for (let yy = y; yy >= lowest; yy--) {
        volume.set(cx + dx, yy, cz + dz, yy === y ? id : tileShadow);
      }

      // corner bells on a two-link chain
      if (o.bells && isCorner && Math.abs(dx) === hx && Math.abs(dz) === hz) {
        volume.set(cx + dx, lowest - 1, cz + dz, P.GOLD_D);
        volume.set(cx + dx, lowest - 2, cz + dz, P.GOLD);
        volume.set(cx + dx, lowest - 3, cz + dz, P.GOLD_L);
      }
    }
  }
  return apex;
}

/** Simple stepped gable used for tiny shrines and gate caps. */
export function gableCap(
  volume: VoxelBuffer,
  cx: number,
  baseY: number,
  cz: number,
  halfX: number,
  halfZ: number,
  steps: number,
  a: number,
  b: number,
): number {
  let y = baseY;
  for (let s = 0; s < steps; s++) {
    const hz = halfZ - s;
    if (hz < 0) break;
    for (let dx = -halfX - 1; dx <= halfX + 1; dx++) {
      for (let dz = -hz; dz <= hz; dz++) {
        volume.set(cx + dx, y, cz + dz, (dx + dz) % 2 === 0 ? a : b);
      }
    }
    y++;
  }
  return y;
}
