import * as THREE from 'three';
import { P } from '../voxel/Palette';
import type { VoxelBuffer } from '../voxel/VoxelBuffer';
import type { Rng } from '../util/rng';
import type { Terrain } from './Terrain';
import type { Interactive } from './WorldBuilder';
import { LAYOUT } from './Layout';

/** Karesansui dry garden: raked gravel seas, three stone islands, moss shores. */
export function buildZenGarden(volume: VoxelBuffer, terrain: Terrain, rng: Rng): Interactive {
  const { x0, x1, z0, z1 } = LAYOUT.zen;
  let sum = 0;
  let n = 0;
  for (let z = z0; z <= z1; z++) {
    for (let x = x0; x <= x1; x++) {
      const h = terrain.surfaceAt(x, z);
      if (h === -999) continue;
      sum += h;
      n++;
    }
  }
  const level = Math.round(sum / Math.max(1, n));

  const rocks: { x: number; z: number; r: number }[] = [
    { x: x0 + 8, z: z0 + 8, r: 3.4 },
    { x: x1 - 8, z: z0 + 15, r: 2.6 },
    { x: x0 + 15, z: z1 - 7, r: 2.0 },
  ];

  for (let z = z0 - 1; z <= z1 + 1; z++) {
    for (let x = x0 - 1; x <= x1 + 1; x++) {
      const inside = x >= x0 && x <= x1 && z >= z0 && z <= z1;
      const ground = terrain.surfaceAt(x, z);
      if (ground === -999) continue;

      if (!inside) {
        // dark stone kerb
        for (let y = level; y <= level + 1; y++) volume.set(x, y, z, y === level + 1 ? P.SLATE : P.ROCK_D);
        continue;
      }

      for (let y = Math.min(ground, level); y <= level; y++) {
        volume.set(x, y, z, y === level ? P.SAND_M : P.SOIL_M);
      }
      for (let y = level + 1; y <= Math.max(ground, level); y++) volume.set(x, y, z, 0);

      // rake pattern: concentric rings around stones, long waves elsewhere
      let nearest = 999;
      for (const r of rocks) nearest = Math.min(nearest, Math.hypot(x - r.x, z - r.z) - r.r);
      let line: number;
      if (nearest < 7) line = Math.floor(nearest * 1.15) % 2;
      else line = Math.floor((z + Math.sin(x * 0.18) * 1.6) * 0.9) % 2;
      volume.set(x, level, z, line === 0 ? P.SAND_L : P.SAND_M);
      if (rng.chance(0.03)) volume.set(x, level, z, P.SAND_D);
    }
  }

  // stone islands
  for (const rock of rocks) {
    const h = rng.range(2.5, 5);
    volume.ellipsoid(rock.x, level + h * 0.35, rock.z, rock.r, h, rock.r * 0.85, (_x, y, _z, d) => {
      if (d > 0.82 && rng.chance(0.4)) return 0;
      const top = y > level + h * 0.5;
      if (top && rng.chance(0.3)) return P.MOSS_STONE;
      return rng.chance(0.3) ? P.ROCK_L : rng.chance(0.5) ? P.ROCK_M : P.ROCK_D;
    });
    // moss shore + accent stones
    volume.disc(rock.x, level, rock.z, rock.r + 1.6, P.MOSS_D, true);
    for (let i = 0; i < 4; i++) {
      const a = rng.range(0, Math.PI * 2);
      const d = rock.r + rng.range(1.2, 2.4);
      volume.set(Math.round(rock.x + Math.cos(a) * d), level, Math.round(rock.z + Math.sin(a) * d), P.GRANITE_M);
    }
  }

  // viewing deck on the west edge
  const deckX = x0 - 4;
  const deckZ0 = z0 + 6;
  const deckZ1 = z0 + 16;
  for (let z = deckZ0; z <= deckZ1; z++) {
    for (let x = deckX - 3; x <= deckX; x++) {
      const gy = terrain.surfaceAt(x, z);
      if (gy === -999) continue;
      for (let y = gy + 1; y <= level; y++) volume.set(x, y, z, P.WOOD_D);
      volume.set(x, level + 1, z, (x + 300) % 3 === 0 ? P.WOOD_L : P.WOOD_M);
    }
    volume.set(deckX - 3, level + 2, z, P.WOOD_D);
    if ((z - deckZ0) % 4 === 0) volume.set(deckX - 3, level + 3, z, P.WOOD_M);
  }

  return {
    id: 'zen',
    label: 'Dry garden · 枯山水',
    hint: 'Raked gravel, three stone islands',
    position: new THREE.Vector3((x0 + x1) / 2, level + 3, (z0 + z1) / 2),
    radius: 16,
    kind: 'info',
  };
}
