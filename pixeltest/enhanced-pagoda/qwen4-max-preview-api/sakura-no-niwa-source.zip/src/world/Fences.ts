import { P } from '../voxel/Palette';
import type { VoxelBuffer } from '../voxel/VoxelBuffer';
import type { Rng } from '../util/rng';

/** Takegaki bamboo screen fence along a straight run. */
export function bambooFence(
  volume: VoxelBuffer,
  groundAt: (x: number, z: number) => number,
  rng: Rng,
  x0: number,
  z0: number,
  x1: number,
  z1: number,
  height = 5,
): void {
  const steps = Math.max(Math.abs(x1 - x0), Math.abs(z1 - z0));
  for (let i = 0; i <= steps; i++) {
    const t = steps === 0 ? 0 : i / steps;
    const x = Math.round(x0 + (x1 - x0) * t);
    const z = Math.round(z0 + (z1 - z0) * t);
    const y = groundAt(x, z);
    if (y === -999) continue;
    const post = i % 6 === 0;
    const h = post ? height + 1 : height - rng.int(0, 1);
    for (let k = 1; k <= h; k++) {
      volume.set(x, y + k, z, post ? P.BAMBOO_D : k % 4 === 0 ? P.BAMBOO_D : P.BAMBOO_M);
    }
    if (post) volume.set(x, y + h + 1, z, P.WOOD_D);
  }
  // horizontal rails
  const railYs = [2, height - 1];
  for (const ry of railYs) {
    for (let i = 0; i <= steps; i++) {
      const t = steps === 0 ? 0 : i / steps;
      const x = Math.round(x0 + (x1 - x0) * t);
      const z = Math.round(z0 + (z1 - z0) * t);
      const y = groundAt(x, z);
      if (y === -999) continue;
      const along = Math.abs(x1 - x0) >= Math.abs(z1 - z0);
      volume.set(x + (along ? 0 : 1), y + ry, z + (along ? 1 : 0), P.BAMBOO_D);
    }
  }
}

/** Low clipped hedge (karikomi) — rounded green mounds in a row. */
export function hedgeRow(
  volume: VoxelBuffer,
  groundAt: (x: number, z: number) => number,
  rng: Rng,
  x0: number,
  z0: number,
  x1: number,
  z1: number,
  radius = 2,
): void {
  const len = Math.hypot(x1 - x0, z1 - z0);
  const n = Math.max(1, Math.round(len / (radius * 1.3)));
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const x = x0 + (x1 - x0) * t;
    const z = z0 + (z1 - z0) * t;
    const y = groundAt(Math.round(x), Math.round(z));
    if (y === -999) continue;
    volume.ellipsoid(x, y + radius * 0.5, z, radius, radius * 0.8, radius, (_vx, vy, _vz, d) => {
      if (d > 0.75 && rng.chance(0.4)) return 0;
      return vy > y + radius * 0.6 ? (rng.chance(0.4) ? P.PINE_L : P.HEDGE) : P.HEDGE;
    });
  }
}
