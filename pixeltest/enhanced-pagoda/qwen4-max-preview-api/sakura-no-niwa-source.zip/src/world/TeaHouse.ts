import * as THREE from 'three';
import { P } from '../voxel/Palette';
import type { VoxelBuffer } from '../voxel/VoxelBuffer';
import type { Rng } from '../util/rng';
import type { VoxelMaterials } from '../voxel/VoxelMaterials';
import type { Interactive } from './WorldBuilder';
import type { LanternAnchor } from '../core/Lighting';
import { ShishiOdoshi } from '../anim/ShishiOdoshi';
import { hipRoof } from './RoofKit';
import { LAYOUT } from './Layout';

export interface TeaHouseResult {
  interactives: Interactive[];
  lanterns: LanternAnchor[];
  odoshi: ShishiOdoshi;
  chimney: THREE.Vector3;
}

/** Chashitsu tea house: thatched hip roof, shoji walls, engawa deck, tsukubai basin. */
export function buildTeaHouse(volume: VoxelBuffer, materials: VoxelMaterials, groundAt: (x: number, z: number) => number, rng: Rng): TeaHouseResult {
  const { cx, cz, w, d } = LAYOUT.teaHouse;
  const hx = Math.floor(w / 2);
  const hz = Math.floor(d / 2);
  const y = groundAt(cx, cz);
  const floor = y + 2;
  const wallTop = floor + 6;

  // stone footing + raised floor
  for (let dz = -hz - 2; dz <= hz + 2; dz++) {
    for (let dx = -hx - 2; dx <= hx + 2; dx++) {
      const inside = Math.abs(dx) <= hx && Math.abs(dz) <= hz;
      const deck = Math.abs(dx) <= hx + 2 && Math.abs(dz) <= hz + 2;
      if (!deck) continue;
      const gy = groundAt(cx + dx, cz + dz);
      for (let fy = gy + 1; fy < floor; fy++) volume.set(cx + dx, fy, cz + dz, P.GRANITE_D);
      volume.set(cx + dx, floor, cz + dz, inside ? P.TATAMI : (dx + 300) % 3 === 0 ? P.WOOD_L : P.WOOD_M);
    }
  }

  // walls: plaster, timber frame, shoji panels
  for (let wy = floor + 1; wy <= wallTop; wy++) {
    for (let dz = -hz; dz <= hz; dz++) {
      for (let dx = -hx; dx <= hx; dx++) {
        const ax = Math.abs(dx);
        const az = Math.abs(dz);
        if (ax !== hx && az !== hz) continue;
        const corner = ax === hx && az === hz;
        const post = corner || (ax === hx ? (dz + 300) % 4 === 0 : (dx + 300) % 4 === 0);
        let id: number;
        if (wy === wallTop || wy === floor + 1) id = P.WOOD_D;
        else if (post) id = P.WOOD_M;
        else if (wy >= floor + 2 && wy <= floor + 4) id = (dx + dz) % 3 === 0 ? P.WOOD_L : P.SHOJI_GLOW;
        else id = rng.chance(0.2) ? P.PLASTER_D : P.PLASTER;
        volume.set(cx + dx, wy, cz + dz, id);
      }
    }
  }
  // doorway on the west face
  for (let wy = floor + 1; wy <= floor + 4; wy++) {
    for (let dz = -1; dz <= 1; dz++) volume.set(cx - hx, wy, cz + dz, 0);
  }
  volume.box(cx - hx - 1, floor + 5, cz - 1, cx - hx - 1, floor + 5, cz + 1, P.WOOD_D);

  // engawa railing on the south deck
  for (let dx = -hx - 2; dx <= hx + 2; dx++) {
    if ((dx + 300) % 3 === 0) volume.set(cx + dx, floor + 1, cz + hz + 2, P.WOOD_D);
    volume.set(cx + dx, floor + 2, cz + hz + 2, P.WOOD_L);
  }
  // entry steps
  for (let s = 0; s < 2; s++) {
    for (let dz = -1; dz <= 1; dz++) {
      volume.set(cx - hx - 3 - s, floor - s, cz + dz, P.GRANITE_M);
      volume.set(cx - hx - 3 - s, floor - s - 1, cz + dz, P.GRANITE_D);
    }
  }

  // thatched roof
  const apex = hipRoof(volume, cx, wallTop + 1, cz, {
    halfX: hx + 3,
    halfZ: hz + 3,
    height: 6,
    curve: 1.55,
    upturn: 1.2,
    thickness: 3,
    soffit: wallTop,
    stripe: 2,
    tileA: P.THATCH_M,
    tileB: P.THATCH_D,
    tileShadow: P.THATCH_D,
    ridge: P.THATCH_L,
    trim: P.THATCH_L,
    cornerTip: P.THATCH_D,
  });
  // ridge logs
  for (let dx = -hx - 1; dx <= hx + 1; dx++) {
    volume.set(cx + dx, apex + 1, cz, P.WOOD_D);
    if ((dx + 300) % 3 === 0) volume.set(cx + dx, apex + 2, cz, P.WOOD_M);
  }

  // chimney (smoke source) on the north slope
  const chimney = new THREE.Vector3(cx + hx - 2, apex + 3, cz - hz + 1);
  volume.box(cx + hx - 2, wallTop + 2, cz - hz + 1, cx + hx - 1, apex + 2, cz - hz + 2, P.ROCK_M);
  volume.set(cx + hx - 2, apex + 3, cz - hz + 1, P.ROCK_D);

  // tsukubai basin + shishi-odoshi to the west
  const bx = cx - hx - 6;
  const bz = cz + 3;
  const by = groundAt(bx, bz);
  volume.disc(bx, by, bz, 2.2, P.GRANITE_M);
  volume.disc(bx, by + 1, bz, 2.2, P.GRANITE_L, true);
  volume.set(bx, by + 1, bz, P.WATER);
  volume.set(bx, by + 2, bz, P.WATER_L);
  // bamboo spout
  volume.column(bx - 3, by + 1, by + 4, bz, P.BAMBOO_M);
  volume.line(bx - 3, by + 4, bz, bx - 1, by + 4, bz, P.BAMBOO_L);
  volume.set(bx - 1, by + 3, bz, P.WATER_L);

  const ox = bx + 5;
  const oz = bz + 4;
  const oy = groundAt(ox, oz);
  volume.box(ox - 1, oy, oz - 1, ox + 1, oy, oz + 1, P.GRANITE_M);
  volume.set(ox - 1, oy + 1, oz, P.WOOD_D);
  volume.set(ox + 1, oy + 1, oz, P.WOOD_D);
  volume.set(ox - 1, oy + 2, oz, P.WOOD_D);
  volume.set(ox + 1, oy + 2, oz, P.WOOD_D);
  volume.disc(ox + 4, oy, oz, 1.6, P.GRANITE_D);
  volume.set(ox + 4, oy + 1, oz, P.WATER);
  const odoshi = new ShishiOdoshi(materials, new THREE.Vector3(ox + 0.5, oy + 3.5, oz + 0.5), 8.5);

  // paper lantern under the eave + stone lantern by the steps
  volume.set(cx - hx - 2, wallTop, cz, P.LANTERN_FIRE);
  volume.set(cx - hx - 2, wallTop - 1, cz, P.LANTERN_CORE);
  volume.set(cx - hx - 2, wallTop + 1, cz, P.WOOD_D);

  return {
    odoshi,
    chimney,
    interactives: [
      {
        id: 'teahouse',
        label: 'Tea house · 茶室',
        hint: 'Shoji glow and a bamboo water pipe',
        position: new THREE.Vector3(cx, floor + 4, cz),
        radius: 12,
        kind: 'info',
      },
      {
        id: 'tsukubai',
        label: 'Tsukubai basin · 蹲踞',
        hint: 'The deer-scarer knocks every few seconds',
        position: new THREE.Vector3(ox + 0.5, oy + 3, oz + 0.5),
        radius: 5,
        kind: 'info',
      },
    ],
    lanterns: [
      { position: new THREE.Vector3(cx - hx - 2, wallTop, cz), color: new THREE.Color('#ffca7a'), power: 0.8 },
      { position: new THREE.Vector3(cx, floor + 3, cz), color: new THREE.Color('#ffd79a'), power: 0.7 },
    ],
  };
}
