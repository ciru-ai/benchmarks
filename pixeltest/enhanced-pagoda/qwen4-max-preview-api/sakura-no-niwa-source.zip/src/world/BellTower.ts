import * as THREE from 'three';
import { P } from '../voxel/Palette';
import type { VoxelBuffer } from '../voxel/VoxelBuffer';
import type { Rng } from '../util/rng';
import type { VoxelMaterials } from '../voxel/VoxelMaterials';
import type { Interactive, } from './WorldBuilder';
import type { LanternAnchor } from '../core/Lighting';
import { Bell } from '../anim/Bell';
import { hipRoof } from './RoofKit';

export interface BellTowerResult {
  bell: Bell;
  interactive: Interactive;
  lantern: LanternAnchor;
}

/** Shōrō belfry: four posts, a tiled hip roof and a swinging bronze bonshō. */
export function buildBellTower(
  volume: VoxelBuffer,
  materials: VoxelMaterials,
  x: number,
  y: number,
  z: number,
  rng: Rng,
): BellTowerResult {
  const half = 4;
  // stone platform
  for (let dz = -half - 1; dz <= half + 1; dz++) {
    for (let dx = -half - 1; dx <= half + 1; dx++) {
      if (Math.abs(dx) + Math.abs(dz) > (half + 1) * 1.8) continue;
      volume.set(x + dx, y, z + dz, rng.chance(0.25) ? P.GRANITE_M : P.GRANITE_L);
      volume.set(x + dx, y - 1, z + dz, P.GRANITE_D);
    }
  }
  // steps on the south face
  for (let dx = -2; dx <= 2; dx++) {
    volume.set(x + dx, y, z + half + 2, P.GRANITE_M);
    volume.set(x + dx, y - 1, z + half + 2, P.GRANITE_D);
  }

  const postTop = y + 10;
  for (const [sx, sz] of [[1, 1], [1, -1], [-1, 1], [-1, -1]] as const) {
    const px = x + sx * half;
    const pz = z + sz * half;
    volume.box(px, y + 1, pz, px, postTop, pz, P.WOOD_D);
    volume.set(px, y + 1, pz, P.GRANITE_XL);
    volume.set(px, postTop, pz, P.VERMILION);
  }
  // tie beams + bracket line
  for (let d = -half; d <= half; d++) {
    volume.set(x + d, postTop, z + half, P.VERMILION);
    volume.set(x + d, postTop, z - half, P.VERMILION);
    volume.set(x + half, postTop, z + d, P.VERMILION);
    volume.set(x - half, postTop, z + d, P.VERMILION);
    volume.set(x + d, postTop - 3, z + half, P.WOOD_M);
    volume.set(x + d, postTop - 3, z - half, P.WOOD_M);
  }
  // low railing on three sides
  for (let d = -half; d <= half; d++) {
    for (const [dx, dz] of [[d, -half], [half, d], [-half, d]] as const) {
      volume.set(x + dx, y + 2, z + dz, (d + 300) % 3 === 0 ? P.VERMILION : P.VERMILION_D);
    }
  }
  // hanging beam
  for (let d = -half; d <= half; d++) volume.set(x + d, postTop - 1, z, P.WOOD_D);

  hipRoof(volume, x, postTop + 1, z, {
    halfX: half + 3,
    halfZ: half + 3,
    height: 4,
    curve: 1.8,
    upturn: 2.4,
    thickness: 2,
    bells: true,
    soffit: postTop,
    tileA: P.ROOF_M,
    tileB: P.ROOF_D,
    ridge: P.RIDGE,
    trim: P.ROOF_XL,
    cornerTip: P.GOLD,
  });
  volume.set(x, postTop + 6, z, P.GOLD);
  volume.set(x, postTop + 7, z, P.GOLD_L);

  const bell = new Bell(materials, new THREE.Vector3(x + 0.5, postTop - 1, z + 0.5), 1, 'x');

  return {
    bell,
    interactive: {
      id: 'belfry',
      label: 'Bell tower · 鐘楼',
      hint: 'Strike the bonshō',
      position: new THREE.Vector3(x + 0.5, postTop - 5, z + 0.5),
      radius: 7,
      kind: 'bell',
    },
    lantern: {
      position: new THREE.Vector3(x + 0.5, y + 4, z + half + 1),
      color: new THREE.Color('#ffb45e'),
      power: 0.5,
    },
  };
}
