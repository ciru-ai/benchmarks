import * as THREE from 'three';
import { Rng, hashString } from '../util/rng';
import { VoxelBuffer, WORLD_BOUNDS } from '../voxel/VoxelBuffer';
import { meshVolume } from '../voxel/Mesher';
import type { VoxelMaterials } from '../voxel/VoxelMaterials';
import type { LanternAnchor } from '../core/Lighting';
import type { Settings } from '../core/Settings';
import type { Prop } from '../anim/types';
import { Terrain } from './Terrain';
import { buildPlateau } from './Plateau';
import { buildPagoda } from './Pagoda';
import { buildZenGarden } from './ZenGarden';
import { layPath } from './Paths';
import { buildBridge } from './Bridge';
import { buildTorii } from './Torii';
import { buildBellTower } from './BellTower';
import { buildTeaHouse } from './TeaHouse';
import { buildShrine } from './Shrine';
import { bambooFence, hedgeRow } from './Fences';
import { buildLantern } from './Lanterns';
import { plantSakura, plantMaple, plantPine, plantWeepingCherry, plantBambooGrove, type TreeContext, type BlossomSource } from './Trees';
import { scatterFlora, boulder } from './Flora';
import { LAYOUT } from './Layout';

export interface Interactive {
  id: string;
  label: string;
  hint: string;
  position: THREE.Vector3;
  radius: number;
  kind: 'bell' | 'lantern' | 'water' | 'info';
  data?: Record<string, unknown>;
}

export interface WorldStats {
  voxels: number;
  faces: number;
  vertices: number;
  buildMs: number;
  meshMs: number;
}

export interface World {
  group: THREE.Group;
  terrain: Terrain;
  volume: VoxelBuffer;
  lanterns: LanternAnchor[];
  interactives: Interactive[];
  blossomSources: BlossomSource[];
  fireflyZones: { center: THREE.Vector3; radius: number }[];
  props: Prop[];
  bell: Prop & { ring(strength?: number): void; onRing?: (s: number) => void };
  odoshi: Prop & { onClack?: () => void };
  chimney: THREE.Vector3;
  spiritOrbs: THREE.Vector3[];
  waterfall: { x: number; y: number; z: number };
  stats: WorldStats;
  dispose(): void;
}

export interface BuildProgress {
  step: number;
  steps: number;
  label: string;
  jp: string;
}

const nextFrame = (): Promise<void> => new Promise((r) => requestAnimationFrame(() => r()));

/** Assembles every world module into three merged voxel meshes plus a few animated props. */
export class WorldBuilder {
  private materials: VoxelMaterials;

  constructor(materials: VoxelMaterials) {
    this.materials = materials;
  }

  async build(settings: Settings, onProgress: (p: BuildProgress) => void): Promise<World> {
    const t0 = performance.now();
    const seedNum = hashString(settings.seed);
    const rng = new Rng(seedNum);
    const volume = new VoxelBuffer(WORLD_BOUNDS);
    const group = new THREE.Group();
    group.name = 'voxel-world';
    const lanterns: LanternAnchor[] = [];
    const interactives: Interactive[] = [];
    const blossomSources: BlossomSource[] = [];
    const fireflyZones: { center: THREE.Vector3; radius: number }[] = [];
    const props: Prop[] = [];
    const spiritOrbs: THREE.Vector3[] = [];
    const disposables: THREE.BufferGeometry[] = [];
    let chimney = new THREE.Vector3(34, 24, 22);

    const terrain = new Terrain(volume, seedNum);
    const groundAt = (x: number, z: number): number => {
      const h = terrain.surfaceAt(x, z);
      if (h === -999) return -999;
      return volume.groundAt(x, z, h + 14, h);
    };
    const treeCtx: TreeContext = { volume, rng: rng.fork(7), noise: terrain.noise, density: settings.blossomDensity, sources: blossomSources };

    const addLantern = (x: number, z: number, style: 'kasuga' | 'yukimi' | 'torch' = 'kasuga', yOverride?: number): void => {
      const y = yOverride ?? groundAt(x, z);
      if (y === -999) return;
      const built = buildLantern(volume, x, y + 1, z, rng.fork(x * 31 + z), style);
      lanterns.push(built.anchor);
      interactives.push(built.interactive);
    };

    const stages: { label: string; jp: string; run: () => void }[] = [];
    const addStage = (label: string, jp: string, run: () => void): void => {
      stages.push({ label, jp, run });
    };

    addStage('Carving the floating island', '島', () => {
      terrain.build(volume);
    });

    addStage('Raising the stone precinct', '壇', () => {
      buildPlateau(volume, terrain, rng.fork(11));
    });

    addStage('Stacking the pagoda roofs', '塔', () => {
      const pagoda = buildPagoda(volume, {
        cx: LAYOUT.pagoda.cx,
        cz: LAYOUT.pagoda.cz,
        baseY: LAYOUT.plateau.top + 1,
        tiers: settings.pagodaTiers,
        rng: rng.fork(23),
        detail: settings.gardenDetail,
      });
      interactives.push(...pagoda.interactives);
      lanterns.push(...pagoda.lanterns);
      fireflyZones.push({ center: new THREE.Vector3(LAYOUT.pagoda.cx, LAYOUT.plateau.top + 6, LAYOUT.pagoda.cz), radius: 24 });
    });

    addStage('Raking the dry garden', '砂', () => {
      interactives.push(buildZenGarden(volume, terrain, rng.fork(31)));
      const z = LAYOUT.zen;
      bambooFence(volume, groundAt, rng.fork(37), z.x0 - 1, z.z0 - 2, z.x1 + 1, z.z0 - 2, 6);
      bambooFence(volume, groundAt, rng.fork(41), z.x1 + 2, z.z0 - 2, z.x1 + 2, z.z1 + 1, 6);
      hedgeRow(volume, groundAt, rng.fork(43), z.x0 - 2, z.z1 + 3, z.x1 - 4, z.z1 + 3, 2);
    });

    addStage('Laying the stepping stones', '道', () => {
      layPath(volume, terrain, rng.fork(53), LAYOUT.pathMain, { width: 2.4, step: 2 });
      layPath(volume, terrain, rng.fork(59), LAYOUT.pathTea, { width: 1.8, step: 2.2 });
      layPath(volume, terrain, rng.fork(61), LAYOUT.pathZen, { width: 1.6, step: 2.4 });
      layPath(volume, terrain, rng.fork(67), LAYOUT.pathPond, { width: 1.8, step: 2.2 });
      layPath(volume, terrain, rng.fork(71), LAYOUT.pathShrine, { width: 1.5, step: 2.4 });
    });

    addStage('Spanning the drum bridge', '橋', () => {
      interactives.push(buildBridge(volume, rng.fork(73), LAYOUT.waterLevel + 1));
      interactives.push(buildTorii(volume, { x: LAYOUT.torii.cx, y: groundAt(LAYOUT.torii.cx, LAYOUT.torii.cz) + 1, z: LAYOUT.torii.cz, rng: rng.fork(79) }));
      interactives.push({
        id: 'pond',
        label: 'Koi pond · 池',
        hint: 'Tap the water to send a ripple',
        position: new THREE.Vector3(LAYOUT.pond.cx + 8, LAYOUT.waterLevel + 1, LAYOUT.pond.cz + 5),
        radius: 18,
        kind: 'water',
      });
      fireflyZones.push({ center: new THREE.Vector3(LAYOUT.pond.cx, LAYOUT.waterLevel + 4, LAYOUT.pond.cz), radius: 20 });
    });

    addStage('Building the tea house', '茶', () => {
      const tea = buildTeaHouse(volume, this.materials, groundAt, rng.fork(83));
      props.push(tea.odoshi);
      interactives.push(...tea.interactives);
      lanterns.push(...tea.lanterns);
      chimney = tea.chimney;
      bambooFence(volume, groundAt, rng.fork(89), 24, 34, 46, 34, 5);
      bambooFence(volume, groundAt, rng.fork(97), 46, 34, 46, 18, 5);
    });

    addStage('Hanging the temple bell', '鐘', () => {
      const tower = buildBellTower(volume, this.materials, 14, groundAt(14, 14), 14, rng.fork(101));
      props.push(tower.bell);
      interactives.push(tower.interactive);
      lanterns.push(tower.lantern);
      const shrine = buildShrine(volume, groundAt, rng.fork(103));
      interactives.push(...shrine.interactives);
      lanterns.push(...shrine.lanterns);
      spiritOrbs.push(...shrine.orbs);
      fireflyZones.push({ center: new THREE.Vector3(LAYOUT.shrine.cx, groundAt(LAYOUT.shrine.cx, LAYOUT.shrine.cz) + 6, LAYOUT.shrine.cz), radius: 14 });
    });

    addStage('Planting the cherry trees', '桜', () => {
      const density = settings.treeDensity;
      const place = (list: readonly (readonly [number, number, number])[], fn: (c: TreeContext, x: number, y: number, z: number, s: number) => void, keep: number) => {
        list.forEach(([x, z, s], i) => {
          if (i >= Math.ceil(list.length * keep) && i > 2) return;
          const y = groundAt(x, z);
          if (y === -999) return;
          fn(treeCtx, x, y + 1, z, s);
        });
      };
      place(LAYOUT.sakura, plantSakura, Math.min(1, density));
      place(LAYOUT.maple, plantMaple, Math.min(1, density));
      place(LAYOUT.pine, plantPine, Math.min(1, density));

      // weeping cherry on the pond island
      const [wx, wz, ws] = LAYOUT.weeping;
      const wy = groundAt(wx, wz);
      if (wy !== -999) plantWeepingCherry(treeCtx, wx, wy + 1, wz, ws);

      // extra scattered cherries when density is high
      const extra = Math.round((density - 1) * 8);
      for (let i = 0; i < extra; i++) {
        const a = treeCtx.rng.range(0, Math.PI * 2);
        const d = treeCtx.rng.range(24, 50);
        const x = Math.round(Math.cos(a) * d);
        const z = Math.round(Math.sin(a) * d);
        const y = groundAt(x, z);
        if (y === -999 || terrain.pondAt(x, z) > 0.1) continue;
        plantSakura(treeCtx, x, y + 1, z, treeCtx.rng.range(0.7, 1));
      }

      plantBambooGrove(treeCtx, LAYOUT.bamboo.cx, LAYOUT.bamboo.cz, LAYOUT.bamboo.r, groundAt, Math.round(34 * density));
    });

    addStage('Lighting the stone lanterns', '灯', () => {
      addLantern(-2, 20);
      addLantern(9, 33);
      addLantern(20, 44);
      addLantern(-12, 27, 'yukimi');
      addLantern(-24, 37, 'yukimi');
      addLantern(-46, 8, 'yukimi');
      addLantern(26, 24);
      addLantern(30, 2);
      addLantern(-28, -8);
      addLantern(-36, -22);
      addLantern(4, 4, 'torch');
      addLantern(-16, 4, 'torch');
      addLantern(-11, 8, 'kasuga', LAYOUT.plateau.top);
      addLantern(-1, 8, 'kasuga', LAYOUT.plateau.top);
      const isl = LAYOUT.pondIsland;
      addLantern(isl.cx + 4, isl.cz + 3, 'yukimi');

      // islet decorations
      for (const islet of terrain.islets) {
        const top = volume.groundAt(islet.cx, islet.cz, islet.top + 4, islet.top);
        if (islet.deco === 'pine') plantPine(treeCtx, islet.cx, top + 1, islet.cz, 0.7);
        else if (islet.deco === 'torii') interactives.push(buildTorii(volume, { x: islet.cx, y: top + 1, z: islet.cz, scale: 0.5, rng: rng.fork(islet.cx) }));
        else if (islet.deco === 'lantern') addLantern(islet.cx, islet.cz, 'kasuga', top);
        else boulder(volume, islet.cx, top + 1, islet.cz, rng.fork(islet.cz), 1.2);
      }
    });

    addStage('Seeding flowers and moss', '花', () => {
      scatterFlora(volume, terrain, rng.fork(107), settings.gardenDetail);
      fireflyZones.push({ center: new THREE.Vector3(30, 12, -14), radius: 18 });
      fireflyZones.push({ center: new THREE.Vector3(34, 12, 26), radius: 14 });
    });

    for (let i = 0; i < stages.length; i++) {
      onProgress({ step: i, steps: stages.length + 1, label: stages[i].label, jp: stages[i].jp });
      await nextFrame();
      stages[i].run();
    }

    onProgress({ step: stages.length, steps: stages.length + 1, label: 'Meshing voxels', jp: '積' });
    await nextFrame();
    const meshed = meshVolume(volume);

    if (meshed.solid) {
      const mesh = new THREE.Mesh(meshed.solid, this.materials.solid);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      mesh.name = 'world-solid';
      group.add(mesh);
      disposables.push(meshed.solid);
    }
    if (meshed.glow) {
      const mesh = new THREE.Mesh(meshed.glow, this.materials.glow);
      mesh.name = 'world-glow';
      group.add(mesh);
      disposables.push(meshed.glow);
    }
    if (meshed.water) {
      const mesh = new THREE.Mesh(meshed.water, this.materials.water);
      mesh.receiveShadow = true;
      mesh.renderOrder = 4;
      mesh.name = 'world-water';
      group.add(mesh);
      disposables.push(meshed.water);
    }

    for (const prop of props) group.add(prop.object);

    const bellProp = props.find((p) => p.object.name === 'temple-bell') as World['bell'];
    const odoshiProp = props.find((p) => p.object.name === 'shishi-odoshi') as World['odoshi'];

    return {
      group,
      terrain,
      volume,
      lanterns,
      interactives,
      blossomSources,
      fireflyZones,
      props,
      bell: bellProp,
      odoshi: odoshiProp,
      chimney,
      spiritOrbs,
      waterfall: terrain.waterfallLip,
      stats: {
        voxels: meshed.stats.voxels,
        faces: meshed.stats.faces,
        vertices: meshed.stats.vertices,
        buildMs: performance.now() - t0,
        meshMs: meshed.stats.ms,
      },
      dispose() {
        for (const d of disposables) d.dispose();
        for (const p of props) p.dispose();
        group.clear();
      },
    };
  }
}
