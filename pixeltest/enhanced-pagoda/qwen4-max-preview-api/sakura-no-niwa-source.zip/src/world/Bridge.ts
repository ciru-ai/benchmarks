import * as THREE from 'three';
import { P } from '../voxel/Palette';
import type { VoxelBuffer } from '../voxel/VoxelBuffer';
import type { Rng } from '../util/rng';
import type { Interactive } from './WorldBuilder';
import { LAYOUT } from './Layout';

/** Taiko-bashi drum bridge: a lacquer-red arc with gilded giboshu newels. */
export function buildBridge(volume: VoxelBuffer, rng: Rng, baseY: number): Interactive {
  const { x0, x1, z, width, rise } = LAYOUT.bridge;
  const half = Math.floor(width / 2);
  const span = Math.abs(x1 - x0);
  const dir = Math.sign(x1 - x0);
  const deckAt = (i: number): number => baseY + Math.round(Math.sin((i / span) * Math.PI) * rise);

  for (let i = 0; i <= span; i++) {
    const x = x0 + dir * i;
    const y = deckAt(i);
    for (let dz = -half; dz <= half; dz++) {
      const plank = (i + 300) % 3 === 0 ? P.VERMILION_L : P.VERMILION;
      volume.set(x, y, z + dz, Math.abs(dz) === half ? P.VERMILION_D : plank);
      volume.set(x, y - 1, z + dz, P.WOOD_D);
      if (Math.abs(dz) <= half - 1 && i % 4 === 0) volume.set(x, y - 2, z + dz, P.WOOD_M);
    }
    // railings
    for (const side of [-1, 1]) {
      const rz = z + side * (half + 1);
      const post = i % 3 === 0 || i === 0 || i === span;
      if (post) {
        volume.set(x, y + 1, rz, P.VERMILION_D);
        volume.set(x, y + 2, rz, P.VERMILION);
        volume.set(x, y + 3, rz, P.VERMILION_L);
      }
      volume.set(x, y + 3, rz, post ? P.VERMILION_L : P.VERMILION);
      volume.set(x, y + 1, rz, post ? P.VERMILION_D : 0);
    }
    // supporting piles into the water
    if (i % 5 === 2 && i > 1 && i < span - 1) {
      for (const side of [-1, 1]) {
        for (let y = baseY - 4; y < y - 1; y++) {
          volume.set(x, y, z + side * (half - 1), P.WOOD_D);
        }
      }
    }
  }

  // giboshu finials at the four corners
  for (const i of [0, span]) {
    const x = x0 + dir * i;
    const y = deckAt(i);
    for (const side of [-1, 1]) {
      const rz = z + side * (half + 1);
      volume.set(x, y + 4, rz, P.GOLD_D);
      volume.set(x, y + 5, rz, P.GOLD);
      volume.set(x, y + 6, rz, P.GOLD_L);
    }
  }

  // stone abutments
  for (const i of [0, span]) {
    const x = x0 + dir * i;
    for (let dz = -half - 1; dz <= half + 1; dz++) {
      for (let y = baseY - 3; y <= baseY - 1; y++) {
        volume.set(x + (i === 0 ? 1 : -1), y, z + dz, rng.chance(0.3) ? P.GRANITE_M : P.GRANITE_D);
      }
    }
  }

  return {
    id: 'bridge',
    label: 'Drum bridge · 太鼓橋',
    hint: 'Cross to the blossom island',
    position: new THREE.Vector3((x0 + x1) / 2, baseY + rise + 2, z + 0.5),
    radius: 10,
    kind: 'info',
  };
}
