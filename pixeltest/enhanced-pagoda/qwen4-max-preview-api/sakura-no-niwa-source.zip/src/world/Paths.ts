import { P } from '../voxel/Palette';
import type { VoxelBuffer } from '../voxel/VoxelBuffer';
import type { Rng } from '../util/rng';
import type { Terrain } from './Terrain';

interface PathOptions {
  gravel?: boolean;
  stones?: boolean;
  width?: number;
  step?: number;
}

/** Tobi-ishi stepping stones with an optional nobedan gravel bed. */
export function layPath(
  volume: VoxelBuffer,
  terrain: Terrain,
  rng: Rng,
  points: readonly (readonly [number, number])[],
  o: PathOptions = {},
): void {
  const width = o.width ?? 2;
  const step = o.step ?? 2;
  const gravel = o.gravel ?? true;
  const stones = o.stones ?? true;

  for (let s = 0; s < points.length - 1; s++) {
    const [ax, az] = points[s];
    const [bx, bz] = points[s + 1];
    const len = Math.hypot(bx - ax, bz - az);
    const n = Math.max(1, Math.ceil(len / step));
    for (let i = 0; i <= n; i++) {
      const t = i / n;
      const cx = ax + (bx - ax) * t;
      const cz = az + (bz - az) * t;
      const jitterX = rng.range(-0.5, 0.5);
      const jitterZ = rng.range(-0.5, 0.5);
      const x = Math.round(cx + jitterX);
      const z = Math.round(cz + jitterZ);
      const ground = terrain.surfaceAt(x, z);
      if (ground === -999) continue;
      const y = volume.groundAt(x, z, ground + 6, ground);
      if (volume.get(x, y, z) === P.WATER) continue;

      if (gravel) {
        const r = width + 0.6;
        for (let dz = -Math.ceil(r); dz <= Math.ceil(r); dz++) {
          for (let dx = -Math.ceil(r); dx <= Math.ceil(r); dx++) {
            if (dx * dx + dz * dz > r * r) continue;
            const gx = x + dx;
            const gz = z + dz;
            const gy = volume.groundAt(gx, gz, ground + 6, -999);
            if (gy === -999) continue;
            const cur = volume.get(gx, gy, gz);
            if (cur === P.WATER || cur === P.WATER_D || cur === P.GRANITE_M) continue;
            const edge = dx * dx + dz * dz > (r - 1) * (r - 1);
            volume.set(gx, gy, gz, edge ? P.GRAVEL_D : rng.chance(0.4) ? P.GRAVEL_L : P.GRAVEL_M);
          }
        }
      }

      if (stones && i % 1 === 0) {
        const r = rng.range(1.1, 1.7);
        for (let dz = -2; dz <= 2; dz++) {
          for (let dx = -2; dx <= 2; dx++) {
            const d = Math.hypot(dx, dz);
            if (d > r + rng.range(-0.25, 0.25)) continue;
            const sx = x + dx;
            const sz = z + dz;
            const sy = volume.groundAt(sx, sz, ground + 6, -999);
            if (sy === -999) continue;
            volume.set(sx, sy, sz, rng.chance(0.25) ? P.GRANITE_XL : rng.chance(0.5) ? P.GRANITE_L : P.GRANITE_M);
            if (rng.chance(0.08)) volume.set(sx, sy, sz, P.MOSS_STONE);
          }
        }
      }
    }
  }
}
