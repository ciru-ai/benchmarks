/** Single source of truth for where everything sits on the island. */
export const LAYOUT = {
  island: { radius: 56, squareness: 3.2 },
  waterLevel: 3,
  groundBase: 6,

  pond: { cx: -30, cz: 21, rx: 20, rz: 15 },
  pondIsland: { cx: -35, cz: 20, r: 5.2, top: 6 },
  bridge: { x0: -10, x1: -29, z: 21, width: 5, rise: 4 },
  stream: { x0: -32, z0: 34, x1: -37, z1: 55, width: 3.4 },
  waterfall: { x: -37, z: 55 },

  plateau: { cx: -6, cz: -12, half: 19, top: 12 },
  pagoda: { cx: -6, cz: -12 },
  stairs: { cx: -6, z: 7, width: 9 },

  torii: { cx: 16, cz: 42 },
  zen: { x0: 18, x1: 46, z0: -30, z1: -3 },
  teaHouse: { cx: 34, cz: 26, w: 14, d: 11 },
  shrine: { cx: -40, cz: -32 },
  bamboo: { cx: 40, cz: -40, r: 12 },
  pineHill: { cx: 16, cz: -40, r: 12, lift: 7 },

  /** Stepping-stone spine: torii -> plateau stairs, with two branches. */
  pathMain: [
    [16, 48],
    [16, 42],
    [13, 35],
    [7, 29],
    [1, 23],
    [-3, 16],
    [-6, 10],
    [-6, 7],
  ] as [number, number][],
  pathTea: [
    [7, 29],
    [16, 29],
    [24, 28],
    [30, 26],
  ] as [number, number][],
  pathZen: [
    [16, 29],
    [22, 20],
    [26, 10],
    [30, 0],
    [32, -4],
  ] as [number, number][],
  pathPond: [
    [1, 23],
    [-6, 24],
    [-10, 23],
  ] as [number, number][],
  pathShrine: [
    [-24, -4],
    [-30, -14],
    [-36, -24],
    [-40, -29],
  ] as [number, number][],

  /** Hand-placed specimen trees (x, z, scale). */
  sakura: [
    [-8, -3, 1.1],
    [-52, 41, 0.95],
    [-55, -4, 0.9],
    [4, 27, 1.08],
    [11, 12, 0.95],
    [23, 34, 1.05],
    [-24, -2, 1.0],
    [2, -34, 0.9],
  ] as [number, number, number][],
  maple: [
    [46, 8, 1.0],
    [12, -22, 1.1],
    [-16, -34, 0.95],
    [40, 16, 0.9],
  ] as [number, number, number][],
  pine: [
    [16, -40, 1.2],
    [24, -34, 0.95],
    [8, -44, 1.0],
    [-52, -14, 1.05],
    [-44, -44, 0.9],
  ] as [number, number, number][],
  weeping: [-35, 20, 0.85] as [number, number, number],

  islets: [
    { cx: 66, cz: -16, top: 20, r: 8, deco: 'pine' },
    { cx: -66, cz: 34, top: 26, r: 6.5, deco: 'torii' },
    { cx: 20, cz: 68, top: -6, r: 7, deco: 'lantern' },
    { cx: -52, cz: -60, top: 34, r: 5.5, deco: 'pine' },
    { cx: 58, cz: 48, top: 12, r: 4.5, deco: 'rock' },
  ],
} as const;

export type LayoutType = typeof LAYOUT;
