import * as THREE from 'three';
import { P } from '../voxel/Palette';
import type { VoxelBuffer } from '../voxel/VoxelBuffer';
import type { Rng } from '../util/rng';
import type { Interactive } from './WorldBuilder';
import type { LanternAnchor } from '../core/Lighting';
import { buildTorii } from './Torii';
import { gableCap } from './RoofKit';
import { LAYOUT } from './Layout';

export interface ShrineResult {
  interactives: Interactive[];
  lanterns: LanternAnchor[];
  orbs: THREE.Vector3[];
}

/** Inari hokora: stone steps, vermilion shrine, mini torii, fox guardians, spirit fire. */
export function buildShrine(volume: VoxelBuffer, groundAt: (x: number, z: number) => number, rng: Rng): ShrineResult {
  const { cx, cz } = LAYOUT.shrine;
  const y = groundAt(cx, cz);
  const interactives: Interactive[] = [];
  const lanterns: LanternAnchor[] = [];
  const orbs: THREE.Vector3[] = [];

  // stone terrace
  for (let dz = -5; dz <= 5; dz++) {
    for (let dx = -6; dx <= 6; dx++) {
      if (Math.abs(dx) + Math.abs(dz) > 9) continue;
      const gy = groundAt(cx + dx, cz + dz);
      for (let fy = gy + 1; fy <= y + 1; fy++) volume.set(cx + dx, fy, cz + dz, P.ROCK_M);
      volume.set(cx + dx, y + 1, cz + dz, rng.chance(0.25) ? P.MOSS_STONE : rng.chance(0.5) ? P.GRANITE_M : P.GRANITE_L);
    }
  }
  // steps to the south
  for (let s = 0; s < 3; s++) {
    for (let dx = -2; dx <= 2; dx++) {
      volume.set(cx + dx, y + 1 - s, cz + 6 + s, P.GRANITE_M);
      volume.set(cx + dx, y - s, cz + 6 + s, P.GRANITE_D);
    }
  }

  const floor = y + 2;
  // shrine body
  volume.box(cx - 3, floor, cz - 3, cx + 3, floor, cz + 3, P.WOOD_M);
  for (let wy = floor + 1; wy <= floor + 5; wy++) {
    for (let dz = -3; dz <= 3; dz++) {
      for (let dx = -3; dx <= 3; dx++) {
        const ax = Math.abs(dx);
        const az = Math.abs(dz);
        if (ax !== 3 && az !== 3) continue;
        const corner = ax === 3 && az === 3;
        const id = corner ? P.VERMILION_D : wy === floor + 5 ? P.VERMILION : rng.chance(0.15) ? P.PLASTER_D : P.PLASTER;
        volume.set(cx + dx, wy, cz + dz, id);
      }
    }
  }
  // open front with a glowing interior
  for (let wy = floor + 1; wy <= floor + 4; wy++) {
    for (let dx = -1; dx <= 1; dx++) volume.set(cx + dx, wy, cz + 3, 0);
  }
  volume.set(cx, floor + 2, cz - 2, P.LANTERN_CORE);
  volume.set(cx, floor + 3, cz - 2, P.LANTERN_FIRE);
  volume.box(cx - 1, floor + 1, cz - 1, cx + 1, floor + 1, cz + 1, P.TATAMI);
  lanterns.push({ position: new THREE.Vector3(cx, floor + 3, cz), color: new THREE.Color('#ffc478'), power: 0.75 });

  // roof
  const roofY = gableCap(volume, cx, floor + 6, cz, 4, 4, 4, P.ROOF_M, P.ROOF_D);
  for (let dx = -5; dx <= 5; dx++) volume.set(cx + dx, roofY, cz, P.RIDGE);
  volume.set(cx - 5, roofY + 1, cz, P.GOLD);
  volume.set(cx + 5, roofY + 1, cz, P.GOLD);

  // shimenawa rope with paper shide
  for (let dx = -3; dx <= 3; dx++) {
    volume.set(cx + dx, floor + 5, cz + 4, dx % 2 === 0 ? P.THATCH_M : P.THATCH_D);
    if (dx % 2 === 0) {
      volume.set(cx + dx, floor + 4, cz + 4, P.PAPER);
      volume.set(cx + dx, floor + 3, cz + 4, P.PAPER);
    }
  }
  // offering box
  volume.box(cx - 2, floor, cz + 5, cx + 2, floor + 1, cz + 6, P.WOOD_M);
  for (let dx = -2; dx <= 2; dx++) volume.set(cx + dx, floor + 2, cz + 5, dx % 2 === 0 ? P.WOOD_D : 0);
  volume.set(cx, floor + 2, cz + 6, P.GOLD_D);

  // fox guardians
  for (const side of [-1, 1]) {
    const fx = cx + side * 5;
    const fz = cz + 5;
    volume.box(fx - 1, floor - 1, fz - 1, fx + 1, floor, fz + 1, P.GRANITE_M);
    volume.box(fx, floor + 1, fz, fx, floor + 3, fz, P.GRANITE_XL);
    volume.set(fx, floor + 4, fz, P.GRANITE_L);
    volume.set(fx, floor + 4, fz + 1, P.GRANITE_XL);
    volume.set(fx, floor + 5, fz - 1, P.GRANITE_L);
    volume.set(fx, floor + 2, fz - 1, P.GRANITE_L);
    volume.set(fx, floor + 1, fz + 1, P.VERMILION);
    const orb = new THREE.Vector3(fx + 0.5, floor + 6.5, fz + 0.5);
    orbs.push(orb);
    volume.set(fx, floor + 6, fz, P.FOX_FIRE);
    lanterns.push({ position: orb, color: new THREE.Color('#7fe3d4'), power: 0.5 });
  }

  // mini torii on the approach
  interactives.push(
    buildTorii(volume, { x: cx, y: y + 1, z: cz + 10, scale: 0.55, axis: 'x', rng }),
  );

  interactives.push({
    id: 'shrine',
    label: 'Fox shrine · 稲荷社',
    hint: 'Two guardians and a pair of spirit flames',
    position: new THREE.Vector3(cx, floor + 4, cz),
    radius: 10,
    kind: 'info',
  });

  return { interactives, lanterns, orbs };
}
