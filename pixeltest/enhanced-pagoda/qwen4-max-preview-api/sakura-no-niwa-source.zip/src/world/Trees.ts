import * as THREE from 'three';
import { P } from '../voxel/Palette';
import type { VoxelBuffer } from '../voxel/VoxelBuffer';
import type { Rng } from '../util/rng';
import { Noise } from '../util/noise';
import { clamp01 } from '../util/math';

export interface BlossomSource {
  center: THREE.Vector3;
  radius: number;
}

export interface TreeContext {
  volume: VoxelBuffer;
  rng: Rng;
  noise: Noise;
  density: number;
  sources: BlossomSource[];
}

/** Scatter the fallen-petal carpet under a canopy. */
function petalCarpet(ctx: TreeContext, cx: number, cz: number, y: number, r: number, a: number, b: number): void {
  const { volume, rng } = ctx;
  const rr = r * r;
  for (let dz = -Math.ceil(r); dz <= Math.ceil(r); dz++) {
    for (let dx = -Math.ceil(r); dx <= Math.ceil(r); dx++) {
      const d2 = dx * dx + dz * dz;
      if (d2 > rr) continue;
      const falloff = 1 - Math.sqrt(d2) / r;
      if (!rng.chance(0.42 * falloff + 0.06)) continue;
      const x = cx + dx;
      const z = cz + dz;
      const top = volume.groundAt(x, z, y + 3, -999);
      if (top === -999 || top < y - 4 || top > y + 2) continue;
      const under = volume.get(x, top, z);
      if (under === P.WATER || under === P.WATER_D) {
        volume.setIfAir(x, top + 1, z, rng.chance(0.5) ? a : b);
      } else {
        volume.set(x, top, z, rng.chance(0.55) ? a : b);
      }
    }
  }
}

/** Curved trunk with a couple of root flares. */
function trunk(
  ctx: TreeContext,
  x: number,
  y: number,
  z: number,
  height: number,
  lean: [number, number],
  barkA: number,
  barkB: number,
  thick = 2,
): { x: number; y: number; z: number } {
  const { volume, rng } = ctx;
  let cx = x;
  let cz = z;
  for (let i = 0; i < height; i++) {
    const t = i / height;
    cx = x + Math.round(lean[0] * t * t);
    cz = z + Math.round(lean[1] * t * t);
    const w = i < height * 0.35 && thick > 1 ? 1 : 0;
    for (let dz = -w; dz <= w; dz++) {
      for (let dx = -w; dx <= w; dx++) {
        if (w > 0 && Math.abs(dx) + Math.abs(dz) > 1 && rng.chance(0.5)) continue;
        volume.set(cx + dx, y + i, cz + dz, rng.chance(0.3) ? barkB : barkA);
      }
    }
  }
  // root flares
  for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
    if (rng.chance(0.7)) volume.set(x + dx * 2, y, z + dz * 2, barkB);
    volume.set(x + dx, y, z + dz, barkA);
  }
  return { x: cx, y: y + height - 1, z: cz };
}

function branch(ctx: TreeContext, from: THREE.Vector3, dir: THREE.Vector3, len: number, bark: number): THREE.Vector3 {
  const { volume, rng } = ctx;
  const p = from.clone();
  for (let i = 0; i < len; i++) {
    p.add(dir);
    p.y += 0.35;
    const x = Math.round(p.x);
    const y = Math.round(p.y);
    const z = Math.round(p.z);
    volume.set(x, y, z, bark);
    if (i < len * 0.5 && rng.chance(0.4)) volume.set(x, y - 1, z, bark);
  }
  return p;
}

interface CanopyOptions {
  palette: [number, number, number, number, number];
  radius: number;
  squash: number;
  blobs: number;
  erosion: number;
  fluff: number;
}

function canopy(ctx: TreeContext, center: THREE.Vector3, o: CanopyOptions): void {
  const { volume, rng, noise, density } = ctx;
  const [dark, mid, light, xl, white] = o.palette;
  const blobs = Math.max(3, Math.round(o.blobs * clamp01(density * 0.75 + 0.35)));
  const top = center.y + o.radius * o.squash;
  const bottom = center.y - o.radius * o.squash;

  for (let b = 0; b < blobs; b++) {
    const ang = (b / blobs) * Math.PI * 2 + rng.range(-0.4, 0.4);
    const dist = b === 0 ? 0 : o.radius * rng.range(0.35, 0.78);
    const bx = center.x + Math.cos(ang) * dist;
    const bz = center.z + Math.sin(ang) * dist;
    const by = center.y + rng.range(-0.25, 0.5) * o.radius;
    const r = o.radius * rng.range(0.52, 0.82) * (0.85 + density * 0.2);

    volume.ellipsoid(bx, by, bz, r, r * o.squash, r, (x, y, z, d) => {
      const n = noise.noise2(x * 0.42 + b * 3.1, z * 0.42 - y * 0.2);
      if (d > 0.52 && n > 0.42 - o.erosion) return 0;
      if (d > 0.78 && rng.chance(0.45)) return 0;
      const h = clamp01((y - bottom) / Math.max(1, top - bottom));
      const v = h + n * 0.28 + rng.range(-0.12, 0.12);
      if (v > 0.88) return rng.chance(0.45) ? white : xl;
      if (v > 0.66) return xl;
      if (v > 0.42) return light;
      if (v > 0.2) return mid;
      return rng.chance(0.35) ? dark : mid;
    });
  }

  // detached fluff so the silhouette is not a perfect sphere
  const fluffCount = Math.round(o.fluff * 26 * density);
  for (let i = 0; i < fluffCount; i++) {
    const ang = rng.range(0, Math.PI * 2);
    const el = rng.range(-0.5, 0.9);
    const r = o.radius * rng.range(0.95, 1.22);
    const x = Math.round(center.x + Math.cos(ang) * r);
    const z = Math.round(center.z + Math.sin(ang) * r);
    const y = Math.round(center.y + el * r * o.squash);
    volume.setIfAir(x, y, z, rng.pick([mid, light, xl, white]));
  }
}

/** Somei-yoshino cherry: forked trunk, cloud canopy, petal carpet. */
export function plantSakura(ctx: TreeContext, x: number, y: number, z: number, scale = 1): void {
  const { rng, volume } = ctx;
  const height = Math.round(rng.range(8, 11) * scale);
  const lean: [number, number] = [rng.range(-2.2, 2.2), rng.range(-2.2, 2.2)];
  const top = trunk(ctx, x, y, z, height, lean, P.WOOD_D, P.ROCK_D, 2);
  const center = new THREE.Vector3(top.x, top.y + 2.4 * scale, top.z);

  const arms = rng.int(3, 5);
  for (let i = 0; i < arms; i++) {
    const ang = (i / arms) * Math.PI * 2 + rng.range(-0.5, 0.5);
    const dir = new THREE.Vector3(Math.cos(ang), rng.range(0.25, 0.6), Math.sin(ang)).normalize();
    branch(ctx, new THREE.Vector3(top.x, top.y - rng.range(0, 2), top.z), dir, rng.int(3, 5), P.WOOD_D);
  }

  const radius = rng.range(5.2, 6.6) * scale;
  canopy(ctx, center, {
    palette: [P.SAKURA_BUD, P.SAKURA_D, P.SAKURA_M, P.SAKURA_L, P.SAKURA_W],
    radius,
    squash: 0.72,
    blobs: 7,
    erosion: 0.1,
    fluff: 1.2,
  });

  ctx.sources.push({ center: center.clone(), radius });
  petalCarpet(ctx, x, z, y, radius * 1.35, P.PETAL_CARPET, P.PETAL_CARPET_D);
  volume.setIfAir(top.x, top.y + 1, top.z, P.WOOD_D);
}

/** Weeping cherry (shidarezakura) — cascading blossom strands. */
export function plantWeepingCherry(ctx: TreeContext, x: number, y: number, z: number, scale = 1): void {
  const { rng, volume } = ctx;
  const height = Math.round(rng.range(6, 8) * scale);
  const top = trunk(ctx, x, y, z, height, [rng.range(-1.5, 1.5), rng.range(-1.5, 1.5)], P.WOOD_D, P.WOOD_M, 2);
  const center = new THREE.Vector3(top.x, top.y + 2, top.z);
  const radius = 5.4 * scale;

  canopy(ctx, center, {
    palette: [P.SAKURA_D, P.SAKURA_M, P.SAKURA_L, P.SAKURA_XL, P.SAKURA_W],
    radius,
    squash: 0.55,
    blobs: 6,
    erosion: 0.05,
    fluff: 0.8,
  });

  // hanging strands from the canopy rim
  const rim = Math.ceil(radius);
  for (let dz = -rim; dz <= rim; dz++) {
    for (let dx = -rim; dx <= rim; dx++) {
      const d = Math.hypot(dx, dz);
      if (d < radius * 0.55 || d > radius * 1.02) continue;
      if (!rng.chance(0.5)) continue;
      const sx = Math.round(center.x + dx);
      const sz = Math.round(center.z + dz);
      let sy = Math.round(center.y - 1);
      while (sy > center.y - 4 && volume.get(sx, sy, sz) === 0) sy--;
      const len = Math.round(rng.range(3, 9) * (1 - (d / radius) * 0.35));
      for (let k = 1; k <= len; k++) {
        if (rng.chance(0.12)) continue;
        volume.setIfAir(sx, sy - k, sz, k % 3 === 0 ? P.SAKURA_XL : k % 2 === 0 ? P.SAKURA_L : P.SAKURA_M);
      }
      if (rng.chance(0.4)) volume.setIfAir(sx, sy - len - 1, sz, P.SAKURA_W);
    }
  }

  ctx.sources.push({ center: center.clone(), radius: radius * 1.1 });
  petalCarpet(ctx, x, z, y, radius * 1.5, P.PETAL_CARPET, P.PETAL_CARPET_D);
}

/** Momiji maple — angular, fiery, wide-spreading. */
export function plantMaple(ctx: TreeContext, x: number, y: number, z: number, scale = 1): void {
  const { rng } = ctx;
  const height = Math.round(rng.range(6, 9) * scale);
  const top = trunk(ctx, x, y, z, height, [rng.range(-2, 2), rng.range(-2, 2)], P.WOOD_M, P.WOOD_D, 2);
  const center = new THREE.Vector3(top.x, top.y + 1.6 * scale, top.z);

  const arms = rng.int(4, 6);
  for (let i = 0; i < arms; i++) {
    const ang = (i / arms) * Math.PI * 2 + rng.range(-0.4, 0.4);
    const dir = new THREE.Vector3(Math.cos(ang), rng.range(0.1, 0.35), Math.sin(ang)).normalize();
    branch(ctx, new THREE.Vector3(top.x, top.y - 1, top.z), dir, rng.int(3, 6), P.WOOD_M);
  }

  const radius = rng.range(4.6, 6) * scale;
  canopy(ctx, center, {
    palette: [P.MAPLE_D, P.MAPLE_M, P.MAPLE_L, P.MAPLE_XL, P.MARIGOLD_L],
    radius,
    squash: 0.6,
    blobs: 8,
    erosion: 0.22,
    fluff: 1.5,
  });
  ctx.sources.push({ center: center.clone(), radius });
  petalCarpet(ctx, x, z, y, radius * 1.2, P.MAPLE_L, P.MAPLE_D);
}

/** Niwaki black pine — layered horizontal pads on a leaning trunk. */
export function plantPine(ctx: TreeContext, x: number, y: number, z: number, scale = 1): void {
  const { rng, volume, noise } = ctx;
  const height = Math.round(rng.range(12, 17) * scale);
  const lean: [number, number] = [rng.range(-3.5, 3.5), rng.range(-3.5, 3.5)];
  const top = trunk(ctx, x, y, z, height, lean, P.WOOD_D, P.WOOD_M, 2);

  const pads = rng.int(3, 5);
  for (let i = 0; i < pads; i++) {
    const t = 0.42 + (i / pads) * 0.62;
    const py = Math.round(y + height * t);
    const px = Math.round(x + lean[0] * t * t + rng.range(-2.5, 2.5));
    const pz = Math.round(z + lean[1] * t * t + rng.range(-2.5, 2.5));
    const r = (4.6 - i * 0.55) * scale * rng.range(0.85, 1.15);
    // branch out to the pad
    volume.line(Math.round(x + lean[0] * t * t), py - 1, Math.round(z + lean[1] * t * t), px, py - 1, pz, P.WOOD_D);
    volume.ellipsoid(px, py, pz, r, 1.35 * scale, r, (vx, vy, vz, d) => {
      const n = noise.noise2(vx * 0.4, vz * 0.4);
      if (d > 0.6 && n > 0.3) return 0;
      if (d > 0.85 && rng.chance(0.5)) return 0;
      if (vy > py) return rng.chance(0.35) ? P.PINE_L : P.PINE_M;
      return rng.chance(0.3) ? P.PINE_M : P.PINE_D;
    });
  }
  // crown
  volume.ellipsoid(top.x, top.y + 1, top.z, 2.6 * scale, 1.6 * scale, 2.6 * scale, (_x, vy, _z, d) =>
    d > 0.8 && rng.chance(0.4) ? 0 : vy > top.y ? P.PINE_L : P.PINE_M,
  );
}

/** Moso bamboo grove with segmented culms and leaf sprays. */
export function plantBambooGrove(ctx: TreeContext, cx: number, cz: number, r: number, groundAt: (x: number, z: number) => number, count: number): void {
  const { rng, volume } = ctx;
  for (let i = 0; i < count; i++) {
    const ang = rng.range(0, Math.PI * 2);
    const dist = Math.sqrt(rng.next()) * r;
    const x = Math.round(cx + Math.cos(ang) * dist);
    const z = Math.round(cz + Math.sin(ang) * dist);
    const y = groundAt(x, z);
    if (y === -999) continue;
    const h = rng.int(13, 23);
    const sway = rng.range(-1.6, 1.6);
    const swayZ = rng.range(-1.6, 1.6);
    for (let k = 0; k < h; k++) {
      const t = k / h;
      const sx = x + Math.round(sway * t * t);
      const sz = z + Math.round(swayZ * t * t);
      const node = k % 4 === 0;
      volume.set(sx, y + k, sz, node ? P.BAMBOO_D : rng.chance(0.4) ? P.BAMBOO_L : P.BAMBOO_M);
      if (k > h * 0.45 && rng.chance(0.3)) {
        const lx = sx + rng.int(-2, 2);
        const lz = sz + rng.int(-2, 2);
        volume.setIfAir(lx, y + k + rng.int(0, 1), lz, P.BAMBOO_LEAF);
        if (rng.chance(0.5)) volume.setIfAir(lx + rng.int(-1, 1), y + k, lz + rng.int(-1, 1), P.BAMBOO_LEAF);
      }
    }
    const tx = x + Math.round(sway);
    const tz = z + Math.round(swayZ);
    for (let l = 0; l < 7; l++) {
      volume.setIfAir(tx + rng.int(-2, 2), y + h + rng.int(-2, 1), tz + rng.int(-2, 2), P.BAMBOO_LEAF);
    }
  }
}
