import { P } from '../voxel/Palette';
import type { VoxelBuffer } from '../voxel/VoxelBuffer';
import type { Rng } from '../util/rng';
import type { Terrain } from './Terrain';
import { LAYOUT } from './Layout';

/** Raised temple precinct: battered stone retaining walls, gravel court, grand stair. */
export function buildPlateau(volume: VoxelBuffer, terrain: Terrain, rng: Rng): void {
  const { cx, cz, half, top } = LAYOUT.plateau;

  for (let dz = -half - 1; dz <= half + 1; dz++) {
    for (let dx = -half - 1; dx <= half + 1; dx++) {
      const ax = Math.abs(dx);
      const az = Math.abs(dz);
      const m = Math.max(ax, az);
      if (m > half) continue;
      const chamfer = ax + az > half * 1.78;
      if (chamfer) continue;
      const x = cx + dx;
      const z = cz + dz;
      const ground = terrain.surfaceAt(x, z);
      if (ground === -999) continue;
      const edge = m >= half - 1;

      for (let y = Math.min(ground, top); y <= top; y++) {
        let id: number;
        if (y === top) {
          if (edge) id = P.GRANITE_L;
          else {
            const court = Math.abs(dx) < 15 && Math.abs(dz) < 15;
            const r = rng.next();
            if (court) id = r > 0.86 ? P.GRAVEL_L : r > 0.4 ? P.GRAVEL_M : P.GRAVEL_D;
            else id = r > 0.7 ? P.MOSS_L : r > 0.35 ? P.GRASS_M : P.GRASS_L;
          }
        } else if (edge) {
          // ishigaki: big irregular blocks, wider at the base
          const block = (Math.floor(x / 3) * 3 + Math.floor(y / 2) * 5 + Math.floor(z / 3)) % 5;
          id = block === 0 ? P.GRANITE_D : block === 1 ? P.GRANITE_M : block === 2 ? P.GRANITE_L : P.ROCK_M;
          if (rng.chance(0.07)) id = P.MOSS_STONE;
        } else {
          id = y >= top - 2 ? P.SOIL_M : P.ROCK_M;
        }
        volume.set(x, y, z, id);
      }

      // a few stones jut out of the wall face
      if (m === half && rng.chance(0.18)) {
        const ox = ax === half ? Math.sign(dx) : 0;
        const oz = az === half ? Math.sign(dz) : 0;
        const y = top - rng.int(1, 3);
        volume.set(x + ox, y, z + oz, rng.chance(0.4) ? P.MOSS_STONE : P.GRANITE_M);
      }
    }
  }

  // ------------------------------------------------------------- grand stair
  const stairHalf = 5;
  const startZ = cz + half;
  const baseGround = terrain.surfaceAt(cx, startZ + 7);
  const steps = Math.max(3, top - (baseGround === -999 ? top - 5 : baseGround));
  for (let s = 0; s <= steps; s++) {
    const y = top - s;
    const z = startZ + s;
    for (let dx = -stairHalf; dx <= stairHalf; dx++) {
      volume.set(cx + dx, y, z, (dx + s + 300) % 4 === 0 ? P.GRANITE_L : P.GRANITE_M);
      volume.set(cx + dx, y - 1, z, P.GRANITE_D);
      volume.set(cx + dx, y - 2, z, P.ROCK_M);
    }
    for (const side of [-1, 1]) {
      const x = cx + side * (stairHalf + 1);
      volume.set(x, y, z, P.GRANITE_L);
      volume.set(x, y + 1, z, P.VERMILION_D);
      volume.set(x, y + 2, z, P.VERMILION);
      if (s === 0 || s === steps) {
        volume.set(x, y + 3, z, P.GOLD);
        volume.set(x, y + 4, z, P.GOLD_L);
      }
    }
  }

  // --------------------------------------------------- low tamagaki railing
  for (let dz = -half; dz <= half; dz++) {
    for (let dx = -half; dx <= half; dx++) {
      const ax = Math.abs(dx);
      const az = Math.abs(dz);
      if (Math.max(ax, az) !== half) continue;
      if (ax + az > half * 1.78) continue;
      const x = cx + dx;
      const z = cz + dz;
      // leave the stair mouth open
      if (dz === half && Math.abs(dx) <= stairHalf + 1) continue;
      if ((dx + dz + 400) % 4 === 0) {
        volume.set(x, top + 1, z, P.VERMILION_D);
        volume.set(x, top + 2, z, P.VERMILION);
      }
      volume.set(x, top + 2, z, P.VERMILION_L);
    }
  }
}
