import * as THREE from 'three';
import { P } from '../voxel/Palette';
import type { VoxelBuffer } from '../voxel/VoxelBuffer';
import type { Rng } from '../util/rng';
import type { Interactive } from './WorldBuilder';

export interface ToriiOptions {
  x: number;
  y: number;
  z: number;
  scale?: number;
  /** 'x' = beam runs along X, 'z' = beam runs along Z */
  axis?: 'x' | 'z';
  rng: Rng;
}

/** Myōjin torii: inclined vermilion pillars, curved kasagi with black cap, nuki and tablet. */
export function buildTorii(volume: VoxelBuffer, o: ToriiOptions): Interactive {
  const s = o.scale ?? 1;
  const axis = o.axis ?? 'x';
  const rng = o.rng;
  const height = Math.round(15 * s);
  const halfSpan = Math.round(7 * s);
  const put = (a: number, y: number, b: number, id: number): void => {
    if (axis === 'x') volume.set(o.x + a, y, o.z + b, id);
    else volume.set(o.x + b, y, o.z + a, id);
  };
  const box = (a0: number, y0: number, b0: number, a1: number, y1: number, b1: number, id: number): void => {
    if (axis === 'x') volume.box(o.x + a0, y0, o.z + b0, o.x + a1, y1, o.z + b1, id);
    else volume.box(o.x + b0, y0, o.z + a0, o.x + b1, y1, o.z + a1, id);
  };

  // pillars with a slight inward lean (uchikorobi)
  for (const side of [-1, 1]) {
    for (let i = 0; i < height; i++) {
      const t = i / height;
      const lean = Math.round(side * -1.2 * t * t);
      const a = side * halfSpan + lean;
      const thick = i < height * 0.12 ? 1 : 1;
      for (let da = -thick; da <= thick; da++) {
        for (let db = -thick; db <= thick; db++) {
          if (Math.abs(da) + Math.abs(db) > 1 && rng.chance(0.35)) continue;
          const id = i < 2 ? P.LACQUER : rng.chance(0.18) ? P.VERMILION_D : P.VERMILION;
          put(a + da, o.y + i, db, id);
        }
      }
    }
    // stone base
    box(side * halfSpan - 2, o.y - 1, -2, side * halfSpan + 2, o.y - 1, 2, P.GRANITE_M);
  }

  const topY = o.y + height;
  // nuki (tie beam)
  for (let a = -halfSpan - 2; a <= halfSpan + 2; a++) {
    for (let db = -1; db <= 1; db++) {
      put(a, topY - 4, db, P.VERMILION_D);
      put(a, topY - 3, db, db === 0 ? P.VERMILION : P.VERMILION_D);
    }
  }
  // gakuzuka tablet
  for (let a = -1; a <= 1; a++) {
    put(a, topY - 2, 0, P.GOLD_D);
    put(a, topY - 1, 0, a === 0 ? P.LACQUER : P.GOLD);
  }
  // shimaki + curved kasagi
  const reach = halfSpan + 4;
  for (let a = -reach; a <= reach; a++) {
    const t = Math.abs(a) / reach;
    const lift = Math.round(Math.pow(t, 2.6) * 3.2);
    for (let db = -2; db <= 2; db++) {
      put(a, topY + lift, db, P.VERMILION_D);
      put(a, topY + lift + 1, db, Math.abs(db) === 2 ? P.VERMILION_D : P.VERMILION);
    }
    for (let db = -2; db <= 2; db++) {
      put(a, topY + lift + 2, db, P.LACQUER);
    }
    if (Math.abs(a) === reach) {
      for (let db = -1; db <= 1; db++) put(a, topY + lift + 3, db, P.LACQUER);
    }
  }
  // gold end caps
  for (const side of [-1, 1]) {
    put(side * reach, topY + 3, 0, P.GOLD);
  }

  return {
    id: `torii-${o.x}-${o.z}`,
    label: 'Torii gate · 鳥居',
    hint: 'Threshold of the sacred garden',
    position: new THREE.Vector3(o.x + 0.5, o.y + height * 0.6, o.z + 0.5),
    radius: 11 * s,
    kind: 'info',
  };
}
