import * as THREE from 'three';
import { P } from '../voxel/Palette';
import type { VoxelBuffer } from '../voxel/VoxelBuffer';
import type { Rng } from '../util/rng';
import type { Interactive } from './WorldBuilder';
import type { LanternAnchor } from '../core/Lighting';
import { hipRoof } from './RoofKit';

export interface PagodaOptions {
  cx: number;
  cz: number;
  baseY: number;
  tiers: number;
  rng: Rng;
  detail: number;
}

export interface PagodaResult {
  apex: number;
  floorY: number;
  interactives: Interactive[];
  lanterns: LanternAnchor[];
}

const stone = (rng: Rng, x: number, y: number, z: number): number => {
  const block = (Math.floor(x / 3) + Math.floor(z / 2) + y) % 4;
  const r = rng.next();
  if (r > 0.94) return P.MOSS_STONE;
  if (block === 0) return P.GRANITE_D;
  if (block === 1) return P.GRANITE_M;
  if (block === 2) return r > 0.6 ? P.GRANITE_L : P.GRANITE_M;
  return r > 0.8 ? P.GRANITE_XL : P.GRANITE_L;
};

/**
 * A five-tier tō: battered stone plinth, railed balconies, plaster and
 * vermilion walls with glowing shoji, bracket complexes, five flared tile
 * roofs with gilded corner bells, and a nine-ring sorin finial.
 */
export function buildPagoda(volume: VoxelBuffer, o: PagodaOptions): PagodaResult {
  const { cx, cz, baseY, rng } = o;
  const tiers = Math.max(3, Math.min(7, Math.round(o.tiers)));
  const interactives: Interactive[] = [];
  const lanterns: LanternAnchor[] = [];

  // ---------------------------------------------------------------- plinth
  const baseHalf = 13;
  const baseTop = baseY + 3;
  for (let y = baseY; y <= baseTop; y++) {
    const inset = y - baseY >= 2 ? 1 : 0;
    const h = baseHalf - inset;
    for (let dz = -h; dz <= h; dz++) {
      for (let dx = -h; dx <= h; dx++) {
        if (Math.abs(dx) + Math.abs(dz) > h * 1.82) continue; // chamfered corners
        const edge = Math.abs(dx) === h || Math.abs(dz) === h;
        volume.set(cx + dx, y, cz + dz, edge && y === baseTop ? P.GRANITE_XL : stone(rng, cx + dx, y, cz + dz));
      }
    }
  }

  // ------------------------------------------------------------- grand stair
  const stairW = 4;
  for (let s = 0; s <= 4; s++) {
    const y = baseTop - s;
    const z = cz + baseHalf + s;
    for (let dx = -stairW; dx <= stairW; dx++) {
      volume.set(cx + dx, y, z, (dx + s) % 3 === 0 ? P.GRANITE_L : P.GRANITE_M);
      volume.set(cx + dx, y - 1, z, P.GRANITE_D);
    }
    // balustrade
    for (const side of [-1, 1]) {
      const x = cx + side * (stairW + 1);
      volume.set(x, y, z, P.GRANITE_L);
      volume.set(x, y + 1, z, P.VERMILION);
      volume.set(x, y + 2, z, s % 2 === 0 ? P.VERMILION_L : P.VERMILION);
      if (s === 0 || s === 4) volume.set(x, y + 3, z, P.GOLD);
    }
  }

  // komainu guardian figures flanking the stair
  for (const side of [-1, 1]) {
    const gx = cx + side * (stairW + 3);
    const gz = cz + baseHalf + 4;
    volume.box(gx - 1, baseY, gz - 1, gx + 1, baseY + 1, gz + 1, P.GRANITE_M);
    volume.box(gx, baseY + 2, gz, gx, baseY + 3, gz + 1, P.GRANITE_L);
    volume.set(gx, baseY + 4, gz + 1, P.GRANITE_XL);
    volume.set(gx, baseY + 4, gz, P.GRANITE_L);
    volume.set(gx, baseY + 3, gz - 1, P.GRANITE_M);
    volume.set(gx, baseY + 5, gz + 1, P.MOSS_STONE);
  }

  // ---------------------------------------------------------------- tiers
  const floorY = baseTop + 1;
  let y0 = floorY;
  const startHalf = 10;
  const endHalf = tiers >= 6 ? 5 : 6;
  const bodyH0 = 7;
  const bodyH = tiers >= 6 ? 4 : 5;
  const roofH = 4;
  let apex = y0;

  // central shinbashira pillar, visible through the windows
  const pillarTop = floorY + bodyH0 + roofH + (tiers - 1) * (bodyH + roofH) + 6;
  volume.box(cx, floorY, cz, cx + 1, pillarTop, cz + 1, P.WOOD_D);

  for (let i = 0; i < tiers; i++) {
    const t = tiers === 1 ? 0 : i / (tiers - 1);
    const w = Math.round(startHalf + (endHalf - startHalf) * t);
    const h = i === 0 ? bodyH0 : bodyH;
    const bw = w + 2;

    // balcony deck
    for (let dz = -bw; dz <= bw; dz++) {
      for (let dx = -bw; dx <= bw; dx++) {
        const edge = Math.abs(dx) === bw || Math.abs(dz) === bw;
        const plank = (dx + 300) % 4 === 0 ? P.WOOD_L : P.WOOD_M;
        volume.set(cx + dx, y0, cz + dz, edge ? P.WOOD_D : plank);
      }
    }

    // railing
    for (let dz = -bw; dz <= bw; dz++) {
      for (let dx = -bw; dx <= bw; dx++) {
        const onEdge = Math.abs(dx) === bw || Math.abs(dz) === bw;
        if (!onEdge) continue;
        const isCorner = Math.abs(dx) === bw && Math.abs(dz) === bw;
        const isPost = isCorner || (dx + dz + 300) % 3 === 0;
        const stairGap = i === 0 && dz === bw && Math.abs(dx) <= stairW - 1;
        if (stairGap) continue;
        if (isPost) {
          volume.set(cx + dx, y0 + 1, cz + dz, P.VERMILION);
          volume.set(cx + dx, y0 + 2, cz + dz, P.VERMILION_L);
        } else {
          volume.set(cx + dx, y0 + 2, cz + dz, P.VERMILION);
        }
        if (isCorner) volume.set(cx + dx, y0 + 3, cz + dz, P.GOLD);
      }
    }

    // walls
    for (let y = y0 + 1; y <= y0 + h; y++) {
      for (let dz = -w; dz <= w; dz++) {
        for (let dx = -w; dx <= w; dx++) {
          const ax = Math.abs(dx);
          const az = Math.abs(dz);
          if (ax !== w && az !== w) continue;
          const corner = ax === w && az === w;
          const post = corner || (ax === w ? (dz + 300) % 4 === 0 : (dx + 300) % 4 === 0);
          let id: number;
          if (y === y0 + h) id = P.VERMILION;
          else if (y === y0 + 1) id = P.VERMILION_D;
          else if (post) id = P.WOOD_D;
          else id = rng.chance(0.14) ? P.PLASTER_D : P.PLASTER;
          volume.set(cx + dx, y, cz + dz, id);
        }
      }
    }

    // shoji windows on all four faces
    const winY0 = y0 + 3;
    const winY1 = Math.min(y0 + h - 1, winY0 + 1);
    const winHalf = Math.max(1, Math.min(2, w - 3));
    for (let k = -winHalf; k <= winHalf; k++) {
      for (let y = winY0; y <= winY1; y++) {
        const mullion = k === 0 && winHalf > 1;
        const id = mullion ? P.WOOD_D : P.SHOJI_GLOW;
        volume.set(cx + k, y, cz + w, id);
        volume.set(cx + k, y, cz - w, id);
        volume.set(cx + w, y, cz + k, id);
        volume.set(cx - w, y, cz + k, id);
      }
    }

    // bracket complexes (tokyō) beneath the eaves
    const by = y0 + h + 1;
    for (let k = -w; k <= w; k += 2) {
      for (const [dx, dz] of [[k, w + 1], [k, -w - 1], [w + 1, k], [-w - 1, k]] as const) {
        volume.set(cx + dx, by, cz + dz, (k + 300) % 4 === 0 ? P.GOLD_D : P.WOOD_L);
      }
    }
    for (const [sx, sz] of [[1, 1], [1, -1], [-1, 1], [-1, -1]] as const) {
      volume.set(cx + sx * (w + 1), by, cz + sz * (w + 1), P.GOLD);
      volume.set(cx + sx * (w + 2), by, cz + sz * (w + 2), P.GOLD_D);
    }

    // roof
    const roofBase = y0 + h + 1;
    const roofHalf = w + 3;
    apex = hipRoof(volume, cx, roofBase, cz, {
      halfX: roofHalf,
      halfZ: roofHalf,
      height: roofH,
      curve: 1.85,
      upturn: 3.1,
      stripe: 3,
      thickness: 2,
      bells: true,
      soffit: y0 + h,
      tileA: P.ROOF_M,
      tileB: P.ROOF_D,
      ridge: P.RIDGE,
      trim: P.ROOF_XL,
      cornerTip: P.GOLD,
    });

    // lantern anchors glowing at the balcony corners
    if (i === 0 || i === tiers - 1) {
      for (const [sx, sz] of [[1, 1], [-1, -1]] as const) {
        lanterns.push({
          position: new THREE.Vector3(cx + sx * (w + 1) + 0.5, y0 + 4.5, cz + sz * (w + 1) + 0.5),
          color: new THREE.Color('#ffb45e'),
          power: 0.55,
        });
      }
    }

    y0 = apex;
  }

  // ------------------------------------------------------------- doorway
  const doorZ = cz + startHalf;
  for (let y = floorY + 1; y <= floorY + 4; y++) {
    for (let dx = -1; dx <= 1; dx++) {
      volume.set(cx + dx, y, doorZ, 0);
    }
  }
  for (let y = floorY + 1; y <= floorY + 5; y++) {
    volume.set(cx - 2, y, doorZ, P.VERMILION_D);
    volume.set(cx + 2, y, doorZ, P.VERMILION_D);
  }
  for (let dx = -2; dx <= 2; dx++) volume.set(cx + dx, floorY + 5, doorZ, P.VERMILION_D);
  volume.box(cx - 1, floorY + 1, doorZ - 3, cx + 1, floorY + 1, doorZ - 1, P.TATAMI);
  volume.set(cx, floorY + 2, doorZ - 3, P.LANTERN_CORE);
  volume.set(cx, floorY + 3, doorZ - 3, P.LANTERN_FIRE);
  lanterns.push({
    position: new THREE.Vector3(cx + 0.5, floorY + 3, doorZ - 1),
    color: new THREE.Color('#ffc472'),
    power: 0.9,
  });

  // plaque above the door
  for (let dx = -2; dx <= 2; dx++) {
    volume.set(cx + dx, floorY + 6, doorZ, P.GOLD);
    volume.set(cx + dx, floorY + 7, doorZ, dx % 2 === 0 ? P.LACQUER : P.GOLD_D);
  }

  // --------------------------------------------------------------- sorin
  const sorinBase = apex + 1;
  volume.box(cx - 1, sorinBase, cz - 1, cx + 1, sorinBase, cz + 1, P.GOLD_D);
  volume.box(cx, sorinBase + 1, cz, cx + 1, sorinBase + 1, cz + 1, P.GOLD);
  const mastTop = sorinBase + 11;
  volume.box(cx, sorinBase + 1, cz, cx, mastTop, cz, P.GOLD);
  for (let k = 0; k < 9; k++) {
    const ry = sorinBase + 2 + k;
    const r = 2.6 - k * 0.16;
    volume.disc(cx, ry, cz, r, k % 2 === 0 ? P.GOLD_L : P.GOLD, true);
  }
  // suien — four flame fins
  for (const [sx, sz] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
    volume.set(cx + sx * 2, sorinBase + 2, cz + sz * 2, P.GOLD_L);
    volume.set(cx + sx * 2, sorinBase + 3, cz + sz * 2, P.GOLD);
    volume.set(cx + sx * 3, sorinBase + 2, cz + sz * 3, P.GOLD_D);
  }
  volume.set(cx, mastTop + 1, cz, P.GOLD_L);
  volume.set(cx, mastTop + 2, cz, P.SPIRIT_ORB);
  volume.set(cx, mastTop + 3, cz, P.GOLD_L);

  interactives.push({
    id: 'pagoda',
    label: `${tiers}-tier pagoda · 五重塔`,
    hint: 'Ring the temple bell',
    position: new THREE.Vector3(cx + 0.5, floorY + 14, cz + 0.5),
    radius: 20,
    kind: 'bell',
  });

  return { apex: mastTop + 3, floorY, interactives, lanterns };
}
