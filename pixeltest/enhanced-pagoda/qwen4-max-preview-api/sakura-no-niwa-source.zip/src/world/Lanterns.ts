import * as THREE from 'three';
import { P } from '../voxel/Palette';
import type { VoxelBuffer } from '../voxel/VoxelBuffer';
import type { Rng } from '../util/rng';
import type { LanternAnchor } from '../core/Lighting';
import type { Interactive } from './WorldBuilder';

export type LanternStyle = 'kasuga' | 'yukimi' | 'torch';

export interface LanternBuild {
  anchor: LanternAnchor;
  interactive: Interactive;
}

/** Ishi-dōrō stone lanterns; their fire boxes are emissive voxels + bloom. */
export function buildLantern(
  volume: VoxelBuffer,
  x: number,
  y: number,
  z: number,
  rng: Rng,
  style: LanternStyle = 'kasuga',
  scale = 1,
): LanternBuild {
  const g = (): number => (rng.chance(0.22) ? P.MOSS_STONE : rng.chance(0.5) ? P.GRANITE_M : P.GRANITE_L);
  let fireY = y + 9;

  if (style === 'kasuga') {
    volume.box(x - 1, y, z - 1, x + 1, y, z + 1, g());
    volume.set(x, y + 1, z, g());
    for (let i = 2; i <= 5; i++) volume.set(x, y + i, z, i === 4 ? P.GRANITE_XL : g());
    volume.box(x - 1, y + 6, z - 1, x + 1, y + 6, z + 1, g());
    volume.box(x - 1, y + 7, z - 1, x + 1, y + 7, z + 1, P.GRANITE_XL);
    // fire box
    for (let dy = 8; dy <= 10; dy++) {
      for (let dz = -1; dz <= 1; dz++) {
        for (let dx = -1; dx <= 1; dx++) {
          const corner = Math.abs(dx) === 1 && Math.abs(dz) === 1;
          const centre = dx === 0 && dz === 0;
          if (centre) {
            volume.set(x, y + dy, z, dy === 9 ? P.LANTERN_CORE : P.LANTERN_FIRE);
          } else if (corner) {
            volume.set(x + dx, y + dy, z + dz, g());
          } else {
            volume.set(x + dx, y + dy, z + dz, dy === 9 ? P.LANTERN_FIRE : P.SHOJI_GLOW);
          }
        }
      }
    }
    // kasa roof with lifted corners
    for (let dz = -2; dz <= 2; dz++) {
      for (let dx = -2; dx <= 2; dx++) {
        const m = Math.max(Math.abs(dx), Math.abs(dz));
        const lift = m === 2 ? 1 : 0;
        volume.set(x + dx, y + 11 + lift, z + dz, m === 2 ? P.GRANITE_D : g());
        if (m <= 1) volume.set(x + dx, y + 12, z + dz, P.GRANITE_M);
      }
    }
    volume.set(x, y + 13, z, P.GRANITE_L);
    volume.set(x, y + 14, z, P.MOSS_STONE);
    fireY = y + 9;
  } else if (style === 'yukimi') {
    // snow-viewing lantern: squat, wide roof on three legs
    for (const [dx, dz] of [[1, 0], [-1, 1], [0, -1]] as const) {
      volume.column(x + dx, y, y + 3, z + dz, g());
    }
    volume.disc(x, y + 4, z, 2.2, P.GRANITE_XL);
    for (let dy = 5; dy <= 6; dy++) {
      volume.set(x, y + dy, z, P.LANTERN_CORE);
      for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
        volume.set(x + dx, y + dy, z + dz, P.LANTERN_FIRE);
      }
      for (const [dx, dz] of [[1, 1], [1, -1], [-1, 1], [-1, -1]] as const) {
        volume.set(x + dx, y + dy, z + dz, g());
      }
    }
    volume.disc(x, y + 7, z, 3.2, P.GRANITE_M);
    volume.disc(x, y + 8, z, 2.2, P.GRANITE_L);
    volume.set(x, y + 9, z, P.GRANITE_XL);
    volume.set(x, y + 10, z, P.MOSS_STONE);
    fireY = y + 6;
  } else {
    // torch stand: iron basket on a pole
    volume.box(x - 1, y, z - 1, x + 1, y, z + 1, P.GRANITE_D);
    for (let i = 1; i <= 6; i++) volume.set(x, y + i, z, P.WOOD_D);
    volume.box(x - 1, y + 7, z - 1, x + 1, y + 7, z + 1, P.BRONZE);
    volume.set(x, y + 8, z, P.EMBER);
    volume.set(x, y + 9, z, P.LANTERN_FIRE);
    for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
      volume.set(x + dx, y + 8, z + dz, P.BRONZE);
    }
    fireY = y + 8;
  }

  const s = scale;
  return {
    anchor: {
      position: new THREE.Vector3(x + 0.5, fireY + 0.5, z + 0.5),
      color: new THREE.Color(style === 'torch' ? '#ff9a4a' : '#ffc478'),
      power: (style === 'yukimi' ? 0.8 : 1) * s,
    },
    interactive: {
      id: `lantern-${x}-${z}`,
      label: style === 'yukimi' ? 'Snow-viewing lantern · 雪見灯籠' : style === 'torch' ? 'Torch stand · 篝火' : 'Stone lantern · 春日灯籠',
      hint: 'Tap to make the flame flare',
      position: new THREE.Vector3(x + 0.5, fireY + 0.5, z + 0.5),
      radius: 4.5,
      kind: 'lantern',
    },
  };
}
