import { Noise } from '../util/noise';
import { Rng } from '../util/rng';
import { clamp, lerp, smoothstep } from '../util/math';
import { P } from '../voxel/Palette';
import type { VoxelBuffer } from '../voxel/VoxelBuffer';
import { LAYOUT } from './Layout';

export interface IsletInfo {
  cx: number;
  cz: number;
  top: number;
  r: number;
  deco: string;
}

/**
 * The floating island: superellipse footprint, rolling hills, a carved koi
 * pond with an island, a stream to the cliff edge and a tapered rocky root
 * system underneath with spirit crystals glinting in the cracks.
 */
export class Terrain {
  private heights: Int16Array;
  private land: Uint8Array;
  private pondMask: Float32Array;
  private streamMask: Float32Array;
  private sx: number;
  private sz: number;
  private ox: number;
  private oz: number;
  readonly noise: Noise;
  readonly rng: Rng;
  readonly islets: IsletInfo[] = [];
  waterfallLip: { x: number; y: number; z: number } = { x: LAYOUT.waterfall.x, y: LAYOUT.waterLevel, z: LAYOUT.waterfall.z };

  constructor(volume: VoxelBuffer, seed: number) {
    this.sx = volume.sx;
    this.sz = volume.sz;
    this.ox = volume.ox;
    this.oz = volume.oz;
    this.heights = new Int16Array(this.sx * this.sz).fill(-999);
    this.land = new Uint8Array(this.sx * this.sz);
    this.pondMask = new Float32Array(this.sx * this.sz);
    this.streamMask = new Float32Array(this.sx * this.sz);
    this.noise = new Noise(seed);
    this.rng = new Rng(seed ^ 0x5f3a);
    this.computeField();
  }

  private gi(x: number, z: number): number {
    return x - this.ox + (z - this.oz) * this.sx;
  }

  /** 0 at the centre, 1 at the shoreline of the rounded-square island. */
  islandDistance(x: number, z: number): number {
    const { radius, squareness } = LAYOUT.island;
    const wobble = 1 + this.noise.fbm2(x * 0.021 + 11, z * 0.021 - 7, 3) * 0.075;
    const r = radius * wobble;
    const ax = Math.abs(x) / r;
    const az = Math.abs(z) / r;
    return Math.pow(Math.pow(ax, squareness) + Math.pow(az, squareness), 1 / squareness);
  }

  private streamDistance(x: number, z: number): number {
    const s = LAYOUT.stream;
    const vx = s.x1 - s.x0;
    const vz = s.z1 - s.z0;
    const wx = x - s.x0;
    const wz = z - s.z0;
    const len2 = vx * vx + vz * vz;
    const t = clamp((wx * vx + wz * vz) / len2, 0, 1);
    const px = s.x0 + vx * t;
    const pz = s.z0 + vz * t;
    return Math.hypot(x - px, z - pz);
  }

  private computeField(): void {
    const n = this.noise;
    const pond = LAYOUT.pond;
    const isl = LAYOUT.pondIsland;
    const hill = LAYOUT.pineHill;
    const plat = LAYOUT.plateau;

    for (let z = this.oz; z < this.oz + this.sz; z++) {
      for (let x = this.ox; x < this.ox + this.sx; x++) {
        const i = this.gi(x, z);
        const d = this.islandDistance(x, z);
        if (d > 1) continue;
        this.land[i] = 1;

        let h = LAYOUT.groundBase + n.fbm2(x * 0.017, z * 0.017, 4) * 5.2 + n.fbm2(x * 0.056 + 4, z * 0.056 - 3, 2) * 1.7;

        const hillD = Math.hypot(x - hill.cx, z - hill.cz);
        h += hill.lift * Math.exp(-(hillD * hillD) / (2 * Math.pow(hill.r * 0.62, 2)));

        const platD = Math.hypot(x - plat.cx, z - plat.cz);
        h += 3.1 * Math.exp(-(platD * platD) / (2 * 23 * 23));

        h -= smoothstep(0.84, 1.0, d) * 3.2;

        const pd = Math.pow((x - pond.cx) / pond.rx, 2) + Math.pow((z - pond.cz) / pond.rz, 2);
        const pondBlend = smoothstep(1.2, 0.7, pd);
        this.pondMask[i] = pondBlend;
        h = lerp(h, 0.2 + n.fbm2(x * 0.12, z * 0.12, 2) * 0.8, pondBlend);

        const islandD = Math.hypot(x - isl.cx, z - isl.cz);
        h = lerp(h, isl.top + n.noise2(x * 0.2, z * 0.2) * 0.6, smoothstep(isl.r + 1.6, isl.r - 1.2, islandD));

        const sd = this.streamDistance(x, z);
        const streamBlend = smoothstep(LAYOUT.stream.width + 1.8, LAYOUT.stream.width - 0.8, sd);
        this.streamMask[i] = streamBlend;
        h = lerp(h, 1.1 + n.noise2(x * 0.15, z * 0.15) * 0.5, streamBlend);

        this.heights[i] = Math.round(h);
      }
    }
  }

  isLand(x: number, z: number): boolean {
    if (x < this.ox || x >= this.ox + this.sx || z < this.oz || z >= this.oz + this.sz) return false;
    return this.land[this.gi(Math.round(x), Math.round(z))] === 1;
  }

  /** Terrain surface height (before buildings). -999 outside the island. */
  surfaceAt(x: number, z: number): number {
    const xi = Math.round(x);
    const zi = Math.round(z);
    if (xi < this.ox || xi >= this.ox + this.sx || zi < this.oz || zi >= this.oz + this.sz) return -999;
    return this.heights[this.gi(xi, zi)];
  }

  pondAt(x: number, z: number): number {
    const xi = Math.round(x);
    const zi = Math.round(z);
    if (xi < this.ox || xi >= this.ox + this.sx || zi < this.oz || zi >= this.oz + this.sz) return 0;
    return this.pondMask[this.gi(xi, zi)];
  }

  streamAt(x: number, z: number): number {
    const xi = Math.round(x);
    const zi = Math.round(z);
    if (xi < this.ox || xi >= this.ox + this.sx || zi < this.oz || zi >= this.oz + this.sz) return 0;
    return this.streamMask[this.gi(xi, zi)];
  }

  slopeAt(x: number, z: number): number {
    const h = this.surfaceAt(x, z);
    if (h === -999) return 0;
    let max = 0;
    for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
      const nh = this.surfaceAt(x + dx, z + dz);
      if (nh === -999) continue;
      max = Math.max(max, Math.abs(nh - h));
    }
    return max;
  }

  private grassId(x: number, z: number, h: number): number {
    const n = this.noise;
    const moss = n.fbm2(x * 0.045 + 31, z * 0.045 + 17, 3);
    if (moss > 0.34) return this.rng.chance(0.5) ? P.MOSS_L : P.MOSS_D;
    const v = n.noise2(x * 0.35, z * 0.35) + this.rng.range(-0.35, 0.35);
    if (h > 12 && v > 0.2) return P.GRASS_XL;
    if (v > 0.45) return P.GRASS_XL;
    if (v > 0.1) return P.GRASS_L;
    if (v > -0.4) return P.GRASS_M;
    return P.GRASS_D;
  }

  private rockId(x: number, y: number, z: number): number {
    const band = Math.floor((y + 60) / 5) % 3;
    const v = this.noise.noise2(x * 0.18 + y * 0.05, z * 0.18 - y * 0.03) + this.rng.range(-0.25, 0.25);
    if (v > 0.55) return P.ROCK_XL;
    if (band === 0) return v > 0.1 ? P.ROCK_M : P.ROCK_D;
    if (band === 1) return v > 0.25 ? P.ROCK_L : P.ROCK_M;
    return v > 0.3 ? P.ROCK_M : P.ROCK_D;
  }

  build(volume: VoxelBuffer): void {
    const n = this.noise;
    const wl = LAYOUT.waterLevel;

    for (let z = this.oz; z < this.oz + this.sz; z++) {
      for (let x = this.ox; x < this.ox + this.sx; x++) {
        const i = this.gi(x, z);
        if (!this.land[i]) continue;
        const top = this.heights[i];
        const d = this.islandDistance(x, z);
        const pondBlend = this.pondMask[i];
        const streamBlend = this.streamMask[i];
        const wet = Math.max(pondBlend, streamBlend);
        const slope = this.slopeAt(x, z);

        // --- underside profile ---
        const ridged = n.ridge2(x * 0.055 + 3, z * 0.055 - 9, 3);
        const depth = 4 + 30 * Math.pow(1 - Math.min(1, d), 0.62) + ridged * 13 * (1 - d * 0.75);
        const bottom = Math.round(top - depth);

        // --- surface material ---
        let surfaceId: number;
        if (wet > 0.45 && top <= wl + 1) {
          surfaceId = this.rng.chance(0.35) ? P.SAND_D : P.GRAVEL_D;
        } else if (wet > 0.16 && top <= wl + 3) {
          surfaceId = this.rng.chance(0.5) ? P.SAND_M : P.SAND_L;
        } else if (slope >= 3) {
          surfaceId = this.rng.chance(0.5) ? P.ROCK_L : P.GRANITE_M;
        } else {
          surfaceId = this.grassId(x, z, top);
        }

        for (let y = bottom; y <= top; y++) {
          let id: number;
          if (y === top) id = surfaceId;
          else if (y >= top - 2) id = wet > 0.4 ? P.SAND_D : this.rng.chance(0.5) ? P.SOIL_M : P.SOIL_D;
          else if (y >= top - 4) id = this.rng.chance(0.3) ? P.SOIL_L : P.ROCK_L;
          else {
            id = this.rockId(x, y, z);
            if (y < -10 && this.rng.chance(0.0035)) id = P.FOX_FIRE;
          }
          volume.set(x, y, z, id);
        }

        // --- water body ---
        if (wet > 0.3 && top < wl) {
          for (let y = top + 1; y <= wl; y++) {
            volume.set(x, y, z, y === wl ? P.WATER : P.WATER_D);
          }
        }

        // --- mossy rim + hanging vines ---
        if (d > 0.9) {
          volume.set(x, top, z, this.rng.chance(0.55) ? P.MOSS_D : P.GRASS_D);
          if (d > 0.965 && this.rng.chance(0.22)) {
            const len = this.rng.int(2, 7);
            for (let k = 1; k <= len; k++) {
              volume.setIfAir(x, top - k, z, k % 3 === 0 ? P.WILLOW_D : P.MOSS_D);
            }
          }
        }
      }
    }

    this.buildIslets(volume);
    this.findWaterfallLip(volume);
  }

  private buildIslets(volume: VoxelBuffer): void {
    for (const spec of LAYOUT.islets) {
      const r = spec.r;
      const info: IsletInfo = { ...spec };
      this.islets.push(info);
      for (let z = Math.floor(spec.cz - r - 2); z <= Math.ceil(spec.cz + r + 2); z++) {
        for (let x = Math.floor(spec.cx - r - 2); x <= Math.ceil(spec.cx + r + 2); x++) {
          const dd = Math.hypot(x - spec.cx, z - spec.cz) / r;
          const wob = 1 + this.noise.noise2(x * 0.14, z * 0.14) * 0.18;
          if (dd > wob) continue;
          const top = Math.round(spec.top + this.noise.noise2(x * 0.2 + 5, z * 0.2 - 5) * 1.2);
          const depth = Math.round(3 + (1 - dd) * r * 2.4 + this.noise.ridge2(x * 0.1, z * 0.1, 2) * 4);
          for (let y = top - depth; y <= top; y++) {
            const id = y === top ? this.grassId(x, z, top) : y >= top - 2 ? P.SOIL_M : this.rockId(x, y, z);
            volume.set(x, y, z, id);
          }
          if (dd > 0.8 && this.rng.chance(0.3)) volume.set(x, top, z, P.MOSS_D);
        }
      }
    }
  }

  private findWaterfallLip(volume: VoxelBuffer): void {
    const s = LAYOUT.stream;
    // Walk the stream outward until the island ends; that column is the lip.
    let last: { x: number; z: number } = { x: s.x0, z: s.z0 };
    for (let t = 0; t <= 1.001; t += 0.02) {
      const x = Math.round(lerp(s.x0, s.x1, t));
      const z = Math.round(lerp(s.z0, s.z1, t));
      if (!this.isLand(x, z)) break;
      last = { x, z };
    }
    const y = Math.max(LAYOUT.waterLevel, volume.topAt(last.x, last.z, LAYOUT.waterLevel + 2, LAYOUT.waterLevel));
    this.waterfallLip = { x: last.x, y, z: last.z };
  }
}
