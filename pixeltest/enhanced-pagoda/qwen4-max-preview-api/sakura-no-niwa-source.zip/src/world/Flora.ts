import { P, KIND_OF, Kind } from '../voxel/Palette';
import type { VoxelBuffer } from '../voxel/VoxelBuffer';
import type { Rng } from '../util/rng';
import type { Terrain } from './Terrain';
import { LAYOUT } from './Layout';

const GRASS_IDS = new Set([P.GRASS_D, P.GRASS_M, P.GRASS_L, P.GRASS_XL, P.MOSS_D, P.MOSS_L, P.CLOVER]);

function isGrass(id: number): boolean {
  return GRASS_IDS.has(id);
}

/** Azalea / boxwood shrub, optionally in flower. */
export function shrub(volume: VoxelBuffer, x: number, y: number, z: number, rng: Rng, flowering = true, scale = 1): void {
  const r = rng.range(1.8, 3.1) * scale;
  volume.ellipsoid(x, y + r * 0.55, z, r, r * 0.75, r, (_vx, vy, _vz, d) => {
    if (d > 0.7 && rng.chance(0.45)) return 0;
    if (!flowering) return rng.chance(0.35) ? P.PINE_L : P.HEDGE;
    const bloom = vy > y + r * 0.45 && rng.chance(0.55);
    if (bloom) return rng.pick([P.AZALEA_M, P.AZALEA_L, P.AZALEA_D]);
    return rng.chance(0.4) ? P.HEDGE : P.PINE_M;
  });
  if (flowering) {
    for (let i = 0; i < 5; i++) {
      const a = rng.range(0, Math.PI * 2);
      volume.setIfAir(
        Math.round(x + Math.cos(a) * r),
        Math.round(y + r * rng.range(0.4, 1.1)),
        Math.round(z + Math.sin(a) * r),
        P.AZALEA_L,
      );
    }
  }
}

/** Iris / kakitsubata clump for the pond margin. */
export function irisClump(volume: VoxelBuffer, x: number, y: number, z: number, rng: Rng): void {
  const n = rng.int(3, 6);
  for (let i = 0; i < n; i++) {
    const dx = rng.int(-1, 1);
    const dz = rng.int(-1, 1);
    const h = rng.int(2, 4);
    for (let k = 1; k <= h; k++) volume.setIfAir(x + dx, y + k, z + dz, P.STEM);
    volume.setIfAir(x + dx, y + h + 1, z + dz, rng.pick([P.IRIS_M, P.IRIS_L, P.IRIS_D]));
    if (rng.chance(0.5)) volume.setIfAir(x + dx + rng.int(-1, 1), y + h, z + dz + rng.int(-1, 1), P.IRIS_L);
  }
}

/** Marigold / nanohana flower bed. */
export function flowerBed(volume: VoxelBuffer, x: number, y: number, z: number, rng: Rng, r = 3): void {
  for (let dz = -r; dz <= r; dz++) {
    for (let dx = -r; dx <= r; dx++) {
      if (dx * dx + dz * dz > r * r) continue;
      const gx = x + dx;
      const gz = z + dz;
      const top = volume.groundAt(gx, gz, y + 3, -999);
      if (top === -999 || !isGrass(volume.get(gx, top, gz))) continue;
      if (!rng.chance(0.55)) continue;
      const h = rng.int(1, 2);
      for (let k = 1; k <= h; k++) volume.setIfAir(gx, top + k, gz, P.STEM);
      volume.setIfAir(gx, top + h + 1, gz, rng.chance(0.5) ? P.MARIGOLD : P.MARIGOLD_L);
    }
  }
}

/** Weathered boulder with a mossy cap. */
export function boulder(volume: VoxelBuffer, x: number, y: number, z: number, rng: Rng, scale = 1): void {
  const r = rng.range(1.6, 3.4) * scale;
  const h = r * rng.range(0.7, 1.3);
  volume.ellipsoid(x, y + h * 0.4, z, r, h, r * rng.range(0.7, 1.1), (_vx, vy, _vz, d) => {
    if (d > 0.78 && rng.chance(0.4)) return 0;
    if (vy > y + h * 0.7 && rng.chance(0.45)) return P.MOSS_STONE;
    return rng.chance(0.3) ? P.ROCK_L : rng.chance(0.5) ? P.ROCK_M : P.ROCK_D;
  });
}

/** Lily pads and lotus flowers floating on the pond. */
export function lilyPads(volume: VoxelBuffer, rng: Rng, count: number): void {
  const { cx, cz, rx, rz } = LAYOUT.pond;
  const wl = LAYOUT.waterLevel;
  for (let i = 0; i < count; i++) {
    const a = rng.range(0, Math.PI * 2);
    const d = Math.sqrt(rng.next()) * 0.92;
    const x = Math.round(cx + Math.cos(a) * rx * d);
    const z = Math.round(cz + Math.sin(a) * rz * d);
    if (volume.get(x, wl, z) !== P.WATER) continue;
    if (volume.get(x, wl + 1, z) !== 0) continue;
    const r = rng.range(1, 1.9);
    volume.disc(x, wl + 1, z, r, rng.chance(0.4) ? P.LILY_PAD_L : P.LILY_PAD);
    if (rng.chance(0.28)) {
      volume.set(x, wl + 2, z, P.LOTUS);
      volume.setIfAir(x, wl + 3, z, P.LOTUS_L);
      for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
        volume.setIfAir(x + dx, wl + 2, z + dz, P.LOTUS);
      }
    }
  }
}

/** Reeds at the water's edge. */
export function reeds(volume: VoxelBuffer, x: number, y: number, z: number, rng: Rng): void {
  const n = rng.int(2, 5);
  for (let i = 0; i < n; i++) {
    const dx = rng.int(-1, 1);
    const dz = rng.int(-1, 1);
    const h = rng.int(2, 5);
    for (let k = 1; k <= h; k++) {
      volume.setIfAir(x + dx, y + k, z + dz, k === h ? P.BAMBOO_LEAF : P.STEM);
    }
  }
}

/**
 * Scatter the small stuff: shrubs, boulders, iris margins, reeds, tufts and
 * drifts of fallen petals. Only paints on natural ground so paths, courts and
 * buildings stay clean.
 */
export function scatterFlora(volume: VoxelBuffer, terrain: Terrain, rng: Rng, detail: number): void {
  const attempts = Math.round(1500 * detail);
  for (let i = 0; i < attempts; i++) {
    const x = rng.int(-56, 56);
    const z = rng.int(-56, 56);
    if (!terrain.isLand(x, z)) continue;
    const y = volume.groundAt(x, z, 30, -999);
    if (y === -999) continue;
    const id = volume.get(x, y, z);
    const above = volume.get(x, y + 1, z);
    if (above !== 0 && KIND_OF[above] !== Kind.Water) continue;

    const pond = terrain.pondAt(x, z);
    const stream = terrain.streamAt(x, z);
    const wet = Math.max(pond, stream);
    const r = rng.next();

    if (wet > 0.05 && wet < 0.42 && y <= LAYOUT.waterLevel + 2) {
      if (r < 0.4) irisClump(volume, x, y, z, rng);
      else if (r < 0.7) reeds(volume, x, y + 1, z, rng);
      else if (r < 0.82) boulder(volume, x, y, z, rng, 0.7);
      continue;
    }
    if (!isGrass(id)) continue;

    if (r < 0.1) shrub(volume, x, y + 1, z, rng, rng.chance(0.6), rng.range(0.7, 1.1));
    else if (r < 0.16) boulder(volume, x, y, z, rng, rng.range(0.5, 0.9));
    else if (r < 0.2) flowerBed(volume, x, y, z, rng, rng.int(2, 3));
    else if (r < 0.42) {
      // grass tufts / clover
      const h = rng.int(1, 2);
      for (let k = 1; k <= h; k++) volume.setIfAir(x, y + k, z, rng.chance(0.4) ? P.CLOVER : P.GRASS_XL);
    } else if (r < 0.5) {
      volume.set(x, y, z, rng.chance(0.5) ? P.MOSS_L : P.MOSS_D);
    }
  }

  lilyPads(volume, rng, Math.round(46 * detail));
}
