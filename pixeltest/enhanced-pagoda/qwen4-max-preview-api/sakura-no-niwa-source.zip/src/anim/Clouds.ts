import * as THREE from 'three';
import { P } from '../voxel/Palette';
import { propGeometry, type Cell } from '../voxel/PropKit';
import type { VoxelMaterials } from '../voxel/VoxelMaterials';
import type { Rng } from '../util/rng';

interface CloudInstance {
  angle: number;
  radius: number;
  y: number;
  speed: number;
  scale: number;
  spin: number;
}

/** Chunky voxel cumulus drifting around the island. */
export class Clouds {
  readonly object: THREE.InstancedMesh;
  private geometry: THREE.BufferGeometry;
  private items: CloudInstance[] = [];
  private dummy = new THREE.Object3D();

  constructor(
    materials: VoxelMaterials,
    rng: Rng,
    opts: { count?: number; radius?: [number, number]; y?: [number, number]; scale?: [number, number] } = {},
  ) {
    const count = opts.count ?? 7;
    const radiusRange = opts.radius ?? [165, 260];
    const yRange = opts.y ?? [46, 104];
    const scaleRange = opts.scale ?? [0.85, 1.7];
    const cells: Cell[] = [];
    const blobs = 7;
    for (let b = 0; b < blobs; b++) {
      const bx = rng.range(-6, 6);
      const bz = rng.range(-3, 3);
      const by = rng.range(-0.6, 1.2);
      const r = rng.range(2, 3.6);
      for (let z = Math.ceil(-r); z <= Math.ceil(r); z++) {
        for (let y = Math.ceil(-r * 0.6); y <= Math.ceil(r * 0.6); y++) {
          for (let x = Math.ceil(-r); x <= Math.ceil(r); x++) {
            const d = (x / r) ** 2 + (y / (r * 0.55)) ** 2 + (z / (r * 0.8)) ** 2;
            if (d > 1) continue;
            cells.push([Math.round(bx + x), Math.round(by + y), Math.round(bz + z), y < 0 ? P.CLOUD_D : P.CLOUD]);
          }
        }
      }
    }
    this.geometry = propGeometry(cells, true);
    this.object = new THREE.InstancedMesh(this.geometry, materials.solid, count);
    this.object.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.object.frustumCulled = false;
    this.object.name = 'clouds';

    for (let i = 0; i < count; i++) {
      this.items.push({
        angle: (i / count) * Math.PI * 2 + rng.range(-0.3, 0.3),
        radius: rng.range(radiusRange[0], radiusRange[1]),
        y: rng.range(yRange[0], yRange[1]),
        speed: rng.range(0.004, 0.012) * (rng.chance(0.5) ? 1 : -1),
        scale: rng.range(scaleRange[0], scaleRange[1]),
        spin: rng.range(0, Math.PI * 2),
      });
    }
  }

  update(dt: number, time: number): void {
    this.items.forEach((c, i) => {
      c.angle += dt * c.speed;
      this.dummy.position.set(Math.cos(c.angle) * c.radius, c.y + Math.sin(time * 0.12 + i) * 1.6, Math.sin(c.angle) * c.radius);
      this.dummy.rotation.set(0, c.spin + c.angle * 0.3, 0);
      this.dummy.scale.setScalar(c.scale);
      this.dummy.updateMatrix();
      this.object.setMatrixAt(i, this.dummy.matrix);
    });
    this.object.instanceMatrix.needsUpdate = true;
  }

  dispose(): void {
    this.geometry.dispose();
    this.object.dispose();
  }
}
