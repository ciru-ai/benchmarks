import * as THREE from 'three';
import { P } from '../voxel/Palette';
import { VoxelBuffer } from '../voxel/VoxelBuffer';
import { meshProp } from '../voxel/Mesher';
import type { VoxelMaterials } from '../voxel/VoxelMaterials';
import type { Prop } from './types';

/** Bonshō temple bell hanging from a pivot; rings with a damped swing. */
export class Bell implements Prop {
  readonly object: THREE.Group;
  private mesh: THREE.Mesh;
  private geometry: THREE.BufferGeometry;
  private amplitude = 0;
  private phase = 0;
  private axis: 'x' | 'z';
  onRing?: (strength: number) => void;

  constructor(materials: VoxelMaterials, position: THREE.Vector3, scale = 1, axis: 'x' | 'z' = 'x') {
    this.axis = axis;
    const vol = new VoxelBuffer({ sx: 12, sy: 16, sz: 12, ox: -6, oy: -14, oz: -6 });
    vol.set(0, -1, 0, P.GOLD_D);
    vol.box(-1, -2, -1, 1, -2, 1, P.BRONZE);
    for (let y = -3; y >= -7; y--) {
      const r = y >= -3 ? 1 : 2;
      for (let dz = -r; dz <= r; dz++) {
        for (let dx = -r; dx <= r; dx++) {
          if (Math.abs(dx) === r && Math.abs(dz) === r && y > -7) continue;
          const shell = Math.abs(dx) === r || Math.abs(dz) === r || y === -3;
          if (!shell) continue;
          let id = P.BRONZE;
          if (y === -7) id = P.GOLD_D;
          else if (y === -5 && (dx + dz) % 2 === 0) id = P.GOLD;
          else if ((dx === 0 || dz === 0) && y === -4) id = P.GOLD_L;
          vol.set(dx, y, dz, id);
        }
      }
    }
    vol.box(-2, -8, -2, 2, -8, 2, P.BRONZE);
    for (const [dx, dz] of [[2, 0], [-2, 0], [0, 2], [0, -2]] as const) vol.set(dx, -8, dz, P.GOLD_D);

    this.geometry = meshProp(vol, false);
    this.mesh = new THREE.Mesh(this.geometry, materials.solid);
    this.mesh.castShadow = true;
    this.mesh.receiveShadow = true;
    this.object = new THREE.Group();
    this.object.add(this.mesh);
    this.object.position.copy(position);
    this.object.scale.setScalar(scale);
    this.object.name = 'temple-bell';
  }

  ring(strength = 1): void {
    this.amplitude = Math.min(0.42, this.amplitude + 0.26 * strength);
    this.phase = 0;
    this.onRing?.(strength);
  }

  update(dt: number, _time: number): void {
    if (this.amplitude < 0.0004) {
      if (this.object.rotation.x !== 0 || this.object.rotation.z !== 0) {
        this.object.rotation.set(0, 0, 0);
      }
      return;
    }
    this.phase += dt;
    const angle = this.amplitude * Math.sin(this.phase * 4.6) * Math.exp(-this.phase * 0.55);
    if (this.axis === 'x') this.object.rotation.z = angle;
    else this.object.rotation.x = angle;
    this.amplitude *= Math.exp(-dt * 0.32);
  }

  dispose(): void {
    this.geometry.dispose();
  }
}
