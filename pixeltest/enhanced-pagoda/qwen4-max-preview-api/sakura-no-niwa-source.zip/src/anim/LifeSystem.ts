import * as THREE from 'three';
import { Rng } from '../util/rng';
import type { VoxelMaterials } from '../voxel/VoxelMaterials';
import type { SettingsStore } from '../core/Settings';
import type { World } from '../world/WorldBuilder';
import { Petals } from './Petals';
import { Koi } from './Koi';
import { Clouds } from './Clouds';
import { Fireflies } from './Fireflies';
import { Waterfall } from './Waterfall';
import { Smoke } from './Smoke';
import { Cranes } from './Cranes';
import { SpiritOrbs } from './SpiritOrbs';

/**
 * Everything that moves: blossom fall, koi, cranes, clouds, fireflies,
 * waterfall, hearth smoke and shrine flames. One update call per frame.
 */
export class LifeSystem {
  readonly group = new THREE.Group();
  readonly petals: Petals;
  readonly koi: Koi;
  readonly clouds: Clouds;
  readonly cloudsLow: Clouds;
  readonly fireflies: Fireflies;
  readonly waterfall: Waterfall;
  readonly smoke: Smoke;
  readonly cranes: Cranes;
  readonly orbs: SpiritOrbs;

  private settings: SettingsStore;
  private materials: VoxelMaterials;
  private gustTimer = 8;
  private rng: Rng;
  onGust?: (strength: number) => void;
  onPetalLand?: (x: number, z: number) => void;

  constructor(world: World, materials: VoxelMaterials, settings: SettingsStore) {
    this.settings = settings;
    this.materials = materials;
    this.rng = new Rng(`${settings.get('seed')}-life`);
    this.group.name = 'life';

    this.petals = new Petals(materials, world.blossomSources, world.terrain, this.rng.fork(1));
    this.petals.onWaterLand = (x, z) => {
      this.materials.addRipple(x, z, 0.22);
      this.onPetalLand?.(x, z);
    };
    this.koi = new Koi(materials, this.rng.fork(2));
    this.clouds = new Clouds(materials, this.rng.fork(3), { count: 7 });
    this.cloudsLow = new Clouds(materials, this.rng.fork(8), { count: 5, radius: [105, 165], y: [-16, 26], scale: [1.1, 2.1] });
    this.fireflies = new Fireflies(world.fireflyZones, this.rng.fork(4), 240);
    this.waterfall = new Waterfall(materials, world.waterfall, this.rng.fork(5));
    this.smoke = new Smoke(world.chimney, this.rng.fork(6));
    this.cranes = new Cranes(materials, this.rng.fork(7));
    this.orbs = new SpiritOrbs(materials, world.spiritOrbs);

    this.group.add(
      this.petals.group,
      this.koi.group,
      this.clouds.object,
      this.cloudsLow.object,
      this.fireflies.object,
      this.waterfall.group,
      this.smoke.object,
      this.cranes.group,
      this.orbs.object,
    );

    this.syncAll();
  }

  syncAll(): void {
    const s = this.settings;
    this.petals.setAmount(s.get('petalAmount'));
    this.petals.setWind(s.get('windSpeed'));
    this.koi.setCount(s.get('koiCount'));
    this.clouds.object.visible = s.get('clouds');
    this.cloudsLow.object.visible = s.get('clouds');
    this.cranes.group.visible = s.get('cranes');
  }

  applySetting(key: string): void {
    const s = this.settings;
    switch (key) {
      case 'petalAmount':
        this.petals.setAmount(s.get('petalAmount'));
        break;
      case 'windSpeed':
        this.petals.setWind(s.get('windSpeed'));
        break;
      case 'koiCount':
        this.koi.setCount(s.get('koiCount'));
        break;
      case 'clouds':
        this.clouds.object.visible = s.get('clouds');
        this.cloudsLow.object.visible = s.get('clouds');
        break;
      case 'cranes':
        this.cranes.group.visible = s.get('cranes');
        break;
      default:
        break;
    }
  }

  setPixelRatio(pr: number): void {
    this.fireflies.setPixelRatio(pr);
  }

  gust(strength = 1): void {
    this.petals.addGust(strength);
    this.onGust?.(strength);
  }

  update(dt: number, time: number, night: number): void {
    const wind = this.settings.get('windSpeed');
    this.gustTimer -= dt;
    if (this.gustTimer <= 0) {
      this.gustTimer = this.rng.range(14, 26);
      this.gust(this.rng.range(0.5, 1.1));
    }

    this.petals.update(dt, time);
    this.koi.update(dt, time);
    if (this.clouds.object.visible) {
      this.clouds.update(dt, time);
      this.cloudsLow.update(dt, time);
    }
    this.fireflies.update(dt, time, night, this.settings.get('fireflies'));
    this.waterfall.update(dt, time, wind);
    this.smoke.update(dt, time, wind);
    if (this.cranes.group.visible) this.cranes.update(dt, time);
    this.orbs.update(dt, time, night);
  }

  dispose(): void {
    this.petals.dispose();
    this.koi.dispose();
    this.clouds.dispose();
    this.cloudsLow.dispose();
    this.fireflies.dispose();
    this.waterfall.dispose();
    this.smoke.dispose();
    this.cranes.dispose();
    this.orbs.dispose();
    this.group.clear();
  }
}
