import * as THREE from 'three';
import { P } from '../voxel/Palette';
import { VoxelBuffer } from '../voxel/VoxelBuffer';
import { meshProp } from '../voxel/Mesher';
import type { VoxelMaterials } from '../voxel/VoxelMaterials';
import type { Prop } from './types';

/**
 * Shishi-odoshi: the bamboo tube fills, tips, and knocks back against its
 * stone with a clack. A tiny mechanical heartbeat for the tea garden.
 */
export class ShishiOdoshi implements Prop {
  readonly object: THREE.Group;
  private geometry: THREE.BufferGeometry;
  private mesh: THREE.Mesh;
  private t = 0;
  private period: number;
  private angle = 0;
  private lastCycle = -1;
  onClack?: () => void;

  constructor(materials: VoxelMaterials, position: THREE.Vector3, period = 7.5) {
    this.period = period;
    const vol = new VoxelBuffer({ sx: 14, sy: 8, sz: 8, ox: -7, oy: -4, oz: -4 });
    // tube runs along +X, pivot at origin, open mouth at the far end
    for (let x = -3; x <= 4; x++) {
      const open = x === 4;
      vol.set(x, 0, 0, open ? P.BAMBOO_L : x % 3 === 0 ? P.BAMBOO_D : P.BAMBOO_M);
      vol.set(x, 1, 0, open ? 0 : P.BAMBOO_L);
      if (!open) {
        vol.set(x, 0, 1, P.BAMBOO_D);
        vol.set(x, 0, -1, P.BAMBOO_D);
      }
    }
    vol.set(-3, 1, 0, P.BAMBOO_D);
    this.geometry = meshProp(vol, false);
    this.mesh = new THREE.Mesh(this.geometry, materials.solid);
    this.mesh.castShadow = true;
    this.object = new THREE.Group();
    this.object.add(this.mesh);
    this.object.position.copy(position);
    this.object.name = 'shishi-odoshi';
  }

  update(dt: number, _time: number): void {
    this.t += dt;
    const cycle = Math.floor(this.t / this.period);
    const p = (this.t % this.period) / this.period;
    // 0..0.72 filling (slow tilt back), 0.72..0.8 tipping, 0.8..0.9 return + clack
    let target: number;
    if (p < 0.72) target = -0.16 - (p / 0.72) * 0.16;
    else if (p < 0.8) target = -0.32 + ((p - 0.72) / 0.08) * 0.86;
    else if (p < 0.86) target = 0.54 - ((p - 0.8) / 0.06) * 0.62;
    else target = -0.08 + Math.sin((p - 0.86) * 42) * 0.05 * (1 - (p - 0.86) / 0.14);

    if (p >= 0.8 && this.lastCycle !== cycle) {
      this.lastCycle = cycle;
      this.onClack?.();
    }
    this.angle += (target - this.angle) * Math.min(1, dt * 14);
    this.object.rotation.z = this.angle;
  }

  dispose(): void {
    this.geometry.dispose();
  }
}
