import * as THREE from 'three';
import { P } from '../voxel/Palette';
import { cubeGeometry } from '../voxel/PropKit';
import type { VoxelMaterials } from '../voxel/VoxelMaterials';

/** Hitodama: the paired fox-flames that hover above the shrine guardians. */
export class SpiritOrbs {
  readonly object: THREE.InstancedMesh;
  private geometry: THREE.BufferGeometry;
  private dummy = new THREE.Object3D();
  private homes: THREE.Vector3[];

  constructor(materials: VoxelMaterials, positions: THREE.Vector3[]) {
    this.homes = positions.length ? positions : [new THREE.Vector3(0, 20, 0)];
    this.geometry = cubeGeometry(P.FOX_FIRE);
    this.object = new THREE.InstancedMesh(this.geometry, materials.glow, this.homes.length);
    this.object.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.object.frustumCulled = false;
    this.object.name = 'spirit-orbs';
  }

  update(_dt: number, time: number, night: number): void {
    this.homes.forEach((h, i) => {
      const t = time * 0.9 + i * 2.1;
      const pulse = 0.55 + 0.45 * Math.sin(t * 1.7);
      this.dummy.position.set(h.x + Math.sin(t * 0.7) * 0.7, h.y + Math.sin(t) * 0.9, h.z + Math.cos(t * 0.6) * 0.7);
      this.dummy.rotation.set(t * 0.4, t * 0.6, 0);
      this.dummy.scale.setScalar((0.5 + pulse * 0.45) * (0.65 + night * 0.6));
      this.dummy.updateMatrix();
      this.object.setMatrixAt(i, this.dummy.matrix);
    });
    this.object.instanceMatrix.needsUpdate = true;
  }

  dispose(): void {
    this.geometry.dispose();
    this.object.dispose();
  }
}
