import * as THREE from 'three';
import type { Rng } from '../util/rng';

export interface FireflyZone {
  center: THREE.Vector3;
  radius: number;
}

/** Hotaru: additive drifting sparks that only wake after dusk. */
export class Fireflies {
  readonly object: THREE.Points;
  private geometry: THREE.BufferGeometry;
  private material: THREE.ShaderMaterial;
  private positions: Float32Array;
  private seeds: Float32Array;
  private homes: Float32Array;
  private count: number;

  constructor(zones: FireflyZone[], rng: Rng, count = 220) {
    this.count = count;
    this.positions = new Float32Array(count * 3);
    this.homes = new Float32Array(count * 3);
    this.seeds = new Float32Array(count * 3);
    const sizes = new Float32Array(count);
    const safeZones = zones.length ? zones : [{ center: new THREE.Vector3(0, 12, 0), radius: 40 }];

    for (let i = 0; i < count; i++) {
      const zone = rng.pick(safeZones);
      const a = rng.range(0, Math.PI * 2);
      const d = Math.sqrt(rng.next()) * zone.radius;
      const x = zone.center.x + Math.cos(a) * d;
      const y = zone.center.y + rng.range(-3, 9);
      const z = zone.center.z + Math.sin(a) * d;
      this.homes.set([x, y, z], i * 3);
      this.positions.set([x, y, z], i * 3);
      this.seeds.set([rng.range(0, 6.28), rng.range(0.3, 1.1), rng.range(1.5, 5)], i * 3);
      sizes[i] = rng.range(1.4, 3.4);
    }

    this.geometry = new THREE.BufferGeometry();
    this.geometry.setAttribute('position', new THREE.BufferAttribute(this.positions, 3));
    this.geometry.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
    this.geometry.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 20, 0), 140);

    this.material = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      uniforms: {
        uTime: { value: 0 },
        uOpacity: { value: 0 },
        uPixelRatio: { value: 1 },
        uColorA: { value: new THREE.Color('#ffd76a') },
        uColorB: { value: new THREE.Color('#9ef7c8') },
      },
      vertexShader: /* glsl */ `
        attribute float aSize;
        uniform float uTime;
        uniform float uPixelRatio;
        varying float vTwinkle;
        varying float vMix;
        void main() {
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          float t = uTime * 1.6 + position.x * 0.7 + position.z * 0.4;
          vTwinkle = 0.35 + 0.65 * pow(max(0.0, sin(t)), 3.0);
          vMix = fract(position.x * 0.13 + position.z * 0.07);
          gl_PointSize = aSize * uPixelRatio * (170.0 / max(1.0, -mv.z)) * (0.6 + vTwinkle * 0.8);
          gl_Position = projectionMatrix * mv;
        }
      `,
      fragmentShader: /* glsl */ `
        uniform float uOpacity;
        uniform vec3 uColorA;
        uniform vec3 uColorB;
        varying float vTwinkle;
        varying float vMix;
        void main() {
          vec2 c = gl_PointCoord - 0.5;
          float d = length(c);
          float alpha = smoothstep(0.5, 0.02, d);
          alpha *= alpha;
          vec3 col = mix(uColorA, uColorB, vMix);
          gl_FragColor = vec4(col * (1.4 + vTwinkle), alpha * vTwinkle * uOpacity);
        }
      `,
    });

    this.object = new THREE.Points(this.geometry, this.material);
    this.object.frustumCulled = false;
    this.object.name = 'fireflies';
  }

  setPixelRatio(pr: number): void {
    this.material.uniforms.uPixelRatio.value = pr;
  }

  update(dt: number, time: number, night: number, enabled: boolean): void {
    const target = enabled ? night : 0;
    const u = this.material.uniforms.uOpacity;
    u.value += (target - u.value) * Math.min(1, dt * 2);
    this.object.visible = u.value > 0.01;
    if (!this.object.visible) return;
    this.material.uniforms.uTime.value = time;

    for (let i = 0; i < this.count; i++) {
      const i3 = i * 3;
      const phase = this.seeds[i3];
      const speed = this.seeds[i3 + 1];
      const range = this.seeds[i3 + 2];
      this.positions[i3] = this.homes[i3] + Math.sin(time * speed * 0.5 + phase) * range;
      this.positions[i3 + 1] = this.homes[i3 + 1] + Math.sin(time * speed * 0.8 + phase * 2.1) * range * 0.5;
      this.positions[i3 + 2] = this.homes[i3 + 2] + Math.cos(time * speed * 0.45 + phase * 1.4) * range;
    }
    this.geometry.attributes.position.needsUpdate = true;
  }

  dispose(): void {
    this.geometry.dispose();
    this.material.dispose();
  }
}
