import * as THREE from 'three';
import { P } from '../voxel/Palette';
import { cubeGeometry } from '../voxel/PropKit';
import type { VoxelMaterials } from '../voxel/VoxelMaterials';
import type { Rng } from '../util/rng';

const DROPS = 190;
const MIST = 46;

/** The stream tips off the island edge and shreds into mist below. */
export class Waterfall {
  readonly group = new THREE.Group();
  private drops: THREE.InstancedMesh;
  private mist: THREE.InstancedMesh;
  private dropGeo: THREE.BufferGeometry;
  private mistGeo: THREE.BufferGeometry;
  private mistMat: THREE.MeshStandardMaterial;
  private state: Float32Array;
  private mistState: Float32Array;
  private dummy = new THREE.Object3D();
  private rng: Rng;
  private lip: THREE.Vector3;
  private fallHeight = 46;

  constructor(materials: VoxelMaterials, lip: { x: number; y: number; z: number }, rng: Rng) {
    this.rng = rng;
    this.lip = new THREE.Vector3(lip.x + 0.5, lip.y + 1, lip.z + 0.5);
    this.group.name = 'waterfall';

    this.dropGeo = cubeGeometry(P.WATER_L);
    this.drops = new THREE.InstancedMesh(this.dropGeo, materials.solid, DROPS);
    this.drops.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.drops.frustumCulled = false;
    this.group.add(this.drops);

    this.mistGeo = cubeGeometry(P.FOAM);
    this.mistMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#dff2fb'),
      transparent: true,
      opacity: 0.42,
      roughness: 1,
      depthWrite: false,
    });
    this.mist = new THREE.InstancedMesh(this.mistGeo, this.mistMat, MIST);
    this.mist.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.mist.frustumCulled = false;
    this.group.add(this.mist);

    this.state = new Float32Array(DROPS * 6);
    for (let i = 0; i < DROPS; i++) this.resetDrop(i, true);
    this.mistState = new Float32Array(MIST * 5);
    for (let i = 0; i < MIST; i++) this.resetMist(i, true);
  }

  private resetDrop(i: number, initial = false): void {
    const s = this.state;
    const o = i * 6;
    s[o] = this.lip.x + this.rng.range(-1.8, 1.8);
    s[o + 1] = this.lip.y + (initial ? -this.rng.range(0, this.fallHeight) : this.rng.range(-0.5, 1));
    s[o + 2] = this.lip.z + this.rng.range(-1.2, 1.6);
    s[o + 3] = this.rng.range(-0.35, 0.35);
    s[o + 4] = this.rng.range(-1.5, -0.4);
    s[o + 5] = this.rng.range(0.5, 1.5);
  }

  private resetMist(i: number, initial = false): void {
    const s = this.mistState;
    const o = i * 5;
    s[o] = this.lip.x + this.rng.range(-5, 5);
    s[o + 1] = this.lip.y - this.fallHeight + this.rng.range(-4, 6) + (initial ? this.rng.range(0, 10) : 0);
    s[o + 2] = this.lip.z + this.rng.range(-4, 6);
    s[o + 3] = initial ? this.rng.range(0, 1) : 0;
    s[o + 4] = this.rng.range(1.4, 3.6);
  }

  update(dt: number, time: number, wind: number): void {
    const s = this.state;
    for (let i = 0; i < DROPS; i++) {
      const o = i * 6;
      s[o + 4] -= dt * 15;
      s[o] += (s[o + 3] + wind * 0.8) * dt;
      s[o + 1] += s[o + 4] * dt;
      s[o + 2] += this.rng.range(-0.2, 0.2) * dt;
      if (s[o + 1] < this.lip.y - this.fallHeight) this.resetDrop(i);
      const stretch = Math.min(3.4, 1 + Math.abs(s[o + 4]) * 0.09);
      this.dummy.position.set(s[o], s[o + 1], s[o + 2]);
      this.dummy.rotation.set(0, 0, 0);
      this.dummy.scale.set(s[o + 5] * 0.7, s[o + 5] * stretch, s[o + 5] * 0.7);
      this.dummy.updateMatrix();
      this.drops.setMatrixAt(i, this.dummy.matrix);
    }
    this.drops.instanceMatrix.needsUpdate = true;

    const m = this.mistState;
    for (let i = 0; i < MIST; i++) {
      const o = i * 5;
      m[o + 3] += dt * 0.24;
      if (m[o + 3] > 1) this.resetMist(i);
      const life = m[o + 3];
      const scale = m[o + 4] * (0.5 + life * 1.5) * (1 - life * 0.35);
      this.dummy.position.set(m[o] + Math.sin(time * 0.5 + i) * 1.6 + wind * life * 4, m[o + 1] + life * 9, m[o + 2] + Math.cos(time * 0.4 + i) * 1.4);
      this.dummy.rotation.set(life * 1.2, life * 0.8, 0);
      this.dummy.scale.setScalar(Math.max(0.01, scale));
      this.dummy.updateMatrix();
      this.mist.setMatrixAt(i, this.dummy.matrix);
    }
    this.mist.instanceMatrix.needsUpdate = true;
  }

  dispose(): void {
    this.dropGeo.dispose();
    this.mistGeo.dispose();
    this.mistMat.dispose();
    this.drops.dispose();
    this.mist.dispose();
  }
}
