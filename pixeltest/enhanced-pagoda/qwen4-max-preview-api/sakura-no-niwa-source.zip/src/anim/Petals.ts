import * as THREE from 'three';
import { P } from '../voxel/Palette';
import { cubeGeometry } from '../voxel/PropKit';
import type { VoxelMaterials } from '../voxel/VoxelMaterials';
import type { Rng } from '../util/rng';
import type { BlossomSource } from '../world/Trees';
import type { Terrain } from '../world/Terrain';
import { LAYOUT } from '../world/Layout';

const PETAL_IDS = [P.PETAL_A, P.PETAL_B, P.PETAL_C, P.PETAL_D, P.PETAL_E];
const MAX_PER_GROUP = 460;

interface Petal {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  rot: THREE.Euler;
  spin: THREE.Vector3;
  scale: number;
  phase: number;
  group: number;
}

/**
 * Blossom fall. Petals are born in the cherry canopies, flutter on the wind,
 * and dissolve when they touch ground or water (leaving a ripple behind).
 */
export class Petals {
  readonly group = new THREE.Group();
  private meshes: THREE.InstancedMesh[] = [];
  private geometries: THREE.BufferGeometry[] = [];
  private petals: Petal[] = [];
  private dummy = new THREE.Object3D();
  private rng: Rng;
  private sources: BlossomSource[];
  private terrain: Terrain;
  private amount = 0;
  private wind = 0.5;
  private gust = 0;
  private gustDir = new THREE.Vector2(1, 0.3);
  onWaterLand?: (x: number, z: number) => void;

  constructor(materials: VoxelMaterials, sources: BlossomSource[], terrain: Terrain, rng: Rng) {
    this.rng = rng;
    this.sources = sources.length ? sources : [{ center: new THREE.Vector3(0, 40, 0), radius: 30 }];
    this.terrain = terrain;
    this.group.name = 'petals';

    for (let g = 0; g < PETAL_IDS.length; g++) {
      const geo = cubeGeometry(PETAL_IDS[g]);
      this.geometries.push(geo);
      const mesh = new THREE.InstancedMesh(geo, materials.solid, MAX_PER_GROUP);
      mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      mesh.frustumCulled = false;
      mesh.castShadow = false;
      mesh.receiveShadow = false;
      mesh.count = 0;
      this.meshes.push(mesh);
      this.group.add(mesh);
    }

    for (let i = 0; i < MAX_PER_GROUP * PETAL_IDS.length; i++) {
      const petal: Petal = {
        pos: new THREE.Vector3(),
        vel: new THREE.Vector3(),
        rot: new THREE.Euler(),
        spin: new THREE.Vector3(),
        scale: 0.5,
        phase: 0,
        group: i % PETAL_IDS.length,
      };
      this.respawn(petal, true);
      this.petals.push(petal);
    }
  }

  private respawn(p: Petal, initial = false): void {
    const src = this.rng.pick(this.sources);
    const a = this.rng.range(0, Math.PI * 2);
    const d = Math.sqrt(this.rng.next()) * src.radius;
    p.pos.set(
      src.center.x + Math.cos(a) * d,
      src.center.y + this.rng.range(-1.5, 2.5) + (initial ? this.rng.range(-24, 6) : 0),
      src.center.z + Math.sin(a) * d,
    );
    p.vel.set(this.rng.range(-0.4, 0.4), this.rng.range(-1.4, -0.7), this.rng.range(-0.4, 0.4));
    p.rot.set(this.rng.range(0, 6.28), this.rng.range(0, 6.28), this.rng.range(0, 6.28));
    p.spin.set(this.rng.range(-1.6, 1.6), this.rng.range(-1.2, 1.2), this.rng.range(-1.8, 1.8));
    p.scale = this.rng.range(0.42, 0.78);
    p.phase = this.rng.range(0, 6.28);
  }

  setAmount(n: number): void {
    this.amount = Math.max(0, Math.min(MAX_PER_GROUP * PETAL_IDS.length, Math.round(n)));
    const perGroup = Math.ceil(this.amount / PETAL_IDS.length);
    this.meshes.forEach((m, i) => {
      m.count = Math.max(0, Math.min(MAX_PER_GROUP, perGroup - i * 0));
    });
  }

  setWind(w: number): void {
    this.wind = w;
  }

  addGust(strength = 1): void {
    this.gust = Math.min(2.4, this.gust + strength);
    const a = this.rng.range(0, Math.PI * 2);
    this.gustDir.set(Math.cos(a), Math.sin(a));
  }

  update(dt: number, time: number): void {
    if (this.amount === 0) return;
    this.gust *= Math.exp(-dt * 0.55);
    const perGroup = Math.ceil(this.amount / PETAL_IDS.length);
    const counts = new Array(PETAL_IDS.length).fill(0);
    const windBase = this.wind * 2.4;
    const gustX = this.gustDir.x * this.gust * 5.5;
    const gustZ = this.gustDir.y * this.gust * 5.5;

    for (let i = 0; i < this.amount; i++) {
      const p = this.petals[i];
      const flutter = Math.sin(time * 2.4 + p.phase);
      const flutter2 = Math.cos(time * 1.7 + p.phase * 1.3);

      p.vel.x += ((windBase + gustX) * 0.6 + flutter * 0.9 - p.vel.x) * Math.min(1, dt * 1.6);
      p.vel.z += ((windBase * 0.35 + gustZ) * 0.6 + flutter2 * 0.9 - p.vel.z) * Math.min(1, dt * 1.6);
      p.vel.y += (-1.35 + Math.abs(flutter) * 0.55 - p.vel.y) * Math.min(1, dt * 2.2);

      p.pos.addScaledVector(p.vel, dt);
      p.rot.x += p.spin.x * dt * (1 + this.gust);
      p.rot.y += p.spin.y * dt;
      p.rot.z += p.spin.z * dt * (1 + this.gust * 0.6);

      const ground = this.terrain.surfaceAt(p.pos.x, p.pos.z);
      const floor = ground === -999 ? -34 : ground + 0.6;
      if (p.pos.y <= floor || Math.abs(p.pos.x) > 78 || Math.abs(p.pos.z) > 78) {
        if (ground !== -999 && this.terrain.pondAt(p.pos.x, p.pos.z) > 0.35 && this.rng.chance(0.05)) {
          this.onWaterLand?.(p.pos.x, p.pos.z);
        }
        this.respawn(p);
      }

      const g = p.group;
      const idx = counts[g]++;
      if (idx >= MAX_PER_GROUP) continue;
      this.dummy.position.copy(p.pos);
      this.dummy.rotation.copy(p.rot);
      this.dummy.scale.set(p.scale, p.scale * 0.42, p.scale * 0.78);
      this.dummy.updateMatrix();
      this.meshes[g].setMatrixAt(idx, this.dummy.matrix);
    }

    for (let g = 0; g < this.meshes.length; g++) {
      this.meshes[g].count = Math.min(counts[g], perGroup, MAX_PER_GROUP);
      this.meshes[g].instanceMatrix.needsUpdate = true;
    }
  }

  /** Splash a burst of petals into the air (used by the bell / gust interaction). */
  burst(center: THREE.Vector3, count = 60): void {
    for (let i = 0; i < Math.min(count, this.amount); i++) {
      const p = this.petals[Math.floor(this.rng.next() * this.amount)];
      const a = this.rng.range(0, Math.PI * 2);
      p.pos.set(center.x + Math.cos(a) * this.rng.range(0, 6), center.y + this.rng.range(-2, 4), center.z + Math.sin(a) * this.rng.range(0, 6));
      p.vel.set(Math.cos(a) * this.rng.range(2, 6), this.rng.range(1.5, 4.5), Math.sin(a) * this.rng.range(2, 6));
    }
  }

  get pondLevel(): number {
    return LAYOUT.waterLevel;
  }

  dispose(): void {
    for (const g of this.geometries) g.dispose();
    for (const m of this.meshes) m.dispose();
  }
}
