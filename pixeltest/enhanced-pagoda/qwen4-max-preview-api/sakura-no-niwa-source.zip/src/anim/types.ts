import type * as THREE from 'three';

/** A small animated voxel prop that lives outside the merged static meshes. */
export interface Prop {
  readonly object: THREE.Object3D;
  update(dt: number, time: number): void;
  dispose(): void;
}
