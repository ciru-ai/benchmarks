import * as THREE from 'three';
import { P } from '../voxel/Palette';
import { propGeometry, type Cell } from '../voxel/PropKit';
import type { VoxelMaterials } from '../voxel/VoxelMaterials';
import type { Rng } from '../util/rng';

const COUNT = 5;

function bodyCells(): Cell[] {
  const c: Cell[] = [];
  for (let x = -2; x <= 2; x++) c.push([x, 0, 0, P.CRANE_W]);
  c.push([-3, 0, 0, P.CRANE_K], [-3, 1, 0, P.CRANE_K], [-2, 1, 0, P.CRANE_W]);
  c.push([3, 1, 0, P.CRANE_W], [4, 2, 0, P.CRANE_W], [5, 2, 0, P.CRANE_W]);
  c.push([6, 2, 0, P.CRANE_K], [5, 3, 0, P.CRANE_R]);
  c.push([-3, -1, 0, P.CRANE_K], [-4, -1, 0, P.CRANE_K]);
  return c;
}

function wingCells(sign: number): Cell[] {
  const c: Cell[] = [];
  for (let z = 1; z <= 4; z++) {
    for (let x = -1; x <= 1; x++) {
      c.push([x, 0, z * sign, z >= 4 ? P.CRANE_K : P.CRANE_W]);
    }
  }
  c.push([0, 0, 5 * sign, P.CRANE_K]);
  c.push([1, 0, 5 * sign, P.CRANE_K]);
  return c;
}

interface Crane {
  angle: number;
  radius: number;
  y: number;
  speed: number;
  flap: number;
  bob: number;
}

/** Tancho cranes wheeling over the garden, wings beating out of phase. */
export class Cranes {
  readonly group = new THREE.Group();
  private body: THREE.InstancedMesh;
  private wingL: THREE.InstancedMesh;
  private wingR: THREE.InstancedMesh;
  private geos: THREE.BufferGeometry[] = [];
  private items: Crane[] = [];
  private dummy = new THREE.Object3D();
  private mat = new THREE.Matrix4();
  private wingMat = new THREE.Matrix4();
  private rot = new THREE.Matrix4();
  private trans = new THREE.Matrix4();

  constructor(materials: VoxelMaterials, rng: Rng) {
    this.group.name = 'cranes';
    const bg = propGeometry(bodyCells(), true);
    const lg = propGeometry(wingCells(1), false);
    const rg = propGeometry(wingCells(-1), false);
    this.geos.push(bg, lg, rg);
    this.body = new THREE.InstancedMesh(bg, materials.solid, COUNT);
    this.wingL = new THREE.InstancedMesh(lg, materials.solid, COUNT);
    this.wingR = new THREE.InstancedMesh(rg, materials.solid, COUNT);
    for (const m of [this.body, this.wingL, this.wingR]) {
      m.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      m.frustumCulled = false;
      this.group.add(m);
    }
    for (let i = 0; i < COUNT; i++) {
      this.items.push({
        angle: (i / COUNT) * Math.PI * 2 + rng.range(-0.4, 0.4),
        radius: rng.range(58, 92),
        y: rng.range(42, 72),
        speed: rng.range(0.055, 0.095),
        flap: rng.range(0, 6.28),
        bob: rng.range(0, 6.28),
      });
    }
  }

  update(dt: number, time: number): void {
    this.items.forEach((c, i) => {
      c.angle += dt * c.speed;
      const x = Math.cos(c.angle) * c.radius;
      const z = Math.sin(c.angle) * c.radius;
      const y = c.y + Math.sin(time * 0.35 + c.bob) * 3.2;
      const heading = Math.atan2(-Math.cos(c.angle), -Math.sin(c.angle));
      const bank = Math.sin(time * 0.4 + c.bob) * 0.12;
      this.dummy.position.set(x, y, z);
      this.dummy.rotation.set(bank, heading, 0);
      this.dummy.scale.setScalar(0.42);
      this.dummy.updateMatrix();
      this.body.setMatrixAt(i, this.dummy.matrix);
      this.mat.copy(this.dummy.matrix);

      const flap = Math.sin(time * 3.1 + c.flap) * 0.62;
      this.trans.makeTranslation(0, 0.5, 1);
      this.rot.makeRotationX(-flap);
      this.wingMat.copy(this.mat).multiply(this.trans).multiply(this.rot);
      this.wingL.setMatrixAt(i, this.wingMat);

      this.trans.makeTranslation(0, 0.5, -1);
      this.rot.makeRotationX(flap);
      this.wingMat.copy(this.mat).multiply(this.trans).multiply(this.rot);
      this.wingR.setMatrixAt(i, this.wingMat);
    });
    this.body.instanceMatrix.needsUpdate = true;
    this.wingL.instanceMatrix.needsUpdate = true;
    this.wingR.instanceMatrix.needsUpdate = true;
  }

  dispose(): void {
    for (const g of this.geos) g.dispose();
    this.body.dispose();
    this.wingL.dispose();
    this.wingR.dispose();
  }
}
