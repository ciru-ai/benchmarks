import * as THREE from 'three';
import { cubeGeometry } from '../voxel/PropKit';
import { P } from '../voxel/Palette';
import type { Rng } from '../util/rng';

const PUFFS = 30;

/** Hearth smoke from the tea house chimney, thinning as it climbs. */
export class Smoke {
  readonly object: THREE.InstancedMesh;
  private geometry: THREE.BufferGeometry;
  private material: THREE.MeshStandardMaterial;
  private state: Float32Array;
  private dummy = new THREE.Object3D();
  private origin: THREE.Vector3;
  private rng: Rng;

  constructor(origin: THREE.Vector3, rng: Rng) {
    this.origin = origin.clone();
    this.rng = rng;
    this.geometry = cubeGeometry(P.CLOUD);
    this.material = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#cfd4dd'),
      transparent: true,
      opacity: 0.3,
      roughness: 1,
      depthWrite: false,
    });
    this.object = new THREE.InstancedMesh(this.geometry, this.material, PUFFS);
    this.object.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.object.frustumCulled = false;
    this.object.name = 'smoke';
    this.state = new Float32Array(PUFFS * 4);
    for (let i = 0; i < PUFFS; i++) {
      const o = i * 4;
      this.state[o] = rng.range(0, 1);
      this.state[o + 1] = rng.range(-0.6, 0.6);
      this.state[o + 2] = rng.range(-0.6, 0.6);
      this.state[o + 3] = rng.range(0.7, 1.5);
    }
  }

  update(dt: number, time: number, wind: number): void {
    for (let i = 0; i < PUFFS; i++) {
      const o = i * 4;
      this.state[o] += dt * 0.11 * this.state[o + 3];
      if (this.state[o] > 1) {
        this.state[o] = 0;
        this.state[o + 1] = this.rng.range(-0.6, 0.6);
        this.state[o + 2] = this.rng.range(-0.6, 0.6);
      }
      const life = this.state[o];
      const rise = life * 22;
      const drift = life * life * (6 + wind * 16);
      const scale = (0.7 + life * 3.4) * (life > 0.82 ? (1 - life) / 0.18 : 1);
      this.dummy.position.set(
        this.origin.x + this.state[o + 1] * (1 + life * 3) + drift + Math.sin(time * 0.7 + i) * life * 1.6,
        this.origin.y + rise,
        this.origin.z + this.state[o + 2] * (1 + life * 3) + Math.cos(time * 0.6 + i) * life * 1.6,
      );
      this.dummy.rotation.set(life * 1.4, life * 2 + i, 0);
      this.dummy.scale.setScalar(Math.max(0.02, scale));
      this.dummy.updateMatrix();
      this.object.setMatrixAt(i, this.dummy.matrix);
    }
    this.object.instanceMatrix.needsUpdate = true;
  }

  dispose(): void {
    this.geometry.dispose();
    this.material.dispose();
    this.object.dispose();
  }
}
