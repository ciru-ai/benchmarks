import * as THREE from 'three';
import { P } from '../voxel/Palette';
import { propGeometry, type Cell } from '../voxel/PropKit';
import type { VoxelMaterials } from '../voxel/VoxelMaterials';
import type { Rng } from '../util/rng';
import { LAYOUT } from '../world/Layout';

const MAX_KOI = 30;

function koiCells(body: number, patch: number, fin: number): Cell[] {
  const cells: Cell[] = [];
  // head at +X, tail at -X
  for (let x = -3; x <= 3; x++) {
    const w = x >= 2 ? 0 : x <= -2 ? 0 : 1;
    for (let z = -w; z <= w; z++) {
      for (let y = 0; y <= (w === 1 ? 1 : 0); y++) {
        const isPatch = (x === 1 || x === -1) && y === 1;
        cells.push([x, y, z, isPatch ? patch : body]);
      }
    }
  }
  cells.push([3, 0, 0, body]);
  cells.push([-4, 0, 0, fin], [-4, 1, 0, fin], [-4, 0, 1, fin], [-4, 0, -1, fin]);
  cells.push([1, 0, 2, fin], [1, 0, -2, fin]);
  cells.push([2, 1, 0, P.KOI_INK]);
  return cells;
}

interface Fish {
  cx: number;
  cz: number;
  rx: number;
  rz: number;
  speed: number;
  phase: number;
  depth: number;
  variant: number;
  startle: number;
}

/** Nishikigoi brocade carp circling the pond just under the surface. */
export class Koi {
  readonly group = new THREE.Group();
  private meshes: THREE.InstancedMesh[] = [];
  private geometries: THREE.BufferGeometry[] = [];
  private fish: Fish[] = [];
  private dummy = new THREE.Object3D();
  private count = 12;

  constructor(materials: VoxelMaterials, rng: Rng) {
    this.group.name = 'koi';
    const variants: Cell[][] = [
      koiCells(P.KOI_ORANGE, P.KOI_WHITE, P.KOI_WHITE),
      koiCells(P.KOI_WHITE, P.KOI_RED, P.KOI_WHITE),
      koiCells(P.KOI_GOLD, P.KOI_WHITE, P.KOI_ORANGE),
      koiCells(P.KOI_INK, P.KOI_WHITE, P.KOI_RED),
    ];
    for (const cells of variants) {
      const geo = propGeometry(cells, true);
      this.geometries.push(geo);
      const mesh = new THREE.InstancedMesh(geo, materials.solid, MAX_KOI);
      mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      mesh.frustumCulled = false;
      mesh.count = 0;
      this.meshes.push(mesh);
      this.group.add(mesh);
    }

    const pond = LAYOUT.pond;
    for (let i = 0; i < MAX_KOI; i++) {
      const a = rng.range(0, Math.PI * 2);
      const d = Math.sqrt(rng.next()) * 0.55;
      this.fish.push({
        cx: pond.cx + Math.cos(a) * pond.rx * d,
        cz: pond.cz + Math.sin(a) * pond.rz * d,
        rx: rng.range(3.5, 8.5),
        rz: rng.range(3, 7),
        speed: rng.range(0.16, 0.34) * (rng.chance(0.5) ? 1 : -1),
        phase: rng.range(0, Math.PI * 2),
        depth: rng.range(0.25, 1.0),
        variant: i % variants.length,
        startle: 0,
      });
    }
  }

  setCount(n: number): void {
    this.count = Math.max(0, Math.min(MAX_KOI, Math.round(n)));
  }

  /** Scatter the shoal away from a point (pond tap). */
  startle(x: number, z: number): void {
    for (const f of this.fish) {
      const d = Math.hypot(f.cx - x, f.cz - z);
      if (d < 16) f.startle = 1;
    }
  }

  update(dt: number, time: number): void {
    const counts = new Array(this.meshes.length).fill(0);
    const wl = LAYOUT.waterLevel;
    for (let i = 0; i < this.count; i++) {
      const f = this.fish[i];
      f.startle = Math.max(0, f.startle - dt * 0.5);
      f.phase += dt * f.speed * (1 + f.startle * 2.4);
      const x = f.cx + Math.cos(f.phase) * f.rx;
      const z = f.cz + Math.sin(f.phase) * f.rz;
      const vx = -Math.sin(f.phase) * f.rx * Math.sign(f.speed);
      const vz = Math.cos(f.phase) * f.rz * Math.sign(f.speed);
      const y = wl + 0.35 - f.depth + Math.sin(time * 0.8 + f.phase * 2) * 0.22;

      this.dummy.position.set(x, y, z);
      this.dummy.rotation.set(0, Math.atan2(-vz, vx), Math.sin(time * 5.5 + f.phase * 3) * 0.13);
      const s = 0.78 + (i % 3) * 0.1;
      this.dummy.scale.set(s, s * 0.8, s);
      this.dummy.updateMatrix();
      const idx = counts[f.variant]++;
      this.meshes[f.variant].setMatrixAt(idx, this.dummy.matrix);
    }
    this.meshes.forEach((m, i) => {
      m.count = counts[i];
      m.instanceMatrix.needsUpdate = true;
    });
  }

  dispose(): void {
    for (const g of this.geometries) g.dispose();
    for (const m of this.meshes) m.dispose();
  }
}
