import * as THREE from 'three';
import { clamp01, lerp, smoothstep, TAU } from '../util/math';

interface SkyStop {
  h: number;
  zenith: string;
  horizon: string;
  ground: string;
  sun: string;
  sunI: number;
  hemiI: number;
  ambI: number;
}

const STOPS: SkyStop[] = [
  { h: 0, zenith: '#070c1e', horizon: '#141d3a', ground: '#0b1020', sun: '#a8bcff', sunI: 0.34, hemiI: 0.26, ambI: 0.14 },
  { h: 4.5, zenith: '#141f47', horizon: '#3d3663', ground: '#1a2036', sun: '#b9c4ff', sunI: 0.36, hemiI: 0.32, ambI: 0.16 },
  { h: 6.0, zenith: '#3c5a92', horizon: '#e28a5e', ground: '#4a4a55', sun: '#ff9d5c', sunI: 1.25, hemiI: 0.6, ambI: 0.22 },
  { h: 7.5, zenith: '#4f86c8', horizon: '#ffc79a', ground: '#7d8894', sun: '#ffd0a0', sunI: 2.2, hemiI: 0.85, ambI: 0.26 },
  { h: 10, zenith: '#3f86d6', horizon: '#cfe9f7', ground: '#93a7b3', sun: '#fff3dc', sunI: 2.95, hemiI: 1.0, ambI: 0.3 },
  { h: 13, zenith: '#3579cf', horizon: '#d7ecfa', ground: '#9db0bb', sun: '#fff8ec', sunI: 3.15, hemiI: 1.05, ambI: 0.32 },
  { h: 16, zenith: '#4a80c4', horizon: '#ffdfb8', ground: '#96a2a8', sun: '#ffe6bd', sunI: 2.6, hemiI: 0.92, ambI: 0.28 },
  { h: 18, zenith: '#35406f', horizon: '#ff8a5c', ground: '#5c5560', sun: '#ff8347', sunI: 1.6, hemiI: 0.62, ambI: 0.24 },
  { h: 19.5, zenith: '#1b2246', horizon: '#7c4a74', ground: '#2c2c40', sun: '#ff6a5a', sunI: 0.6, hemiI: 0.38, ambI: 0.19 },
  { h: 21, zenith: '#0a1028', horizon: '#1e2649', ground: '#101528', sun: '#a8bcff', sunI: 0.36, hemiI: 0.28, ambI: 0.15 },
  { h: 24, zenith: '#070c1e', horizon: '#141d3a', ground: '#0b1020', sun: '#a8bcff', sunI: 0.34, hemiI: 0.26, ambI: 0.14 },
];

export interface LanternAnchor {
  position: THREE.Vector3;
  color: THREE.Color;
  power: number;
}

/** Sun / moon rig, hemisphere fill, rim light and the garden's lantern fires. */
export class Lighting {
  readonly sun: THREE.DirectionalLight;
  readonly rim: THREE.DirectionalLight;
  readonly hemi: THREE.HemisphereLight;
  readonly ambient: THREE.AmbientLight;
  readonly group = new THREE.Group();
  readonly sunDir = new THREE.Vector3(0.5, 0.7, 0.3);
  readonly horizonColor = new THREE.Color('#cfe9f7');
  readonly zenithColor = new THREE.Color('#3f86d6');
  readonly groundColor = new THREE.Color('#93a7b3');
  readonly sunColor = new THREE.Color('#fff3dc');

  dayFactor = 1;
  nightFactor = 0;
  hour = 8.2;
  azimuth = 24;
  lanternsLit = true;
  glowStrength = 1;

  private lanterns: { light: THREE.PointLight; anchor: LanternAnchor; phase: number }[] = [];
  private shadowDirty = true;
  private tmpA = new THREE.Color();
  private tmpB = new THREE.Color();

  constructor(shadowMapSize: number) {
    this.sun = new THREE.DirectionalLight(0xfff3dc, 3);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(shadowMapSize, shadowMapSize);
    const cam = this.sun.shadow.camera;
    cam.left = -112;
    cam.right = 112;
    cam.top = 118;
    cam.bottom = -112;
    cam.near = 1;
    cam.far = 520;
    cam.updateProjectionMatrix();
    this.sun.shadow.bias = -0.0004;
    this.sun.shadow.normalBias = 0.6;
    this.sun.target.position.set(0, 12, 0);

    this.rim = new THREE.DirectionalLight(0x9fc4ff, 0.55);
    this.rim.position.set(-70, 45, -90);

    this.hemi = new THREE.HemisphereLight(0xcfe9f7, 0x4a5a3c, 1);
    this.ambient = new THREE.AmbientLight(0xffffff, 0.3);

    this.group.add(this.sun, this.sun.target, this.rim, this.hemi, this.ambient);
    this.group.name = 'lighting';
  }

  setShadowMapSize(size: number): void {
    if (this.sun.shadow.mapSize.x === size) return;
    this.sun.shadow.mapSize.set(size, size);
    this.sun.shadow.map?.dispose();
    this.sun.shadow.map = null as unknown as THREE.WebGLRenderTarget;
    this.shadowDirty = true;
  }

  setLanternAnchors(anchors: LanternAnchor[]): void {
    for (const l of this.lanterns) {
      this.group.remove(l.light);
      l.light.dispose();
    }
    this.lanterns = [];
    // Only the strongest few lanterns get real point lights; the rest are emissive + bloom.
    const chosen = anchors.slice(0, 6);
    chosen.forEach((anchor, i) => {
      const light = new THREE.PointLight(anchor.color, 0, 40, 2);
      light.position.copy(anchor.position);
      light.castShadow = false;
      this.group.add(light);
      this.lanterns.push({ light, anchor, phase: i * 1.7 });
    });
  }

  /** Recompute the whole celestial state from the hour dial. */
  setTime(hour: number, azimuthDeg: number): void {
    this.hour = hour;
    this.azimuth = azimuthDeg;
    const h = ((hour % 24) + 24) % 24;

    let a = STOPS[0];
    let b = STOPS[STOPS.length - 1];
    for (let i = 0; i < STOPS.length - 1; i++) {
      if (h >= STOPS[i].h && h <= STOPS[i + 1].h) {
        a = STOPS[i];
        b = STOPS[i + 1];
        break;
      }
    }
    const t = b.h === a.h ? 0 : (h - a.h) / (b.h - a.h);
    const mix = (ka: string, kb: string, out: THREE.Color): THREE.Color => {
      this.tmpA.set(ka);
      this.tmpB.set(kb);
      return out.copy(this.tmpA).lerp(this.tmpB, t);
    };
    mix(a.zenith, b.zenith, this.zenithColor);
    mix(a.horizon, b.horizon, this.horizonColor);
    mix(a.ground, b.ground, this.groundColor);
    mix(a.sun, b.sun, this.sunColor);

    const sunI = lerp(a.sunI, b.sunI, t);
    const hemiI = lerp(a.hemiI, b.hemiI, t);
    const ambI = lerp(a.ambI, b.ambI, t);

    const elev = Math.sin(((h - 6) / 12) * Math.PI);
    this.dayFactor = smoothstep(-0.06, 0.16, elev);
    this.nightFactor = 1 - this.dayFactor;

    const elevAngle = elev * (Math.PI * 0.46);
    const az = ((h - 6) / 12) * Math.PI - Math.PI / 2 + (azimuthDeg * Math.PI) / 180;
    this.sunDir.set(Math.cos(elevAngle) * Math.sin(az), Math.sin(elevAngle), Math.cos(elevAngle) * Math.cos(az)).normalize();

    const active = this.dayFactor > 0.02 ? this.sunDir : this.sunDir.clone().negate();
    this.sun.position.copy(active).multiplyScalar(210).add(new THREE.Vector3(0, 12, 0));
    this.sun.color.copy(this.sunColor);
    this.sun.intensity = lerp(0.42, sunI, this.dayFactor);

    this.rim.position.set(-this.sunDir.x * 120, 60 + this.dayFactor * 30, -this.sunDir.z * 120);
    this.rim.color.set(this.nightFactor > 0.5 ? '#6f86d8' : '#bcd8ff');
    this.rim.intensity = lerp(0.42, 0.62, this.dayFactor);

    this.hemi.color.copy(this.zenithColor).lerp(this.horizonColor, 0.5);
    this.hemi.groundColor.copy(this.groundColor).multiplyScalar(0.7);
    this.hemi.intensity = hemiI;
    this.ambient.intensity = ambI;
    this.ambient.color.copy(this.horizonColor).lerp(new THREE.Color('#ffffff'), 0.55);

    this.shadowDirty = true;
  }

  /** Emissive multiplier for lantern / shoji voxels. */
  get glowLevel(): number {
    const base = lerp(0.22, 2.9, this.nightFactor);
    return (this.lanternsLit ? base : 0.12) * this.glowStrength;
  }

  update(time: number): void {
    const night = this.nightFactor;
    for (const l of this.lanterns) {
      const flicker = 0.88 + 0.09 * Math.sin(time * 6.3 + l.phase) + 0.05 * Math.sin(time * 11.7 + l.phase * 2.1);
      l.light.intensity = (this.lanternsLit ? 1 : 0) * l.anchor.power * lerp(2, 52, night) * flicker;
    }
  }

  /** Shadows are static: only re-render the map when the sun or geometry moved. */
  consumeShadowDirty(): boolean {
    const dirty = this.shadowDirty;
    this.shadowDirty = false;
    return dirty;
  }

  markShadowDirty(): void {
    this.shadowDirty = true;
  }

  /** Screen-space position of the sun for the shaft pass. */
  sunScreenPosition(camera: THREE.Camera, out: THREE.Vector2): number {
    const p = this.sunDir.clone().multiplyScalar(600).project(camera);
    out.set(p.x * 0.5 + 0.5, p.y * 0.5 + 0.5);
    const behind = this.sunDir.clone().applyQuaternion(camera.quaternion.clone().invert()).z > 0;
    return behind ? 0 : clamp01(1 - Math.max(Math.abs(p.x), Math.abs(p.y)) * 0.35);
  }

  static hourLabel(hour: number): string {
    const h = ((hour % 24) + 24) % 24;
    const hh = Math.floor(h);
    const mm = Math.floor((h - hh) * 60);
    return `${hh.toString().padStart(2, '0')}:${mm.toString().padStart(2, '0')}`;
  }

  static phaseLabel(hour: number): string {
    const h = ((hour % 24) + 24) % 24;
    if (h < 4.5) return 'Deep night';
    if (h < 6.3) return 'First light';
    if (h < 8.5) return 'Golden dawn';
    if (h < 11) return 'Morning';
    if (h < 14.5) return 'High noon';
    if (h < 16.8) return 'Afternoon';
    if (h < 18.6) return 'Golden hour';
    if (h < 20) return 'Twilight';
    return 'Lantern night';
  }

  static readonly TAU = TAU;
}
