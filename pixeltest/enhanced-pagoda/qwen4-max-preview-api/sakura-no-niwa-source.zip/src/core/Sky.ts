import * as THREE from 'three';

/** Painted sky dome: horizon gradient, sun/moon discs, twinkling stars. */
export class Sky {
  readonly mesh: THREE.Mesh;
  readonly material: THREE.ShaderMaterial;
  private envScene: THREE.Scene;
  private pmrem: THREE.PMREMGenerator | null = null;
  private envTarget: THREE.WebGLRenderTarget | null = null;

  readonly uniforms = {
    uSunDir: { value: new THREE.Vector3(0.4, 0.6, 0.3) },
    uZenith: { value: new THREE.Color('#3f86d6') },
    uHorizon: { value: new THREE.Color('#cfe9f7') },
    uGround: { value: new THREE.Color('#8fa2ad') },
    uSunColor: { value: new THREE.Color('#fff0cf') },
    uNight: { value: 0 },
    uTime: { value: 0 },
    uSeasonTint: { value: new THREE.Color('#ffd9e6') },
  };

  constructor() {
    this.material = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      toneMapped: true,
      vertexShader: /* glsl */ `
        varying vec3 vDir;
        void main() {
          vDir = position;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: /* glsl */ `
        precision highp float;
        uniform vec3 uSunDir;
        uniform vec3 uZenith;
        uniform vec3 uHorizon;
        uniform vec3 uGround;
        uniform vec3 uSunColor;
        uniform vec3 uSeasonTint;
        uniform float uNight;
        uniform float uTime;
        varying vec3 vDir;

        float hash21(vec2 p) {
          p = fract(p * vec2(233.34, 851.73));
          p += dot(p, p + 23.45);
          return fract(p.x * p.y);
        }

        float vnoise(vec2 p) {
          vec2 i = floor(p);
          vec2 f = fract(p);
          f = f * f * (3.0 - 2.0 * f);
          float a = hash21(i);
          float b = hash21(i + vec2(1.0, 0.0));
          float c = hash21(i + vec2(0.0, 1.0));
          float d = hash21(i + vec2(1.0, 1.0));
          return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
        }

        float fbm(vec2 p) {
          float v = 0.0;
          float a = 0.5;
          for (int i = 0; i < 4; i++) {
            v += vnoise(p) * a;
            p *= 2.07;
            a *= 0.5;
          }
          return v;
        }

        void main() {
          vec3 dir = normalize(vDir);
          float h = dir.y;
          float t = pow(clamp(h, 0.0, 1.0), 0.48);
          vec3 col = mix(uHorizon, uZenith, t);
          col = mix(col, uSeasonTint * 0.55 + col * 0.45, exp(-abs(h) * 9.0) * 0.3);
          col = mix(col, uGround, smoothstep(0.0, -0.17, h));
          col *= 1.0 - smoothstep(-0.12, -0.75, h) * 0.28;

          // drifting cirrus bands give the void some weather
          vec2 skyUv = vec2(atan(dir.z, dir.x) * 1.6, dir.y * 3.4);
          float drift = uTime * 0.006;
          float band = fbm(skyUv * vec2(1.4, 2.6) + vec2(drift, drift * 0.3));
          float band2 = fbm(skyUv * vec2(3.1, 5.2) - vec2(drift * 1.7, 0.0));
          float clouds = smoothstep(0.52, 0.86, band * 0.7 + band2 * 0.4);
          float horizonMask = exp(-abs(h - 0.06) * 5.5) + exp(-abs(h + 0.22) * 7.0) * 0.6;
          vec3 cloudCol = mix(uHorizon * 1.05, uSunColor, 0.35) * (1.0 - uNight * 0.72);
          col = mix(col, cloudCol, clouds * horizonMask * 0.5);

          float sd = max(dot(dir, uSunDir), 0.0);
          float disc = smoothstep(0.99880, 0.99945, sd);
          float halo = pow(sd, 260.0) * 0.85 + pow(sd, 14.0) * 0.20 + pow(sd, 3.0) * 0.05;
          col += uSunColor * (halo + disc * 9.0) * (1.0 - uNight * 0.92);

          float md = max(dot(dir, -uSunDir), 0.0);
          float moon = smoothstep(0.99905, 0.99950, md);
          float moonGlow = pow(md, 700.0) * 0.5 + pow(md, 40.0) * 0.05;
          col += vec3(0.85, 0.9, 1.0) * (moon * 2.6 + moonGlow) * uNight;

          if (uNight > 0.01 && h > -0.06) {
            vec2 sph = vec2(atan(dir.z, dir.x) * 0.15915 + 0.5, asin(clamp(dir.y, -1.0, 1.0)) * 0.31831 + 0.5);
            vec2 g = sph * vec2(420.0, 210.0);
            vec2 cell = floor(g);
            vec2 f = fract(g);
            float r = hash21(cell);
            float star = 0.0;
            if (r > 0.982) {
              vec2 sp = vec2(hash21(cell + 3.1), hash21(cell + 7.7));
              float d = length(f - sp);
              float tw = 0.55 + 0.45 * sin(uTime * 2.3 + r * 120.0);
              star = smoothstep(0.17, 0.0, d) * tw * ((r - 0.982) / 0.018);
            }
            col += vec3(0.92, 0.96, 1.0) * star * uNight * 1.7 * smoothstep(-0.04, 0.2, h);
          }

          gl_FragColor = vec4(col, 1.0);
        }
      `,
    });

    const geo = new THREE.SphereGeometry(900, 48, 32);
    this.mesh = new THREE.Mesh(geo, this.material);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = -1000;
    this.mesh.name = 'sky-dome';

    this.envScene = new THREE.Scene();
    this.envScene.add(new THREE.Mesh(geo, this.material));
  }

  update(time: number): void {
    this.uniforms.uTime.value = time;
  }

  /** Bake the current sky into a PMREM environment (called on light changes only). */
  bakeEnvironment(renderer: THREE.WebGLRenderer): THREE.Texture {
    if (!this.pmrem) {
      this.pmrem = new THREE.PMREMGenerator(renderer);
      this.pmrem.compileEquirectangularShader();
    }
    const next = this.pmrem.fromScene(this.envScene, 0, 1, 1400);
    if (this.envTarget) this.envTarget.dispose();
    this.envTarget = next;
    return next.texture;
  }

  dispose(): void {
    this.mesh.geometry.dispose();
    this.material.dispose();
    this.envTarget?.dispose();
    this.pmrem?.dispose();
  }
}
