import * as THREE from 'three';
import { PostFX } from './PostFX';
import { QUALITY_PRESETS, type QualityLevel, type SettingsStore } from './Settings';

export type FrameCallback = (dt: number, time: number) => void;

export interface EngineStats {
  fps: number;
  frameMs: number;
  drawCalls: number;
  triangles: number;
  programs: number;
}

/**
 * Renderer + single requestAnimationFrame loop.
 * Everything else registers a frame callback; nobody else owns a loop.
 */
export class Engine {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly post: PostFX;
  readonly stats: EngineStats = { fps: 0, frameMs: 0, drawCalls: 0, triangles: 0, programs: 0 };

  private container: HTMLElement;
  private callbacks: FrameCallback[] = [];
  private clock = new THREE.Timer();
  private raf = 0;
  private running = false;
  private time = 0;
  private paused = false;
  private fpsAccum = 0;
  private fpsFrames = 0;
  private quality: QualityLevel;
  private resizeObserver: ResizeObserver;
  private onResizeCbs: ((w: number, h: number) => void)[] = [];
  private width = 1;
  private height = 1;
  private contextLost = false;

  constructor(container: HTMLElement, camera: THREE.Camera, settings: SettingsStore) {
    this.container = container;
    this.quality = settings.get('quality');
    const preset = QUALITY_PRESETS[this.quality];

    this.renderer = new THREE.WebGLRenderer({
      antialias: false,
      powerPreference: 'high-performance',
      stencil: false,
      alpha: false,
      preserveDrawingBuffer: true,
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, preset.pixelRatio));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = settings.get('exposure');
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.shadowMap.autoUpdate = false;
    this.renderer.info.autoReset = false;
    this.renderer.domElement.classList.add('scene-canvas');
    this.renderer.domElement.setAttribute('aria-label', 'Voxel pagoda garden, interactive 3D scene');
    this.renderer.domElement.tabIndex = 0;
    container.appendChild(this.renderer.domElement);

    this.post = new PostFX(this.renderer, this.scene, camera, this.quality);

    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(container);
    this.resize();

    this.renderer.domElement.addEventListener('webglcontextlost', this.handleContextLost);
    this.renderer.domElement.addEventListener('webglcontextrestored', this.handleContextRestored);
  }

  private handleContextLost = (event: Event): void => {
    event.preventDefault();
    this.contextLost = true;
    this.container.dispatchEvent(new CustomEvent('scene-context-lost'));
  };

  private handleContextRestored = (): void => {
    this.contextLost = false;
    this.renderer.shadowMap.needsUpdate = true;
    this.container.dispatchEvent(new CustomEvent('scene-context-restored'));
  };

  setCamera(camera: THREE.Camera): void {
    this.post.setCamera(camera);
  }

  onFrame(cb: FrameCallback): () => void {
    this.callbacks.push(cb);
    return () => {
      const i = this.callbacks.indexOf(cb);
      if (i >= 0) this.callbacks.splice(i, 1);
    };
  }

  onResize(cb: (w: number, h: number) => void): () => void {
    this.onResizeCbs.push(cb);
    cb(this.width, this.height);
    return () => {
      const i = this.onResizeCbs.indexOf(cb);
      if (i >= 0) this.onResizeCbs.splice(i, 1);
    };
  }

  setQuality(quality: QualityLevel): void {
    this.quality = quality;
    const preset = QUALITY_PRESETS[quality];
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, preset.pixelRatio));
    this.post.setQuality(quality);
    this.renderer.shadowMap.needsUpdate = true;
    this.resize();
  }

  setExposure(value: number): void {
    this.renderer.toneMappingExposure = value;
  }

  setPaused(paused: boolean): void {
    this.paused = paused;
  }

  get elapsed(): number {
    return this.time;
  }

  get size(): { width: number; height: number } {
    return { width: this.width, height: this.height };
  }

  resize(): void {
    const rect = this.container.getBoundingClientRect();
    const width = Math.max(1, Math.floor(rect.width));
    const height = Math.max(1, Math.floor(rect.height));
    if (width === this.width && height === this.height) return;
    this.width = width;
    this.height = height;
    this.renderer.setSize(width, height, false);
    const pr = Math.min(window.devicePixelRatio || 1, QUALITY_PRESETS[this.quality].pixelRatio);
    this.renderer.setPixelRatio(pr);
    this.post.resize(width, height, pr);
    for (const cb of this.onResizeCbs) cb(width, height);
  }

  start(): void {
    if (this.running) return;
    this.running = true;
    this.clock.connect(document);
    const tick = (): void => {
      this.raf = requestAnimationFrame(tick);
      this.clock.update();
      const raw = this.clock.getDelta();
      const dt = Math.min(raw, 0.1);
      if (!this.paused) this.time += dt;

      const t0 = performance.now();
      for (const cb of this.callbacks) cb(this.paused ? 0 : dt, this.time);
      if (!this.contextLost) {
        this.renderer.info.reset();
        this.post.render(dt);
      }
      const frameMs = performance.now() - t0;

      this.fpsAccum += raw;
      this.fpsFrames++;
      if (this.fpsAccum >= 0.4) {
        this.stats.fps = this.fpsFrames / this.fpsAccum;
        this.stats.frameMs = frameMs;
        this.stats.drawCalls = this.renderer.info.render.calls;
        this.stats.triangles = this.renderer.info.render.triangles;
        this.stats.programs = this.renderer.info.programs?.length ?? 0;
        this.fpsAccum = 0;
        this.fpsFrames = 0;
      }
    };
    this.raf = requestAnimationFrame(tick);
  }

  stop(): void {
    this.running = false;
    cancelAnimationFrame(this.raf);
  }

  /** Render one frame immediately (used after rebuilds while paused). */
  renderOnce(): void {
    this.post.render(0);
  }

  dispose(): void {
    this.stop();
    this.resizeObserver.disconnect();
    this.renderer.domElement.removeEventListener('webglcontextlost', this.handleContextLost);
    this.renderer.domElement.removeEventListener('webglcontextrestored', this.handleContextRestored);
    this.post.dispose();
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }
}
