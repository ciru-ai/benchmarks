import type { SeasonId } from '../voxel/Palette';

export type QualityLevel = 'low' | 'medium' | 'high' | 'ultra';

export interface Settings {
  // world (rebuild)
  seed: string;
  pagodaTiers: number;
  treeDensity: number;
  blossomDensity: number;
  gardenDetail: number;
  // season & sky (live)
  season: SeasonId;
  hour: number;
  sunAzimuth: number;
  fogDensity: number;
  exposure: number;
  // life (live)
  petalAmount: number;
  windSpeed: number;
  koiCount: number;
  waveHeight: number;
  waterOpacity: number;
  clouds: boolean;
  cranes: boolean;
  fireflies: boolean;
  lanternsLit: boolean;
  // look (live)
  bloom: number;
  sunShafts: number;
  tiltShift: number;
  grain: number;
  vignette: number;
  aoStrength: number;
  edgeLines: number;
  glowStrength: number;
  wireframe: boolean;
  showGrid: boolean;
  // camera (live)
  autoRotate: boolean;
  rotateSpeed: number;
  fov: number;
  // system
  quality: QualityLevel;
  audio: boolean;
  audioVolume: number;
  paused: boolean;
}

export const DEFAULTS: Settings = {
  seed: 'sakura-niwa-108',
  pagodaTiers: 5,
  treeDensity: 1,
  blossomDensity: 1,
  gardenDetail: 1,

  season: 'spring',
  hour: 8.2,
  sunAzimuth: 24,
  fogDensity: 0.0009,
  exposure: 1.05,

  petalAmount: 900,
  windSpeed: 0.55,
  koiCount: 12,
  waveHeight: 0.17,
  waterOpacity: 0.74,
  clouds: true,
  cranes: true,
  fireflies: true,
  lanternsLit: true,

  bloom: 0.62,
  sunShafts: 0.5,
  tiltShift: 0.3,
  grain: 0.35,
  vignette: 0.42,
  aoStrength: 1,
  edgeLines: 0.5,
  glowStrength: 1,
  wireframe: false,
  showGrid: false,

  autoRotate: true,
  rotateSpeed: 0.32,
  fov: 42,

  quality: 'high',
  audio: true,
  audioVolume: 0.55,
  paused: false,
};

/** Keys that require the voxel world to be regenerated. */
export const REBUILD_KEYS: (keyof Settings)[] = ['seed', 'pagodaTiers', 'treeDensity', 'blossomDensity', 'gardenDetail'];

type Listener<K extends keyof Settings> = (value: Settings[K], key: K) => void;

export class SettingsStore {
  readonly values: Settings;
  private listeners = new Map<keyof Settings, Set<Listener<never>>>();
  private anyListeners = new Set<(key: keyof Settings, value: unknown) => void>();

  constructor(initial: Partial<Settings> = {}) {
    this.values = { ...DEFAULTS, ...initial };
  }

  get<K extends keyof Settings>(key: K): Settings[K] {
    return this.values[key];
  }

  set<K extends keyof Settings>(key: K, value: Settings[K], silent = false): void {
    if (this.values[key] === value) return;
    this.values[key] = value;
    if (silent) return;
    const set = this.listeners.get(key);
    if (set) for (const fn of set) (fn as Listener<K>)(value, key);
    for (const fn of this.anyListeners) fn(key, value);
  }

  patch(values: Partial<Settings>): void {
    for (const [k, v] of Object.entries(values)) {
      this.set(k as keyof Settings, v as never);
    }
  }

  on<K extends keyof Settings>(key: K, fn: Listener<K>): () => void {
    let set = this.listeners.get(key);
    if (!set) {
      set = new Set();
      this.listeners.set(key, set);
    }
    set.add(fn as Listener<never>);
    return () => set!.delete(fn as Listener<never>);
  }

  onAny(fn: (key: keyof Settings, value: unknown) => void): () => void {
    this.anyListeners.add(fn);
    return () => this.anyListeners.delete(fn);
  }

  reset(keep: (keyof Settings)[] = ['quality', 'audio', 'audioVolume']): void {
    const kept = Object.fromEntries(keep.map((k) => [k, this.values[k]])) as Partial<Settings>;
    this.patch({ ...DEFAULTS, ...kept });
  }
}

export const QUALITY_PRESETS: Record<QualityLevel, { pixelRatio: number; shadowMap: number; samples: number; bloomRes: number; shaftTaps: number }> = {
  low: { pixelRatio: 1, shadowMap: 1024, samples: 0, bloomRes: 0.5, shaftTaps: 8 },
  medium: { pixelRatio: 1.25, shadowMap: 1536, samples: 2, bloomRes: 0.6, shaftTaps: 12 },
  high: { pixelRatio: 1.6, shadowMap: 2048, samples: 4, bloomRes: 0.75, shaftTaps: 18 },
  ultra: { pixelRatio: 2, shadowMap: 3072, samples: 4, bloomRes: 1, shaftTaps: 26 },
};
