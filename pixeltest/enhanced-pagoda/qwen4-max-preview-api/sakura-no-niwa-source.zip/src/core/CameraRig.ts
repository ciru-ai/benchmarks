import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { clamp01, easeInOutCubic } from '../util/math';

export interface CameraPreset {
  id: string;
  label: string;
  jp: string;
  position: [number, number, number];
  target: [number, number, number];
}

export const CAMERA_PRESETS: CameraPreset[] = [
  { id: 'vista', label: 'Grand Vista', jp: '全景', position: [-150, 96, 168], target: [-8, 26, 4] },
  { id: 'pagoda', label: 'Pagoda', jp: '塔', position: [64, 76, 98], target: [-6, 46, -12] },
  { id: 'bridge', label: 'Drum Bridge', jp: '橋', position: [-8, 50, 78], target: [-21, 5, 21] },
  { id: 'pond', label: 'Koi Pond', jp: '池', position: [-32, 64, 70], target: [-30, 3, 21] },
  { id: 'zen', label: 'Dry Garden', jp: '枯山水', position: [80, 80, 24], target: [32, 8, -16] },
  { id: 'gate', label: 'Torii Approach', jp: '鳥居', position: [46, 58, 106], target: [16, 12, 40] },
  { id: 'tea', label: 'Tea House', jp: '茶室', position: [82, 68, 76], target: [33, 10, 26] },
  { id: 'aerial', label: 'Aerial Plan', jp: '鳥瞰', position: [6, 158, 44], target: [0, 6, 0] },
  { id: 'roots', label: 'Floating Roots', jp: '浮島', position: [96, -26, 96], target: [0, -8, 0] },
];

/** Damped orbit rig with cinematic tweens between named viewpoints. */
export class CameraRig {
  readonly camera: THREE.PerspectiveCamera;
  readonly controls: OrbitControls;
  private tween: {
    fromPos: THREE.Vector3;
    toPos: THREE.Vector3;
    fromTarget: THREE.Vector3;
    toTarget: THREE.Vector3;
    t: number;
    duration: number;
    onDone?: () => void;
  } | null = null;
  private shake = 0;
  private shakeSeed = Math.random() * 100;
  private baseFov: number;
  private biasX = 0;
  private biasY = 0;
  private viewW = 1;
  private viewH = 1;
  private framingScale = 1;

  constructor(domElement: HTMLElement, aspect: number, fov = 42) {
    this.baseFov = fov;
    this.camera = new THREE.PerspectiveCamera(fov, aspect, 0.6, 2600);
    this.camera.position.set(205, 132, 232);
    this.controls = new OrbitControls(this.camera, domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.055;
    this.controls.rotateSpeed = 0.62;
    this.controls.zoomSpeed = 0.85;
    this.controls.panSpeed = 0.6;
    this.controls.minDistance = 16;
    this.controls.maxDistance = 340;
    this.controls.maxPolarAngle = Math.PI * 0.68;
    this.controls.minPolarAngle = 0.08;
    this.controls.target.set(-2, 18, -2);
    this.controls.autoRotateSpeed = 0.32;
    this.controls.screenSpacePanning = false;
    this.controls.update();
  }

  get isTweening(): boolean {
    return this.tween !== null;
  }

  flyTo(position: THREE.Vector3 | [number, number, number], target: THREE.Vector3 | [number, number, number], duration = 1.8, onDone?: () => void): void {
    const toPos = Array.isArray(position) ? new THREE.Vector3(...position) : position.clone();
    const toTarget = Array.isArray(target) ? new THREE.Vector3(...target) : target.clone();
    this.tween = {
      fromPos: this.camera.position.clone(),
      toPos,
      fromTarget: this.controls.target.clone(),
      toTarget,
      t: 0,
      duration: Math.max(0.1, duration),
      onDone,
    };
    this.controls.enabled = false;
  }

  /**
   * Portrait phones hand a third of the screen to the instrument dock, so
   * presets pull back far enough that the whole diorama still fits above it.
   */
  setFramingScale(scale: number): void {
    this.framingScale = Math.max(0.6, Math.min(2.2, scale));
  }

  private framed(position: [number, number, number], target: [number, number, number]): [THREE.Vector3, THREE.Vector3] {
    const t = new THREE.Vector3(...target);
    const p = new THREE.Vector3(...position).sub(t).multiplyScalar(this.framingScale).add(t);
    return [p, t];
  }

  applyPreset(id: string, duration = 1.8): void {
    const preset = CAMERA_PRESETS.find((p) => p.id === id) ?? CAMERA_PRESETS[0];
    const [pos, target] = this.framed(preset.position, preset.target);
    this.flyTo(pos, target, duration);
  }

  intro(onDone?: () => void): void {
    const vista = CAMERA_PRESETS[0];
    const [pos, target] = this.framed(vista.position, vista.target);
    this.camera.position.copy(pos).sub(target).multiplyScalar(1.75).add(target);
    this.controls.target.copy(target);
    this.flyTo(pos, target, 4.4, onDone);
  }

  cancelTween(): void {
    if (!this.tween) return;
    this.tween = null;
    this.controls.enabled = true;
  }

  /** Look at a world point from the current direction, keeping distance sane. */
  focus(point: THREE.Vector3, distance = 46, duration = 1.3): void {
    const dir = this.camera.position.clone().sub(this.controls.target).normalize();
    if (dir.y < 0.18) dir.y = 0.18;
    dir.normalize();
    const pos = point.clone().add(dir.multiplyScalar(distance));
    this.flyTo(pos, point, duration);
  }

  kick(amount: number): void {
    this.shake = Math.min(1.2, this.shake + amount);
  }

  setFov(fov: number): void {
    this.baseFov = fov;
    this.camera.fov = fov;
    this.camera.updateProjectionMatrix();
  }

  setAutoRotate(enabled: boolean, speed: number): void {
    this.controls.autoRotate = enabled;
    this.controls.autoRotateSpeed = speed;
  }

  update(dt: number, time: number): void {
    if (this.tween) {
      const tw = this.tween;
      tw.t += dt;
      const k = easeInOutCubic(clamp01(tw.t / tw.duration));
      this.camera.position.lerpVectors(tw.fromPos, tw.toPos, k);
      this.controls.target.lerpVectors(tw.fromTarget, tw.toTarget, k);
      this.camera.lookAt(this.controls.target);
      if (tw.t >= tw.duration) {
        this.tween = null;
        this.controls.enabled = true;
        tw.onDone?.();
      }
    } else {
      this.controls.update(dt);
    }

    if (this.shake > 0.0005) {
      const s = this.shake;
      const t = time * 26 + this.shakeSeed;
      this.camera.position.x += Math.sin(t) * s * 0.32;
      this.camera.position.y += Math.sin(t * 1.37 + 1.1) * s * 0.26;
      this.camera.position.z += Math.cos(t * 0.91) * s * 0.32;
      this.camera.fov = this.baseFov + s * 0.7;
      this.camera.updateProjectionMatrix();
      this.shake *= Math.exp(-dt * 4.2);
    } else if (this.camera.fov !== this.baseFov) {
      this.camera.fov = this.baseFov;
      this.camera.updateProjectionMatrix();
      this.shake = 0;
    }
  }

  resize(aspect: number): void {
    this.camera.aspect = aspect;
    this.applyBias();
    this.camera.updateProjectionMatrix();
  }

  /**
   * Shift the frustum so the diorama stays centred in the space that the
   * instrument rail and bottom dock leave free.
   */
  setViewBias(x: number, y: number, width: number, height: number): void {
    this.biasX = x;
    this.biasY = y;
    this.viewW = width;
    this.viewH = height;
    this.applyBias();
  }

  private applyBias(): void {
    if (Math.abs(this.biasX) < 0.5 && Math.abs(this.biasY) < 0.5) {
      this.camera.clearViewOffset();
    } else {
      this.camera.setViewOffset(this.viewW, this.viewH, this.biasX, this.biasY, this.viewW, this.viewH);
    }
    this.camera.updateProjectionMatrix();
  }

  dispose(): void {
    this.controls.dispose();
  }
}
