import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { QUALITY_PRESETS, type QualityLevel } from './Settings';

/**
 * Final grade: screen-space sun shafts, diorama tilt-shift, chromatic fringe,
 * vignette and film grain — all in one full-screen pass before tone mapping.
 */
const GradeShader = {
  name: 'DioramaGrade',
  uniforms: {
    tDiffuse: { value: null as THREE.Texture | null },
    uResolution: { value: new THREE.Vector2(1, 1) },
    uTime: { value: 0 },
    uSunPos: { value: new THREE.Vector2(0.5, 0.9) },
    uShafts: { value: 0.5 },
    uShaftTaps: { value: 18 },
    uTiltShift: { value: 0.4 },
    uFocusY: { value: 0.52 },
    uFocusWidth: { value: 0.22 },
    uVignette: { value: 0.42 },
    uGrain: { value: 0.35 },
    uAberration: { value: 0.55 },
    uSaturation: { value: 1.12 },
  },
  vertexShader: /* glsl */ `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: /* glsl */ `
    precision highp float;
    uniform sampler2D tDiffuse;
    uniform vec2 uResolution;
    uniform float uTime;
    uniform vec2 uSunPos;
    uniform float uShafts;
    uniform float uShaftTaps;
    uniform float uTiltShift;
    uniform float uFocusY;
    uniform float uFocusWidth;
    uniform float uVignette;
    uniform float uGrain;
    uniform float uAberration;
    uniform float uSaturation;
    varying vec2 vUv;

    float hash(vec2 p) {
      p = fract(p * vec2(443.897, 441.423));
      p += dot(p, p + 19.19);
      return fract((p.x + p.y) * p.x);
    }

    vec3 tap(vec2 uv) {
      return texture2D(tDiffuse, clamp(uv, vec2(0.0009), vec2(0.9991))).rgb;
    }

    void main() {
      vec2 uv = vUv;
      vec2 texel = 1.0 / uResolution;
      vec2 centered = uv - 0.5;
      float radius = length(centered);

      // --- chromatic fringe toward the frame edges ---
      float ca = uAberration * 0.0016 * radius * radius * 4.0;
      vec3 color;
      color.r = tap(uv + centered * ca).r;
      color.g = tap(uv).g;
      color.b = tap(uv - centered * ca).b;

      // --- miniature / tilt-shift blur band ---
      float band = smoothstep(uFocusWidth, uFocusWidth + 0.30, abs(uv.y - uFocusY));
      float blur = band * uTiltShift;
      if (blur > 0.002) {
        vec3 sum = color;
        float total = 1.0;
        for (int i = 1; i <= 5; i++) {
          float fi = float(i);
          float w = 1.0 - fi / 6.0;
          vec2 off = vec2(0.35, 1.0) * texel * fi * blur * 7.0;
          sum += tap(uv + off) * w;
          sum += tap(uv - off) * w;
          total += 2.0 * w;
        }
        color = sum / total;
      }

      // --- volumetric-ish sun shafts (radial gather of bright pixels) ---
      if (uShafts > 0.002) {
        vec2 dir = (uSunPos - uv) / max(uShaftTaps, 1.0);
        vec2 suv = uv;
        float decay = 1.0;
        vec3 shafts = vec3(0.0);
        float weightSum = 0.0;
        for (int i = 0; i < 26; i++) {
          if (float(i) >= uShaftTaps) break;
          suv += dir * 0.92;
          vec3 s = tap(suv);
          float bright = max(0.0, dot(s, vec3(0.299, 0.587, 0.114)) - 0.72);
          shafts += s * bright * decay;
          weightSum += decay;
          decay *= 0.93;
        }
        shafts /= max(weightSum, 0.001);
        float sunFalloff = smoothstep(1.25, 0.05, distance(uv, uSunPos));
        color += shafts * uShafts * 1.5 * sunFalloff;
      }

      // --- grade ---
      float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
      color = mix(vec3(luma), color, uSaturation);
      color *= 1.0 - uVignette * pow(radius * 1.32, 2.4);

      float g = hash(uv * uResolution + fract(uTime) * 137.0) - 0.5;
      color += g * uGrain * 0.045 * (0.35 + 0.65 * (1.0 - luma));

      gl_FragColor = vec4(max(color, vec3(0.0)), 1.0);
    }
  `,
};

export class PostFX {
  readonly composer: EffectComposer;
  readonly bloom: UnrealBloomPass;
  readonly grade: ShaderPass;
  readonly renderPass: RenderPass;
  private target: THREE.WebGLRenderTarget;
  private renderer: THREE.WebGLRenderer;
  private quality: QualityLevel;
  private width = 1;
  private height = 1;
  private pixelRatio = 1;

  constructor(renderer: THREE.WebGLRenderer, scene: THREE.Scene, camera: THREE.Camera, quality: QualityLevel) {
    this.renderer = renderer;
    this.quality = quality;
    const preset = QUALITY_PRESETS[quality];
    this.target = new THREE.WebGLRenderTarget(1, 1, {
      type: THREE.HalfFloatType,
      samples: preset.samples,
      colorSpace: THREE.LinearSRGBColorSpace,
    });
    this.composer = new EffectComposer(renderer, this.target);
    this.renderPass = new RenderPass(scene, camera);
    this.bloom = new UnrealBloomPass(new THREE.Vector2(512, 512), 0.62, 0.72, 0.82);
    this.grade = new ShaderPass(GradeShader);
    this.grade.uniforms.uShaftTaps.value = preset.shaftTaps;
    const output = new OutputPass();
    this.composer.addPass(this.renderPass);
    this.composer.addPass(this.bloom);
    this.composer.addPass(this.grade);
    this.composer.addPass(output);
  }

  setCamera(camera: THREE.Camera): void {
    this.renderPass.camera = camera;
  }

  setQuality(quality: QualityLevel): void {
    if (quality === this.quality) return;
    this.quality = quality;
    const preset = QUALITY_PRESETS[quality];
    this.target.samples = preset.samples;
    this.target.dispose();
    this.grade.uniforms.uShaftTaps.value = preset.shaftTaps;
    this.resize(this.width, this.height, this.pixelRatio);
  }

  resize(width: number, height: number, pixelRatio: number): void {
    this.width = width;
    this.height = height;
    this.pixelRatio = pixelRatio;
    this.composer.setPixelRatio(pixelRatio);
    this.composer.setSize(width, height);
    const preset = QUALITY_PRESETS[this.quality];
    this.bloom.setSize(Math.max(64, width * preset.bloomRes), Math.max(64, height * preset.bloomRes));
    this.grade.uniforms.uResolution.value.set(width * pixelRatio, height * pixelRatio);
  }

  render(dt: number): void {
    this.composer.render(dt);
  }

  get domElement(): HTMLCanvasElement {
    return this.renderer.domElement;
  }

  dispose(): void {
    this.composer.dispose();
    this.target.dispose();
    this.bloom.dispose();
  }
}
