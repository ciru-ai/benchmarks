# 桜の庭 · Sakura-no-Niwa

**An interactive voxel-art diorama: a five-tier pagoda in a cherry-blossom garden, floating in the sky.**

Built with **Vite + TypeScript + three.js**, one module per concern, ~330 000 voxels merged into
three draw calls, and a permanently visible instrument rail that repaints the island live.

```bash
npm install
npm run dev        # http://127.0.0.1:5288
npm run build      # type-check + production bundle
npm run preview    # serve the built bundle
npm run verify     # headless browser check (screenshots + console + WebGL stats)
```

---

## What is in the garden

| | |
|---|---|
| **塔 Pagoda** | 3 / 5 / 7 tiers, battered stone plinth, railed balconies, plaster + vermilion walls, glowing shoji, bracket complexes, concave flared tile roofs with gilded corner bells, nine-ring *sorin* finial |
| **島 Island** | Superellipse floating island, rolling hills, tapered rock roots with spirit crystals, mossy rim vines, five satellite islets |
| **池 Pond** | Carved koi pond with an island, animated wave + ripple shader, lily pads, lotus, iris margins, reeds, brocade carp |
| **橋 Bridge** | Vermilion *taiko-bashi* drum bridge with gilded *giboshu* newels and piles into the water |
| **鳥居 Torii** | Myōjin gate with inclined pillars, curved *kasagi*, *nuki* and gilded tablet |
| **枯山水 Dry garden** | Raked gravel with concentric rings around three stone islands, slate kerb, viewing deck, bamboo screens |
| **茶室 Tea house** | Thatched hip roof, shoji walls, *engawa* deck, hearth smoke, *tsukubai* basin and a tipping *shishi-odoshi* |
| **鐘楼 Belfry** | Swinging bronze *bonshō* — click it (or the pagoda) to ring |
| **稲荷社 Shrine** | Fox guardians, *shimenawa* with paper *shide*, offering box, mini torii, hovering fox-fire |
| **桜 Trees** | Somei-yoshino cherries, a weeping cherry on the pond island, momiji maples, layered niwaki pines, a moso bamboo grove |
| **空 Sky & life** | Painted sky dome with sun/moon/stars/cirrus, drifting voxel clouds, wheeling cranes, blossom fall, fireflies, waterfall + mist |

## Controls

* **Drag** orbit · **wheel** zoom · **right-drag** pan
* **Click** the pagoda or belfry to ring the bell, a lantern to flare it, the pond to ripple it
* **Space** freeze time · **R** reset view · **H** hide interface · **M** mute · **P** snapshot · **B** bell · **G** gust · **F** fullscreen · **1–9** viewpoints

The right-hand rail holds 40+ live instruments: season cards, hour / sun bearing / atmosphere /
exposure, seed + dice, pagoda tiers, tree / canopy / undergrowth density, blossom fall, wind, koi
count, water swell and clarity, lantern / cloud / crane / firefly toggles, bloom, sun shafts, glow,
voxel occlusion, voxel edges, miniature blur, vignette, grain, orbit, FOV, wireframe, grid, quality,
ambience volume, freeze — plus snapshot, share link, save / load recipe, randomize and reset.

URL state: `?seed=…&season=autumn&hour=19.2&quality=high&view=pond`

## Architecture

```
src/
  core/      Engine (single rAF loop) · CameraRig (damped orbit + tweens) · Lighting (sun/moon rig)
             Sky (shader dome + PMREM bake) · PostFX (bloom, shafts, tilt-shift, grain) · Settings store
  voxel/     Palette (256-slot seasonal lookup texture) · VoxelBuffer · Mesher (face culling + baked AO)
             VoxelMaterials (palette / AO / edge / sway / water shaders) · PropKit
  world/     Layout · Terrain · Plateau · Pagoda · RoofKit · Torii · Bridge · Lanterns · Paths
             ZenGarden · TeaHouse · BellTower · Shrine · Fences · Trees · Flora · WorldBuilder
  anim/      LifeSystem · Petals · Koi · Clouds · Fireflies · Waterfall · Smoke · Cranes · SpiritOrbs
             Bell · ShishiOdoshi
  audio/     Ambience — fully synthesised WebAudio: wind, stream, crickets, chimes, bonshō, clack, splash
  ui/        ControlPanel · TopBar · Views · Hud · Loading · Toasts · Interaction · dom helpers
  util/      rng (mulberry32) · noise (perlin/fBm/ridged) · math
```

### Rendering notes

* Voxels store a **palette id**, not a colour. A 256×1 float texture is sampled in the shader, so a
  whole season (spring → winter) repaints instantly without rebuilding a triangle.
* The mesher emits only faces touching air, bakes **per-vertex ambient occlusion** into an attribute
  (strength stays a live uniform), and carries face-local UVs for the mortar/edge shader.
* Three merged meshes (solid / emissive / water) + instanced props keep the scene at ~38 draw calls.
* Shadows are **static** (`shadowMap.autoUpdate = false`) and only re-rendered when the sun or the
  geometry changes; the environment map is PMREM-baked on light changes, never per frame.
* Pixel ratio is capped per quality tier; software rasterisers are detected and start on the lean
  preset. One `requestAnimationFrame` loop drives everything.
* Every animated system reuses geometry, materials and `Object3D` scratch objects; rebuilds dispose
  the old world and life system before installing the new one.

## Verification

`scripts/verify.mjs` drives headless Chrome (SwiftShader) and records console output, page errors,
WebGL context state, scene stats and screenshots into `shots/`. Companion scripts:
`scripts/interact.mjs` (orbit, zoom, dials, rebuild, pause, quality, resize, clicks) and
`scripts/views.mjs` (every camera preset).

```bash
node scripts/verify.mjs --tag my-check --wait 6000 \
  --url "http://127.0.0.1:5288/?view=vista" --script scripts/interact.mjs
node scripts/verify.mjs --tag mobile --mobile --wait 6000
```
